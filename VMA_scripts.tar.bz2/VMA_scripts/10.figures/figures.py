#!/usr/bin/env python3
"""Figures for the MEME x BEAST through-time analysis."""
import os, warnings
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import statsmodels.api as sm
warnings.filterwarnings("ignore")

OUT = os.environ.get("MBT_OUT", "./results")
FIG = os.path.join(OUT, "figures")
os.makedirs(FIG, exist_ok=True)
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False,
                     "figure.dpi": 140, "savefig.bbox": "tight"})
C_HA, C_NA = "#2c7fb8", "#d95f0e"
C_H1, C_H3 = "#1b9e77", "#7570b3"

PER = pd.read_csv(os.path.join(OUT, "per_dataset_trends.csv"), keep_default_na=False)
for c in ["norm_slope","norm_se","norm_p","raw_slope","raw_se","n_episodes"]:
    PER[c] = pd.to_numeric(PER[c], errors="coerce")
PER["fitted"] = PER["fitted"].astype(str).str.strip().eq("True")
BINS = pd.read_csv(os.path.join(OUT, "time_bins_all.csv"), keep_default_na=False)
for c in ["bin_mid","count","exposure"]:
    BINS[c] = pd.to_numeric(BINS[c], errors="coerce")
BINS["reliable"] = BINS["reliable"].astype(str).str.strip().eq("True")
META = pd.read_csv(os.path.join(OUT, "meta_analysis.csv"), keep_default_na=False)
for _c in META.columns:
    if _c != "group": META[_c] = pd.to_numeric(META[_c], errors="coerce")

# ---------- Fig 1: forest plot of per-dataset normalized slopes ----------
def fig_forest():
    f = PER[PER.fitted].copy().sort_values(["gene","subtype","norm_slope"])
    f = f.reset_index(drop=True)
    fig, ax = plt.subplots(figsize=(7.2, 9))
    y = np.arange(len(f))[::-1]
    for yi, (_, r) in zip(y, f.iterrows()):
        col = C_HA if r.gene == "HA" else C_NA
        lo, hi = r.norm_slope - 1.96*r.norm_se, r.norm_slope + 1.96*r.norm_se
        ax.plot([lo, hi], [yi, yi], color=col, lw=1.6, alpha=0.85)
        ax.plot(r.norm_slope, yi, "o", color=col, ms=5,
                mec="k" if r.norm_p < 0.05 else col, mew=1.0 if r.norm_p<0.05 else 0)
    ax.set_yticks(y)
    ax.set_yticklabels([f"{r.dataset.replace('_',' ')} (n={int(r.n_episodes)})" for _, r in f.iterrows()],
                       fontsize=7.5)
    ax.axvline(0, color="grey", lw=1, ls="--")
    # meta diamonds for ALL / HA / NA
    base = -2
    for i,(g,col,yy) in enumerate([("ALL","k",base),("HA",C_HA,base-1.4),("NA",C_NA,base-2.8)]):
        m = META[META.group==g]
        if len(m):
            m=m.iloc[0]; b=m.b_re; se=m.se_re
            ax.plot([b-1.96*se,b,b+1.96*se,b,b-1.96*se],[yy,yy+0.35,yy,yy-0.35,yy],
                    color=col,lw=1.5)
            ax.fill([b-1.96*se,b,b+1.96*se,b],[yy,yy+0.35,yy,yy-0.35],color=col,alpha=0.5)
            ax.text(ax.get_xlim()[1], yy, f"  {g} meta", va="center", fontsize=8, color=col)
    ax.set_ylim(base-3.6, len(f)-0.3)
    ax.set_xlabel("Temporal slope of episode rate  (Δ log episodes·lineage-year$^{-1}$ per calendar year)")
    ax.set_title("Per-dataset trend in episodic positive selection through time\n"
                 "(MEME episodes dated on BEAST MAP trees; normalized by branch-length)", fontsize=10)
    import matplotlib.lines as ml
    ax.legend(handles=[ml.Line2D([],[],color=C_HA,marker="o",ls="-",label="HA"),
                       ml.Line2D([],[],color=C_NA,marker="o",ls="-",label="NA"),
                       ml.Line2D([],[],color="k",marker="o",ls="",label="p<0.05 (black edge)")],
              loc="lower right", fontsize=8, frameon=False)
    fig.savefig(os.path.join(FIG,"fig1_forest_slopes.png")); plt.close(fig)

# ---------- Fig 2: pooled rate vs time, by gene and by subtype ----------
def pooled_rate(df, key, val, w=3.0):
    d = df[(df.reliable) & (df[key]==val)]
    g = d.groupby("bin_mid").agg(count=("count","sum"), expo=("exposure","sum")).reset_index()
    g = g[g.expo>0]
    g["rate"] = g["count"]/g["expo"]
    return g

def fitline(g):
    yr = g.bin_mid.values - g.bin_mid.mean()
    m = sm.GLM(g["count"].values, sm.add_constant(yr),
               family=sm.families.Poisson(), offset=np.log(g["expo"].values)).fit()
    xs = np.linspace(g.bin_mid.min(), g.bin_mid.max(), 100)
    pred = np.exp(m.params[0] + m.params[1]*(xs-g.bin_mid.mean()))
    return xs, pred

def fig_pooled():
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.4))
    for ax, key, vals, cols, title in [
        (axes[0],"gene",["HA","NA"],[C_HA,C_NA],"By gene"),
        (axes[1],"subtype",["H1N1","H3N2"],[C_H1,C_H3],"By subtype")]:
        for val,col in zip(vals,cols):
            g = pooled_rate(BINS,key,val)
            ax.scatter(g.bin_mid, g.rate*100, s=18, color=col, alpha=0.6, label=val)
            xs,pred = fitline(g)
            ax.plot(xs, pred*100, color=col, lw=2)
        ax.set_xlabel("Calendar year (episode branch-midpoint)")
        ax.set_ylabel("Episodes per 100 lineage-years")
        ax.set_title(title); ax.legend(frameon=False)
    fig.suptitle("Pooled rate of episodic positive selection through time (branch-length normalized)", y=1.02)
    fig.savefig(os.path.join(FIG,"fig2_pooled_rate.png")); plt.close(fig)

# ---------- Fig 3: raw vs normalized + exposure (the confound) ----------
def fig_confound():
    d = BINS[BINS.reliable]
    g = d.groupby("bin_mid").agg(count=("count","sum"), expo=("exposure","sum")).reset_index()
    g = g[g.expo>0]
    fig, ax = plt.subplots(1,3, figsize=(13,3.9))
    ax[0].bar(g.bin_mid, g["count"], width=2.6, color="#888"); ax[0].set_title("Raw episode counts")
    ax[0].set_ylabel("episodes per 3-yr bin")
    ax[1].plot(g.bin_mid, g["expo"], color="#2b8cbe", lw=2); ax[1].set_title("Available branch-length (exposure)")
    ax[1].set_ylabel("lineage-years per bin")
    ax[2].scatter(g.bin_mid, g["count"]/g["expo"]*100, s=18, color="#cb181d")
    xs,pred=fitline(g); ax[2].plot(xs,pred*100,color="#cb181d",lw=2)
    ax[2].set_title("Normalized rate (counts / exposure)"); ax[2].set_ylabel("episodes / 100 lineage-yr")
    for a in ax: a.set_xlabel("Calendar year")
    fig.suptitle("Why normalization matters: raw counts track the growth in lineages; "
                 "the normalized rate still rises", y=1.04)
    fig.savefig(os.path.join(FIG,"fig3_raw_vs_normalized.png")); plt.close(fig)

# ---------- Fig 4: small multiples per fitted dataset ----------
def fig_small_multiples():
    f = PER[PER.fitted].sort_values(["subtype","gene","dataset"])
    n = len(f); ncol=4; nrow=int(np.ceil(n/ncol))
    fig, axes = plt.subplots(nrow, ncol, figsize=(13, 2.6*nrow))
    axes = axes.flatten()
    for ax,(_,r) in zip(axes, f.iterrows()):
        g = BINS[BINS.dataset==r.dataset]; g=g[g.exposure>0]
        col = C_HA if r.gene=="HA" else C_NA
        ax.scatter(g.bin_mid, g["count"]/g["exposure"]*100, s=12, color=col, alpha=0.6)
        try:
            xs,pred=fitline(g.rename(columns={"exposure":"expo"})); ax.plot(xs,pred*100,color=col,lw=1.6)
        except Exception: pass
        ax.set_title(f"{r.dataset.replace('_',' ')}\nslope p={r.norm_p:.3g}", fontsize=7.5)
        ax.tick_params(labelsize=7)
    for ax in axes[n:]: ax.axis("off")
    fig.suptitle("Episode rate through time, per dataset (episodes per 100 lineage-years)", y=1.005)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG,"fig4_small_multiples.png")); plt.close(fig)

if __name__ == "__main__":
    fig_forest(); fig_pooled(); fig_confound(); fig_small_multiples()
    print("figures written to", FIG)
    print(os.listdir(FIG))
