#!/usr/bin/env Rscript

# Rscript make_hyphy_nexus.R \
#   -f fasta_nostop_noambiguous \
#   -t rerooted_trees \
#   -o hyphy_nexus


suppressPackageStartupMessages({
  library(Biostrings)
  library(ape)
})

parse_args <- function(args) {
  opts <- list(
    fasta_dir = "fasta_nostop_noambiguous",
    tree_dir = "rerooted_trees",
    output_dir = "hyphy_nexus",
    overwrite = FALSE,
    recursive = FALSE
  )

  i <- 1
  while (i <= length(args)) {
    a <- args[i]

    if (a %in% c("-f", "--fasta-dir")) {
      i <- i + 1
      opts$fasta_dir <- args[i]
    } else if (a %in% c("-t", "--tree-dir")) {
      i <- i + 1
      opts$tree_dir <- args[i]
    } else if (a %in% c("-o", "--output-dir")) {
      i <- i + 1
      opts$output_dir <- args[i]
    } else if (a == "--overwrite") {
      opts$overwrite <- TRUE
    } else if (a == "--recursive") {
      opts$recursive <- TRUE
    }

    i <- i + 1
  }

  opts
}

sanitize_taxon_names <- function(x) {
  x <- gsub("'", "", x, fixed = TRUE)
  x <- gsub("\\s+", "_", x)
  x <- gsub(",", "_", x)
  x <- gsub(";", "_", x)
  x <- gsub("\\(", "_", x)
  x <- gsub("\\)", "_", x)
  x
}

read_fasta_as_strings <- function(path) {
  x <- readDNAStringSet(path)
  list(
    names = names(x),
    seqs = as.character(x),
    widths = width(x)
  )
}

tree_to_newick <- function(path) {
  tr <- read.tree(path)
  nwk <- write.tree(tr)
  nwk <- sub(";$", "", nwk)
  nwk
}

write_nexus <- function(fasta_file, tree_file, out_file) {
  dat <- read_fasta_as_strings(fasta_file)
  nwk <- tree_to_newick(tree_file)

  ntax <- length(dat$seqs)
  nchar_vec <- unique(dat$widths)

  if (length(nchar_vec) != 1) {
    stop(sprintf("%s: sequences are not all the same length", basename(fasta_file)))
  }

  original_names <- dat$names
  safe_names <- sanitize_taxon_names(original_names)

  if (anyDuplicated(safe_names)) {
    stop(sprintf("%s: taxon names are duplicated after sanitization", basename(fasta_file)))
  }

  seq_lines <- paste0(safe_names, " ", dat$seqs)

  nexus_lines <- c(
    "#NEXUS",
    "",
    "Begin data;",
    sprintf("Dimensions ntax=%d nchar=%d;", ntax, nchar_vec[1]),
    "Format datatype=dna missing=? gap=-;",
    "Matrix",
    seq_lines,
    ";",
    "End;",
    "",
    "Begin trees;",
    paste0("Tree tree_1 = [&R] ", nwk, ";"),
    "End;"
  )

  writeLines(nexus_lines, con = out_file, useBytes = TRUE)
}

process_one <- function(fasta_file, tree_dir, output_dir, overwrite = FALSE) {
  fasta_file <- normalizePath(fasta_file, winslash = "/", mustWork = TRUE)
  base <- tools::file_path_sans_ext(basename(fasta_file))

  tree_file <- file.path(tree_dir, paste0(base, "_rooted.tree"))

  if (!file.exists(tree_file)) {
    stop(sprintf("%s: expected tree file not found: %s", basename(fasta_file), tree_file))
  }

  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  out_file <- file.path(output_dir, paste0(base, ".nexus"))

  if (file.exists(out_file) && !overwrite) {
    return(sprintf("[skipped] %s", basename(fasta_file)))
  }

  write_nexus(fasta_file, tree_file, out_file)

  sprintf(
    "[ok] %s + %s -> %s",
    basename(fasta_file),
    basename(tree_file),
    out_file
  )
}

main <- function() {
  args <- commandArgs(trailingOnly = TRUE)
  opts <- parse_args(args)

  if (!dir.exists(opts$fasta_dir)) {
    stop(sprintf("FASTA directory does not exist: %s", opts$fasta_dir))
  }

  if (!dir.exists(opts$tree_dir)) {
    stop(sprintf("Tree directory does not exist: %s", opts$tree_dir))
  }

  patterns <- c("\\.fa$", "\\.fasta$", "\\.fas$", "\\.fna$")
  fasta_files <- character()

  for (pat in patterns) {
    fasta_files <- c(
      fasta_files,
      list.files(
        opts$fasta_dir,
        pattern = pat,
        full.names = TRUE,
        recursive = opts$recursive
      )
    )
  }

  fasta_files <- sort(unique(fasta_files))

  if (length(fasta_files) == 0) {
    cat("No FASTA files found.\n")
    quit(status = 0)
  }

  results <- lapply(
    fasta_files,
    function(f) {
      tryCatch(
        process_one(
          fasta_file = f,
          tree_dir = opts$tree_dir,
          output_dir = opts$output_dir,
          overwrite = opts$overwrite
        ),
        error = function(e) sprintf("[error] %s: %s", basename(f), conditionMessage(e))
      )
    }
  )

  cat(paste(unlist(results), collapse = "\n"), "\n")
}

main()
