#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(Biostrings)
  library(parallel)
})

parse_args <- function(args) {
  opts <- list(
    input_dir = "fasta_nostop",
    output_dir = "fasta_nostop_noambiguous",
    jobs = detectCores(),
    recursive = FALSE,
    overwrite = FALSE
  )

  i <- 1
  while (i <= length(args)) {
    a <- args[i]
    if (a %in% c("-o", "--output-dir")) {
      i <- i + 1
      opts$output_dir <- args[i]
    } else if (a %in% c("-j", "--jobs")) {
      i <- i + 1
      opts$jobs <- as.integer(args[i])
    } else if (a == "--recursive") {
      opts$recursive <- TRUE
    } else if (a == "--overwrite") {
      opts$overwrite <- TRUE
    } else {
      opts$input_dir <- a
    }
    i <- i + 1
  }
  opts
}

dna_to_matrix <- function(dna_set) {
  seqs <- as.character(dna_set)
  if (length(seqs) == 0) {
    return(matrix(character(0), nrow = 0, ncol = 0))
  }

  widths <- nchar(seqs)
  if (length(unique(widths)) != 1) {
    stop("Sequences are not all the same length; input must be an alignment")
  }

  m <- do.call(
    rbind,
    lapply(seqs, function(s) strsplit(s, "", fixed = TRUE)[[1]])
  )

  rownames(m) <- names(dna_set)
  m
}

resolve_ambiguous <- function(dna_set) {
  m <- dna_to_matrix(dna_set)
  if (nrow(m) == 0 || ncol(m) == 0) return(dna_set)

  unambiguous <- c("A", "C", "G", "T")
  keep_ok <- c(unambiguous, "-")

  for (j in seq_len(ncol(m))) {
    col <- toupper(m[, j])

    ambiguous_idx <- which(!(col %in% keep_ok))
    if (length(ambiguous_idx) == 0) next

    counts <- table(factor(col[col %in% unambiguous], levels = unambiguous))

    if (sum(counts) == 0) {
      replacement <- "N"
    } else {
      replacement <- names(counts)[which.max(counts)]
    }

    m[ambiguous_idx, j] <- replacement
  }

  seqs2 <- apply(m, 1, paste0, collapse = "")
  x2 <- DNAStringSet(seqs2)
  names(x2) <- rownames(m)
  x2
}

process_one <- function(fasta_file, output_dir, overwrite = FALSE) {
  out_file <- file.path(output_dir, basename(fasta_file))

  if (file.exists(out_file) && !overwrite) {
    return(sprintf("[skipped] %s", basename(fasta_file)))
  }

  x <- readDNAStringSet(fasta_file)
  x2 <- resolve_ambiguous(x)
  writeXStringSet(x2, out_file, format = "fasta")

  sprintf("[ok] %s -> %s", basename(fasta_file), out_file)
}

main <- function() {
  args <- commandArgs(trailingOnly = TRUE)
  opts <- parse_args(args)

  if (!dir.exists(opts$input_dir)) {
    stop(sprintf("Input directory does not exist: %s", opts$input_dir))
  }

  dir.create(opts$output_dir, recursive = TRUE, showWarnings = FALSE)

  patterns <- c("\\.fa$", "\\.fasta$", "\\.fas$", "\\.fna$")
  files <- character()
  for (pat in patterns) {
    files <- c(
      files,
      list.files(opts$input_dir, pattern = pat, full.names = TRUE, recursive = opts$recursive)
    )
  }
  files <- sort(unique(files))

  if (length(files) == 0) {
    cat("No FASTA files found.\n")
    quit(status = 0)
  }

  jobs <- max(1, min(opts$jobs, length(files)))

  results <- mclapply(
    files,
    function(f) {
      tryCatch(
        process_one(f, opts$output_dir, overwrite = opts$overwrite),
        error = function(e) sprintf("[error] %s: %s", basename(f), conditionMessage(e))
      )
    },
    mc.cores = jobs
  )

  cat(paste(unlist(results), collapse = "\n"), "\n")
}

main()
