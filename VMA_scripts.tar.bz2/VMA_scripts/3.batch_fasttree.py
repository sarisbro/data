#!/usr/bin/env python3

# python batch_fasttree.py /path/to/fasta_folder -j 8
# python batch_fasttree.py /path/to/fasta_folder --model nt
# python batch_fasttree.py /path/to/fasta_folder --model gtr
# python batch_fasttree.py /path/to/fasta_folder --model gtrgamma
# python batch_fasttree.py /path/to/fasta_folder --recursive
# python batch_fasttree.py /path/to/fasta_folder --fasttree-bin /usr/local/bin/FastTree


import argparse
import shutil
import subprocess
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed


def run_fasttree_one(fasta_path, out_dir, fasttree_bin="FastTree", model="gtrgamma", overwrite=False):
    fasta_path = Path(fasta_path)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    tree_path = out_dir / f"{fasta_path.stem}.tree"
    log_path = out_dir / f"{fasta_path.stem}.fasttree.log"

    if tree_path.exists() and not overwrite:
        return (fasta_path.name, "skipped", f"{tree_path} already exists")

    if model == "nt":
        cmd = [fasttree_bin, "-nt", str(fasta_path)]
    elif model == "gtr":
        cmd = [fasttree_bin, "-nt", "-gtr", str(fasta_path)]
    elif model == "gtrgamma":
        cmd = [fasttree_bin, "-nt", "-gtr", "-gamma", str(fasta_path)]
    else:
        raise ValueError(f"Unknown model: {model}")

    with open(tree_path, "w") as tree_out, open(log_path, "w") as log_out:
        result = subprocess.run(cmd, stdout=tree_out, stderr=log_out, text=True)

    if result.returncode != 0:
        raise RuntimeError(f"FastTree failed for {fasta_path.name}; see {log_path}")

    return (fasta_path.name, "ok", f"{tree_path}")


def main():
    parser = argparse.ArgumentParser(
        description="Run FastTree on all FASTA files in a folder using multiple CPU cores."
    )
    parser.add_argument("input_dir", help="Folder containing FASTA files")
    parser.add_argument(
        "-o", "--output-dir",
        default=None,
        help="Output folder for tree files (default: input_dir/trees)"
    )
    parser.add_argument(
        "-j", "--jobs",
        type=int,
        default=None,
        help="Number of parallel worker processes (default: all available cores)"
    )
    parser.add_argument(
        "--fasttree-bin",
        default="FastTree",
        help="Path to FastTree executable (default: FastTree)"
    )
    parser.add_argument(
        "--model",
        choices=["nt", "gtr", "gtrgamma"],
        default="gtrgamma",
        help="FastTree nucleotide model options"
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Overwrite existing tree files"
    )
    parser.add_argument(
        "--recursive",
        action="store_true",
        help="Search recursively for FASTA files"
    )
    args = parser.parse_args()

    if shutil.which(args.fasttree_bin) is None and not Path(args.fasttree_bin).exists():
        raise SystemExit(f"FastTree executable not found: {args.fasttree_bin}")

    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir) if args.output_dir else input_dir / "trees"

    patterns = ("*.fa", "*.fasta", "*.fas", "*.fna")
    fasta_files = []

    if args.recursive:
        for pattern in patterns:
            fasta_files.extend(input_dir.rglob(pattern))
    else:
        for pattern in patterns:
            fasta_files.extend(input_dir.glob(pattern))

    fasta_files = sorted(set(fasta_files))

    if not fasta_files:
        print("No FASTA files found.")
        return

    print(f"Found {len(fasta_files)} FASTA files.")
    print(f"Writing trees to: {output_dir}")
    print(f"Model: {args.model}")

    with ProcessPoolExecutor(max_workers=args.jobs) as ex:
        futures = {
            ex.submit(
                run_fasttree_one,
                fasta,
                output_dir,
                args.fasttree_bin,
                args.model,
                args.overwrite
            ): fasta
            for fasta in fasta_files
        }

        for fut in as_completed(futures):
            fasta = futures[fut]
            try:
                name, status, msg = fut.result()
                print(f"[{status}] {name}: {msg}")
            except Exception as e:
                print(f"[error] {fasta.name}: {e}")


if __name__ == "__main__":
    main()
