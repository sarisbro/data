#!/bin/bash
#SBATCH --time=03:00:00
#SBATCH --account=def-sarisbr0
#SBATCH --cpus-per-task=1
#SBATCH --mem=32G
#SBATCH --array=1-66:2

module load StdEnv/2023
module load gcc/12.3  r/4.4.0

mkdir $SLURM_TMPDIR/batch1
mkdir $SLURM_TMPDIR/batch2

file_nb2=$(( ${SLURM_ARRAY_TASK_ID} + 1 ))
line1=$(sed -n ${SLURM_ARRAY_TASK_ID}p dir_list.txt)
line2=$(sed -n ${file_nb2}p dir_list.txt)

  
#check if only one log or multiple logs
#if multiple logs seprate files and run logcombiner
multiple_logs="../results/$line1/${line1}_all_runs.log"
multiple_logs2="../results/$line2/${line2}_all_runs.log"
multiple_trees="../results/$line1/${line1}_all_runs.trees"
multiple_trees2="../results/$line2/${line2}_all_runs.trees"

if [ -f $multiple_logs ]
then
  echo "$line1 has multiple runs"
  # split logs and trees into multipe files (one for each run)
  csplit -s -z -f $SLURM_TMPDIR/batch1/logs $multiple_logs "/# BEAST/"  '{*}'
  csplit -s -z -f $SLURM_TMPDIR/batch1/trees $multiple_trees /#NEXUS/ '{*}'

    #compute burnin according to number of line in files

  ~/bin/BEASTv1.10.4/bin/logcombiner  $(ls $SLURM_TMPDIR/batch1/logs* ) $SLURM_TMPDIR/batch1/temp1.log
  ~/bin/BEASTv1.10.4/bin/logcombiner -trees  $(ls $SLURM_TMPDIR/batch1/trees* ) $SLURM_TMPDIR/batch1/temp1.trees

  nb_steps=$(tail -1 $SLURM_TMPDIR/batch1/temp1.log | awk '{print $1;}')
  burnin=$(( $nb_steps / 2 ))
  trees_burnin=$(( $burnin / 5000 ))


  ~/bin/BEASTv1.10.4/bin/logcombiner -burnin $burnin $SLURM_TMPDIR/batch1/temp1.log $SLURM_TMPDIR/batch1/batch1.log
  ~/bin/BEASTv1.10.4/bin/logcombiner -trees -burnin $trees_burnin $SLURM_TMPDIR/batch1/temp1.trees $SLURM_TMPDIR/batch1/batch1.trees 

else
    # compute burnin
  echo "$line1 has one  run"

  nb_steps=$(tail -1 "../results/$line1/${line1}.log" | awk '{print $1;}')
  burnin=$(( $nb_steps / 2 ))
  trees_burnin=$(( $burnin / 5000 ))
  ~/bin/BEASTv1.10.4/bin/logcombiner -burnin $burnin "../results/$line1/${line1}.log"  $SLURM_TMPDIR/batch1/batch1.log
  ~/bin/BEASTv1.10.4/bin/logcombiner -trees -burnin $trees_burnin "../results/$line1/${line1}.trees"  $SLURM_TMPDIR/batch1/batch1.trees

fi

if [ -f $multiple_logs2 ]
then
  echo "$line2 has multiple runs"
  # split logs and trees into multipe files (one for each run)
  csplit -s -z -f $SLURM_TMPDIR/batch2/logs $multiple_logs2 "/# BEAST/"  '{*}'
  csplit -s -z -f $SLURM_TMPDIR/batch2/trees $multiple_trees2 /#NEXUS/  '{*}'

  #compute burnin according to number of line in file
  ~/bin/BEASTv1.10.4/bin/logcombiner  $(ls $SLURM_TMPDIR/batch2/logs* ) $SLURM_TMPDIR/batch2/temp2.log
  ~/bin/BEASTv1.10.4/bin/logcombiner -trees  $(ls $SLURM_TMPDIR/batch2/trees* ) $SLURM_TMPDIR/batch2/temp2.trees

  nb_steps=$(tail -1 $SLURM_TMPDIR/batch2/temp2.log | awk '{print $1;}')
  burnin=$(( $nb_steps / 2 ))
  trees_burnin=$(( $burnin / 5000 ))

  ~/bin/BEASTv1.10.4/bin/logcombiner -burnin $burnin $SLURM_TMPDIR/batch2/temp2.log $SLURM_TMPDIR/batch2/batch2.log
  ~/bin/BEASTv1.10.4/bin/logcombiner -trees -burnin $trees_burnin $SLURM_TMPDIR/batch2/temp2.trees $SLURM_TMPDIR/batch2/batch2.trees

else
   # compute burnin
  echo "$line2 has one run"

  nb_steps=$(tail -1 "../results/$line1/${line1}.log" | awk '{print $1;}')
  burnin=$(( $nb_steps / 2 ))
  trees_burnin=$(( $burnin / 5000 ))

  ~/bin/BEASTv1.10.4/bin/logcombiner -burnin $burnin "../results/$line2/${line1}.log"  $SLURM_TMPDIR/batch2/batch2.log
  ~/bin/BEASTv1.10.4/bin/logcombiner -trees -burnin $trees_burnin "../results/$line2/${line1}.log"  $SLURM_TMPDIR/batch2/batch2.trees

fi

~/bin/BEASTv1.10.4/bin/logcombiner $SLURM_TMPDIR/batch1/batch1.log $SLURM_TMPDIR/batch2/batch2.log ${line1}_combined.log
~/bin/BEASTv1.10.4/bin/logcombiner -trees $SLURM_TMPDIR/batch1/batch1.trees $SLURM_TMPDIR/batch2/batch2.trees ${line1}_combined.trees

~/bin/BEASTv1.10.4/bin/treeannotator_big ${line1}_combined.trees ${line1}_map.trees

rm $SLURM_TMPDIR/batch1/*
rm $SLURM_TMPDIR/batch2/*



