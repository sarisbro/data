#!/bin/bash
#SBATCH --time=03:00:00
#SBATCH --account=def-sarisbr0
#SBATCH --cpus-per-task=1
#SBATCH --mem=32G


module load StdEnv/2023
module load gcc/12.3  r/4.4.0
working_dir='/home/mvila035/scratch/rasha_project99_rand/beast_files/convergence/'

cat dir_list.txt | while read line1; read  line2; do
  
  #check if only one log or multiple logs
  #if multiple logs seprate files and run logcombiner
  multiple_runs=/home/mvila035/scratch/rasha_project99_rand/beast_files/results/$line1/${line1}_all_runs.log
  multiple_runs2=/home/mvila035/scratch/rasha_project99_rand/beast_files/results/$line2/${line2}_all_runs.log

  if [ -f $multiple_runs ]
  then
    last_log=/home/mvila035/scratch/rasha_project99_rand/beast_files/results/$line1/$line1.log
    python separate_runs.py $SLURM_TMPDIR $multiple_runs $last_log
    ~/bin/BEASTv1.10.4/bin/logcombiner `< ${SLURM_TMPDIR}/${line1}_command.txt` 
    path1=/home/mvila035/scratch/rasha_project99_rand/beast_files/convergence/${line1}_combined_runs.log
  
  else
    cp /home/mvila035/scratch/rasha_project99_rand/beast_files/results/$line1/$line1.log ${line1}_combined_runs.log
    path1=${line1}_combined_runs.log
  fi
  
  if [ -f $multiple_runs2 ]
  then

    last_log2=/home/mvila035/scratch/rasha_project99_rand/beast_files/results/$line2/$line1.log
    python separate_runs.py $SLURM_TMPDIR $multiple_runs2 $last_log2
    ~/bin/BEASTv1.10.4/bin/logcombiner `< ${SLURM_TMPDIR}/${line2}_command.txt` 
    path2=/home/mvila035/scratch/rasha_project99_rand/beast_files/convergence/${line2}_combined_runs.log
  
  else 
    cp /home/mvila035/scratch/rasha_project99_rand/beast_files/results/$line2/$line1.log ${line2}_combined_runs.log
    path2=${line2}_combined_runs.log
  
  fi
  
  Rscript converging_graph.R $path1 $path2 $working_dir

done
