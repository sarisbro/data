library(ggplot2)
library(ggpubr)

args = commandArgs(trailingOnly=TRUE)

setwd(args[3])


name <- strsplit(args[1], "/")

name <- tail(name[[1]],1)

name <- strsplit(name, "\\.")

name <- head(name[[1]],1)

name <- paste0(name,"_convergence",".pdf")



table1 <- read.csv(args[1] ,sep= "", comment.char = "#")

table2 <- read.csv(args[2] ,sep= "", comment.char = "#")

#burnin 50%
nb_row_keep1 <- as.integer(nrow(table1) * 0.50)
nb_row_keep2 <- as.integer(nrow(table2) * 0.50)

table1 <- tail(table1, n= nb_row_keep1)
table2 <- tail(table2, n= nb_row_keep2)



trace_plot <- ggplot() + 
  geom_line(data=table1, aes(x=state, y=joint), color='green') + 
  geom_line(data=table2, aes(x=state, y=joint), color='red')


density_plot <- ggplot()+
  geom_density(data=table1, aes(x=joint), color='green', fill= 'green', alpha=0.5) +
  geom_density(data=table2, aes(x=joint), color='red', fill= 'red', alpha=0.5)

ggarrange(trace_plot, density_plot, ncol=1, nrow=2)

ggsave(name)

