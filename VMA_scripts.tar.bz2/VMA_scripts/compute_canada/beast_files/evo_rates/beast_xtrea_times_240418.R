library(ape)
library(lubridate)
library(ggplot2)

# from: https://github.com/YuLab-SMU/treeio
# run L.7 only once
# devtools::install_github("YuLab-SMU/treeio")
library(treeio)
library(tidytree)


################
# read in data #
################
args = commandArgs(trailingOnly=TRUE)

setwd(args[2])

tr <- treeio::read.beast(args[1]) 					# tr <- treeio::read.beast("H1N1_NA_china_map.trees")
trdf <- data.frame(get_tree_data(tr))

map_rates <- trdf$rate
map_height <- trdf$height
map_node <- trdf$node
map_rates_heights <- data.frame(node = map_node, rates = map_rates, heights = map_height)

head(map_rates_heights)
#   node       rates  heights
# 1   96 0.002919292 65.86027
# 2  120 0.001546007 26.69315
# 3   41 0.002350982 28.69315
# 4   91 0.002397274 26.11233
# 5  121 0.006048909 26.69315
# 6   88 0.001057863 24.11233

# get dates
seq_names <- tr@phylo$tip.label
# tmp <- strsplit(seq_names, "_HA_")
tmp <- strsplit(seq_names, "\\\\")

parent_node <- c()
for (i in 1:length(map_node)) {
  
  temp_node <- parent(tr,map_node[i])
  parent_node <- c(parent_node, as.numeric(temp_node))
}

parent_height <- c()
for (i in 1:length(parent_node)) {
  
  temp_height <- trdf[trdf$node == parent_node[i], "height"]
  if (parent_node[i] == 0) {
    temp_height <- NA
  }
  parent_height <- c(parent_height, as.numeric(temp_height))
}

#get list of date to find max date
date_lst <- c()
for(j in 1:length(tmp)){
	
	tmp_date <- tail(tmp[[j]],n=1)
	tmp_date <- strptime(tmp_date, "%Y_%m_%d")
	tmp_date <- decimal_date(tmp_date)
	date_lst <- c(date_lst, as.numeric(tmp_date))
}

max_date <- max(date_lst)
# map_dates <- round(max_date - map_height)
map_dates <- max_date - map_height
map_parent_dates <- max_date - parent_height

df <- data.frame(map_rates, map_dates, map_parent_dates)

file_path <- strsplit(args[1], "/")
file_name <- tail(file_path[[1]], 1)

split_name <- strsplit(file_name,"_")
  
new_name <- paste0(split_name[[1]][1],"_",split_name[[1]][2],
                   "_",split_name[[1]][3],"_rates.csv")

write.csv(df,new_name)

