#!/bin/bash
#SBATCH --time=01:00:00
#SBATCH --account=def-sarisbr0
#SBATCH --cpus-per-task=1
#SBATCH --mem=8G


module load StdEnv/2020
module load gcc/9.3.0  r/4.3.1
working_dir=$(pwd)

cat files_list.txt | while read line; do

 file=../combined_files/${line}
 Rscript beast_xtrea_times_240418.R $file $working_dir

done
