#!/bin/bash
#SBATCH --time=02:00:00
#SBATCH --account=def-sarisbr0
#SBATCH --cpus-per-task=1
#SBATCH --mem=8G

module load python/3.11.2

virtualenv $SLURM_TMPDIR/env
source $SLURM_TMPDIR/env/bin/activate
pip install --upgrade pip

pip install -r requirements.txt

python merge_by_country.py /home/mvila035/scratch/rasha_project99_rand/sequences_by_years/rand/H1N1_HA_rand/ /home/mvila035/scratch/rasha_project99_rand/sequences_by_years/seq_by_countries/H1N1_HA/

python merge_by_country.py /home/mvila035/scratch/rasha_project99_rand/sequences_by_years/rand/H1N1_NA_rand/ /home/mvila035/scratch/rasha_project99_rand/sequences_by_years/seq_by_countries/H1N1_NA/

python merge_by_country.py /home/mvila035/scratch/rasha_project99_rand/sequences_by_years/rand/H3N2_HA_rand/ /home/mvila035/scratch/rasha_project99_rand/sequences_by_years/seq_by_countries/H3N2_HA/

python merge_by_country.py /home/mvila035/scratch/rasha_project99_rand/sequences_by_years/rand/H3N2_NA_rand/ /home/mvila035/scratch/rasha_project99_rand/sequences_by_years/seq_by_countries/H3N2_NA/

