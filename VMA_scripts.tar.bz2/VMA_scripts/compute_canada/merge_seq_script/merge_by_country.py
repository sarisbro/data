#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 11 09:56:21 2024

@author: matthieuvilain

! Merge fasta files according to countries for alignement !

"""

from Bio import SeqIO
from os import listdir
import sys



def write_file(read, write):
    
    with open(write, 'a') as write_file:
        
        for seq in SeqIO.parse(read, "fasta"):
            
            write_file.write(">"+seq.id+"\n")
            write_file.write(str(seq.seq)+"\n")



PATH_TO_READ= sys.argv[1]
PATH_TO_WRITE= sys.argv[2]

files= listdir(PATH_TO_READ)

dict_countries= dict()

for file in files:
    
    if file[-5:] == "fasta":
        
        country= file.split("_")[2]
        
        if country in dict_countries:
            
            file_to_write= dict_countries[country]
            
            write_file(PATH_TO_READ+file, PATH_TO_WRITE+file_to_write)
        
        else:
            
            tags= file.split("_")
            
            file_to_write= f"{tags[0]}_{tags[1]}_{country}_rand.fasta"
            dict_countries[country]= f"{tags[0]}_{tags[1]}_{country}_rand.fasta"
            
            write_file(PATH_TO_READ+file, PATH_TO_WRITE+file_to_write)
