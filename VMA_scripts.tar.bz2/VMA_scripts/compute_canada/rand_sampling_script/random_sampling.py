import glob
import pandas as pd 
import sys
import random
from Bio import SeqIO

seed= 357490

random.seed(seed)

cluster_counts= pd.read_csv("cluster_counts.csv")

for file_path in glob.glob(sys.argv[1]+"/H*/*.fasta"):
    file_name= file_path.split("/")[-1]
    file_name= file_name.split(".")[0]

    variant= file_name.split("_")[0]
    gene= file_name.split("_")[1]
    country= file_name.split("_")[2]
    year= file_name.split("_")[3]

    country_year= country+"_"+year
    variant_gene= variant+"_"+gene

    sequences= []
    with open(file_path, "r") as file:

        for seq in SeqIO.parse(file, "fasta"):
            sequences.append((seq.id,seq.seq))
    
    try:
        nb_seq_to_keep= cluster_counts.query("country_year == @country_year and variant_gene==@variant_gene")["cluster_count"].item()
    
    except:
        print("ERROR see log:\n\n")
        print( nb_seq_to_keep= cluster_counts.query("country_year == @country_year and variant_gene==@variant_gene"))
    
    
    sequences_to_keep= random.sample(sequences, nb_seq_to_keep)
    
    file_write= sys.argv[1]+f"rand/{variant_gene}_rand/{file_name}_rand.fasta"
    
    with open(file_write, "w") as file:
        
        for (header,seq) in sequences_to_keep:
            
            file.write(">"+header+"\n")
            file.write(str(seq)+"\n")
            
    

        

        

