import glob
import pandas as pd 
import sys

country_year= []
variant_gene= []
cluster_counts= []


for path_to_file in glob.glob(sys.argv[1]+"/*/*.clstr"): 
    file_name= path_to_file.split("/")[-1]

    variant= file_name.split("_")[0]
    gene= file_name.split("_")[1]
    country= file_name.split("_")[2]
    year= file_name.split("_")[3]
    
    cluster_count= 0
    with open(path_to_file, "r") as file:
        for line in file:
            if line[0]==">":
                cluster_count += 1
    
    country_year.append(country+"_"+year)
    variant_gene.append(variant+"_"+gene)
    cluster_counts.append(cluster_count)



df= pd.DataFrame({"country_year":country_year, "variant_gene":variant_gene, "cluster_count":cluster_counts})
df.to_csv("cluster_counts.csv")

    


