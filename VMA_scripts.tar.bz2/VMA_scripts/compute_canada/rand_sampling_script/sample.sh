#!/bin/bash
#SBATCH --time=20:10:00
#SBATCH --account=def-sarisbr0
#SBATCH --cpus-per-task=1
#SBATCH --mem=32G

module load  StdEnv/2020
module load python/3.11.2

virtualenv $SLURM_TMPDIR/env
source $SLURM_TMPDIR/env/bin/activate
pip install --upgrade pip

pip install -r requirements.txt


python get_seq_distribution.py /home/mvila035/projects/def-sarisbr0/mvila035/rasha_project/sequences_by_years/CD-HIT/
python random_sampling.py /home/mvila035/scratch/rasha_project99_rand/sequences_by_years/
