#!/bin/bash
# Here you should provide the sbatch arguments to be used in all jobs in this serial farm
# It has to contain the runtime switch (either -t or --time):
#SBATCH -t 0-20:00
#SBATCH --mem=32G
#  You have to replace Your_account_name below with the name of your account:
#SBATCH -A def-sarisbr0

module load  cd-hit/4.8.1

# Don't change this line:
task.run
