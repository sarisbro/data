#!/bin/bash
# The actual (serial) computation, for a single case No. $2 in the table $1.

TABLE1=$1
i1=$2

# Total number of cases:
## If the env. variable N_cases is defined, using it, otherwise computing the number of lines in the table:
if test -z $N_cases
  then
  N_cases=`cat "$TABLE1" | wc -l`
  fi

# Exiting if $i1 goes beyond $N_cases (can happen in bundled farms):
if test $i1 -lt 1 -o $i1 -gt $N_cases  
  then
  exit
  fi
  
# Extracing the $i1-th line from file $TABLE1:
LINE=`sed -n ${i1}p $TABLE1`
# Case id (from the original cases table):
ID=`echo "$LINE" | cut -d" " -f1`
# The rest of the line:
COMM=`echo "$LINE" | cut -d" " -f2-`

METAJOB_ID=${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}

# ++++++++++++++++++++++  This part can be customized:  ++++++++++++++++++++++++
#  Here:
#  $ID contains the case id from the original table (can be used to provide a unique seed to the code etc)
#  $COMM is the line corresponding to the case $ID in the original table, without the ID field
#  $METAJOB_ID is the jobid for the current meta-job (convenient for creating per-job files)

name=${COMM%.*}

if [ "${name: -1}" == "2" ]
then
  file_to_cp="${name::-1}"

else
  file_to_cp=$name

fi

module load StdEnv/2020 
module load intel-opencl/2021.2.0
module load beagle-lib/3.1.2

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$EBROOTBEAGLEMINLIB/lib/

echo "Case $ID:"
cd /home/mvila035/scratch/rasha_project99_rand/beast_files/results

# if it is the first time running beast on this file
# create a directory for results and start beast 
if [ ! -d "$name" ]
then
  mkdir $name
  cd $name
  ~/bin/BEASTv1.10.4/bin/beast -overwrite -save_every 5000 -save_state checkpoint.state  /home/mvila035/scratch/rasha_project99_rand/beast_files/xml_files/$COMM

# if beast already ran onn this file
# save previous log and tree file and restart beast from last checkpoint
else
  cd $name
  
  cp checkpoint.state checkpoint.state.bak
  cat "${file_to_cp}.log" >> "${name}_all_runs.log"
  cat "${file_to_cp}.trees" >> "${name}_all_runs.trees"

  ~/bin/BEASTv1.10.4/bin/beast -overwrite -force_resume -load_state checkpoint.state -save_every 5000 -save_state checkpoint.state /home/mvila035/scratch/rasha_project99_rand/beast_files/xml_files/$COMM

fi

# Exit status of the code:
STATUS=$?
if test ! -e "${file_to_cp}.ops"
then
  STATUS=1
fi


cd ~/scratch/rasha_project99_rand/beast_farm/

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

# Saving all current metajob statuses to a single file with a unique name:
echo $ID $STATUS >> STATUSES/status.$METAJOB_ID
