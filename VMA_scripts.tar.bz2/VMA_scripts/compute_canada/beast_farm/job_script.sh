#!/bin/bash
# Here you should provide the sbatch arguments to be used in all jobs in this serial farm
# It has to contain the runtime switch (either -t or --time):
#SBATCH --time=1-00:00:00
#SBATCH --account=def-sarisbr0
#SBATCH --mem=32G


# Don't change this line:
task.run
