#!/bin/bash
# Here you should provide the sbatch arguments to be used in all jobs in this serial farm
# It has to contain the runtime switch (either -t or --time):
#SBATCH -t 1-00:10
#SBATCH --mem=32G
#  You have to replace Your_account_name below with the name of your account:
#SBATCH -A def-sarisbr0

module load  StdEnv/2020
module load  mafft/7.471

# Don't change this line:
task.run
