#!/usr/bin/env python3

# python make_meme_bash.py hyphy_nexus -o meme_jobs -r meme_results


from pathlib import Path
import argparse
import os


def make_executable(path):
    mode = os.stat(path).st_mode
    os.chmod(path, mode | 0o111)


def write_job_script(nexus_file, script_dir, result_dir, hyphy_bin="hyphy", branches="All"):
    nexus_file = Path(nexus_file).resolve()
    base = nexus_file.stem

    script_path = script_dir / f"run_meme_{base}.sh"
    json_out = result_dir / f"{base}.MEME.json"
    log_out = result_dir / f"{base}.MEME.log"

    lines = [
        "#!/usr/bin/env bash",
        "set -euo pipefail",
        "",
        f'ALIGNMENT="{nexus_file}"',
        f'JSON_OUT="{json_out.resolve()}"',
        f'LOG_OUT="{log_out.resolve()}"',
        "",
        f'"{hyphy_bin}" meme \\',
        '  --alignment "$ALIGNMENT" \\',
        f'  --branches {branches} \\',
        '  --output "$JSON_OUT" \\',
        '  > "$LOG_OUT" 2>&1',
        "",
        'echo "Finished MEME: $ALIGNMENT"'
    ]

    script_path.write_text("\n".join(lines) + "\n")
    make_executable(script_path)
    return script_path


def main():
    parser = argparse.ArgumentParser(
        description="Generate bash scripts to run HyPhy MEME on a folder of NEXUS files."
    )
    parser.add_argument(
        "input_dir",
        nargs="?",
        default="hyphy_nexus",
        help="Folder containing NEXUS files (default: hyphy_nexus)"
    )
    parser.add_argument(
        "-o", "--script-dir",
        default="meme_jobs",
        help="Folder where bash job scripts will be written"
    )
    parser.add_argument(
        "-r", "--result-dir",
        default="meme_results",
        help="Folder where MEME output files will be written"
    )
    parser.add_argument(
        "--hyphy-bin",
        default="hyphy",
        help="Path to the HyPhy executable (default: hyphy)"
    )
    parser.add_argument(
        "--branches",
        default="All",
        help='Branch set to test, e.g. "All" (default: All)'
    )
    parser.add_argument(
        "--recursive",
        action="store_true",
        help="Search recursively for .nex and .nexus files"
    )
    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    script_dir = Path(args.script_dir)
    result_dir = Path(args.result_dir)

    script_dir.mkdir(parents=True, exist_ok=True)
    result_dir.mkdir(parents=True, exist_ok=True)

    patterns = ("*.nex", "*.nexus")
    nexus_files = []

    if args.recursive:
        for p in patterns:
            nexus_files.extend(input_dir.rglob(p))
    else:
        for p in patterns:
            nexus_files.extend(input_dir.glob(p))

    nexus_files = sorted(set(nexus_files))

    if not nexus_files:
        raise SystemExit(f"No NEXUS files found in {input_dir}")

    generated = []
    for nexus_file in nexus_files:
        script_path = write_job_script(
            nexus_file=nexus_file,
            script_dir=script_dir,
            result_dir=result_dir,
            hyphy_bin=args.hyphy_bin,
            branches=args.branches
        )
        generated.append(script_path)

    master_script = script_dir / "run_all_meme.sh"
    master_lines = [
        "#!/usr/bin/env bash",
        "set -euo pipefail",
        ""
    ]
    master_lines += [f'"{p.resolve()}"' for p in generated]
    master_lines += ["", 'echo "All MEME jobs completed."']

    master_script.write_text("\n".join(master_lines) + "\n")
    make_executable(master_script)

    print(f"Generated {len(generated)} MEME job scripts in: {script_dir}")
    print(f"Master launcher script: {master_script}")
    print(f"Results will be written to: {result_dir}")


if __name__ == "__main__":
    main()
