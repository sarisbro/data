library(lubridate)
library(stringr)
library(robust)

test <- read.csv("/Users/matthieuvilain/Desktop/PhD/Research/Rasha_project/temperature_data/2023.thailand.tmp.per", sep = "", skip= 3, header= TRUE)

get_month_val <- function(month, row, parent_year= FALSE) {
  
  if (parent_year) {
    
    tmp_vals <- unname(unlist( row[, (month+1):ncol(row)] ))
  }
  
  else {
    tmp_vals <- unname(unlist( row[, 2:(month+1)] ))
  }
  
  return(tmp_vals)
}

add_reg_tmp <- function(df) {
  
  avg_tmp <- c()
  for (i in 1:nrow(df)) {
    country <- df[i,]$country
    date <- df[i,]$map_dates
    parent_date <- df[i,]$map_parent_dates
  
    
    tmp_df <- read.csv(paste0("/Users/matthieuvilain/Desktop/PhD/Research/Rasha_project/temperature_data/2023.",
                              country,".tmp.per"),  sep = "", skip= 3, header= TRUE)
    
    reg <- lmRob( ANN ~ YEAR, tmp_df)
    parent_tmp <- predict(reg, data.frame(YEAR = parent_date))
    tmp <- predict(reg, data.frame(YEAR = date))
    
    mean_tmp <- (parent_tmp+tmp)/2
      
    
    avg_tmp <- c( avg_tmp, mean_tmp )
    
  }
  
  df$reg_tmp <- avg_tmp
  return(df)
  
}


add_avg_tmp <- function(df) {
  
  avg_tmp <- c()
  for (i in 1:nrow(df)) {
    country <- df[i,]$country
    date <- date_decimal( df[i,]$map_dates )
    y_date <- year(date)
    m_date <- month(date)
    
    parent_date <- date_decimal( df[i,]$map_parent_dates )
    y_parent_date <- year(parent_date)
    m_parent_date <- month(parent_date)
    
    tmp_df <- read.csv(paste0("/Users/matthieuvilain/Desktop/PhD/Research/Rasha_project/temperature_data/2023.",
                              country,".tmp.per"),  sep = "", skip= 3, header= TRUE)
    tmp_df <- subset(tmp_df, select=-c(MAM,JJA,SON,DJF,ANN))
    
    
    if (y_parent_date == y_date) {
      row <- tmp_df[tmp_df["YEAR"]== y_date,]
      tmp_over_period <- unname(unlist( row[, (m_parent_date+1):(m_date+1)] ))
      
    }
    
    else {
      row <- tmp_df[tmp_df["YEAR"]== y_date,]
      row_parent <- tmp_df[tmp_df["YEAR"]== y_parent_date,]
      tmp_over_period <- unname(unlist( tmp_df[( tmp_df["YEAR"] > y_parent_date & tmp_df["YEAR"] < y_date ), 2:13] ))
      tmp_over_period <- c(get_month_val(m_parent_date, row_parent, TRUE),
                           tmp_over_period,
                           get_month_val(m_date, row, FALSE)
                           )
      
      
    }
    
    avg_tmp <- c( avg_tmp, mean(tmp_over_period) )
    
  }
  
  df$avg_tmp <- avg_tmp
  return(df)
}


list_99rand <- list.files("/Users/matthieuvilain/Desktop/PhD/Research/Rasha_project99_rand/beast_files/evo_rates/",pattern = "*.csv", full.names = TRUE)
list_99cdhit <- list.files("/Users/matthieuvilain/Desktop/PhD/Research/Rasha_project/beast_files/evo_rates/",pattern = "*.csv", full.names = TRUE)

list_99.7rand <- list.files("/Users/matthieuvilain/Desktop/PhD/Research/Rasha_project_rand/beast_files/evo_rates/",pattern = "*.csv", full.names = TRUE)
list_99.7cdhit <- list.files("/Users/matthieuvilain/Desktop/PhD/Research/Rasha_project99.7/beast_files/evo_rates/",pattern = "*.csv", full.names = TRUE)


for (file in list_99rand) {
  
  temp_df <- read.csv(file)
  
  file_name <-strsplit(file, split="//")[[1]][2]
  tags<- strsplit(file_name, split= "_")[[1]]
  type <- paste0(tags[1],"_", tags[2])
  country<- tags[3]
  sampling <- "99rand"
  
  country_vec <- rep(country, length(temp_df$map_rates))
  type_vec <-  rep(type, length(temp_df$map_rates))
  sampling_vec <- rep(sampling, length(temp_df$map_rates))
  
  temp_df$country <- country_vec
  temp_df$type <- type_vec
  temp_df$sampling <- sampling_vec
  
  if (exists("evorates_df")) {
    evorates_df <- rbind(evorates_df, temp_df)
  }
  
  else {
    evorates_df <- temp_df
  }
}

for (file in list_99cdhit) {
  
  temp_df <- read.csv(file)
  
  file_name <-strsplit(file, split="//")[[1]][2]
  tags<- strsplit(file_name, split= "_")[[1]]
  type <- paste0(tags[1],"_", tags[2])
  country<- tags[3]
  sampling <- "99cdhit"
  
  country_vec <- rep(country, length(temp_df$map_rates))
  type_vec <-  rep(type, length(temp_df$map_rates))
  sampling_vec <- rep(sampling, length(temp_df$map_rates))
  
  temp_df$country <- country_vec
  temp_df$type <- type_vec
  temp_df$sampling <- sampling_vec
  
  if (exists("evorates_df")) {
    evorates_df <- rbind(evorates_df, temp_df)
  }
  
  else {
    evorates_df <- temp_df
  }
}

for (file in list_99.7rand) {
  
  temp_df <- read.csv(file)
  
  file_name <-strsplit(file, split="//")[[1]][2]
  tags<- strsplit(file_name, split= "_")[[1]]
  type <- paste0(tags[1],"_", tags[2])
  country<- tags[3]
  sampling <- "99.7rand"
  
  country_vec <- rep(country, length(temp_df$map_rates))
  type_vec <-  rep(type, length(temp_df$map_rates))
  sampling_vec <- rep(sampling, length(temp_df$map_rates))
  
  temp_df$country <- country_vec
  temp_df$type <- type_vec
  temp_df$sampling <- sampling_vec
  
  if (exists("evorates_df")) {
    evorates_df <- rbind(evorates_df, temp_df)
  }
  
  else {
    evorates_df <- temp_df
  }
}

for (file in list_99.7cdhit) {
  
  temp_df <- read.csv(file)
  
  file_name <-strsplit(file, split="//")[[1]][2]
  tags<- strsplit(file_name, split= "_")[[1]]
  type <- paste0(tags[1],"_", tags[2])
  country<- tags[3]
  sampling <- "99.7cdhit"
  
  country_vec <- rep(country, length(temp_df$map_rates))
  type_vec <-  rep(type, length(temp_df$map_rates))
  sampling_vec <- rep(sampling, length(temp_df$map_rates))
  
  temp_df$country <- country_vec
  temp_df$type <- type_vec
  temp_df$sampling <- sampling_vec
  
  if (exists("evorates_df")) {
    evorates_df <- rbind(evorates_df, temp_df)
  }
  
  else {
    evorates_df <- temp_df
  }
}

evorates_df <- na.omit(evorates_df)
evorates_df <- evorates_df[evorates_df["country"] != "taiwan",]
evorates_df <- add_avg_tmp(evorates_df)
evorates_df <- add_reg_tmp(evorates_df)

write.csv(evorates_df, "/Users/matthieuvilain/Desktop/PhD/Research/combined_datasets_evorates/evorates/evorates.csv")

