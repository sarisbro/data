library(ggplot2)
library(robust)
library(reshape2)
library(ggtext)
library(dplyr)
library(stringr)
library(countrycode)
library(car)
library(performance)
library(see)
library(MASS)
library(emmeans)
library(segmented)


df <- read.csv("/Users/matthieuvilain/Desktop/PhD/Research/combined_datasets_evorates/evorates/evorates.csv")
df <- df[df["country"] != "taiwan",]

#keep analysis with 
conditions <- data.frame(
  country= c("japan","russia","usa","russia","usa","australia","australia",
             "china","netherlands","netherlands", "australia","australia", "chile",
             "china", "china", "netherlands","netherlands", "russia", "thailand" ),
  type= c("H1N1_HA","H1N1_HA","H1N1_HA","H1N1_NA","H1N1_NA","H3N2_HA",
          "H3N2_HA","H3N2_HA", "H3N2_HA", "H3N2_HA", "H3N2_NA", "H3N2_NA", "H3N2_NA",
          "H3N2_NA", "H3N2_NA", "H3N2_NA", "H3N2_NA", "H3N2_NA", "H3N2_HA" ),
  sampling= c("99.7cdhit","99.7cdhit", "99.7cdhit", "99.7cdhit", "99cdhit",
              "99.7cdhit","99.7rand", "99.7cdhit", "99.7cdhit", "99.7rand", 
              "99.7cdhit","99cdhit", "99.7cdhit","99.7cdhit", "99.7rand", "99.7cdhit",
              "99.7rand", "99.7cdhit", "99.7cdhit")
)

#### anova rates #####
df$sampling <- as.factor(df$sampling)
ggplot(df, aes(x= sampling, y= map_rates))+
  geom_boxplot()+
  ylim(0,0.01)+
  xlab("Sampling Method")+
  ylab("Substitution Rate (substitution/site/year)")+
  theme_classic()
ggsave("/Users/matthieuvilain/Desktop/PhD/Research/combined_datasets_evorates/figures/sampling_rate_anova.pdf", width = 5, height = 5)


robanova <- rlm(log2(map_rates) ~ sampling ,df, method = "MM")
posthoc <- glht(robanova, linfct= mcp(sampling = "Tukey"))
summary(posthoc)


#### prep df for ancova ####
#df$gene <- str_split_fixed(df$type, "_", 2)[,2]
#df$type <- str_split_fixed(df$type, "_", 2)[,1]
df$map_dates <- round(df$map_dates)
df <- df %>% filter(sampling %in% c("99.7rand","99.7cdhit"))
avg_rate <- df %>% group_by(type,map_dates,sampling) %>% summarise(avg= mean(map_rates))
avg_rate$type <- as.factor(avg_rate$type)


ggplot(avg_rate, aes(x=map_dates, y=avg, colour = type))+
  geom_point(alpha= 0.5)+
  #geom_smooth(method= "lm", formula = y~x, se= FALSE, fullrange= TRUE)+
  stat_smooth(method=function(formula,data,weights=weight) rlm(formula,
                                                               data,
                                                               weights=weight,
                                                               method= "MM"),
              fullrange=TRUE, se= FALSE) +
  ylim(0.002,0.011)+
  ylab("Average Substitution Rate (substitution/site/year)")+
  xlab("Years")+
  scale_colour_manual(values = c("H1N1_HA"= "#B02418", "H1N1_NA"="#410E09", "H3N2_HA"= "#636C75", "H3N2_NA"="#40454B"))+
  labs(colour = "Subtypes")+
  theme_bw()+
  theme(legend.position = "None",
        axis.text.x = element_text(angle = 90),
        rect = element_rect(fill = "transparent"))+
  facet_wrap(vars(sampling,type), nrow= 2)

ggsave("/Users/matthieuvilain/Desktop/PhD/Conferences/ACMBCB_2025/figures/poster_fig.pdf", width = 7, height = 4)



#### ANCOVAs ######
avg_rand <- avg_rate %>% filter(sampling == "99.7rand")
boxplot(avg ~ type, avg_rand)
ancova_model <- lm(avg ~ map_dates * type , avg_rand)
summary(ancova_model)
Anova(ancova_model)
par(mfrow = c(2, 2))
plot(ancova_model)


ancova_rob <- rlm(avg ~ map_dates*type, avg_rand, method= "MM")
Anova(ancova_rob, type= "III")
emm.vis <- emmeans(ancova_rob, ~ type * map_dates, at = list( map_dates= c(1930,1945, 1960,1975, 1990, 2005, 2020)))
emmip(emm.vis,  type ~ map_dates )
emm <- emmeans(ancova_rob, "type")
pairs(emm, adjust= "tukey")
emm.trend <- emtrends(ancova_rob, ~ type, var= "map_dates")
pairs(emm.trend, simple= "type", adjust= "tukey")


avg_cdhit <- avg_rate %>% filter(sampling == "99.7cdhit")
boxplot(avg ~ type, avg_cdhit)
ancova_model <- aov(avg ~ map_dates * type , avg_cdhit)
Anova(ancova_model)
par(mfrow = c(2, 2))
plot(ancova_model)

ancova_rob <- rlm(avg ~ map_dates*type , avg_cdhit, method = "MM")
Anova(ancova_rob, type= "II")
emm <- emmeans(ancova_rob, "type" )
pairs(emm, adjust= "tukey")



#### evorate mean difference ANOVA
df <- read.csv("/Users/matthieuvilain/Desktop/PhD/Research/combined_datasets_evorates/evorates/evorates.csv")
df <- df[df["country"] != "taiwan",]

#remove results for analysis that did not converge
df_H1N1_HA <- df[df["type"] == "H1N1_HA",]
df_H1N1_HA <- df_H1N1_HA[ df_H1N1_HA["country"] != "usa" | df_H1N1_HA["sampling"] != "99.7cdhit", ]
df_H1N1_HA <- df_H1N1_HA[ df_H1N1_HA["country"] != "china" | df_H1N1_HA["sampling"] != "99.7rand", ]
df_H1N1_HA <- df_H1N1_HA[ df_H1N1_HA["country"] != "japan" | df_H1N1_HA["sampling"] != "99.7rand", ]
df_H1N1_HA <- df_H1N1_HA[ df_H1N1_HA["country"] != "usa" | df_H1N1_HA["sampling"] != "99.7rand", ]

df_H1N1_NA <- df[df["type"] == "H1N1_NA",]
df_H1N1_NA <- df_H1N1_NA[ df_H1N1_NA["country"] != "usa" | df_H1N1_NA["sampling"] != "99.7cdhit", ]
df_H1N1_NA <- df_H1N1_NA[ df_H1N1_NA["country"] != "china" | df_H1N1_NA["sampling"] != "99.7rand", ]
df_H1N1_NA <- df_H1N1_NA[ df_H1N1_NA["country"] != "usa" | df_H1N1_NA["sampling"] != "99.7rand", ]


df_H3N2_HA <- df[df["type"] == "H3N2_HA",]
df_H3N2_HA <- df_H3N2_HA[ df_H3N2_HA["country"] != "japan" | df_H3N2_HA["sampling"] != "99.7cdhit", ]
df_H3N2_HA <- df_H3N2_HA[ df_H3N2_HA["country"] != "usa" | df_H3N2_HA["sampling"] != "99.7cdhit", ]
df_H3N2_HA <- df_H3N2_HA[ df_H3N2_HA["country"] != "china" | df_H3N2_HA["sampling"] != "99.7rand", ]
df_H3N2_HA <- df_H3N2_HA[ df_H3N2_HA["country"] != "japan" | df_H3N2_HA["sampling"] != "99.7rand", ]
df_H3N2_HA <- df_H3N2_HA[ df_H3N2_HA["country"] != "usa" | df_H3N2_HA["sampling"] != "99.7rand", ]

df_H3N2_NA <- df[df["type"] == "H3N2_NA",]
df_H3N2_NA <- df_H3N2_NA[ df_H3N2_NA["country"] != "japan" | df_H3N2_NA["sampling"] != "99cdhit", ]
df_H3N2_NA <- df_H3N2_NA[ df_H3N2_NA["country"] != "japan" | df_H3N2_NA["sampling"] != "99.7cdhit", ]
df_H3N2_NA <- df_H3N2_NA[ df_H3N2_NA["country"] != "usa" | df_H3N2_NA["sampling"] != "99.7cdhit", ]
df_H3N2_NA <- df_H3N2_NA[ df_H3N2_NA["country"] != "australia" | df_H3N2_NA["sampling"] != "99.7rand", ]
df_H3N2_NA <- df_H3N2_NA[ df_H3N2_NA["country"] != "japan" | df_H3N2_NA["sampling"] != "99.7rand", ]
df_H3N2_NA <- df_H3N2_NA[ df_H3N2_NA["country"] != "usa" | df_H3N2_NA["sampling"] != "99.7rand", ]


df99<- df %>% filter(sampling %in% c("99rand","99cdhit") )
df99.7 <- df %>% filter(sampling %in% c("99.7rand","99.7cdhit") )

#anova rand vs cdhit at 99%
rob_anova <- rlm(map_rates ~ sampling, df99)
Anova(rob_anova)
emm <- emmeans(rob_anova, "sampling" )
pairs(emm)

#anova rand vs cdhit at 99.7%
rob_anova <- rlm(map_rates ~ sampling, df99.7)
Anova(rob_anova)
emm <- emmeans(rob_anova, "sampling" )
pairs(emm)
