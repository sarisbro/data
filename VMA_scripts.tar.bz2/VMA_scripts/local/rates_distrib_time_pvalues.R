library(ggplot2)
library(robust)
library(reshape2)
library(ggtext)
library(dplyr)
library(stringr)
library(countrycode)

df <- read.csv("/Users/matthieuvilain/Desktop/PhD/Research/combined_datasets_evorates/evorates/evorates.csv")
df <- df[df["country"] != "taiwan",]

nb_seq <- read.csv("/Users/matthieuvilain/Desktop/PhD/Research/combined_datasets_evorates/analysis_tables/analysis_nb_seq.csv")
nb_seq <- nb_seq[nb_seq["nb_seq"] != "n/a",]
nb_seq$nb_seq <- as.integer(nb_seq$nb_seq)

nb_seq_H1N1_HA <- nb_seq[nb_seq["variant"] == "H1N1_HA",] 
nb_seq_H1N1_NA <- nb_seq[nb_seq["variant"] == "H1N1_NA",] 
nb_seq_H3N2_HA <- nb_seq[nb_seq["variant"] == "H3N2_HA",] 
nb_seq_H3N2_NA <- nb_seq[nb_seq["variant"] == "H3N2_NA",] 

#remove results for analysis that did not converge
df_H1N1_HA <- df[df["type"] == "H1N1_HA",]
df_H1N1_HA <- df_H1N1_HA[ df_H1N1_HA["country"] != "usa" | df_H1N1_HA["sampling"] != "99.7cdhit", ]
df_H1N1_HA <- df_H1N1_HA[ df_H1N1_HA["country"] != "china" | df_H1N1_HA["sampling"] != "99.7rand", ]
df_H1N1_HA <- df_H1N1_HA[ df_H1N1_HA["country"] != "japan" | df_H1N1_HA["sampling"] != "99.7rand", ]
df_H1N1_HA <- df_H1N1_HA[ df_H1N1_HA["country"] != "usa" | df_H1N1_HA["sampling"] != "99.7rand", ]

df_H1N1_NA <- df[df["type"] == "H1N1_NA",]
df_H1N1_NA <- df_H1N1_NA[ df_H1N1_NA["country"] != "usa" | df_H1N1_NA["sampling"] != "99.7cdhit", ]
df_H1N1_NA <- df_H1N1_NA[ df_H1N1_NA["country"] != "china" | df_H1N1_NA["sampling"] != "99.7rand", ]
df_H1N1_NA <- df_H1N1_NA[ df_H1N1_NA["country"] != "usa" | df_H1N1_NA["sampling"] != "99.7rand", ]


df_H3N2_HA <- df[df["type"] == "H3N2_HA",]
df_H3N2_HA <- df_H3N2_HA[ df_H3N2_HA["country"] != "japan" | df_H3N2_HA["sampling"] != "99.7cdhit", ]
df_H3N2_HA <- df_H3N2_HA[ df_H3N2_HA["country"] != "usa" | df_H3N2_HA["sampling"] != "99.7cdhit", ]
df_H3N2_HA <- df_H3N2_HA[ df_H3N2_HA["country"] != "china" | df_H3N2_HA["sampling"] != "99.7rand", ]
df_H3N2_HA <- df_H3N2_HA[ df_H3N2_HA["country"] != "japan" | df_H3N2_HA["sampling"] != "99.7rand", ]
df_H3N2_HA <- df_H3N2_HA[ df_H3N2_HA["country"] != "usa" | df_H3N2_HA["sampling"] != "99.7rand", ]

df_H3N2_NA <- df[df["type"] == "H3N2_NA",]
df_H3N2_NA <- df_H3N2_NA[ df_H3N2_NA["country"] != "japan" | df_H3N2_NA["sampling"] != "99cdhit", ]
df_H3N2_NA <- df_H3N2_NA[ df_H3N2_NA["country"] != "japan" | df_H3N2_NA["sampling"] != "99.7cdhit", ]
df_H3N2_NA <- df_H3N2_NA[ df_H3N2_NA["country"] != "usa" | df_H3N2_NA["sampling"] != "99.7cdhit", ]
df_H3N2_NA <- df_H3N2_NA[ df_H3N2_NA["country"] != "australia" | df_H3N2_NA["sampling"] != "99.7rand", ]
df_H3N2_NA <- df_H3N2_NA[ df_H3N2_NA["country"] != "japan" | df_H3N2_NA["sampling"] != "99.7rand", ]
df_H3N2_NA <- df_H3N2_NA[ df_H3N2_NA["country"] != "usa" | df_H3N2_NA["sampling"] != "99.7rand", ]

adjust_pvalue <- function(df) {
  
  p_adjusted_list <- c()
  p_str_adj <- c()
  
  for (country in unique(df$country)) {
    sub_df<- df[df["country"]== country ,]
    
    p_adjusted <- p.adjust( abs(sub_df$p_value), method = "BH") * sign(sub_df$p_value)
    p_adjusted_list <- c( p_adjusted_list, p_adjusted )

    for (p in p_adjusted){
      if (abs(p) < 0.01 ) {
        p_str <-  sprintf("%.4f", p)
        p_str <- paste0("***p*= ",p_str,"**")
        p_str_adj <- c(p_str_adj, p_str)
      }
      
      else {
        p_str <- sprintf("%.4f", p)
        p_str <- paste0("*p*= ",p_str)
        p_str_adj <- c(p_str_adj, p_str)
      }
    }
    
  }
  
  df$p_adjusted <- p_adjusted_list
  df$p_str_adj <- p_str_adj
  
  return(df)
}

compute_robustreg <- function(df) {
  
  country_list <- c()
  sampling_list <- c()
  p_value_list <- c()
  p_str_list <- c()
  rsquared_list <- c()
  reg_coeff <- c()
  
  for (country in unique(df$country) ){
    
    for (samp in unique(df$sampling) ) {
      
      sub_df<- df[(df["country"]== country & df["sampling"] == samp) ,]
      
      if ( nrow(sub_df) != 0 ) {
        model <- lmRob(map_rates ~ map_dates, data= sub_df)
        coeff <- coef(model)["map_dates"]
        
        rsquared <- summary(model)$r.squared
        slope <- summary(model)[[4]][2,1]
        p_value <- sign(coef(model)["map_dates"])*summary(model)[[4]][2,4]
        p_str <-  sprintf("%.4f", p_value)
        p_str <- paste0("*p*= ",p_str)
        
        country_list <- c(country_list, country)
        sampling_list <- c(sampling_list, samp)
        p_value_list <- c(p_value_list, p_value)
        p_str_list <- c(p_str_list, p_str)
        rsquared_list <- c(rsquared_list, rsquared)
        reg_coeff <- c(reg_coeff, slope)
      }
      
    }
    
  }
  
  p_df <- data.frame(country = country_list, sampling= sampling_list, p_value= p_value_list,
                     p_str= p_str_list, coeff= reg_coeff, rsquared= rsquared_list)
  
  return(p_df)
  
}

pvalues_H1N1_HA <- adjust_pvalue( compute_robustreg(df_H1N1_HA) )
pvalues_H1N1_HA <- merge(pvalues_H1N1_HA, nb_seq_H1N1_HA, by= c('country',"sampling"))

pvalues_H1N1_NA <- adjust_pvalue( compute_robustreg(df_H1N1_NA) )
pvalues_H1N1_NA <-  merge(pvalues_H1N1_NA, nb_seq_H1N1_NA, by= c('country',"sampling"))

pvalues_H3N2_HA <- adjust_pvalue( compute_robustreg(df_H3N2_HA) )
pvalues_H3N2_HA <- merge(pvalues_H3N2_HA, nb_seq_H3N2_HA, by= c('country',"sampling"))
  
pvalues_H3N2_NA <- adjust_pvalue( compute_robustreg(df_H3N2_NA) )
pvalues_H3N2_NA <- merge(pvalues_H3N2_NA, nb_seq_H3N2_NA, by= c('country',"sampling"))

pH1N1_HA <- ggplot(data= df_H1N1_HA, aes(x= sampling, y= map_rates, colour= sampling) )+
  geom_violin( show.legend = FALSE)+
  ylab("Substitution rate")+
  xlab("Sampling")+
  facet_wrap(~ country, ncol= 3)+
  geom_richtext(data= pvalues_H1N1_HA,
                mapping = aes(x = sampling, y = 0.03, label = p_str_adj),
                hjust   = 0.5,
                vjust   = 1, size= 3,  show.legend = FALSE)+
  theme_bw()

ggsave("/Users/matthieuvilain/Desktop/PhD/Research/combined_datasets_evorates/figures/H1N1_HA_distrib.pdf",
       plot = pH1N1_HA, width = 10, height = 4)


pH1N1_NA <- ggplot(data= df_H1N1_NA, aes(x= sampling, y= map_rates, colour= sampling) )+
  geom_violin( show.legend = FALSE)+
  ylab("Substitution rate")+
  xlab("Sampling")+
  facet_wrap(~ country, ncol= 3)+
  geom_richtext(data= pvalues_H1N1_NA,
                mapping = aes(x = sampling, y = 0.05, label = p_str_adj),
                hjust   = 0.5,
                vjust   = 1, size= 3,  show.legend = FALSE)+
  theme_bw()

ggsave("/Users/matthieuvilain/Desktop/PhD/Research/combined_datasets_evorates/figures/H1N1_NA_distrib.pdf",
       plot = pH1N1_NA, width = 10, height = 4)


pH3N2_HA <- ggplot(data= df_H3N2_HA, aes(x= sampling, y= map_rates, colour= sampling) )+
  geom_violin( show.legend = FALSE)+
  ylab("Substitution rate")+
  xlab("Sampling")+
  facet_wrap(~ country, ncol= 3)+
  geom_richtext(data= pvalues_H3N2_HA,
                mapping = aes(x = sampling, y = 0.03, label = p_str_adj),
                hjust   = 0.5,
                vjust   = 1, size= 3,  show.legend = FALSE)+
  theme_bw()

ggsave("/Users/matthieuvilain/Desktop/PhD/Research/combined_datasets_evorates/figures/H3N2_HA_distrib.pdf",
       plot = pH3N2_HA, width = 10, height = 10)


pH3N2_NA <- ggplot(data= df_H3N2_NA, aes(x= sampling, y= map_rates, colour= sampling) )+
  geom_violin( show.legend = FALSE)+
  ylab("Substitution rate")+
  xlab("Sampling")+
  facet_wrap(~ country, ncol= 3)+
  geom_richtext(data= pvalues_H3N2_NA,
                mapping = aes(x = sampling, y = 0.03, label = p_str_adj),
                hjust   = 0.5,
                vjust   = 1, size= 3,  show.legend = FALSE)+
  theme_bw()

ggsave("/Users/matthieuvilain/Desktop/PhD/Research/combined_datasets_evorates/figures/H3N2_NA_distrib.pdf",
       plot = pH3N2_NA, width = 10, height = 10)


####### pvavlue according to nb of seq #######

pvalues_all <-rbind(pvalues_H1N1_HA, pvalues_H1N1_NA, pvalues_H3N2_HA, pvalues_H3N2_NA)
pvalues_all$p_log_adj <- -1*log10(abs(pvalues_all$p_adjusted)) * sign(pvalues_all$p_value)
pvalues_all$sign <- as.factor(sign(pvalues_all$p_value))
pvalues_all <- pvalues_all %>% mutate(across('variant', str_replace, 'H1N1_HA', "H1N1 Hemagglutinin")) %>%
  mutate(across('variant', str_replace, 'H1N1_NA', "H1N1 Neuraminidase")) %>%
  mutate(across('variant', str_replace, 'H3N2_HA', "H3N2 Hemagglutinin")) %>%
  mutate(across('variant', str_replace, 'H3N2_NA', "H3N2 Neuraminidase"))

pvalues_plot <- pvalues_all %>% group_by(variant, sign) %>%
  filter(n() > 1) %>%summarize(p.value = ( summary(lm(p_log_adj ~ nb_seq))$coefficients["nb_seq", "Pr(>|t|)"] ))
pvalues_plot$p.value <- sprintf("%.4f", pvalues_plot$p.value )
pvalues_plot$p.value <- paste0("*p*= ",pvalues_plot$p.value)
pvalues_plot <- pvalues_plot %>% mutate(p.value= str_replace(p.value, "\\*p\\*= 0.0000", "\\*p\\*< 0.0001"))
negative <- pvalues_plot[pvalues_plot["sign"] == "-1",]
positive <- pvalues_plot[pvalues_plot["sign"] == "1",]
significant <- filter(pvalues_all, abs(p_adjusted) <= 0.01)
significant$country <- str_to_title(significant$country)
significant <- significant %>% mutate(across('country', str_replace, 'Usa', "USA"))
significant$country <- countrycode(significant$country, origin = "country.name", destination = "iso2c")

pvalue_nbseq <- ggplot(data= pvalues_all, aes(x= nb_seq, y= p_log_adj, colour = sign) )+
  geom_point(aes(shape= sampling))+
  geom_hline(yintercept = 2, linetype= "dashed")+
  geom_hline(yintercept = -2, linetype= "dashed")+
  geom_hline(yintercept = 0)+
  ylab("± log10(*p*-value)")+
  xlab("Number of sequences")+
  ylim(-2,9.5)+
  scale_colour_manual(values = c("1"= "#F8766D", "-1"="#00BFC4"))+
  scale_shape_manual(values=c(3, 4, 1, 2), labels=c('99.7% CD-HIT', '99.7% Random', '99% CD-HIT', '99% Random'))+
  geom_smooth(method= "lm", formula = y~x, se= FALSE, fullrange= TRUE)+
  geom_richtext(aes(x= 950, y = 6.2, colour= sign, label = p.value), data = positive, size = 4,  )+
  geom_richtext(aes(x= 950, y = -1, colour= sign, label = p.value), data = negative, size = 4, )+
  geom_richtext(aes(label=country), fill = NA, label.colour = NA, data = significant, size=2.5, nudge_y = 0.3, nudge_x = -50 )+
  facet_wrap(~ variant, ncol = 2)+
  guides(colour= "none")+
  labs(shape="Sampling Method")+
  theme_classic()+
  theme(axis.title.y = ggtext::element_markdown())
  
ggsave("/Users/matthieuvilain/Desktop/PhD/Research/combined_datasets_evorates/figures/pvalue_per_nbseq_time.pdf",
       plot = pvalue_nbseq, width = 8, height = 7, dpi = 600)

