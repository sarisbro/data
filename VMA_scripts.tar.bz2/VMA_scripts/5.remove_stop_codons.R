#!/usr/bin/env Rscript

# Rscript remove_stop_codons.R fasta_cleaned -o fasta_nostop -j 8


suppressPackageStartupMessages({
  library(Biostrings)
  library(parallel)
})

parse_args <- function(args) {
  opts <- list(
    input_dir = "fasta_cleaned",
    output_dir = "fasta_nostop",
    jobs = detectCores(),
    recursive = FALSE,
    overwrite = FALSE
  )

  i <- 1
  while (i <= length(args)) {
    a <- args[i]
    if (a %in% c("-o", "--output-dir")) {
      i <- i + 1
      opts$output_dir <- args[i]
    } else if (a %in% c("-j", "--jobs")) {
      i <- i + 1
      opts$jobs <- as.integer(args[i])
    } else if (a == "--recursive") {
      opts$recursive <- TRUE
    } else if (a == "--overwrite") {
      opts$overwrite <- TRUE
    } else {
      opts$input_dir <- a
    }
    i <- i + 1
  }
  opts
}

remove_stop_codons <- function(seq) {
  s <- toupper(as.character(seq))
  codons <- substring(s, seq(1, nchar(s), 3), seq(3, nchar(s), 3))
  codons <- codons[nchar(codons) == 3]
  codons[codons %in% c("TAA", "TAG", "TGA")] <- "---"
  paste(codons, collapse = "")
}

process_one <- function(fasta_file, output_dir, overwrite = FALSE) {
  out_file <- file.path(output_dir, basename(fasta_file))

  if (file.exists(out_file) && !overwrite) {
    return(sprintf("[skipped] %s", basename(fasta_file)))
  }

  x <- readDNAStringSet(fasta_file)
  x2 <- x

  for (i in seq_along(x)) {
    x2[[i]] <- DNAString(remove_stop_codons(x[[i]]))
  }

  writeXStringSet(x2, out_file, format = "fasta")
  sprintf("[ok] %s -> %s", basename(fasta_file), out_file)
}

main <- function() {
  args <- commandArgs(trailingOnly = TRUE)
  opts <- parse_args(args)

  if (!dir.exists(opts$input_dir)) {
    stop(sprintf("Input directory does not exist: %s", opts$input_dir))
  }

  dir.create(opts$output_dir, recursive = TRUE, showWarnings = FALSE)

  patterns <- c("\\.fa$", "\\.fasta$", "\\.fas$", "\\.fna$")
  files <- character()
  for (pat in patterns) {
    files <- c(
      files,
      list.files(opts$input_dir, pattern = pat, full.names = TRUE, recursive = opts$recursive)
    )
  }
  files <- sort(unique(files))

  if (length(files) == 0) {
    cat("No FASTA files found.\n")
    quit(status = 0)
  }

  jobs <- max(1, min(opts$jobs, length(files)))

  results <- mclapply(
    files,
    function(f) {
      tryCatch(
        process_one(f, opts$output_dir, overwrite = opts$overwrite),
        error = function(e) sprintf("[error] %s: %s", basename(f), conditionMessage(e))
      )
    },
    mc.cores = jobs
  )

  cat(paste(unlist(results), collapse = "\n"), "\n")
}

main()
