Compute_canada: Contains the scripts that ran on the Digital Research Alliance of Canada servers

	cdhit_farm: scripts used to subsample sequences using CD-HIT (uses META-Farm to automate running the scripts for each country)
	rand_sampling_script: scripts used to subsample	sequences randomly
	merge_sequences: scripts used to merge the different FASTA files for each country
	align_farm: scripts used to align the sequences for each country (uses META-Farm)
	beast_farm: scripts used to run BEAST (uses META-Farm)
	beast_files: folder containing BEAST XML files, results and scripts to process results

		combined_files: scripts used to combine the 2 different MCMC chains we ran for each country/subtype/gene
		convergence: scripts to assess the MCMC chains' convergence
		evo_rates: scripts to extract substitution rates
		results: folder containing the folders of each country/subtype/gene with their respective results
		xml_files: folder containing the BEAST XML files


Local: Contains scripts used to preprocess the extracted substitution rates
	Ancova_analyses.R: ran ANOVA and ANCOVA models
	combine_evorates.R: Combine all results into an easy to analyze csv file
	rates_distrib_time_pvalues.R: Run analyses and figure correlating substitution rates and time
	rates_distrib_tmp_pvalues.R: Run analyses and figure correlating substitution rates and temperatures