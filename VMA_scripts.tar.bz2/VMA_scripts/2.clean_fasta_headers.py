#!/usr/bin/env python3

# python3 2.clean_fasta_headers.py fasta -o fasta_cleaned

from pathlib import Path
import argparse


def clean_header(header):
    header = header.replace("cds:", "")
    header = header.replace("\\", "_")
    return header


def process_fasta(in_path, out_path):
    with open(in_path, "r", encoding="utf-8", errors="ignore") as fin, \
         open(out_path, "w", encoding="utf-8") as fout:
        for line in fin:
            if line.startswith(">"):
                fout.write(">" + clean_header(line[1:].rstrip("\n\r")) + "\n")
            else:
                fout.write(line)


def main():
    parser = argparse.ArgumentParser(
        description="Clean FASTA headers in a folder of files."
    )
    parser.add_argument(
        "input_dir",
        nargs="?",
        default="fasta",
        help="Folder containing FASTA files (default: fasta)"
    )
    parser.add_argument(
        "-o", "--output-dir",
        default=None,
        help="Output folder (default: input_dir/cleaned)"
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Overwrite files in place instead of writing to a new folder"
    )
    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir) if args.output_dir else input_dir / "cleaned"

    fasta_files = sorted(
        list(input_dir.glob("*.fa")) +
        list(input_dir.glob("*.fasta")) +
        list(input_dir.glob("*.fas")) +
        list(input_dir.glob("*.fna"))
    )

    if not fasta_files:
        print(f"No FASTA files found in {input_dir}")
        return

    if args.overwrite:
        for fasta in fasta_files:
            tmp = fasta.with_suffix(fasta.suffix + ".tmp")
            process_fasta(fasta, tmp)
            tmp.replace(fasta)
            print(f"Cleaned in place: {fasta.name}")
    else:
        output_dir.mkdir(parents=True, exist_ok=True)
        for fasta in fasta_files:
            out_path = output_dir / fasta.name
            process_fasta(fasta, out_path)
            print(f"Wrote: {out_path}")


if __name__ == "__main__":
    main()
