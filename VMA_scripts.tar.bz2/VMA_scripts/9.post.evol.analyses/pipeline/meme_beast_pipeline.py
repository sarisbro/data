#!/usr/bin/env python3
"""
MEME (HyPhy episodic positive selection)  x  BEAST (relaxed-clock MAP time tree)
--------------------------------------------------------------------------------
Match per-branch episodes of episodic diversifying selection (MEME) onto a
time-calibrated phylogeny (BEAST MAP tree) and test whether episodes of
positive selection increase through time.

Episode definition (user choice): site MEME p<=0.05 AND branch EBF>100 (beta+ class).
Episode timestamp        (user choice): midpoint of the matched BEAST branch.
Through-time test        (user choice): normalized (per unit branch-length) AND raw.

Author: pipeline generated for S. Aris-Brosou lab.
"""
import json, re, os, glob, datetime, math
import numpy as np
import pandas as pd
import dendropy

DATA = os.environ.get("MBT_DATA", "./data")
MEME_DIR = os.path.join(DATA, "meme_results")
TREE_DIR = os.path.join(DATA, "map_trees")
OUT = os.environ.get("MBT_OUT", "./results")
os.makedirs(OUT, exist_ok=True)

P_THRESH   = 0.05    # MEME site significance
EBF_THRESH = 100.0   # branch empirical Bayes factor threshold

# ------------------------------------------------------------------ helpers
def decimal_date(y, m, d):
    d0 = datetime.date(y, 1, 1)
    # clamp impossible days
    try:
        d1 = datetime.date(y, m, d)
    except ValueError:
        d1 = datetime.date(y, m, 1)
    doy = (d1 - d0).days
    ndays = (datetime.date(y, 12, 31) - d0).days + 1
    return y + doy / ndays

def acc_of(label):
    m = re.search(r'([A-Za-z]{1,3}\d{3,})', label)
    return m.group(1) if m else label

def date_of(label):
    m = re.search(r'(\d{4})_(\d{1,2})_(\d{1,2})', label)
    if not m:
        return None
    y, mo, da = map(int, m.groups())
    mo = min(max(mo, 1), 12)
    return decimal_date(y, mo, max(da, 1))

# ------------------------------------------------------------------ MEME parse
def parse_meme(path):
    d = json.load(open(path))
    mle = np.array(d['MLE']['content']['0'], dtype=float)
    nsites = mle.shape[0]
    pval  = mle[:, 6]
    pplus = mle[:, 4]                     # prior weight of beta+ class
    ba = d['branch attributes']['0']
    branches = {b: np.array(ba[b]['Posterior prob omega class by site'], dtype=float)
                for b in ba if 'Posterior prob omega class by site' in ba[b]}
    meme_tree = d['input']['trees']['0']

    # EBF per branch per site, positive class = row index 1 (validated vs col 7)
    episodes = []      # (site_codon, branch_name, ebf, posterior)
    sig_sites = np.where(pval <= P_THRESH)[0]
    for s in sig_sites:
        prior = pplus[s]
        if prior <= 0 or prior >= 1:
            # degenerate prior: skip EBF (cannot form prior odds); rare at sig sites
            if prior <= 0:
                continue
            prior = min(prior, 1 - 1e-12)
        prior_odds = prior / (1 - prior)
        for bname, pp in branches.items():
            post = pp[1, s]
            if post <= 0:
                continue
            post = min(post, 1 - 1e-12)
            ebf = (post / (1 - post)) / prior_odds
            if ebf > EBF_THRESH:
                episodes.append((int(s) + 1, bname, float(ebf), float(post)))
    return dict(nsites=nsites, pval=pval, pplus=pplus, branches=branches,
                meme_tree=meme_tree, episodes=episodes,
                n_sig_sites=int(len(sig_sites)),
                sig_sites=[int(x) + 1 for x in sig_sites])

# ------------------------------------------------------------------ MEME tree -> bipartitions
def meme_branch_bipartitions(newick, all_acc):
    """Return {branch_label -> frozenset(canonical clade of accessions)} for every
    labelled node in the MEME tree (tips + internal Node# labels)."""
    nwk = newick.strip()
    if not nwk.endswith(';'):
        nwk += ';'
    t = dendropy.Tree.get(data=nwk, schema='newick', preserve_underscores=True)
    # keep original full leaf labels (they ARE the branch-attribute keys); map to accession for clades
    full2acc = {}
    for lf in t.leaf_node_iter():
        full2acc[lf.taxon.label] = acc_of(lf.taxon.label)
    ref = sorted(all_acc)[0]                  # fixed reference for canonicalisation
    out = {}
    for nd in t:
        if nd.parent_node is None:
            continue                          # root edge does not exist
        clade = frozenset(full2acc[l.taxon.label] for l in nd.leaf_iter())
        canon = clade if ref not in clade else frozenset(all_acc - clade)
        # branch label as stored in MEME branch attributes: full name for tips, Node# for internals
        if nd.is_leaf():
            label = nd.taxon.label            # original full MEME taxon name
        else:
            label = nd.label
        if label is None:
            continue
        out[label] = canon
    return out

# ------------------------------------------------------------------ BEAST tree
def read_beast(path):
    txt = open(path).read()
    tb = re.search(r'Translate(.*?);', txt, re.S | re.I).group(1)
    trans = {}
    for line in tb.split('\n'):
        line = line.strip().rstrip(',')
        if not line:
            continue
        m = re.match(r'(\d+)\s+(.*)$', line)
        if m:
            trans[m.group(1)] = m.group(2).strip()
    tl = re.search(r'tree\s+\S+\s*=\s*(\[&[RU]\]\s*)?(.*?);', txt, re.S | re.I)
    nwk = re.sub(r'\[[^\]]*\]', '', tl.group(2)).strip() + ';'
    tree = dendropy.Tree.get(data=nwk, schema='newick', preserve_underscores=True)
    tipdate = {}
    for lf in tree.leaf_node_iter():
        full = trans[lf.taxon.label]
        a = acc_of(full)
        lf.taxon.label = a
        tipdate[a] = date_of(full)
    return tree, tipdate

def name_tree_consistency(tree, tipdate):
    """SD (years) of the root date implied by each tip's NAME date minus its
    root-to-tip branch-length depth. ~0 => names agree with the BEAST timescale;
    large => the sampling dates in the labels do not match the inferred tree."""
    root = tree.seed_node
    vals = []
    for lf in root.leaf_iter():
        d = 0.0; n = lf
        while n is not root:
            d += n.edge.length; n = n.parent_node
        vals.append(tipdate[lf.taxon.label] - d)
    vals = np.array(vals)
    return float(vals.std()), float(np.abs(vals - np.median(vals)).max())

def beast_node_dates(tree, tipdate):
    """Read calendar dates off the BEAST time tree using its OWN branch-length
    structure (robust to label/tree date disagreements):
        depth(node)  = sum of branch lengths from root to node
        date(node)   = mrsd - (max_depth - depth(node))
    where mrsd (most-recent sampling date) is anchored at the maximum label date.
    This guarantees child nodes are younger than their parents and reproduces the
    name-based dates exactly when labels and tree agree (sd~0)."""
    mrsd = max(tipdate.values())
    depth = {}
    for nd in tree.preorder_node_iter():
        if nd.parent_node is None:
            depth[id(nd)] = 0.0
        else:
            depth[id(nd)] = depth[id(nd.parent_node)] + nd.edge.length
    max_depth = max(depth.values())
    return {k: mrsd - (max_depth - v) for k, v in depth.items()}

def beast_edge_table(tree, tipdate, all_acc):
    """For every edge (child node) return canonical clade -> (child_date, parent_date)."""
    nd_date = beast_node_dates(tree, tipdate)
    ref = sorted(all_acc)[0]
    edges = {}
    for nd in tree:
        if nd.parent_node is None:
            continue
        clade = frozenset(l.taxon.label for l in nd.leaf_iter())
        canon = clade if ref not in clade else frozenset(all_acc - clade)
        cdate = nd_date[id(nd)]
        pdate = nd_date[id(nd.parent_node)]
        # for the root split two edges share a bipartition; keep the one with older parent
        if canon in edges:
            if pdate > edges[canon][1]:
                edges[canon] = (cdate, pdate)
        else:
            edges[canon] = (cdate, pdate)
    return edges, nd_date

# ------------------------------------------------------------------ per-dataset driver
def datasets():
    out = []
    for j in sorted(glob.glob(os.path.join(MEME_DIR, "*.MEME.json"))):
        name = os.path.basename(j).replace(".MEME.json", "")
        tree = os.path.join(TREE_DIR, name + "_map.trees")
        if os.path.exists(tree):
            out.append((name, j, tree))
    return out

def run_dataset(name, jpath, tpath):
    subtype, gene, country = name.split("_")[0], name.split("_")[1], name.split("_")[2]
    meme = parse_meme(jpath)
    tree, tipdate = read_beast(tpath)
    all_acc = frozenset(tipdate.keys())
    mbip = meme_branch_bipartitions(meme['meme_tree'], all_acc)
    bedges, nd_date = beast_edge_table(tree, tipdate, all_acc)
    date_sd, date_maxdev = name_tree_consistency(tree, tipdate)

    rows = []
    matched = unmatched = 0
    for site, bname, ebf, post in meme['episodes']:
        canon = mbip.get(bname)
        if canon is None:
            rec_match = False
            cdate = pdate = mid = np.nan
        elif canon in bedges:
            cdate, pdate = bedges[canon]
            mid = 0.5 * (cdate + pdate)
            rec_match = True
        else:
            rec_match = False
            cdate = pdate = mid = np.nan
        if rec_match:
            matched += 1
        else:
            unmatched += 1
        clade_size = len(canon) if canon is not None else np.nan
        rows.append(dict(dataset=name, subtype=subtype, gene=gene, country=country,
                         codon_site=site, branch=bname,
                         clade_size=clade_size, matched=rec_match,
                         EBF=ebf, posterior=post,
                         child_date=cdate, parent_date=pdate, midpoint_date=mid))
    ep = pd.DataFrame(rows)

    # tree time span + tip dates for exposure computation
    info = dict(dataset=name, subtype=subtype, gene=gene, country=country,
                n_tips=len(all_acc), nsites=meme['nsites'],
                n_sig_sites=meme['n_sig_sites'],
                n_episodes=len(meme['episodes']),
                n_episodes_matched=int(matched),
                n_episodes_unmatched=int(unmatched),
                root_date=min(nd_date.values()),
                most_recent_tip=max(tipdate.values()),
                meme_branches=len(mbip),
                beast_edges=len(bedges),
                date_consistency_sd=date_sd,
                date_max_dev_yr=date_maxdev)
    # branch interval list (parent_date, child_date) for exposure
    intervals = []
    for nd in tree:
        if nd.parent_node is None:
            continue
        c = nd_date[id(nd)]; p = nd_date[id(nd.parent_node)]
        intervals.append((p, c))
    return ep, info, intervals, tipdate, nd_date

if __name__ == "__main__":
    all_ep, all_info, all_intervals = [], [], {}
    for name, j, tp in datasets():
        ep, info, intervals, tipdate, nd_date = run_dataset(name, j, tp)
        all_ep.append(ep)
        all_info.append(info)
        all_intervals[name] = intervals
        print(f"{name:28s} tips={info['n_tips']:3d} sigsites={info['n_sig_sites']:3d} "
              f"episodes={info['n_episodes']:4d} matched={info['n_episodes_matched']:4d} "
              f"unmatched={info['n_episodes_unmatched']:3d}")
    EP = pd.concat(all_ep, ignore_index=True)
    INFO = pd.DataFrame(all_info)
    EP.to_csv(os.path.join(OUT, "episodes_all_datasets.csv"), index=False)
    INFO.to_csv(os.path.join(OUT, "dataset_summary.csv"), index=False)
    # save intervals for the through-time step
    import pickle
    pickle.dump(all_intervals, open(os.path.join(OUT, "branch_intervals.pkl"), "wb"))
    print("\nTOTAL episodes:", len(EP), " matched:", int(EP['matched'].sum()),
          " unmatched:", int((~EP['matched']).sum()))
    print("Wrote episodes_all_datasets.csv, dataset_summary.csv")
