#!/usr/bin/env python3
"""
Through-time analysis: do episodes of MEME positive selection increase over time?
Per-dataset Poisson GLMs (normalized by available branch-length, and raw counts) +
pooled meta-analysis and pooled GLM contrasting HA vs NA and H1N1 vs H3N2.
"""
import os, pickle, warnings
import numpy as np, pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
from scipy import stats
warnings.filterwarnings("ignore")

OUT = os.environ.get("MBT_OUT", "./results")
BIN_W = 3.0                 # calendar-year bin width (common grid)
MIN_EP = 8                  # min matched episodes to attempt a per-dataset fit
DATE_SD_MAX = 0.5           # exclude datasets whose labels disagree with the tree

def load_episodes():
    EP = pd.read_csv(os.path.join(OUT, "episodes_all_datasets.csv"), keep_default_na=False)
    for c in ["clade_size", "EBF", "posterior", "child_date", "parent_date", "midpoint_date"]:
        EP[c] = pd.to_numeric(EP[c], errors="coerce")
    EP["matched"] = EP["matched"].astype(str).str.strip().eq("True")
    return EP

def bin_grid(lo, hi, w=BIN_W):
    a = np.floor(lo / w) * w
    edges = np.arange(a, hi + w, w)
    if len(edges) < 2:
        edges = np.array([a, a + w])
    return edges

def exposure_in_bins(intervals, edges):
    """branch-length (lineage-years) overlapping each bin. intervals=(parent,child) older->younger."""
    expo = np.zeros(len(edges) - 1)
    for (p, c) in intervals:                       # p<c
        for i in range(len(edges) - 1):
            a, b = edges[i], edges[i + 1]
            ov = min(b, c) - max(a, p)
            if ov > 0:
                expo[i] += ov
    return expo

def dataset_bins(name, ep_mid, intervals, root, mrt):
    edges = bin_grid(root, mrt)
    mids = 0.5 * (edges[:-1] + edges[1:])
    expo = exposure_in_bins(intervals, edges)
    counts, _ = np.histogram(ep_mid, bins=edges)
    df = pd.DataFrame(dict(bin_mid=mids, count=counts, exposure=expo))
    df = df[df.exposure > 0].reset_index(drop=True)
    df["dataset"] = name
    return df

def fit_poisson(df, offset=True):
    """Return slope(per yr, log-rate), se, z, p, and LRT p vs null."""
    d = df.copy()
    d["yr"] = d["bin_mid"] - d["bin_mid"].mean()
    try:
        if offset:
            off = np.log(d["exposure"].values)
            m = sm.GLM(d["count"].values, sm.add_constant(d["yr"].values),
                       family=sm.families.Poisson(), offset=off).fit()
            m0 = sm.GLM(d["count"].values, np.ones((len(d), 1)),
                        family=sm.families.Poisson(), offset=off).fit()
        else:
            m = sm.GLM(d["count"].values, sm.add_constant(d["yr"].values),
                       family=sm.families.Poisson()).fit()
            m0 = sm.GLM(d["count"].values, np.ones((len(d), 1)),
                        family=sm.families.Poisson()).fit()
        b = m.params[1]; se = m.bse[1]; z = b / se
        p = 2 * stats.norm.sf(abs(z))
        lr = 2 * (m.llf - m0.llf)
        plr = stats.chi2.sf(lr, 1)
        return dict(slope=b, se=se, z=z, p=p, lrt_p=plr, n_bins=len(d))
    except Exception as e:
        return dict(slope=np.nan, se=np.nan, z=np.nan, p=np.nan, lrt_p=np.nan,
                    n_bins=len(d), err=str(e))

def main():
    EP = load_episodes()
    INFO = pd.read_csv(os.path.join(OUT, "dataset_summary.csv"), keep_default_na=False)
    INFO["date_consistency_sd"] = pd.to_numeric(INFO["date_consistency_sd"], errors="coerce")
    intervals = pickle.load(open(os.path.join(OUT, "branch_intervals.pkl"), "rb"))
    info = INFO.set_index("dataset")

    per_rows, all_bins = [], []
    for name in sorted(EP.dataset.unique()):
        sub = EP[(EP.dataset == name) & (EP.matched)]
        r = info.loc[name]
        reliable = float(r.date_consistency_sd) <= DATE_SD_MAX
        df = dataset_bins(name, sub.midpoint_date.values, intervals[name],
                          float(r.root_date), float(r.most_recent_tip))
        df["gene"] = name.split("_")[1]
        df["subtype"] = name.split("_")[0]
        df["reliable"] = reliable
        all_bins.append(df)
        n_ep = len(sub)
        row = dict(dataset=name, subtype=name.split("_")[0], gene=name.split("_")[1],
                   country=name.split("_")[2], n_episodes=n_ep, reliable=reliable,
                   date_sd=float(r.date_consistency_sd))
        if reliable and n_ep >= MIN_EP and (df["count"] > 0).sum() >= 3:
            fn = fit_poisson(df, offset=True)
            fr = fit_poisson(df, offset=False)
            row.update(norm_slope=fn["slope"], norm_se=fn["se"], norm_p=fn["p"],
                       norm_lrt_p=fn["lrt_p"],
                       raw_slope=fr["slope"], raw_se=fr["se"], raw_p=fr["p"],
                       n_bins=fn["n_bins"], fitted=True)
        else:
            row.update(norm_slope=np.nan, norm_se=np.nan, norm_p=np.nan, norm_lrt_p=np.nan,
                       raw_slope=np.nan, raw_se=np.nan, raw_p=np.nan,
                       n_bins=int((df["count"] > 0).sum()), fitted=False)
        per_rows.append(row)

    PER = pd.DataFrame(per_rows)
    BINS = pd.concat(all_bins, ignore_index=True)
    PER.to_csv(os.path.join(OUT, "per_dataset_trends.csv"), index=False)
    BINS.to_csv(os.path.join(OUT, "time_bins_all.csv"), index=False)

    # ---------------- meta-analysis of normalized slopes ----------------
    def meta(sub):
        s = sub.dropna(subset=["norm_slope", "norm_se"])
        s = s[s.norm_se > 0]
        if len(s) == 0:
            return None
        b = s.norm_slope.values; se = s.norm_se.values
        w = 1.0 / se**2
        b_fe = np.sum(w * b) / np.sum(w)
        se_fe = np.sqrt(1.0 / np.sum(w))
        # DerSimonian-Laird random effects
        Q = np.sum(w * (b - b_fe)**2)
        k = len(s); C = np.sum(w) - np.sum(w**2) / np.sum(w)
        tau2 = max(0.0, (Q - (k - 1)) / C) if C > 0 else 0.0
        wr = 1.0 / (se**2 + tau2)
        b_re = np.sum(wr * b) / np.sum(wr); se_re = np.sqrt(1.0 / np.sum(wr))
        z_fe = b_fe / se_fe; z_re = b_re / se_re
        npos = int(np.sum(b > 0)); nneg = int(np.sum(b < 0))
        sign_p = stats.binomtest(npos, k, 0.5).pvalue if k > 0 else np.nan
        # Stouffer (signed z), equal weights
        zi = b / se
        Zst = np.sum(zi) / np.sqrt(k)
        st_p = 2 * stats.norm.sf(abs(Zst))
        return dict(k=k, b_fe=b_fe, se_fe=se_fe, p_fe=2*stats.norm.sf(abs(z_fe)),
                    b_re=b_re, se_re=se_re, p_re=2*stats.norm.sf(abs(z_re)),
                    I2=max(0, (Q-(k-1))/Q*100) if Q > 0 else 0.0, tau2=tau2,
                    n_pos=npos, n_neg=nneg, sign_p=sign_p, stouffer_Z=Zst, stouffer_p=st_p)

    fitted = PER[PER.fitted]
    meta_rows = []
    for label, sub in [("ALL", fitted),
                       ("HA", fitted[fitted.gene == "HA"]),
                       ("NA", fitted[fitted.gene == "NA"]),
                       ("H1N1", fitted[fitted.subtype == "H1N1"]),
                       ("H3N2", fitted[fitted.subtype == "H3N2"])]:
        m = meta(sub)
        if m:
            m = {"group": label, **m}
            meta_rows.append(m)
    META = pd.DataFrame(meta_rows)
    META.to_csv(os.path.join(OUT, "meta_analysis.csv"), index=False)

    # ---------------- pooled GLM with interactions ----------------
    B = BINS[BINS.reliable].copy()
    B = B[B.exposure > 0]
    B["yr"] = B["bin_mid"] - 2000.0
    B["logE"] = np.log(B["exposure"])
    pooled_txt = []
    pooled_json = {}
    try:
        mfull = smf.glm("count ~ yr * gene + yr * subtype + C(dataset)",
                        data=B, family=sm.families.Poisson(), offset=B["logE"]).fit()
        pooled_txt.append("=== Pooled Poisson GLM: count ~ yr*gene + yr*subtype + C(dataset), offset=log(branch-length) ===")
        for term in ["yr", "yr:gene[T.NA]", "yr:subtype[T.H3N2]", "gene[T.NA]", "subtype[T.H3N2]"]:
            if term in mfull.params.index:
                pooled_txt.append(f"  {term:24s} beta={mfull.params[term]:+.5f}  "
                                  f"SE={mfull.bse[term]:.5f}  p={mfull.pvalues[term]:.3g}")
                pooled_json[term] = dict(beta=float(mfull.params[term]),
                                         se=float(mfull.bse[term]),
                                         p=float(mfull.pvalues[term]))
        pooled_txt.append(f"  [yr = per-year change in log episode-rate per lineage-year; "
                          f"reference gene=HA, subtype=H1N1]")
    except Exception as e:
        pooled_txt.append("pooled full GLM failed: " + str(e))
    import json as _json
    _json.dump(pooled_json, open(os.path.join(OUT, "pooled_glm.json"), "w"), indent=1)

    # group-specific pooled trend (separate offset GLM per gene & per subtype)
    pooled_txt.append("\n=== Group-specific pooled trends (count ~ yr + C(dataset), offset=log branch-length) ===")
    grp_rows = []
    for col, val in [("gene", "HA"), ("gene", "NA"), ("subtype", "H1N1"), ("subtype", "H3N2")]:
        d = B[B[col] == val]
        try:
            mm = smf.glm("count ~ yr + C(dataset)", data=d,
                         family=sm.families.Poisson(), offset=d["logE"]).fit()
            b, se, p = mm.params["yr"], mm.bse["yr"], mm.pvalues["yr"]
            pct = (np.exp(b) - 1) * 100
            pooled_txt.append(f"  {val:5s}: yr beta={b:+.5f} SE={se:.5f} p={p:.3g}  "
                              f"=> {pct:+.1f}% change in episode-rate per year")
            grp_rows.append(dict(group=val, beta=b, se=se, p=p, pct_per_yr=pct))
        except Exception as e:
            pooled_txt.append(f"  {val}: failed ({e})")
    pd.DataFrame(grp_rows).to_csv(os.path.join(OUT, "pooled_group_trends.csv"), index=False)

    open(os.path.join(OUT, "pooled_glm.txt"), "w").write("\n".join(pooled_txt))

    # ---------------- console summary ----------------
    print("Per-dataset fits (reliable, n>=%d): %d / %d datasets" %
          (MIN_EP, int(PER.fitted.sum()), len(PER)))
    print("Excluded for unreliable dates:",
          PER[~PER.reliable].dataset.tolist())
    print("\nNormalized-rate slope direction among fitted datasets:")
    print("  positive:", int((fitted.norm_slope > 0).sum()),
          " negative:", int((fitted.norm_slope < 0).sum()),
          " p<0.05:", int((fitted.norm_p < 0.05).sum()))
    print("\n=== META-ANALYSIS (normalized slopes) ===")
    print(META.to_string(index=False))
    print("\n" + "\n".join(pooled_txt))

if __name__ == "__main__":
    main()
