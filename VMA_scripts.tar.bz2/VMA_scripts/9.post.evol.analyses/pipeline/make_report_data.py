#!/usr/bin/env python3
"""Compile all numbers needed by build_report.js into report_data.json (env-driven)."""
import os, json
import pandas as pd, numpy as np

OUT = os.environ.get("MBT_OUT", "./results")
TAG = os.environ.get("MBT_TAG", "")

def rd(name): return pd.read_csv(os.path.join(OUT, name), keep_default_na=False)

PER = rd("per_dataset_trends.csv")
for c in ["n_episodes","norm_slope","norm_se","norm_p","raw_slope","raw_se","raw_p","date_sd"]:
    PER[c] = pd.to_numeric(PER[c], errors="coerce")
PER["fitted"]   = PER["fitted"].astype(str).str.strip().eq("True")
PER["reliable"] = PER["reliable"].astype(str).str.strip().eq("True")

EP = rd("episodes_all_datasets.csv")
EP["matched"]    = EP["matched"].astype(str).str.strip().eq("True")
EP["clade_size"] = pd.to_numeric(EP["clade_size"], errors="coerce")

INFO = rd("dataset_summary.csv")
INFO["date_consistency_sd"] = pd.to_numeric(INFO["date_consistency_sd"], errors="coerce")
INFO["date_max_dev_yr"]     = pd.to_numeric(INFO["date_max_dev_yr"], errors="coerce")

META = rd("meta_analysis.csv")
for c in META.columns:
    if c != "group": META[c] = pd.to_numeric(META[c], errors="coerce")
GRP = rd("pooled_group_trends.csv")
for c in GRP.columns:
    if c != "group": GRP[c] = pd.to_numeric(GRP[c], errors="coerce")

pooled = json.load(open(os.path.join(OUT, "pooled_glm.json"))) if os.path.exists(os.path.join(OUT,"pooled_glm.json")) else {}
rob    = json.load(open(os.path.join(OUT, "robustness.json"))) if os.path.exists(os.path.join(OUT,"robustness.json")) else {}

tot_ep  = len(EP); matched = int(EP.matched.sum()); unm = tot_ep - matched
term    = int((EP.clade_size == 1).sum()); intern = int((EP.clade_size > 1).sum())

# excluded datasets (label/tree date mismatch)
excl = INFO[INFO.date_consistency_sd > 0.5][["dataset","date_max_dev_yr"]]
excluded = [dict(dataset=r.dataset.replace("_"," "), max_dev=round(float(r.date_max_dev_yr),0)) for _,r in excl.iterrows()]

# most-discordant dataset (most unmatched episodes)
by_ds = (rob.get("unmatched") or {}).get("by_dataset", {})
top_discordant = None
if by_ds:
    k = max(by_ds, key=by_ds.get)
    top_discordant = dict(dataset=k.replace("_"," "), n=int(by_ds[k]))

def metarow(g):
    sub = META[META.group == g]
    if len(sub) == 0: return None
    m = sub.iloc[0]
    return dict(k=int(m.k), b_re=float(m.b_re), se_re=float(m.se_re), p_re=float(m.p_re),
                p_fe=float(m.p_fe), I2=float(m.I2), n_pos=int(m.n_pos), n_neg=int(m.n_neg),
                sign_p=float(m.sign_p), stouffer_Z=float(m.stouffer_Z), stouffer_p=float(m.stouffer_p))

PER2 = PER.sort_values(["subtype","gene","country"])
rows = [dict(dataset=r.dataset.replace("_"," "), n=int(r.n_episodes),
             norm_slope=None if pd.isna(r.norm_slope) else round(float(r.norm_slope),4),
             norm_p=None if pd.isna(r.norm_p) else float(r.norm_p),
             raw_slope=None if pd.isna(r.raw_slope) else round(float(r.raw_slope),4),
             fitted=bool(r.fitted), reliable=bool(r.reliable)) for _, r in PER2.iterrows()]

fitted = PER[PER.fitted]
data = dict(
    tag=TAG,
    n_datasets_total=int(EP.dataset.nunique()),
    genes=sorted(EP.gene.unique().tolist()), subtypes=sorted(EP.subtype.unique().tolist()),
    countries=int(EP.country.nunique()),
    tot_ep=tot_ep, matched=matched, unm=unm, match_pct=round(100*matched/max(tot_ep,1),1),
    term=term, intern=intern, term_pct=round(100*term/max(tot_ep,1),1),
    n_fitted=int(PER.fitted.sum()),
    n_pos=int((fitted.norm_slope > 0).sum()),
    n_neg=int((fitted.norm_slope < 0).sum()),
    n_sig=int((fitted.norm_p < 0.05).sum()),
    meta={g: metarow(g) for g in ["ALL","HA","NA","H1N1","H3N2"]},
    grp={str(r.group): dict(beta=float(r.beta), se=float(r.se), p=float(r.p), pct=float(r.pct_per_yr))
         for _, r in GRP.iterrows()},
    pooled=pooled, robustness=rob,
    excluded=excluded, top_discordant=top_discordant,
    per_rows=rows,
)
json.dump(data, open(os.path.join(OUT, "report_data.json"), "w"), indent=1)

PER2[["dataset","subtype","gene","country","n_episodes","reliable","fitted",
      "norm_slope","norm_se","norm_p","raw_slope","raw_se","raw_p"]].to_csv(
      os.path.join(OUT, "per_dataset_trends_clean.csv"), index=False)

print(f"[{TAG}] datasets={data['n_datasets_total']} episodes={tot_ep} matched={matched} "
      f"({data['match_pct']}%) fitted={data['n_fitted']} pos/neg={data['n_pos']}/{data['n_neg']} "
      f"excluded={[e['dataset'] for e in excluded]}")
