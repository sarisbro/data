#!/usr/bin/env python3
"""Robustness checks for the 'episodes increase through time' result."""
import os, pickle, warnings
import numpy as np, pandas as pd
import statsmodels.api as sm
from scipy import stats
warnings.filterwarnings("ignore")
import analysis_through_time as A

OUT = A.OUT
EP = A.load_episodes()
INFO = pd.read_csv(os.path.join(OUT, "dataset_summary.csv"), keep_default_na=False)
INFO["date_consistency_sd"] = pd.to_numeric(INFO["date_consistency_sd"], errors="coerce")
info = INFO.set_index("dataset")
intervals = pickle.load(open(os.path.join(OUT, "branch_intervals.pkl"), "rb"))

def bins_w(name, ep_mid, ivs, root, mrt, w):
    edges = np.arange(np.floor(root / w) * w, mrt + w, w)
    if len(edges) < 2:
        edges = np.array([np.floor(root/w)*w, np.floor(root/w)*w + w])
    mids = 0.5 * (edges[:-1] + edges[1:])
    expo = A.exposure_in_bins(ivs, edges)
    counts, _ = np.histogram(ep_mid, bins=edges)
    df = pd.DataFrame(dict(bin_mid=mids, count=counts, exposure=expo))
    return df[df.exposure > 0].reset_index(drop=True)

def run_meta(which="all", binw=3.0, offset=True, min_ep=8):
    rows = []
    for name in sorted(EP.dataset.unique()):
        r = info.loc[name]
        if float(r.date_consistency_sd) > 0.5:      # exclude unreliable (thailand HA)
            continue
        sub = EP[(EP.dataset == name) & (EP.matched)].copy()
        if which == "internal":
            sub = sub[sub.clade_size > 1]
        elif which == "terminal":
            sub = sub[sub.clade_size == 1]
        if len(sub) < min_ep:
            continue
        df = bins_w(name, sub.midpoint_date.values, intervals[name],
                    float(r.root_date), float(r.most_recent_tip), binw)
        if (df["count"] > 0).sum() < 3:
            continue
        fit = A.fit_poisson(df, offset=offset)
        if np.isfinite(fit["slope"]) and np.isfinite(fit["se"]) and fit["se"] > 0:
            rows.append((name, fit["slope"], fit["se"], fit["p"]))
    if not rows:
        return None
    b = np.array([x[1] for x in rows]); se = np.array([x[2] for x in rows])
    w = 1 / se**2
    b_fe = np.sum(w * b) / np.sum(w); se_fe = np.sqrt(1 / np.sum(w))
    z = b_fe / se_fe; p = 2 * stats.norm.sf(abs(z))
    npos = int(np.sum(b > 0)); k = len(b)
    sign_p = stats.binomtest(npos, k, 0.5).pvalue
    return dict(k=k, b_fe=b_fe, se_fe=se_fe, p=p, n_pos=npos, sign_p=sign_p)

print("ROBUSTNESS OF THE TEMPORAL TREND (meta-analysis of normalized per-dataset slopes)\n")
print(f"{'scenario':40s} {'k':>3s} {'slope/yr':>9s} {'p':>11s} {'pos/k':>7s} {'sign_p':>9s}")
scen = [
    ("All episodes, 3-yr bins, normalized",      dict(which="all", binw=3.0, offset=True)),
    ("All episodes, 2-yr bins, normalized",      dict(which="all", binw=2.0, offset=True)),
    ("All episodes, 5-yr bins, normalized",      dict(which="all", binw=5.0, offset=True)),
    ("All episodes, 3-yr bins, RAW counts",      dict(which="all", binw=3.0, offset=False)),
    ("INTERNAL-branch episodes only, normalized",dict(which="internal", binw=3.0, offset=True, min_ep=6)),
    ("TERMINAL-branch episodes only, normalized",dict(which="terminal", binw=3.0, offset=True, min_ep=6)),
]
import json
rob = {}
keymap = {
    "All episodes, 3-yr bins, normalized": "all_3yr",
    "All episodes, 2-yr bins, normalized": "all_2yr",
    "All episodes, 5-yr bins, normalized": "all_5yr",
    "All episodes, 3-yr bins, RAW counts": "raw",
    "INTERNAL-branch episodes only, normalized": "internal",
    "TERMINAL-branch episodes only, normalized": "terminal",
}
for label, kw in scen:
    m = run_meta(**kw)
    if m:
        print(f"{label:40s} {m['k']:3d} {m['b_fe']:+9.4f} {m['p']:11.2e} "
              f"{m['n_pos']:3d}/{m['k']:<3d} {m['sign_p']:9.2e}")
        rob[keymap[label]] = dict(k=int(m['k']), slope=float(m['b_fe']), p=float(m['p']),
                                  n_pos=int(m['n_pos']), sign_p=float(m['sign_p']))
    else:
        print(f"{label:40s}  (insufficient data)")
        rob[keymap[label]] = None

A.BIN_W = 3.0
# temporal distribution of the 39 unmatched episodes vs matched
m = EP[EP.matched]; u = EP[~EP.matched]
print("\nUnmatched episodes (topological discordance): %d (%.1f%% of all)" %
      (len(u), 100*len(u)/len(EP)))
print("  by dataset:", u.dataset.value_counts().to_dict())
# unmatched have no date; check their clade sizes / which datasets
print("  all unmatched are internal-branch (clade_size>1):", bool((u.clade_size>1).all()))

# raw vs normalized per-dataset comparison
PER = pd.read_csv(os.path.join(OUT, "per_dataset_trends.csv"), keep_default_na=False)
for c in ["norm_slope","raw_slope"]:
    PER[c]=pd.to_numeric(PER[c],errors="coerce")
f=PER[PER.fitted.astype(str)=="True"] if PER.fitted.dtype==object else PER[PER.fitted]
print("\nRaw vs normalized slopes (fitted datasets): median raw=%.4f  median norm=%.4f" %
      (f.raw_slope.median(), f.norm_slope.median()))
print("  => raw slope steeper than normalized in %d/%d datasets (lineage growth inflates raw)" %
      (int((f.raw_slope>f.norm_slope).sum()), len(f)))

rob["unmatched"] = dict(n=int(len(u)), pct=round(100*len(u)/max(len(EP),1),1),
                        by_dataset=u.dataset.value_counts().to_dict(),
                        all_internal=bool((u.clade_size>1).all()) if len(u) else True)
rob["raw_vs_norm"] = dict(median_raw=float(f.raw_slope.median()) if len(f) else None,
                          median_norm=float(f.norm_slope.median()) if len(f) else None,
                          raw_steeper=int((f.raw_slope>f.norm_slope).sum()), n_fitted=int(len(f)))
json.dump(rob, open(os.path.join(OUT, "robustness.json"), "w"), indent=1)
print("\nwrote robustness.json")
