#!/usr/bin/env python3
"""Figures summarising the robustness analyses across the four sampling schemes."""
import json, math, os
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
from scipy import stats

BASE=os.environ.get("MBT_ROOT", ".")
OUT=f"{BASE}/robustness_fig"; os.makedirs(OUT, exist_ok=True)
SCH=[("99_cdhit","CD-HIT 99%","#1b9e77"),("99.7_cdhit","CD-HIT 99.7%","#d95f02"),
     ("99_random","Random 99%","#7570b3"),("99.7_random","Random 99.7%","#e7298a")]
R={tag:json.load(open(f"{BASE}/run_{tag}/results/robustness.json")) for tag,_,_ in SCH}

def pct(b): return (math.exp(b)-1)*100
def ci(s):
    """return (pct, lo_pct, hi_pct) using SE reconstructed from slope & p (normal z)."""
    b=s["slope"]; p=max(s["p"],1e-300)
    z=stats.norm.ppf(1-p/2)
    se=abs(b)/z if z>0 else 0.0
    return pct(b), pct(b-1.96*se), pct(b+1.96*se)

plt.rcParams.update({"font.size":9,"axes.spines.top":False,"axes.spines.right":False,
                     "figure.dpi":150,"savefig.bbox":"tight","font.family":"DejaVu Sans"})
fig,ax=plt.subplots(1,3,figsize=(11.5,3.9))

# (a) time-bin width
widths=[("all_2yr",2),("all_3yr",3),("all_5yr",5)]
for tag,lab,col in SCH:
    ys=[pct(R[tag][k]["slope"]) for k,_ in widths]
    ax[0].plot([w for _,w in widths], ys, "-o", color=col, ms=5, label=lab)
ax[0].set_xticks([2,3,5]); ax[0].set_xlabel("Time-bin width (years)")
ax[0].set_ylabel("Increase in episode rate (% / year)")
ax[0].set_title("(a) Time-bin width", fontsize=10, loc="left")
ax[0].set_ylim(0, None); ax[0].legend(frameon=False, fontsize=7)

# (b) branch class: All / Internal / Terminal
classes=[("all_3yr","All","#666666"),("internal","Internal","#2c7fb8"),("terminal","Terminal","#d95f0e")]
xt=np.arange(len(SCH)); off={"all_3yr":-0.22,"internal":0.0,"terminal":0.22}
for key,clab,ccol in classes:
    for i,(tag,lab,col) in enumerate(SCH):
        s=R[tag][key]; p,lo,hi=ci(s)
        x=xt[i]+off[key]
        sig = s["p"]<0.05
        ax[1].errorbar(x,p,yerr=[[p-lo],[hi-p]],fmt="o",ms=5,color=ccol,ecolor=ccol,
                       elinewidth=1,capsize=2,mfc=ccol if sig else "white",mec=ccol)
ax[1].axhline(0,color="0.6",lw=1,ls="--")
ax[1].set_xticks(xt); ax[1].set_xticklabels([l for _,l,_ in SCH],rotation=20,ha="right",fontsize=7.5)
ax[1].set_ylabel("Increase in episode rate (% / year)")
ax[1].set_title("(b) Branch class", fontsize=10, loc="left")
hb=[mlines.Line2D([],[],marker="o",ls="",color=c,label=l) for _,l,c in classes]
hb.append(mlines.Line2D([],[],marker="o",ls="",mfc="white",mec="0.4",color="0.4",label="open = n.s."))
ax[1].legend(handles=hb,frameon=False,fontsize=7,loc="upper right")

# (c) raw vs normalized
for i,(tag,lab,col) in enumerate(SCH):
    pn,lon,hin=ci(R[tag]["all_3yr"]); pr,lor,hir=ci(R[tag]["raw"])
    ax[2].errorbar(i-0.12,pn,yerr=[[pn-lon],[hin-pn]],fmt="s",ms=5,color="#3182bd",capsize=2,elinewidth=1)
    ax[2].errorbar(i+0.12,pr,yerr=[[pr-lor],[hir-pr]],fmt="D",ms=5,color="#cb181d",capsize=2,elinewidth=1)
ax[2].axhline(0,color="0.6",lw=1,ls="--")
ax[2].set_xticks(range(len(SCH))); ax[2].set_xticklabels([l for _,l,_ in SCH],rotation=20,ha="right",fontsize=7.5)
ax[2].set_ylabel("Increase in episode rate (% / year)")
ax[2].set_title("(c) Raw vs normalized", fontsize=10, loc="left")
ax[2].legend(handles=[mlines.Line2D([],[],marker="s",ls="",color="#3182bd",label="Normalized"),
                      mlines.Line2D([],[],marker="D",ls="",color="#cb181d",label="Raw counts")],
             frameon=False,fontsize=7,loc="upper left")
fig.tight_layout()
fig.savefig(f"{OUT}/figure_robustness.png",dpi=200)
fig.savefig(f"{OUT}/figure_robustness.pdf")
print("wrote",f"{OUT}/figure_robustness.png")
