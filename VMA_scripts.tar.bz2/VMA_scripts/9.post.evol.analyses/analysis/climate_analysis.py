#!/usr/bin/env python3
"""Country-level climate test: does the rate / temporal slope of episodic positive
selection depend on latitude or mean temperature, after controlling for sampling
(n_tips) and calendar time?  Tropical vs temperate comparison included.

Design notes
------------
* Unit = dataset (gene x subtype x country x sampling-scheme). Schemes reuse the
  same underlying sequences, so all between-dataset models use country-CLUSTERED
  robust SE (12 clusters); we also run a country-collapsed Spearman/Mann-Whitney
  (n=12) which is fully non-pseudoreplicated but low power.
* Episode rate is modelled as Poisson counts with offset = log(branch-length
  exposure); sampling is controlled with log(n_tips); time with the exposure-
  weighted mean year. Latitude/temperature/zone are the country-level predictors.
* Climate proxies are coarse population-centroid values (documented below).
"""
import os, json, warnings
import numpy as np, pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
from scipy import stats
warnings.filterwarnings("ignore")

BASE = os.environ.get("MBT_ROOT", ".")
OUT  = f"{BASE}/climate"; os.makedirs(OUT, exist_ok=True)
SCHEMES = ["99_cdhit","99.7_cdhit","99_random","99.7_random"]

# Representative population-centroid latitude (deg), approx mean annual temp (C),
# Koppen-ish zone. Coarse proxies, documented as a limitation.
CLIM = {
 "brazil":      dict(lat=-20, temp=23, zone="tropical"),
 "canada":      dict(lat= 50, temp= 4, zone="temperate"),
 "chile":       dict(lat=-33, temp=14, zone="temperate"),
 "china":       dict(lat= 34, temp=14, zone="temperate"),
 "india":       dict(lat= 22, temp=25, zone="tropical"),
 "italy":       dict(lat= 43, temp=14, zone="temperate"),
 "japan":       dict(lat= 36, temp=13, zone="temperate"),
 "netherlands": dict(lat= 52, temp=10, zone="temperate"),
 "russia":      dict(lat= 56, temp= 5, zone="temperate"),
 "singapore":   dict(lat=1.4, temp=27, zone="tropical"),
 "thailand":    dict(lat= 15, temp=27, zone="tropical"),
 "usa":         dict(lat= 38, temp=12, zone="temperate"),
}

def load_scheme(tag):
    b = pd.read_csv(f"{BASE}/run_{tag}/results/time_bins_all.csv", keep_default_na=False)
    for c in ["bin_mid","count","exposure"]:
        b[c] = pd.to_numeric(b[c], errors="coerce")
    b["reliable"] = b["reliable"].astype(str).str.strip().eq("True")
    b = b[(b.reliable) & (b.exposure > 0)].copy()
    summ = pd.read_csv(f"{BASE}/run_{tag}/results/dataset_summary.csv", keep_default_na=False)
    summ["n_tips"] = pd.to_numeric(summ["n_tips"], errors="coerce")
    per = pd.read_csv(f"{BASE}/run_{tag}/results/per_dataset_trends_clean.csv", keep_default_na=False)
    for c in ["norm_slope","norm_se"]:
        per[c] = pd.to_numeric(per[c], errors="coerce")
    per["fitted"] = per["fitted"].astype(str).str.strip().eq("True")
    rows = []
    for ds, g in b.groupby("dataset"):
        tot_c = g["count"].sum(); tot_e = g["exposure"].sum()
        mean_year = float((g["bin_mid"]*g["exposure"]).sum()/tot_e)
        sub, gene, country = ds.split("_")[0], ds.split("_")[1], ds.split("_")[2]
        ntip = summ.loc[summ.dataset==ds, "n_tips"]
        prow = per[per.dataset==ds]
        rows.append(dict(scheme=tag, dataset=ds, subtype=sub, gene=gene, country=country,
                         total_count=int(tot_c), total_exposure=float(tot_e),
                         rate=float(tot_c/tot_e), mean_year=mean_year,
                         n_tips=int(ntip.iloc[0]) if len(ntip) else np.nan,
                         norm_slope=float(prow.norm_slope.iloc[0]) if len(prow) and prow.fitted.iloc[0] else np.nan,
                         norm_se=float(prow.norm_se.iloc[0]) if len(prow) and prow.fitted.iloc[0] else np.nan))
    return pd.DataFrame(rows)

D = pd.concat([load_scheme(t) for t in SCHEMES], ignore_index=True)
D = D[D.country.isin(CLIM)].copy()
D["lat"]    = D.country.map(lambda c: CLIM[c]["lat"])
D["abslat"] = D.lat.abs()
D["temp"]   = D.country.map(lambda c: CLIM[c]["temp"])
D["zone"]   = D.country.map(lambda c: CLIM[c]["zone"])
D["tropical"] = (D.zone=="tropical").astype(int)
D["log_ntips"] = np.log(D.n_tips)
D["log_rate"]  = np.log(D.rate.replace(0,np.nan))
D["yr_c"] = D.mean_year - 2000
D["ccode"] = D.country.astype("category").cat.codes
D.to_csv(f"{OUT}/dataset_climate_table.csv", index=False)

print(f"datasets used: {len(D)} across {D.country.nunique()} countries, {D.scheme.nunique()} schemes")
print(f"tropical datasets: {int((D.tropical==1).sum())}  temperate: {int((D.tropical==0).sum())}")

# ---- CONFOUND CHECK: is sampling (n_tips) related to latitude? ----
print("\n=== CONFOUND CHECK: sampling vs climate ===")
cc = D.groupby("country").agg(abslat=("abslat","first"), temp=("temp","first"),
                              zone=("zone","first"), mean_ntips=("n_tips","mean")).reset_index()
rho,p = stats.spearmanr(cc.abslat, cc.mean_ntips)
print(f"  per-country mean n_tips vs abs latitude: Spearman rho={rho:+.2f}, p={p:.3f}")
print(f"  mean n_tips tropical={cc.loc[cc.zone=='tropical','mean_ntips'].mean():.0f}  "
      f"temperate={cc.loc[cc.zone=='temperate','mean_ntips'].mean():.0f}")

res = {}

# ============ MODEL 1: episode RATE vs climate (Poisson, offset, clustered) ============
print("\n=== MODEL 1: episode rate (Poisson, offset=log exposure; cluster SE by country) ===")
def poiss(pred):
    f = f"total_count ~ {pred} + log_ntips + yr_c + C(gene) + C(subtype) + C(scheme)"
    m = smf.glm(f, data=D, family=sm.families.Poisson(),
                offset=np.log(D["total_exposure"])).fit(cov_type="cluster",
                cov_kwds={"groups": D["ccode"]})
    return m
for pred in ["abslat","temp","tropical"]:
    m = poiss(pred)
    b,se,p = m.params[pred], m.bse[pred], m.pvalues[pred]
    print(f"  {pred:8s}: beta={b:+.4f}  SE={se:.4f}  p={p:.3f}  "
          f"(rate x{np.exp(b):.3f} per unit)")
    res[f"rate_{pred}"] = dict(beta=float(b), se=float(se), p=float(p))

# ============ MODEL 2: temporal SLOPE vs climate (WLS, inverse-variance, clustered) ============
print("\n=== MODEL 2: per-dataset temporal slope (WLS 1/se^2; cluster SE by country) ===")
Ds = D.dropna(subset=["norm_slope","norm_se"]).copy()
Ds = Ds[Ds.norm_se>0]
Ds["w"] = 1.0/Ds.norm_se**2
print(f"  fitted datasets: {len(Ds)} across {Ds.country.nunique()} countries")
def wls(pred):
    f = f"norm_slope ~ {pred} + log_ntips + C(gene) + C(subtype) + C(scheme)"
    m = smf.wls(f, data=Ds, weights=Ds["w"]).fit(cov_type="cluster",
              cov_kwds={"groups": Ds["ccode"]})
    return m
for pred in ["abslat","temp","tropical"]:
    m = wls(pred)
    b,se,p = m.params[pred], m.bse[pred], m.pvalues[pred]
    print(f"  {pred:8s}: beta={b:+.5f}  SE={se:.5f}  p={p:.3f}")
    res[f"slope_{pred}"] = dict(beta=float(b), se=float(se), p=float(p))

# ============ COUNTRY-COLLAPSED (n=12, non-pseudoreplicated) ============
print("\n=== COUNTRY-COLLAPSED (n=12 countries): Spearman & tropical-vs-temperate ===")
cco = D.groupby("country").agg(abslat=("abslat","first"), temp=("temp","first"),
        zone=("zone","first"), log_rate=("log_rate","mean"),
        rate=("rate","mean"), ntips=("n_tips","mean")).reset_index()
cslope = Ds.groupby("country").apply(
    lambda g: np.average(g.norm_slope, weights=g.w)).rename("slope").reset_index()
cco = cco.merge(cslope, on="country", how="left")
cco.to_csv(f"{OUT}/country_summary.csv", index=False)
for yvar in ["log_rate","slope"]:
    sub = cco.dropna(subset=[yvar])
    rho_l,p_l = stats.spearmanr(sub.abslat, sub[yvar])
    rho_t,p_t = stats.spearmanr(sub.temp,   sub[yvar])
    print(f"  {yvar:9s} vs abslat: rho={rho_l:+.2f} p={p_l:.3f} | vs temp: rho={rho_t:+.2f} p={p_t:.3f} (n={len(sub)})")
    res[f"collapsed_{yvar}_abslat"] = dict(rho=float(rho_l), p=float(p_l))
    res[f"collapsed_{yvar}_temp"]   = dict(rho=float(rho_t), p=float(p_t))

print("\n=== TROPICAL vs TEMPERATE (dataset-level Mann-Whitney) ===")
for yvar,label in [("log_rate","log episode rate"),("rate","episode rate"),("norm_slope","temporal slope")]:
    src = Ds if yvar=="norm_slope" else D
    a = src.loc[src.tropical==1, yvar].dropna()
    b = src.loc[src.tropical==0, yvar].dropna()
    u,p = stats.mannwhitneyu(a, b, alternative="two-sided")
    print(f"  {label:18s}: tropical median={np.median(a):+.4f} (n={len(a)})  "
          f"temperate median={np.median(b):+.4f} (n={len(b)})  MWU p={p:.3f}")
    res[f"mwu_{yvar}"] = dict(trop_median=float(np.median(a)), temp_median=float(np.median(b)),
                              p=float(p), n_trop=int(len(a)), n_temp=int(len(b)))

res["sampling_confound"] = dict(rho_ntips_abslat=float(rho), p=float(p),
    mean_ntips_tropical=float(cc.loc[cc.zone=='tropical','mean_ntips'].mean()),
    mean_ntips_temperate=float(cc.loc[cc.zone=='temperate','mean_ntips'].mean()))
json.dump(res, open(f"{OUT}/climate_results.json","w"), indent=1)
print("\nwrote", f"{OUT}/climate_results.json,  dataset_climate_table.csv,  country_summary.csv")
