#!/usr/bin/env python3
"""Figure for the country-level climate test."""
import os, numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
from scipy import stats

OUT = os.path.join(os.environ.get("MBT_ROOT","."), "climate")
D  = pd.read_csv(f"{OUT}/dataset_climate_table.csv")
CS = pd.read_csv(f"{OUT}/country_summary.csv")
TROP, TEMP = "#d95f0e", "#2c7fb8"
col = lambda z: TROP if z=="tropical" else TEMP
plt.rcParams.update({"font.size":9,"axes.spines.top":False,"axes.spines.right":False,
                     "figure.dpi":150,"savefig.bbox":"tight","font.family":"DejaVu Sans"})

fig, ax = plt.subplots(2,2, figsize=(7.4,6.0))

# (a) episode rate vs |latitude|
a = ax[0,0]
for _,r in D.iterrows():
    a.scatter(r.abslat, r.rate*100, s=8+6*np.log(max(r.n_tips,2)), color=col(r.zone),
              alpha=0.35, edgecolors="none")
for _,r in CS.iterrows():
    a.scatter(r.abslat, r.rate*100, s=70, color=col(r.zone), edgecolors="k", lw=0.6, zorder=5)
    a.annotate(r.country[:3], (r.abslat, r.rate*100), fontsize=6, xytext=(3,3),
               textcoords="offset points")
a.set_yscale("log"); a.set_xlabel("Absolute latitude (°)"); a.set_ylabel("Episodes / 100 lineage-yr")
a.set_title("(a) Episode rate vs latitude", fontsize=9.5, loc="left")

# (b) temporal slope vs |latitude|
b = ax[0,1]
Ds = D.dropna(subset=["norm_slope"])
for _,r in Ds.iterrows():
    b.scatter(r.abslat, r.norm_slope*100, s=14, color=col(r.zone), alpha=0.4, edgecolors="none")
cs2 = CS.dropna(subset=["slope"])
for _,r in cs2.iterrows():
    b.scatter(r.abslat, r.slope*100, s=70, color=col(r.zone), edgecolors="k", lw=0.6, zorder=5)
b.axhline(0, color="0.6", lw=1, ls="--")
b.set_xlabel("Absolute latitude (°)"); b.set_ylabel("Temporal slope (% per year)")
b.set_title("(b) Temporal slope vs latitude", fontsize=9.5, loc="left")

# (c) tropical vs temperate: episode rate
c = ax[1,0]
data_c = [D.loc[D.zone=="tropical","rate"]*100, D.loc[D.zone=="temperate","rate"]*100]
bp=c.boxplot(data_c, labels=["Tropical","Temperate"], patch_artist=True, widths=0.6, showfliers=False)
for patch,cl in zip(bp["boxes"],[TROP,TEMP]): patch.set_facecolor(cl); patch.set_alpha(0.5)
for i,(d,cl) in enumerate(zip(data_c,[TROP,TEMP])):
    c.scatter(np.random.normal(i+1,0.05,len(d)), d, s=8, color=cl, alpha=0.5, zorder=3)
c.set_yscale("log"); c.set_ylabel("Episodes / 100 lineage-yr")
c.set_title("(c) Rate: tropical vs temperate", fontsize=9.5, loc="left")

# (d) tropical vs temperate: temporal slope
d = ax[1,1]
data_d = [Ds.loc[Ds.zone=="tropical","norm_slope"]*100, Ds.loc[Ds.zone=="temperate","norm_slope"]*100]
bp=d.boxplot(data_d, labels=["Tropical","Temperate"], patch_artist=True, widths=0.6, showfliers=False)
for patch,cl in zip(bp["boxes"],[TROP,TEMP]): patch.set_facecolor(cl); patch.set_alpha(0.5)
for i,(dd,cl) in enumerate(zip(data_d,[TROP,TEMP])):
    d.scatter(np.random.normal(i+1,0.05,len(dd)), dd, s=8, color=cl, alpha=0.5, zorder=3)
d.axhline(0, color="0.6", lw=1, ls="--")
d.set_ylabel("Temporal slope (% per year)")
d.set_title("(d) Slope: tropical vs temperate", fontsize=9.5, loc="left")

leg=[mlines.Line2D([],[],marker="o",ls="",color=TROP,label="Tropical"),
     mlines.Line2D([],[],marker="o",ls="",color=TEMP,label="Temperate")]
fig.legend(handles=leg, loc="upper center", ncol=2, frameon=False, bbox_to_anchor=(0.5,1.02))
fig.tight_layout()
fig.savefig(f"{OUT}/figure_climate.png", dpi=200)
print("wrote", f"{OUT}/figure_climate.png")
