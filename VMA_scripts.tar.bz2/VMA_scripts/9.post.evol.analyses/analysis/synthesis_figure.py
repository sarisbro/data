#!/usr/bin/env python3
"""Cross-scheme synthesis across genes (HA/NA) and subtypes (H1N1/H3N2):
   - per gene x subtype temporal slope for each sampling scheme (Poisson GLM, offset=log exposure)
   - composite Figure 1: (a) pooled episode-rate trajectories; (b) slope summary across schemes
   - results_synthesis.json with all numbers for the manuscript text."""
import os, json, warnings
import numpy as np, pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
from scipy import stats
warnings.filterwarnings("ignore")

BASE = os.environ.get("MBT_ROOT", ".")
OUT  = f"{BASE}/synthesis"; os.makedirs(OUT, exist_ok=True)
SCHEMES = [("99_cdhit","CD-HIT 99%"), ("99.7_cdhit","CD-HIT 99.7%"),
           ("99_random","Random 99%"), ("99.7_random","Random 99.7%")]
GS = [("HA","H1N1"),("HA","H3N2"),("NA","H1N1"),("NA","H3N2")]

def load_bins(tag):
    df = pd.read_csv(f"{BASE}/run_{tag}/results/time_bins_all.csv", keep_default_na=False)
    for c in ["bin_mid","count","exposure"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df["reliable"] = df["reliable"].astype(str).str.strip().eq("True")
    return df[(df.reliable) & (df.exposure > 0)].copy()

def cell_slope(df):
    """Poisson GLM count ~ yr + C(dataset), offset log(exposure). Returns beta,se,p,%/yr,CI."""
    d = df.copy()
    if d.dataset.nunique() < 2 or len(d) < 5 or d["count"].sum() < 5:
        # fall back to no dataset effect if too few datasets
        formula = "count ~ yr"
    else:
        formula = "count ~ yr + C(dataset)"
    d["yr"] = d["bin_mid"] - 2000.0
    try:
        m = smf.glm(formula, data=d, family=sm.families.Poisson(), offset=np.log(d["exposure"])).fit()
        b, se = m.params["yr"], m.bse["yr"]
        pct = (np.exp(b)-1)*100
        lo  = (np.exp(b-1.96*se)-1)*100
        hi  = (np.exp(b+1.96*se)-1)*100
        return dict(beta=float(b), se=float(se), p=float(m.pvalues["yr"]),
                    pct=float(pct), lo=float(lo), hi=float(hi),
                    n_datasets=int(d.dataset.nunique()))
    except Exception as e:
        return dict(beta=np.nan, se=np.nan, p=np.nan, pct=np.nan, lo=np.nan, hi=np.nan,
                    n_datasets=int(d.dataset.nunique()), err=str(e))

# ---- compute cell slopes for every scheme ----
cells = {}   # (scheme_tag, gene, subtype) -> slope dict
for tag,_ in SCHEMES:
    b = load_bins(tag)
    for g,s in GS:
        cells[(tag,g,s)] = cell_slope(b[(b.gene==g)&(b.subtype==s)])

# ---- interaction p-values per scheme ----
inter = {}
for tag,_ in SCHEMES:
    pj = f"{BASE}/run_{tag}/results/pooled_glm.json"
    pooled = json.load(open(pj)) if os.path.exists(pj) else {}
    inter[tag] = dict(gene = pooled.get("yr:gene[T.NA]"),
                      subtype = pooled.get("yr:subtype[T.H3N2]"),
                      yr = pooled.get("yr"))

# ---- meta-analysis headline per scheme ----
meta = {}
for tag,_ in SCHEMES:
    M = pd.read_csv(f"{BASE}/run_{tag}/results/meta_analysis.csv", keep_default_na=False)
    for c in M.columns:
        if c!="group": M[c]=pd.to_numeric(M[c],errors="coerce")
    row = M[M.group=="ALL"].iloc[0]
    rob = json.load(open(f"{BASE}/run_{tag}/results/robustness.json"))
    summ = pd.read_csv(f"{BASE}/run_{tag}/results/dataset_summary.csv", keep_default_na=False)
    ep   = pd.read_csv(f"{BASE}/run_{tag}/results/episodes_all_datasets.csv", keep_default_na=False)
    ep["matched"]=ep["matched"].astype(str).str.strip().eq("True")
    meta[tag] = dict(b_re=float(row.b_re), p_re=float(row.p_re), k=int(row.k),
                     n_pos=int(row.n_pos), n_neg=int(row.n_neg),
                     n_ep=int(len(ep)), matched=int(ep.matched.sum()),
                     match_pct=round(100*ep.matched.mean(),1),
                     internal=rob.get("internal"))

# ================= FIGURE =================
C = {("HA","H1N1"):"#2c7fb8",("HA","H3N2"):"#7fcdbb",
     ("NA","H1N1"):"#d95f0e",("NA","H3N2"):"#fec44f"}
plt.rcParams.update({"font.size":10,"axes.spines.top":False,"axes.spines.right":False,
                     "figure.dpi":150,"savefig.bbox":"tight","font.family":"DejaVu Sans"})
fig = plt.figure(figsize=(7.2,3.5))
gs = fig.add_gridspec(1,2, width_ratios=[1.05,1.0], wspace=0.32)

# Panel (a): pooled trajectories from the richest scheme (CD-HIT 99.7%)
axA = fig.add_subplot(gs[0,0])
bb = load_bins("99.7_cdhit")
for g,s in GS:
    d = bb[(bb.gene==g)&(bb.subtype==s)]
    agg = d.groupby("bin_mid").agg(count=("count","sum"),expo=("exposure","sum")).reset_index()
    agg = agg[agg.expo>0]
    axA.scatter(agg.bin_mid, agg["count"]/agg["expo"]*100, s=10, color=C[(g,s)], alpha=0.5)
    yr=agg.bin_mid.values-agg.bin_mid.mean()
    m=sm.GLM(agg["count"].values, sm.add_constant(yr), family=sm.families.Poisson(),
             offset=np.log(agg["expo"].values)).fit()
    xs=np.linspace(agg.bin_mid.min(),agg.bin_mid.max(),100)
    axA.plot(xs, np.exp(m.params[0]+m.params[1]*(xs-agg.bin_mid.mean()))*100,
             color=C[(g,s)], lw=2, label=f"{g}–{s}")
axA.set_xlabel("Year (episode branch-midpoint)")
axA.set_ylabel("Episodes per 100 lineage-years")
axA.set_title("(a) Episode rate through time", fontsize=10, loc="left")
axA.legend(frameon=False, fontsize=7.5, loc="upper left")

# Panel (b): slope (%/yr) per gene x subtype, across the four schemes
axB = fig.add_subplot(gs[0,1])
markers = {"99_cdhit":"o","99.7_cdhit":"s","99_random":"^","99.7_random":"D"}
labels  = dict(SCHEMES)
xpos = {gs_:i for i,gs_ in enumerate(GS)}
offs = {"99_cdhit":-0.18,"99.7_cdhit":-0.06,"99_random":0.06,"99.7_random":0.18}
for tag,_ in SCHEMES:
    for g,s in GS:
        c = cells[(tag,g,s)]
        if not np.isfinite(c["pct"]): continue
        x = xpos[(g,s)] + offs[tag]
        axB.errorbar(x, c["pct"], yerr=[[c["pct"]-c["lo"]],[c["hi"]-c["pct"]]],
                     fmt=markers[tag], ms=4.5, color=C[(g,s)], ecolor=C[(g,s)],
                     elinewidth=1, capsize=2, mec="0.25", mew=0.4)
axB.axhline(0, color="0.6", lw=1, ls="--")
axB.set_xticks(range(len(GS)))
axB.set_xticklabels([f"{g}\n{s}" for g,s in GS], fontsize=8)
axB.set_ylabel("Increase in episode rate (% per year)")
axB.set_title("(b) Temporal slope by gene × subtype", fontsize=10, loc="left")
sh = [mlines.Line2D([],[],color="0.3",marker=markers[t],ls="",ms=5,label=labels[t]) for t,_ in SCHEMES]
axB.legend(handles=sh, frameon=False, fontsize=7, loc="upper left", ncol=1)
axB.margins(y=0.12)

fig.savefig(f"{OUT}/figure1_synthesis.png", dpi=200)
fig.savefig(f"{OUT}/figure1_synthesis.pdf")
plt.close(fig)

# ================= numbers for the text =================
def rng(vals):
    vals=[v for v in vals if np.isfinite(v)]; return (min(vals),max(vals))
res = dict(
    schemes=[t for t,_ in SCHEMES],
    total_ep=sum(meta[t]["n_ep"] for t,_ in SCHEMES),
    total_matched=sum(meta[t]["matched"] for t,_ in SCHEMES),
    match_pct_range=[min(meta[t]["match_pct"] for t,_ in SCHEMES),
                     max(meta[t]["match_pct"] for t,_ in SCHEMES)],
    meta=meta, inter=inter,
    cells={f"{t}|{g}|{s}":cells[(t,g,s)] for t,_ in SCHEMES for g,s in GS},
)
# gene/subtype %/yr ranges across schemes
for g in ["HA","NA"]:
    vv=[cells[(t,g,s)]["pct"] for t,_ in SCHEMES for s in ["H1N1","H3N2"]]
    res[f"pct_{g}"]=list(rng(vv))
for s in ["H1N1","H3N2"]:
    vv=[cells[(t,g,s)]["pct"] for t,_ in SCHEMES for g in ["HA","NA"]]
    res[f"pct_{s}"]=list(rng(vv))
# how many of the 16 gene x subtype x scheme cells are positive / significant
allcells=[cells[(t,g,s)] for t,_ in SCHEMES for g,s in GS]
res["n_cells"]=len(allcells)
res["n_cells_pos"]=int(sum(1 for c in allcells if c["pct"]>0))
res["n_cells_sig"]=int(sum(1 for c in allcells if c["p"]<0.05 and c["pct"]>0))
res["gene_interaction_sig_schemes"]=[t for t,_ in SCHEMES if inter[t]["gene"] and inter[t]["gene"]["p"]<0.05 and inter[t]["gene"]["beta"]>0]
json.dump(res, open(f"{OUT}/results_synthesis.json","w"), indent=1)

print("Figure ->", f"{OUT}/figure1_synthesis.png")
print(f"total episodes across schemes: {res['total_ep']}, matched {res['total_matched']} "
      f"({res['match_pct_range'][0]}-{res['match_pct_range'][1]}%)")
print(f"gene x subtype x scheme cells: {res['n_cells']}, positive {res['n_cells_pos']}, "
      f"sig-positive {res['n_cells_sig']}")
print("HA %/yr range:", res["pct_HA"], " NA %/yr range:", res["pct_NA"])
print("H1N1 %/yr range:", res["pct_H1N1"], " H3N2 %/yr range:", res["pct_H3N2"])
print("NA>HA interaction significant in:", res["gene_interaction_sig_schemes"])
for t,_ in SCHEMES:
    gi=inter[t]["gene"]; si=inter[t]["subtype"]
    print(f"  {t}: meta p={meta[t]['p_re']:.2e}, slope={meta[t]['b_re']:+.4f}; "
          f"yr*gene p={gi['p']:.3g} (b={gi['beta']:+.4f}); yr*subtype p={si['p']:.3g}")
