#!/usr/bin/env Rscript

# Rscript reroot_oldest_to_xml_dir.R trees --xml-dir xml -j 8
# Rscript reroot_oldest_to_xml_dir.R trees --xml-dir xml --recursive
# Rscript reroot_oldest_to_xml_dir.R trees --xml-dir xml -s "_rerooted.tree"
# Rscript reroot_oldest_to_xml_dir.R trees --xml-dir xml --overwrite

suppressPackageStartupMessages({
  library(ape)
  library(parallel)
})

parse_args <- function(args) {
  opts <- list(
    tree_dir = NULL,
    xml_dir = NULL,
    jobs = detectCores(),
    overwrite = FALSE,
    recursive = FALSE,
    suffix = "_rooted.tree"
  )

  i <- 1
  positional <- character()

  while (i <= length(args)) {
    a <- args[i]

    if (a %in% c("-x", "--xml-dir")) {
      i <- i + 1
      opts$xml_dir <- args[i]
    } else if (a %in% c("-j", "--jobs")) {
      i <- i + 1
      opts$jobs <- as.integer(args[i])
    } else if (a %in% c("-s", "--suffix")) {
      i <- i + 1
      opts$suffix <- args[i]
    } else if (a == "--overwrite") {
      opts$overwrite <- TRUE
    } else if (a == "--recursive") {
      opts$recursive <- TRUE
    } else {
      positional <- c(positional, a)
    }

    i <- i + 1
  }

  if (length(positional) < 1 || is.null(opts$xml_dir)) {
    stop("Usage: reroot_oldest_to_xml_dir.R tree_dir --xml-dir xml_dir [-j jobs] [-s suffix] [--overwrite] [--recursive]")
  }

  opts$tree_dir <- positional[1]
  opts
}

extract_date <- function(x) {
  m <- regexpr("[0-9]{4}_[0-9]{2}_[0-9]{2}$", x)
  if (m[1] == -1) return(NA_character_)
  regmatches(x, m)
}

date_to_int <- function(x) {
  as.integer(gsub("_", "", x))
}

build_xml_index <- function(xml_dir, recursive = FALSE) {
  xml_files <- list.files(
    xml_dir,
    pattern = "\\.xml$",
    full.names = TRUE,
    recursive = recursive
  )

  idx <- setNames(xml_files, tools::file_path_sans_ext(basename(xml_files)))
  idx
}

reroot_one <- function(tree_file, xml_index, suffix = "_rooted.tree", overwrite = FALSE) {
  tree_base <- tools::file_path_sans_ext(basename(tree_file))

  if (!tree_base %in% names(xml_index)) {
    stop(sprintf("%s: no matching XML file found", basename(tree_file)))
  }

  xml_file <- xml_index[[tree_base]]
  out_file <- file.path(dirname(xml_file), paste0(tree_base, suffix))

  if (file.exists(out_file) && !overwrite) {
    return(sprintf("[skipped] %s: %s already exists", basename(tree_file), out_file))
  }

  tr <- read.tree(tree_file)
  tips <- tr$tip.label

  dates <- vapply(tips, extract_date, character(1))
  keep <- !is.na(dates)

  if (!any(keep)) {
    stop(sprintf("%s: no tip names ending in YYYY_MM_DD were found", basename(tree_file)))
  }

  valid_tips <- tips[keep]
  valid_dates <- dates[keep]
  numeric_dates <- vapply(valid_dates, date_to_int, integer(1))

  oldest_date_num <- min(numeric_dates)
  oldest_tips <- valid_tips[numeric_dates == oldest_date_num]
  oldest_date_str <- valid_dates[match(oldest_date_num, numeric_dates)]

  rooted <- root(tr, outgroup = oldest_tips, resolve.root = TRUE)

  write.tree(rooted, file = out_file)

  sprintf(
    "[ok] %s: rooted on %d oldest tip(s) (%s) -> %s",
    basename(tree_file),
    length(oldest_tips),
    oldest_date_str,
    out_file
  )
}

main <- function() {
  args <- commandArgs(trailingOnly = TRUE)
  opts <- parse_args(args)

  if (!dir.exists(opts$tree_dir)) {
    stop(sprintf("Tree directory does not exist: %s", opts$tree_dir))
  }
  if (!dir.exists(opts$xml_dir)) {
    stop(sprintf("XML directory does not exist: %s", opts$xml_dir))
  }

  patterns <- c("\\.tree$", "\\.nwk$", "\\.newick$", "\\.tre$")

  tree_files <- character()
  for (pat in patterns) {
    tree_files <- c(
      tree_files,
      list.files(
        opts$tree_dir,
        pattern = pat,
        full.names = TRUE,
        recursive = opts$recursive
      )
    )
  }

  tree_files <- sort(unique(tree_files))

  if (length(tree_files) == 0) {
    cat("No tree files found.\n")
    quit(status = 0)
  }

  xml_index <- build_xml_index(opts$xml_dir, recursive = opts$recursive)

  if (length(xml_index) == 0) {
    stop("No XML files found in xml_dir")
  }

  cat(sprintf("Found %d tree files.\n", length(tree_files)))
  cat(sprintf("Found %d XML files.\n", length(xml_index)))
  cat("Rooted trees will be written beside their matching XML files.\n")

  jobs <- max(1, min(opts$jobs, length(tree_files)))

  results <- mclapply(
    tree_files,
    function(f) {
      tryCatch(
        reroot_one(f, xml_index, suffix = opts$suffix, overwrite = opts$overwrite),
        error = function(e) sprintf("[error] %s: %s", basename(f), conditionMessage(e))
      )
    },
    mc.cores = jobs
  )

  cat(paste(results, collapse = "\n"), "\n")
}

main()
