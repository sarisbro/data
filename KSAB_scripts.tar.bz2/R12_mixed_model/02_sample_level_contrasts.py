#!/usr/bin/env python3
# R12.02 -- Sample-level (one observation per SRA) Wilcoxon + Cliff's delta
#           + bootstrap 95% CI on the per-tree metrics emitted by R12.01.
#
# Why : per-tree pairwise distances are not independent observations.
#       Aggregating to sample-median removes pseudoreplication and reveals
#       the true effective sample size (n_SRA ~ 17-24 per stratum).
#
# Inputs : ${REV_OUT}/R12_mixed_model/per_tree_long.csv     (from R12.01)
# Outputs: ${REV_OUT}/R12_mixed_model/per_sra_median.csv
#          ${REV_OUT}/R12_mixed_model/sample_level_contrasts.csv

import os, sys, pandas as pd, numpy as np
from scipy import stats

REV_OUT = os.environ.get("REV_OUT",
            "/Users/admin/Desktop/_tmp.work_/260220_Vaibhav/revision_outputs")
INP = os.path.join(REV_OUT, "R12_mixed_model", "per_tree_long.csv")
OUT = os.path.dirname(INP)
os.makedirs(OUT, exist_ok=True)

df = pd.read_csv(INP, usecols=["biome","region","sra","n_gene",
                                "mrca_distance","gene_mpd","imgvr_mpd"])
for c in ("mrca_distance","gene_mpd","imgvr_mpd"):
    df[c] = pd.to_numeric(df[c], errors="coerce")

def per_sra(metric):
    sub = df[df[metric].notna() & (df[metric] > 0) & (df[metric] < 6)]
    return sub.groupby(["biome","region","sra"])[metric].median().reset_index()

def contrasts(ag, metric_lbl, B=2000, seed=0):
    col = ag.columns[-1]
    rows = []
    for biome in ("marine","terrestrial"):
        eq = ag[(ag.biome==biome) & (ag.region=="eq")][col]
        for r in ("north","south"):
            x = ag[(ag.biome==biome) & (ag.region==r)][col]
            if len(x) < 2 or len(eq) < 2: continue
            U, p   = stats.mannwhitneyu(x, eq, alternative="two-sided")
            cd     = 2*U/(len(x)*len(eq)) - 1
            d_med  = float(x.median() - eq.median())
            rng    = np.random.default_rng(seed)
            diffs  = [np.median(rng.choice(x, len(x), replace=True))
                    - np.median(rng.choice(eq, len(eq), replace=True))
                    for _ in range(B)]
            lo, hi = np.quantile(diffs, [0.025, 0.975])
            rows.append({"metric": metric_lbl, "biome": biome,
                         "contrast": f"{r}_vs_eq",
                         "n_pole": len(x), "n_eq": len(eq),
                         "median_diff": round(d_med, 3),
                         "ci_lo": round(lo, 3), "ci_hi": round(hi, 3),
                         "cliff_delta": round(cd, 3),
                         "p_wilcoxon":  round(p, 4)})
    return rows

results = []
for m, lbl in [("gene_mpd",      "gene_mpd"),
               ("mrca_distance", "bridging_edge"),
               ("imgvr_mpd",     "imgvr_mpd")]:
    ag = per_sra(m)
    ag.to_csv(os.path.join(OUT, f"per_sra_median_{lbl}.csv"), index=False)
    results.extend(contrasts(ag, lbl))

tab = pd.DataFrame(results)
tab.to_csv(os.path.join(OUT, "sample_level_contrasts.csv"), index=False)
print(tab.to_string(index=False))
