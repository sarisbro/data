#!/usr/bin/env python3
"""Build the two figures supporting the biome-led reframing of the manuscript.

  figure_biome_bridging.pdf   -- main text Fig 6 (replaces the latitude-axis
                                 version): bridging-edge per-SRA boxplot,
                                 biome on x-axis, three sub-panels per region.
  figure_biome_treeshape.pdf  -- Supp Fig S9: same layout for gamma, Colless_z,
                                 Sackin_z.

Also writes:
  marine_vs_terrestrial_contrasts.csv  -- 24-row contrast table for Supp Table S5.
"""
import os, sys, numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
PROJ = "/sessions/compassionate-youthful-einstein/mnt/260220_Vaibhav"
TS   = f"{PROJ}/revision_scripts/R07_treeshape"
LONG = "/sessions/compassionate-youthful-einstein/mnt/outputs/R12_mixed/per_tree_long.csv"

plt.rcParams.update({
    "font.family":"DejaVu Sans","font.size":9,
    "axes.titlesize":9,"axes.labelsize":9,"axes.linewidth":0.8,
    "xtick.labelsize":8,"ytick.labelsize":8,"legend.fontsize":8,
    "axes.spines.top":False,"axes.spines.right":False,
    "pdf.fonttype":42,"ps.fonttype":42,
})

biome_col = {"marine":"#1f78b4","terrestrial":"#33a02c"}
region_lab = {"eq":"equatorial / temperate","north":"Arctic","south":"Antarctic"}
regions = ["eq","north","south"]
biomes  = ["marine","terrestrial"]

# Per-SRA medians ----------------------------------------------------------
print("loading", LONG)
df = pd.read_csv(LONG, usecols=["biome","region","sra","gene_mpd","mrca_distance","imgvr_mpd"])
for c in ("gene_mpd","mrca_distance","imgvr_mpd"):
    df[c] = pd.to_numeric(df[c], errors="coerce")

def per_sra(metric, lo=0.0, hi=6.0):
    s = df[df[metric].notna() & (df[metric]>lo) & (df[metric]<hi)]
    return s.groupby(["biome","region","sra"])[metric].median().reset_index()

ag_bridge = per_sra("mrca_distance")
ag_mpd    = per_sra("gene_mpd")
ag_imgvr  = per_sra("imgvr_mpd", lo=0.0, hi=0.5)
ts = pd.read_csv(f"{TS}/per_sra_medians.csv")

def contrast(a, b, B=2000, seed=0):
    a = np.asarray(a); b = np.asarray(b)
    if len(a) < 2 or len(b) < 2: return None
    U, p = stats.mannwhitneyu(a, b, alternative="two-sided")
    cd = 2*U/(len(a)*len(b)) - 1
    rng = np.random.default_rng(seed)
    diffs = [np.median(rng.choice(a, len(a), replace=True))
           - np.median(rng.choice(b, len(b), replace=True)) for _ in range(B)]
    lo, hi = np.quantile(diffs, [0.025, 0.975])
    return dict(n_M=len(a), n_T=len(b), d_med=float(np.median(a)-np.median(b)),
                cliff=float(cd), ci_lo=float(lo), ci_hi=float(hi), p=float(p))

# --- contrast table (24 rows) for Supp Table S5
rows = []
for tab, col, mname in [
    (ag_mpd,    "gene_mpd",      "gene_mpd"),
    (ag_bridge, "mrca_distance", "bridging_edge"),
    (ag_imgvr,  "imgvr_mpd",     "imgvr_mpd"),
    (ts.rename(columns={"median_gamma":"gamma"}),         "gamma",     "gamma"),
    (ts.rename(columns={"median_colless_z":"colless_z"}), "colless_z", "colless_z"),
    (ts.rename(columns={"median_sackin_z":"sackin_z"}),   "sackin_z",  "sackin_z"),
]:
    if "biome" not in tab.columns: continue
    # pooled
    M = tab[tab.biome=="marine"][col]
    T = tab[tab.biome=="terrestrial"][col]
    r = contrast(M, T)
    if r: r.update(metric=mname, region="ALL"); rows.append(r)
    # per region
    for region in regions:
        M = tab[(tab.biome=="marine")     & (tab.region==region)][col]
        T = tab[(tab.biome=="terrestrial")& (tab.region==region)][col]
        r = contrast(M, T)
        if r: r.update(metric=mname, region=region); rows.append(r)

contrasts = pd.DataFrame(rows)[["metric","region","n_M","n_T","d_med","ci_lo","ci_hi","cliff","p"]]
contrasts.to_csv(os.path.join(HERE, "marine_vs_terrestrial_contrasts.csv"), index=False)
print(f"wrote {len(contrasts)} contrast rows")

# ----- helper: build a 3-panel biome-axis figure -------------------------
def biome_panel(metrics_specs, out_stub, suptitle, figsize, ylim_pad_top=0.20):
    n_rows = len(metrics_specs)
    fig, axes = plt.subplots(n_rows, 3, figsize=figsize,
                              sharex=False, constrained_layout=True)
    if n_rows == 1: axes = np.array([axes])
    rng = np.random.default_rng(7)
    for row_i, (data_tab, col, ylabel, mlabel) in enumerate(metrics_specs):
        for col_i, region in enumerate(regions):
            ax = axes[row_i, col_i]
            data = []; colors = []
            for biome in biomes:
                v = data_tab[(data_tab.biome==biome) & (data_tab.region==region)][col].dropna().values
                data.append(v); colors.append(biome_col[biome])
            positions = [0, 1]
            bp = ax.boxplot(data, positions=positions, widths=0.5, patch_artist=True,
                            showfliers=False, medianprops=dict(color="black", lw=1.3),
                            whiskerprops=dict(lw=0.8), capprops=dict(lw=0.8),
                            boxprops=dict(lw=0.6))
            for patch, c in zip(bp["boxes"], colors):
                patch.set_facecolor(c); patch.set_alpha(0.55)
            for px, y_arr, c in zip(positions, data, colors):
                if len(y_arr) == 0: continue
                jit = rng.uniform(-0.13, 0.13, size=len(y_arr))
                ax.scatter(px+jit, y_arr, s=12, color=c, edgecolors="k", linewidths=0.35,
                           alpha=0.85, zorder=3)
            ax.set_xticks(positions)
            ax.set_xticklabels(biomes, rotation=0)
            if col_i == 0: ax.set_ylabel(ylabel)
            ax.set_title(region_lab[region], fontsize=9.5)
            ax.grid(axis="y", linestyle=":", linewidth=0.4, color="grey", alpha=0.6, zorder=0)
            # significance from the contrast table
            row = contrasts[(contrasts.metric==mlabel) & (contrasts.region==region)]
            if len(row) and row.iloc[0]["p"] < 0.05:
                p = float(row.iloc[0]["p"]); d = float(row.iloc[0]["cliff"])
                all_vals = np.concatenate([np.asarray(a) for a in data if len(a)])
                y_top = np.nanmax(all_vals); y_bot = np.nanmin(all_vals)
                span = (y_top-y_bot) if y_top>y_bot else 1
                y_off = span * 0.07
                y_br = y_top + y_off * 1.2
                ax.plot([0,0,1,1], [y_br-y_off*0.18, y_br, y_br, y_br-y_off*0.18],
                        color="black", linewidth=0.8)
                stars = "***" if p<0.001 else "**" if p<0.01 else "*"
                ax.text(0.5, y_br + y_off*0.05,
                        f"{stars}  $\\delta={d:+.2f}$",
                        ha="center", va="bottom", fontsize=7.8)
                ax.set_ylim(top = y_top + y_off * 1.55)
    letters = "abcdefghijklmnopqrstuvwxyz"
    for i, axrow in enumerate(axes):
        for j, ax in enumerate(axrow):
            idx = i*3 + j
            if idx < len(letters):
                ax.text(-0.20 if j==0 else -0.15, 1.04, letters[idx],
                        transform=ax.transAxes,
                        fontsize=11, fontweight="bold", va="bottom")
    fig.suptitle(suptitle, y=1.04, fontsize=10)
    for ext in ("pdf","png"):
        out = os.path.join(HERE, f"{out_stub}.{ext}")
        fig.savefig(out, bbox_inches="tight", dpi=300 if ext=="png" else None)
        print(" ", out)
    plt.close(fig)

# --- Main text Fig 6: biome contrast on bridging edge, 3 panels ----------
biome_panel(
    [(ag_bridge, "mrca_distance",
      "bridging edge to IMG/VR (subs/site)", "bridging_edge")],
    "figure_biome_bridging",
    "Bridging edge to IMG/VR reference clade by biome  "
    "(per-SRA medians, $n=120$ samples)",
    figsize=(11.0, 4.0))

# --- Supp Fig S9: biome contrast on the three tree-shape statistics ------
biome_panel(
    [(ts.rename(columns={"median_gamma":"gamma"}),         "gamma",
      "Pybus-Harvey $\\gamma$",      "gamma"),
     (ts.rename(columns={"median_colless_z":"colless_z"}), "colless_z",
      "Colless ($z$)",               "colless_z"),
     (ts.rename(columns={"median_sackin_z":"sackin_z"}),   "sackin_z",
      "Sackin ($z$)",                "sackin_z")],
    "figure_biome_treeshape",
    "Tree-shape statistics by biome  "
    "(per-SRA medians, $n=120$ samples)",
    figsize=(11.0, 10.0))

print("\nDone.")
