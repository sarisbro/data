#!/usr/bin/env python3
"""Build the four new revision figures (Fig 6, Supp Figs S6, S7, S8).

Outputs (next to this script's parent revision_scripts/R12_mixed_model/):
    figure_bridging_edge.pdf / .png            (main text Fig 6)
    figure_bridging_edge_per_tree.pdf / .png   (Supp Fig S6)
    figure_imgvr_mpd.pdf / .png                (Supp Fig S7)
    figure_n50_vs_bridging.pdf / .png          (Supp Fig S8)

Inputs:
    per_tree_long.csv (R12.01 consolidated CoPHSe-level long table)
    sample_level_contrasts.csv (R12.02 Wilcoxon)
    all_contig_summary_stats.csv (Publication Code N50 stats)
"""
import os, sys, numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from scipy import stats

HERE   = os.path.dirname(os.path.abspath(__file__))
PROJ   = "/Users/admin/Desktop/_tmp.work_/260220_Vaibhav"
TREE_LONG = "/sessions/compassionate-youthful-einstein/mnt/outputs/R12_mixed/per_tree_long.csv"
CONTRASTS = os.path.join(HERE, "sample_level_contrasts.csv")
N50_CSV   = "/sessions/compassionate-youthful-einstein/mnt/260220_Vaibhav/contigs_by_region/contig_reports_png/all_contig_summary_stats.csv"

plt.rcParams.update({
    "font.family":"DejaVu Sans","font.size":9,
    "axes.titlesize":9,"axes.labelsize":9,"axes.linewidth":0.8,
    "xtick.labelsize":8,"ytick.labelsize":8,"legend.fontsize":8,
    "axes.spines.top":False,"axes.spines.right":False,
    "pdf.fonttype":42,"ps.fonttype":42,
})

biomes    = ["marine","terrestrial"]
regions   = ["eq","north","south"]
biome_col = {"marine":"#1f78b4","terrestrial":"#33a02c"}
region_lab= {"eq":"equatorial / temperate","north":"Arctic","south":"Antarctic"}

def pos_for_grid():
    p=[]; x=0
    for _ in regions:
        for _ in biomes: p.append(x); x+=1
        x+=0.6
    return p

def region_centroids():
    c=[]; cx=0
    for _ in regions: c.append(cx+0.5); cx += 2+0.6
    return c

# ----------------------------------------------------------------------------
# Load data once
# ----------------------------------------------------------------------------
print("reading", TREE_LONG, flush=True)
df = pd.read_csv(TREE_LONG, usecols=["biome","region","sra","mrca_distance","gene_mpd","imgvr_mpd"])
for c in ("mrca_distance","gene_mpd","imgvr_mpd"):
    df[c] = pd.to_numeric(df[c], errors="coerce")
cont = pd.read_csv(CONTRASTS)
print("loaded", len(df), "per-tree rows;", len(cont), "contrasts")

def per_sra_median(metric, lo=0.0, hi=6.0):
    sub = df[df[metric].notna() & (df[metric]>lo) & (df[metric]<hi)]
    return sub.groupby(["biome","region","sra"])[metric].median().reset_index()

# ----------------------------------------------------------------------------
# Helper: single-panel boxplot with brackets (parallel to figure_treeshape.py)
# ----------------------------------------------------------------------------
def boxplot_panel(ax, agg, metric_col, ylabel, contrast_label, ylim_pad_top=0.30):
    positions = pos_for_grid()
    data, colors = [], []
    for r in regions:
        for b in biomes:
            v = agg[(agg.biome==b)&(agg.region==r)][metric_col].dropna().values
            data.append(v); colors.append(biome_col[b])
    bp = ax.boxplot(data, positions=positions, widths=0.7, patch_artist=True,
                    showfliers=False, medianprops=dict(color="black", lw=1.4),
                    whiskerprops=dict(lw=0.8), capprops=dict(lw=0.8),
                    boxprops=dict(lw=0.6))
    for patch, c in zip(bp["boxes"], colors):
        patch.set_facecolor(c); patch.set_alpha(0.55)
    rng = np.random.default_rng(7)
    for px, y_arr, c in zip(positions, data, colors):
        if len(y_arr)==0: continue
        jit = rng.uniform(-0.18, 0.18, size=len(y_arr))
        ax.scatter(px+jit, y_arr, s=11, color=c, edgecolors="k", linewidths=0.35,
                   alpha=0.85, zorder=3)
    ax.set_xticks(region_centroids())
    ax.set_xticklabels([region_lab[r] for r in regions])
    ax.set_ylabel(ylabel)
    ax.grid(axis="y", linestyle=":", linewidth=0.4, color="grey", alpha=0.6, zorder=0)

    # significance brackets from the contrast table
    rows = cont[cont.metric == contrast_label]
    all_vals = np.concatenate([np.asarray(a) for a in data if len(a)])
    q05, q95 = np.nanquantile(all_vals,[0.025,0.975])
    iqr = np.nanquantile(all_vals,0.75)-np.nanquantile(all_vals,0.25)
    lo  = min(q05, np.nanmedian(all_vals)-3*iqr)
    hi  = max(q95, np.nanmedian(all_vals)+3*iqr)
    span = hi - lo if hi>lo else 1
    ax.set_ylim(lo - span*0.04, hi + span*ylim_pad_top)
    y_top = hi; y_off = span*0.045
    for k, biome in enumerate(biomes):
        b_rows = rows[(rows.biome==biome) & (rows.p_wilcoxon<0.05)]
        for j, (_, row) in enumerate(b_rows.iterrows()):
            polar_reg = "north" if row.contrast.startswith("north") else "south"
            eq_idx    = regions.index("eq")    * 2 + biomes.index(biome)
            polar_idx = regions.index(polar_reg) * 2 + biomes.index(biome)
            x_eq, x_pol = positions[eq_idx], positions[polar_idx]
            y_br = y_top + y_off*(1.0 + k*1.5 + j*0.9)
            ax.plot([x_eq, x_eq, x_pol, x_pol],
                    [y_br - y_off*0.18, y_br, y_br, y_br - y_off*0.18],
                    color=colors[eq_idx], linewidth=0.8)
            stars = "***" if row.p_wilcoxon<0.001 else "**" if row.p_wilcoxon<0.01 else "*"
            ax.text((x_eq+x_pol)/2, y_br + y_off*0.05,
                    f"{stars} $\\delta={row.cliff_delta:+.2f}$",
                    ha="center", va="bottom", fontsize=7.5, color=colors[eq_idx])

# ----------------------------------------------------------------------------
# Fig 6 -- bridging-edge per-SRA boxplot
# ----------------------------------------------------------------------------
print("Fig 6: bridging edge per SRA", flush=True)
agg = per_sra_median("mrca_distance")
fig, ax = plt.subplots(1,1, figsize=(6.0, 4.4), constrained_layout=True)
boxplot_panel(ax, agg, "mrca_distance",
              ylabel="bridging edge to IMG/VR (subs/site)",
              contrast_label="bridging_edge",
              ylim_pad_top=0.22)
handles = [Patch(facecolor=biome_col["marine"],alpha=0.6,edgecolor="k",label="marine"),
           Patch(facecolor=biome_col["terrestrial"],alpha=0.6,edgecolor="k",label="terrestrial")]
ax.legend(handles=handles, loc="upper left", frameon=False)
ax.set_title("Bridging edge to IMG/VR reference clade  "
             "(per-SRA medians, $n=120$ samples)", fontsize=10)
for ext in ("pdf","png"):
    out = os.path.join(HERE, f"figure_bridging_edge.{ext}")
    fig.savefig(out, bbox_inches="tight", dpi=300 if ext=="png" else None)
    print(" ", out)
plt.close(fig)

# ----------------------------------------------------------------------------
# Supp Fig S6 -- bridging-edge per-tree violins
# ----------------------------------------------------------------------------
print("Supp Fig S6: bridging edge per tree", flush=True)
rng = np.random.default_rng(7)
df_s = df[df.mrca_distance.notna() & (df.mrca_distance>0) & (df.mrca_distance<6)]
df_s = (df_s.groupby(["biome","region"], group_keys=False, observed=True)
          .apply(lambda g: g.sample(min(len(g), 30000), random_state=42)))

fig, ax = plt.subplots(1,1, figsize=(6.0, 4.0), constrained_layout=True)
positions = pos_for_grid(); data=[]; colors=[]
for r in regions:
    for b in biomes:
        v = df_s[(df_s.biome==b)&(df_s.region==r)]["mrca_distance"].values
        if len(v) > 8000: v = rng.choice(v, 8000, replace=False)
        data.append(v); colors.append(biome_col[b])
parts = ax.violinplot(data, positions=positions, widths=0.85, showmedians=True, showextrema=False)
for body, c in zip(parts["bodies"], colors):
    body.set_facecolor(c); body.set_alpha(0.55); body.set_edgecolor("k"); body.set_linewidth(0.4)
if "cmedians" in parts:
    parts["cmedians"].set_color("black"); parts["cmedians"].set_linewidth(1.1)
ax.set_xticks(region_centroids())
ax.set_xticklabels([region_lab[r] for r in regions])
ax.set_ylabel("bridging edge to IMG/VR (subs/site)")
ax.set_ylim(0, 4)
ax.grid(axis="y", linestyle=":", linewidth=0.4, color="grey", alpha=0.6, zorder=0)
ax.legend(handles=handles, loc="upper right", frameon=False)
ax.set_title("Bridging edge to IMG/VR reference clade  "
             "(per-tree, n=5,890,829; subsampled to 8,000 per stratum for display)",
             fontsize=9)
for ext in ("pdf","png"):
    out = os.path.join(HERE, f"figure_bridging_edge_per_tree.{ext}")
    fig.savefig(out, bbox_inches="tight", dpi=300 if ext=="png" else None)
    print(" ", out)
plt.close(fig)

# ----------------------------------------------------------------------------
# Supp Fig S7 -- IMG/VR reference MPD per-SRA  (the caveat made visual)
# ----------------------------------------------------------------------------
print("Supp Fig S7: IMG/VR reference MPD", flush=True)
agg = per_sra_median("imgvr_mpd", lo=0.0, hi=0.5)   # IMG/VR mpd very small
fig, ax = plt.subplots(1,1, figsize=(6.0, 4.0), constrained_layout=True)
boxplot_panel(ax, agg, "imgvr_mpd",
              ylabel="IMG/VR reference MPD (subs/site)",
              contrast_label="imgvr_mpd",
              ylim_pad_top=0.22)
ax.legend(handles=handles, loc="upper left", frameon=False)
ax.set_title("Within-IMG/VR reference clade MPD by latitudinal band  "
             "(per-SRA medians, $n=120$)", fontsize=10)
for ext in ("pdf","png"):
    out = os.path.join(HERE, f"figure_imgvr_mpd.{ext}")
    fig.savefig(out, bbox_inches="tight", dpi=300 if ext=="png" else None)
    print(" ", out)
plt.close(fig)

# ----------------------------------------------------------------------------
# Supp Fig S8 -- N50 vs bridging-edge scatter
# ----------------------------------------------------------------------------
print("Supp Fig S8: N50 vs bridging edge", flush=True)
n50 = pd.read_csv(N50_CSV)
# sample column looks like "marine/eq/ERR4674065"
n50[["biome","region","sra"]] = n50["sample"].str.split("/", expand=True)
n50 = n50[["biome","region","sra","N50","total_bases","n_contigs"]]
agg = per_sra_median("mrca_distance")
m   = agg.merge(n50, on=["biome","region","sra"], how="inner")

fig, axes = plt.subplots(1,2, figsize=(10.5, 4.2), sharey=True, constrained_layout=True)
for ax, biome in zip(axes, biomes):
    sub = m[m.biome==biome]
    region_col = {"eq":"#888","north":"#1f78b4","south":"#e31a1c"}
    for r in regions:
        s = sub[sub.region==r]
        if len(s)<2: continue
        ax.scatter(s.N50, s.mrca_distance, s=42, alpha=0.85,
                   color=region_col[r], edgecolors="k", linewidths=0.4,
                   label=region_lab[r])
        # log-linear smoother per region
        if len(s) >= 4 and (s.N50>0).all():
            lx = np.log10(s.N50)
            slope, intercept, r_val, p_val, _ = stats.linregress(lx, s.mrca_distance)
            xs = np.linspace(lx.min(), lx.max(), 50)
            ax.plot(10**xs, intercept+slope*xs,
                    color=region_col[r], linewidth=1.0, alpha=0.7)
    ax.set_xscale("log")
    ax.set_xlabel("Assembly N50 (bp, log scale)")
    ax.set_title(biome.capitalize())
    ax.grid(linestyle=":", linewidth=0.4, color="grey", alpha=0.6, zorder=0)
axes[0].set_ylabel("Per-SRA median bridging edge (subs/site)")
axes[0].legend(frameon=False, loc="upper right")
fig.suptitle("Bridging edge as a function of assembly contiguity (N50)",
             y=1.02, fontsize=10)
for ext in ("pdf","png"):
    out = os.path.join(HERE, f"figure_n50_vs_bridging.{ext}")
    fig.savefig(out, bbox_inches="tight", dpi=300 if ext=="png" else None)
    print(" ", out)
plt.close(fig)

print("\nDone.")
