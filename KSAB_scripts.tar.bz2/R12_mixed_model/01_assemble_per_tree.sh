#!/usr/bin/env bash
# R12.01 -- Consolidate the 120 per-sample CoPHSe-level CSVs already produced
#           by Publication Code/08_Bridging_edge_IMGVR.R into a single long
#           table tagged with biome / region / sra.  No tree re-walking
#           required: 08 has already emitted one row per CoPHSe per sample
#           (file: hits_trees_clade_distance_patristic.csv).
#
# Output : revision_outputs/R12_mixed_model/per_tree_long.csv
#          columns: biome, region, sra, cophse_id,
#                   n_gene, n_imgvr, mrca_distance, gene_mpd, imgvr_mpd,
#                   imgvr_tree_flag

set -euo pipefail
source "$(dirname "$0")/../config.sh"
OUT="${REV_OUT}/R12_mixed_model"; mkdir -p "${OUT}"
CSV="${OUT}/per_tree_long.csv"
echo "biome,region,sra,cophse_id,n_gene,n_imgvr,mrca_distance,gene_mpd,imgvr_mpd,imgvr_tree_flag" > "${CSV}"

for biome in marine terrestrial; do
  for region in eq north south; do
    grp_dir="${HMMER_DIR}/${biome}_${region}"
    [[ ! -d "$grp_dir" ]] && continue
    for s in "${grp_dir}"/*; do
      sra=$(basename "$s")
      f="${s}/hits_trees_clade_distance_patristic.csv"
      [[ ! -s "$f" ]] && continue
      # Strip the long localscratch tar path, keep just the CoPHSe id from "member"
      # member looks like "hits_trees/170676.trees" -> cophse = 170676
      awk -F',' -v b="$biome" -v r="$region" -v sra="$sra" '
        NR==1 { next }                # skip header
        {
          # strip quoting on member field
          gsub(/^"|"$/,"",$2);
          n = split($2, m, "/");
          id = m[n]; sub(/\.trees$/,"",id);
          # printf csv with quoted flag
          flag = $13; gsub(/^"|"$/,"",flag);
          printf "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",
            b, r, sra, id, $4, $5, $8, $15, $18, flag
        }' "$f" >> "${CSV}"
    done
  done
done

echo "[R12.01] wrote ${CSV}"
echo "  rows: $(($(wc -l < "${CSV}") - 1))"
