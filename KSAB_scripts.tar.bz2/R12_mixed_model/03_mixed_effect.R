#!/usr/bin/env Rscript
# R12.03 -- lme4 mixed-effect model on per-tree gene_mpd and mrca_distance,
#           with SRA as random intercept.  This is the "proper" inferential
#           pass that the manuscript should ultimately report alongside the
#           sample-level Wilcoxon tests.
#
# Inputs : ${REV_OUT}/R12_mixed_model/per_tree_long.csv  (from R12.01)
# Outputs: ${REV_OUT}/R12_mixed_model/mixed_model_summary.txt
#          ${REV_OUT}/R12_mixed_model/mixed_model_contrasts.csv
#
# Note   : the Python script R12.02 reports a *sample-level* (n=120) test that
#          is robust but very conservative; this script's mixed model retains
#          the within-sample heterogeneity in the response while still
#          honouring the nesting structure.  Report both.

suppressPackageStartupMessages({
  library(lme4); library(lmerTest); library(emmeans); library(data.table)
})

rev_out <- Sys.getenv("REV_OUT",
   "/Users/admin/Desktop/_tmp.work_/260220_Vaibhav/revision_outputs")
csv <- file.path(rev_out, "R12_mixed_model", "per_tree_long.csv")
out <- file.path(rev_out, "R12_mixed_model")

cat("[R12.03] reading", csv, "\n")
d <- fread(csv)
d <- d[!is.na(gene_mpd) & gene_mpd > 0 & gene_mpd < 6, ]
d[, region := factor(region, levels = c("eq", "north", "south"))]
d[, biome  := factor(biome,  levels = c("marine", "terrestrial"))]
cat("rows in modelling set:", nrow(d), "  SRAs:", uniqueN(d$sra), "\n")

# stratified subsample to keep lme4 tractable; matches publication-grade ANOVA practice
set.seed(42)
d_sub <- d[, .SD[sample(.N, min(.N, 60000L))], by = .(biome, region)]
cat("stratified subsample:", nrow(d_sub), "rows\n")

fit_mpd  <- lmer(gene_mpd      ~ region * biome + (1 | sra), data = d_sub)
fit_brid <- lmer(mrca_distance ~ region * biome + (1 | sra), data = d_sub)

sink(file.path(out, "mixed_model_summary.txt"))
cat("\n========== gene_mpd ~ region * biome + (1|sra) ==========\n")
print(summary(fit_mpd))
print(anova(fit_mpd, type = "III"))
cat("\nEM means (region | biome):\n")
print(emmeans(fit_mpd, ~ region | biome))
cat("\nPairwise contrasts (Tukey-adjusted):\n")
print(pairs(emmeans(fit_mpd, ~ region | biome)))

cat("\n========== mrca_distance ~ region * biome + (1|sra) ==========\n")
print(summary(fit_brid))
print(anova(fit_brid, type = "III"))
cat("\nEM means (region | biome):\n")
print(emmeans(fit_brid, ~ region | biome))
cat("\nPairwise contrasts (Tukey-adjusted):\n")
print(pairs(emmeans(fit_brid, ~ region | biome)))
sink()

# tidy CSV of contrasts for table inclusion
make_tab <- function(fit, metric) {
  pw <- as.data.frame(pairs(emmeans(fit, ~ region | biome)))
  pw$metric <- metric
  pw
}
write.csv(rbind(make_tab(fit_mpd,  "gene_mpd"),
                make_tab(fit_brid, "bridging_edge")),
          file.path(out, "mixed_model_contrasts.csv"), row.names = FALSE)
cat("[R12.03] done.  See ", out, "/mixed_model_summary.txt\n", sep="")
