# R12 -- Mixed-effect re-analysis of MPD / bridging edge

The reviewer prior to flag is **pseudoreplication**: each tree contributes
thousands of pairwise distances, but those distances are not independent
observations.  The mega-$\chi^{2}$ values in the original Kruskal-Wallis
tests are arithmetic consequences of n in the millions, not biological
signal.

This folder adds the proper inferential ladder.

| step                | unit                 | n   | tool                    |
|---------------------|----------------------|-----|-------------------------|
| 01\_assemble        | -                    | -   | bash + awk              |
| 02\_sample\_level   | per-SRA medians      | 120 | Python (statsmodels)    |
| 03\_mixed\_effect   | per-tree, RE on SRA  | $\approx 1.9$M | R (lme4 / lmerTest / emmeans) |

The Python step (02) does not need a working R install and can run on a
laptop; the R step (03) is the one to drop into the revised manuscript.

## Headline outputs (full cohort, May 2026)

* ICC = 0.235 — 76.5 % of variance in per-tree `gene_mpd` is *within* a
  sample, only 23.5 % between samples.  The pseudoreplication concern is
  real.
* Sample-level Wilcoxon tests (one observation per SRA):

  | metric          | biome       | south vs eq Cliff $\delta$ | south vs eq p |
  |-----------------|-------------|---------------------------:|--------------:|
  | gene\_mpd       | marine      | $+0.29$                    | $0.14$        |
  | gene\_mpd       | terrestrial | $+0.19$                    | $0.34$        |
  | bridging\_edge  | marine      | $+0.43$                    | $\mathbf{0.026}$ |
  | bridging\_edge  | terrestrial | $+0.41$                    | $\mathbf{0.029}$ |
  | imgvr\_mpd      | marine      | $-0.66$                    | $\mathbf{0.0005}$ |
  | imgvr\_mpd      | terrestrial | $+0.43$                    | $\mathbf{0.023}$ |

  **Take-home:** the *bridging edge* (distance from reconstructed clade
  to its IMG/VR sibling) survives sample-level inference for the South
  pole in both biomes.  The *within-clade* divergence (`gene_mpd`) does
  not -- it is in the right direction but underpowered at n $\approx 20$ per
  stratum.  The IMG/VR reference-distance asymmetry is itself worth
  disclosing as a caveat in the Discussion.

* Full mixed-effect model (R, lme4): retained for reporting in the
  manuscript with Tukey-adjusted contrasts.  See
  `mixed_model_summary.txt` after running `03_mixed_effect.R`.

## Running the pipeline

```
source ../config.sh
bash    01_assemble_per_tree.sh
python3 02_sample_level_contrasts.py
Rscript 03_mixed_effect.R
```

`01_assemble_per_tree.sh` is fast (~minutes) because it consolidates the
per-tree CSVs already emitted by `Publication Code/08_Bridging_edge_IMGVR.R`.
No tarballs are re-walked.

## Why no Python-side R install in this environment

The DRAC analysis cluster will have `r-base` available via a module load
or conda env (`revision_scripts/envs/revision.yml`).  The sandbox where
these scripts were authored cannot install `r-base` because the package
manager is locked.  The Python step (02) was designed to give a
publication-quality sample-level answer without needing R, while step
03 provides the mixed-effect inference for the final manuscript.
