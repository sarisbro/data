#!/usr/bin/env Rscript
# R10 -- Provirus / lysogeny prevalence by biome x region.
#
# Uses existing intermediates:
#   * geNomad : final.contigs_find_proviruses/*_provirus.tsv
#   * CheckV  : quality_summary.tsv  (column 'provirus' == "Yes" / "No")
#
# Tests Knowles et al.'s Piggyback-the-Winner hypothesis at latitude: do polar
# viromes show systematically higher integrated-phage prevalence than temperate?

suppressPackageStartupMessages({
  library(dplyr); library(ggplot2); library(broom); library(binom)
})
ROOT <- Sys.getenv("PROJ_ROOT")
OUT  <- file.path(Sys.getenv("REV_OUT"), "R10_provirus"); dir.create(OUT, showWarnings = FALSE)

records <- list()
for (b in c("marine", "terrestrial")) for (r in c("eq", "north", "south")) {
  grp <- paste0(b, "_", r)
  cv_dir <- file.path(Sys.getenv("CHECKV_DIR"), grp)
  if (!dir.exists(cv_dir)) next
  for (s in list.files(cv_dir)) {
    qs <- file.path(cv_dir, s, "quality_summary.tsv")
    if (!file.exists(qs)) next
    q  <- read.delim(qs)
    q  <- q[q$checkv_quality %in% c("Medium-quality", "High-quality", "Complete"), ]
    if (!nrow(q)) next
    records[[length(records) + 1L]] <- data.frame(
      biome = b, region = r, sra = sub("_checkv$", "", s),
      n_total = nrow(q),
      n_pro   = sum(q$provirus == "Yes", na.rm = TRUE))
  }
}
all <- bind_rows(records)
write.csv(all, file.path(OUT, "provirus_per_sample.csv"), row.names = FALSE)

# binomial test per stratum
agg <- all %>% group_by(biome, region) %>%
  summarise(n_total = sum(n_total), n_pro = sum(n_pro), .groups = "drop")
ci  <- binom.confint(agg$n_pro, agg$n_total, methods = "wilson")
agg <- cbind(agg, prop = ci$mean, lo = ci$lower, hi = ci$upper)
write.csv(agg, file.path(OUT, "provirus_proportions.csv"), row.names = FALSE)

# global GLM
g <- glm(cbind(n_pro, n_total - n_pro) ~ region + biome,
         data = all, family = binomial())
sink(file.path(OUT, "glm_summary.txt")); print(summary(g)); print(anova(g, test = "Chisq")); sink()

# plot
agg$region <- factor(agg$region, levels = c("eq", "north", "south"))
ggplot(agg, aes(region, prop, fill = biome)) +
  geom_col(position = position_dodge(0.7), width = 0.6) +
  geom_errorbar(aes(ymin = lo, ymax = hi), width = 0.15,
                position = position_dodge(0.7)) +
  scale_fill_manual(values = c(marine = "#1f78b4", terrestrial = "#33a02c")) +
  labs(y = "fraction of QC-pass contigs flagged as provirus",
       x = NULL, caption = "Wilson 95% CIs.  Tests 'Piggyback-the-Winner' at latitude.") +
  theme_classic(base_size = 11)
ggsave(file.path(OUT, "provirus_prevalence.pdf"), width = 6, height = 4)
