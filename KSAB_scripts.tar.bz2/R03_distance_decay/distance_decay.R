#!/usr/bin/env Rscript
# R03 -- Distance-decay of viral community similarity.
#
# Idea: similarity_ij = 1 - Bray-Curtis or 1 - Sorensen between vOTU profiles
#       of sample i and j; geographic distance is great-circle (km).
# Per-stratum slopes (log-linear fit) test whether polar viromes show
# steeper isolation-by-distance than temperate -- the mechanistic claim
# made in the Discussion.
#
# Inputs : R02 vOTU table + SI Table S1/S2 latitude+longitude per SRA
# Outputs: distance_decay_panel.pdf, mantel_results.csv

suppressPackageStartupMessages({
  library(geosphere); library(vegan); library(dplyr); library(tidyr)
  library(ggplot2); library(broom); library(readxl)
})

rev_out <- Sys.getenv("REV_OUT")
votu_lf <- read.delim(file.path(rev_out, "R02_rarefaction", "sample_votu_long.tsv"))

# wide site x vOTU
mat <- votu_lf %>% pivot_wider(names_from = votu, values_from = count, values_fill = 0L)
samp <- mat$sample; mat <- as.matrix(mat[, -1])
mat[mat > 0] <- 1; rownames(mat) <- samp                # presence/absence

# SI Table S2 carries SRA -> lat/lon
meta <- readxl::read_excel(
  file.path(Sys.getenv("PROJ_ROOT"), "251028_MS",
            "Kulkarni.Aris-Brosou_SI2-DNATable.xlsx"))
meta <- meta %>%
  transmute(sra = .data[[grep("Accession|SRA", names(meta), value = TRUE)[1]]],
            lat = as.numeric(.data[[grep("Lat",  names(meta), value = TRUE)[1]]]),
            lon = as.numeric(.data[[grep("Lon",  names(meta), value = TRUE)[1]]]))

# pair sample id with biome/region/SRA
key <- data.frame(sample = samp,
                  biome  = sub("_.*$",   "", samp),
                  region = sub("^[a-z]+_", "", sub("__.*$", "", samp)),
                  sra    = sub("^.*__",  "", samp))
key <- left_join(key, meta, by = "sra")
key <- key[complete.cases(key), ]
mat <- mat[key$sample, ]

# geographic + community distance per biome
results <- list()
plots   <- list()
for (b in unique(key$biome)) {
  ix    <- key$biome == b
  geo   <- as.dist(distm(cbind(key$lon[ix], key$lat[ix])) / 1000)     # km
  comm  <- vegdist(mat[ix, ], method = "jaccard", binary = TRUE)
  simi  <- 1 - comm
  df <- data.frame(geo = as.vector(geo), sim = as.vector(simi))
  df <- df[df$geo > 0, ]
  df$logd <- log10(df$geo)
  # stratify dist-pairs by within-region vs across-region
  reg_i <- rep(key$region[ix], each = length(key$region[ix]))
  reg_j <- rep(key$region[ix], times = length(key$region[ix]))
  reg_lower <- matrix(paste(reg_i, reg_j, sep="-"),
                      nrow=sum(ix))[lower.tri(matrix(NA, sum(ix), sum(ix)))]
  df$pair <- ifelse(reg_i[lower.tri(matrix(NA, sum(ix), sum(ix)))] ==
                    reg_j[lower.tri(matrix(NA, sum(ix), sum(ix)))],
                    reg_i[lower.tri(matrix(NA, sum(ix), sum(ix)))],
                    "across")
  fit <- lm(sim ~ logd * pair, data = df)
  results[[b]] <- list(mantel = mantel(geo, comm, method = "spearman", permutations = 999),
                       lm     = fit)

  plots[[b]] <- ggplot(df, aes(logd, sim, colour = pair)) +
    geom_point(alpha = 0.4) +
    geom_smooth(method = "lm", se = TRUE) +
    scale_colour_brewer(palette = "Set1") +
    labs(title = paste0("Distance-decay (", b, ")"),
         x = "log10 geographic distance (km)", y = "Jaccard similarity") +
    theme_classic(base_size = 11)
}

# write outputs
slope_tab <- do.call(rbind, lapply(names(results), function(b) {
  tidy(results[[b]]$lm) %>% mutate(biome = b)
}))
write.csv(slope_tab, file.path(rev_out, "R03_distance_decay", "decay_slopes.csv"),
          row.names = FALSE)
mant_tab <- do.call(rbind, lapply(names(results), function(b) {
  m <- results[[b]]$mantel
  data.frame(biome = b, mantel_r = m$statistic, p = m$signif)
}))
dir.create(file.path(rev_out, "R03_distance_decay"), showWarnings = FALSE, recursive = TRUE)
write.csv(mant_tab,  file.path(rev_out, "R03_distance_decay", "mantel_results.csv"),
          row.names = FALSE)
ggsave(file.path(rev_out, "R03_distance_decay", "distance_decay_panel.pdf"),
       gridExtra::grid.arrange(grobs = plots, ncol = 1), width = 8, height = 8)
