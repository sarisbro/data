"""Fast pure-Python tree-shape stats.

Streams a tar of Newick files and emits per-tree gamma + Colless + Sackin
without dendropy.  Recursive-descent parser fills a parent[]/depth[] array,
and indices of internal nodes / leaves are tracked as we parse.

Usage:
    python3 treeshape_fast.py <tarball> <biome> <region> <sra> <out.csv>
"""
import os, sys, tarfile, csv, math, re, time

TOKEN = re.compile(r'\s*([(),;])|\s*([^():,;]+)')

def parse_newick(txt):
    """Return parallel arrays: parent[i], blen[i], is_leaf[i], children[i]."""
    parent   = []
    blen     = []
    is_leaf  = []
    children = []          # list of child indices per node
    name     = []
    cur_parent = None
    stack = []
    pos = 0
    n = len(txt)
    expect_name = True
    while pos < n:
        c = txt[pos]
        if c == '(':
            # new internal node
            i = len(parent)
            parent.append(cur_parent)
            blen.append(0.0)
            is_leaf.append(False)
            children.append([])
            name.append(None)
            if cur_parent is not None:
                children[cur_parent].append(i)
            stack.append(cur_parent)
            cur_parent = i
            pos += 1
            expect_name = True
        elif c == ',':
            pos += 1
            expect_name = True
        elif c == ')':
            cur_parent = stack.pop()
            pos += 1
            # following may be a name and/or :brlen for the just-closed parent
            # which lives at children[cur_parent][-1] if cur_parent else need root
            expect_name = False
            # parse optional name/support
            m = re.match(r'([^:,();]*)', txt[pos:])
            if m and m.group(0):
                # support / name -- attach to last opened internal node (the one we just closed)
                # which is children[cur_parent][-1] if cur_parent is not None else the root
                last = children[cur_parent][-1] if cur_parent is not None else (len(parent)-1)
                name[last] = m.group(1)
                pos += len(m.group(0))
            # optional :brlen
            if pos < n and txt[pos] == ':':
                pos += 1
                m = re.match(r'([0-9.eE+\-]+)', txt[pos:])
                if m:
                    last = children[cur_parent][-1] if cur_parent is not None else (len(parent)-1)
                    blen[last] = float(m.group(1))
                    pos += len(m.group(0))
        elif c == ';':
            break
        else:
            # leaf name [: brlen]
            m = re.match(r'([^:,();]+)', txt[pos:])
            if not m:
                pos += 1
                continue
            lab = m.group(1)
            pos += len(m.group(0))
            i = len(parent)
            parent.append(cur_parent)
            blen.append(0.0)
            is_leaf.append(True)
            children.append([])
            name.append(lab)
            if cur_parent is not None:
                children[cur_parent].append(i)
            if pos < n and txt[pos] == ':':
                pos += 1
                m = re.match(r'([0-9.eE+\-]+)', txt[pos:])
                if m:
                    blen[i] = float(m.group(1))
                    pos += len(m.group(0))
    return parent, blen, is_leaf, children, name

def depth_from_root(parent, blen):
    n = len(parent)
    d = [0.0]*n
    for i in range(n):
        if parent[i] is not None:
            d[i] = d[parent[i]] + blen[i]
    return d

def subtree_leaf_counts(children, is_leaf):
    n = len(children)
    cnt = [0]*n
    # postorder: children appear later only if file is well-formed -- but our build appended in order
    # so iterate descending index
    for i in range(n-1, -1, -1):
        if is_leaf[i]:
            cnt[i] = 1
        else:
            cnt[i] = sum(cnt[c] for c in children[i])
    return cnt

def pybus_gamma(parent, blen, is_leaf, children):
    """Compute gamma on the root-to-internal-node depths."""
    d = depth_from_root(parent, blen)
    internal_depths = sorted(d[i] for i in range(len(parent)) if not is_leaf[i])
    n_leaf = sum(1 for x in is_leaf if x)
    if n_leaf < 5: return None
    tree_depth = max(d)
    g = [internal_depths[i+1]-internal_depths[i] for i in range(len(internal_depths)-1)]
    g.append(tree_depth - internal_depths[-1])
    g = [x for x in g if x > 0]
    if len(g) < 4: return None
    T = sum((i+2)*g[i] for i in range(len(g)))
    Tsum = sum(sum((k+2)*g[k] for k in range(i+1)) for i in range(len(g)-1))
    num = (Tsum/(len(g)-1)) - T/2
    den = T * math.sqrt(1.0/(12*(len(g)-1)))
    return num/den if den else None

def colless_yule(children, is_leaf, n_leaf):
    if n_leaf < 4: return None
    cnt = subtree_leaf_counts(children, is_leaf)
    cl = 0
    for i in range(len(children)):
        ch = children[i]
        if len(ch) == 2:
            cl += abs(cnt[ch[0]] - cnt[ch[1]])
    n = n_leaf
    E = n*math.log(n) + (0.5772156649015329-1-math.log(2))*n
    V = (3.0 - math.pi**2/6 - math.log(2))*n
    return (cl-E)/math.sqrt(V) if V > 0 else None

def sackin_yule(parent, is_leaf, n_leaf):
    if n_leaf < 4: return None
    s = 0
    for i in range(len(parent)):
        if is_leaf[i]:
            p = parent[i]; d = 0
            while p is not None:
                d += 1; p = parent[p]
            s += d
    Sinv = 2*sum(1.0/k for k in range(2, n_leaf+1))
    E = n_leaf * Sinv
    V = n_leaf**2 * sum(1.0/k**2 for k in range(2, n_leaf+1)) - n_leaf*Sinv
    return (s-E)/math.sqrt(V) if V > 0 else None

def process(tar, biome, region, sra, out_csv):
    written = 0
    with tarfile.open(tar) as tf, open(out_csv, "a") as fh:
        w = csv.writer(fh)
        for m in tf.getmembers():
            if not m.name.endswith(".trees"): continue
            try:
                txt = tf.extractfile(m).read().decode()
                P, BL, L, C, N = parse_newick(txt)
            except Exception: continue
            n_leaf = sum(1 for x in L if x)
            if n_leaf < 6: continue
            try:
                g = pybus_gamma(P, BL, L, C)
                c = colless_yule(C, L, n_leaf)
                s = sackin_yule(P, L, n_leaf)
            except Exception: continue
            w.writerow([biome, region, sra,
                        os.path.basename(m.name).replace(".trees",""),
                        n_leaf, g, c, s])
            written += 1
    return written

if __name__ == "__main__":
    tar, biome, region, sra, out_csv = sys.argv[1:6]
    t0 = time.time()
    n = process(tar, biome, region, sra, out_csv)
    el = time.time() - t0
    print(f"{biome}_{region:5s} {sra:14s} wrote {n:6d} rows in {el:5.1f}s", flush=True)
