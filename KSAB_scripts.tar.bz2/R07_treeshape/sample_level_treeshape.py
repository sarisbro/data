#!/usr/bin/env python3
"""Per-SRA Wilcoxon + Cliff's delta + bootstrap CI on tree-shape metrics.
Usage: python3 sample_level_treeshape.py treeshape_long.csv contrasts.csv per_sra.csv
"""
import sys, numpy as np, pandas as pd
from scipy import stats

inp, out_c, out_a = sys.argv[1:4]
df = pd.read_csv(inp, low_memory=False)
for c in ("gamma","colless_z","sackin_z"):
    df[c] = pd.to_numeric(df[c], errors="coerce")
df = df[df.n_tip >= 6]

# per-SRA medians
agg_dict = {"n_tree":("cophse_id","size"),
            "median_n_tip":("n_tip","median"),
            "median_gamma":("gamma","median"),
            "median_colless_z":("colless_z","median"),
            "median_sackin_z":("sackin_z","median")}
ag = df.groupby(["biome","region","sra"]).agg(**agg_dict).round(4).reset_index()
ag.to_csv(out_a, index=False)

def per_sra(metric):
    sub = df[df[metric].notna() & np.isfinite(df[metric])]
    return sub.groupby(["biome","region","sra"])[metric].median().reset_index()

def contrasts(ag, lbl, B=2000):
    col = ag.columns[-1]; rows = []
    for biome in ("marine","terrestrial"):
        eq = ag[(ag.biome==biome) & (ag.region=="eq")][col]
        for r in ("north","south"):
            x = ag[(ag.biome==biome) & (ag.region==r)][col]
            if len(x)<2 or len(eq)<2: continue
            U, p = stats.mannwhitneyu(x, eq, alternative="two-sided")
            cd = 2*U/(len(x)*len(eq)) - 1
            d_med = float(x.median() - eq.median())
            rng = np.random.default_rng(0)
            diffs = [np.median(rng.choice(x, len(x), replace=True))
                   - np.median(rng.choice(eq, len(eq), replace=True))
                   for _ in range(B)]
            lo, hi = np.quantile(diffs, [0.025, 0.975])
            rows.append({"metric":lbl,"biome":biome,"contrast":f"{r}_vs_eq",
                         "n_pole":len(x),"n_eq":len(eq),
                         "median_diff":round(d_med,3),
                         "ci_lo":round(lo,3),"ci_hi":round(hi,3),
                         "cliff_delta":round(cd,3),"p_wilcox":round(p,4)})
    return rows

all_rows = []
for m, lbl in [("gamma","gamma"), ("colless_z","colless"), ("sackin_z","sackin")]:
    all_rows.extend(contrasts(per_sra(m), lbl))
pd.DataFrame(all_rows).to_csv(out_c, index=False)
print(open(out_c).read())
