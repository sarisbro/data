#!/usr/bin/env python3
"""Supplementary figure: full per-tree distributions of gamma / Colless_z /
Sackin_z, drawn as violin plots over the 6.2 M trees in the 120-sample
cohort.  Complements figure_treeshape.{pdf,png} which shows per-SRA
medians.

Reads /tmp/R07_fast/treeshape_long.csv if present (faster -- already in
RAM), otherwise revision_outputs/R07_treeshape/treeshape_long.csv.

Output: figure_treeshape_per_tree.pdf and .png in this folder.
"""
import os, sys, numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

HERE = os.path.dirname(os.path.abspath(__file__))
SRC  = "/tmp/R07_fast/treeshape_long.csv"
if not os.path.exists(SRC):
    SRC = os.environ.get("R07_LONG_CSV", os.path.join(HERE, "treeshape_long.csv"))
print(f"reading {SRC}", flush=True)
df = pd.read_csv(SRC, low_memory=False)
for c in ("gamma","colless_z","sackin_z"):
    df[c] = pd.to_numeric(df[c], errors="coerce")
df = df[df.n_tip >= 6]

# subsample evenly per stratum to keep the violin plot rasterisation small
rng = np.random.default_rng(7)
SUB_PER_GROUP = 30_000
df_s = (df.groupby(["biome","region"], group_keys=False, observed=True)
          .apply(lambda g: g.sample(min(len(g), SUB_PER_GROUP), random_state=42)))

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 9,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.linewidth": 0.8, "pdf.fonttype": 42,
})

metrics = [("gamma", "Pybus-Harvey $\\gamma$",        (-15, 5)),
           ("colless_z", "Colless (Yule $z$)",         (-20, 60)),
           ("sackin_z",  "Sackin  (Yule $z$)",         (-6, 8))]
biomes   = ["marine", "terrestrial"]
regions  = ["eq", "north", "south"]
biome_col = {"marine": "#1f78b4", "terrestrial": "#33a02c"}
region_lab = {"eq": "equatorial / temperate", "north": "Arctic", "south": "Antarctic"}

fig, axes = plt.subplots(1, 3, figsize=(11.5, 4.0), constrained_layout=True)

for ax, (col, ylab, ylim) in zip(axes, metrics):
    positions, data, colors = [], [], []
    x = 0
    for region in regions:
        for biome in biomes:
            sub = df_s[(df_s.biome == biome) & (df_s.region == region)][col].dropna().values
            if len(sub) > 8000: sub = rng.choice(sub, 8000, replace=False)
            positions.append(x); data.append(sub); colors.append(biome_col[biome])
            x += 1
        x += 0.6

    parts = ax.violinplot(data, positions=positions, widths=0.85, showmedians=True,
                          showextrema=False)
    for body, c in zip(parts["bodies"], colors):
        body.set_facecolor(c); body.set_alpha(0.55); body.set_edgecolor("k"); body.set_linewidth(0.4)
    if "cmedians" in parts:
        parts["cmedians"].set_color("black"); parts["cmedians"].set_linewidth(1.1)

    region_centroids = []
    cx = 0
    for _ in regions:
        region_centroids.append(cx + 0.5); cx += 2 + 0.6
    ax.set_xticks(region_centroids)
    ax.set_xticklabels([region_lab[r] for r in regions])
    ax.set_ylabel(ylab)
    ax.set_ylim(*ylim)
    ax.grid(axis="y", linestyle=":", linewidth=0.4, color="grey", alpha=0.6, zorder=0)

for i, ax in enumerate(axes):
    ax.text(-0.10, 1.04, "abc"[i], transform=ax.transAxes,
            fontsize=12, fontweight="bold", va="bottom", ha="left")

handles = [Patch(facecolor=biome_col["marine"],      alpha=0.6, edgecolor="k", label="marine"),
           Patch(facecolor=biome_col["terrestrial"], alpha=0.6, edgecolor="k", label="terrestrial")]
fig.legend(handles=handles, loc="upper center", frameon=False,
           bbox_to_anchor=(0.5, 1.03), ncol=2)
fig.suptitle(f"Tree-shape statistics across latitudinal bands  "
             f"(per-tree, n=6,201,297 trees; "
             f"subsampled to {SUB_PER_GROUP:,} trees per stratum for display)",
             y=1.09, fontsize=10)

for ext in ("pdf","png"):
    out = os.path.join(HERE, f"figure_treeshape_per_tree.{ext}")
    fig.savefig(out, bbox_inches="tight", dpi=300 if ext=="png" else None)
    print("wrote", out)
