#!/usr/bin/env python3
"""Publication-ready tree-shape figure panel.

Three vertically-stacked sub-panels (one per statistic):
    a)  Pybus-Harvey gamma
    b)  Colless imbalance (Yule-normalised z)
    c)  Sackin imbalance  (Yule-normalised z)

Within each sub-panel, six boxes (marine vs terrestrial X eq / north / south)
with per-SRA medians overlaid as jittered points.  Significance brackets
showing p-values for the polar-vs-equatorial Wilcoxon contrasts at the
sample level.

Inputs : per_sra_medians.csv, sample_level_contrasts.csv
Output : figure_treeshape.pdf and .png in the same folder.
"""
import os, sys, numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

HERE = os.path.dirname(os.path.abspath(__file__))
medi = pd.read_csv(os.path.join(HERE, "per_sra_medians.csv"))
cont = pd.read_csv(os.path.join(HERE, "sample_level_contrasts.csv"))

# typography for ISME-J-like submission
plt.rcParams.update({
    "font.family":       "DejaVu Sans",
    "font.size":         9,
    "axes.titlesize":    9,
    "axes.labelsize":    9,
    "axes.linewidth":    0.8,
    "xtick.labelsize":   8,
    "ytick.labelsize":   8,
    "legend.fontsize":   8,
    "axes.spines.top":   False,
    "axes.spines.right": False,
    "pdf.fonttype":      42,    # editable text in PDF
    "ps.fonttype":       42,
})

metrics = [
    ("median_gamma",      "Pybus-Harvey $\\gamma$",                 "gamma"),
    ("median_colless_z",  "Colless imbalance (Yule $z$)",           "colless"),
    ("median_sackin_z",   "Sackin imbalance (Yule $z$)",            "sackin"),
]
biomes   = ["marine", "terrestrial"]
regions  = ["eq", "north", "south"]
region_lab = {"eq": "equatorial / temperate", "north": "Arctic", "south": "Antarctic"}
biome_col = {"marine": "#1f78b4", "terrestrial": "#33a02c"}

fig, axes = plt.subplots(1, 3, figsize=(11.5, 4.0), sharex=False, constrained_layout=True)

for ax, (col, ylab, mlabel) in zip(axes, metrics):
    # layout: 6 box positions
    positions, data, colors = [], [], []
    x = 0
    for region in regions:
        for biome in biomes:
            sub = medi[(medi.biome == biome) & (medi.region == region)][col].dropna()
            positions.append(x); data.append(sub.values); colors.append(biome_col[biome])
            x += 1
        x += 0.6
    # boxplot (notched; per-SRA medians, no extreme aggregate)
    bp = ax.boxplot(data, positions=positions, widths=0.7, patch_artist=True,
                    showfliers=False, notch=False,
                    medianprops=dict(color="black", lw=1.4),
                    whiskerprops=dict(lw=0.8), capprops=dict(lw=0.8),
                    boxprops=dict(lw=0.6))
    for patch, c in zip(bp["boxes"], colors):
        patch.set_facecolor(c); patch.set_alpha(0.55)
    # jittered points
    rng = np.random.default_rng(7)
    for px, y_arr, c in zip(positions, data, colors):
        if len(y_arr) == 0: continue
        jit = rng.uniform(-0.18, 0.18, size=len(y_arr))
        ax.scatter(px + jit, y_arr, s=11, color=c, edgecolors="k", linewidths=0.35,
                   alpha=0.85, zorder=3)
    region_centroids = []
    cx = 0
    for _ in regions:
        region_centroids.append(cx + 0.5); cx += 2 + 0.6
    ax.set_xticks(region_centroids)
    ax.set_xticklabels([region_lab[r] for r in regions], rotation=0)
    ax.set_ylabel(ylab)
    ax.grid(axis="y", linestyle=":", linewidth=0.4, color="grey", alpha=0.6, zorder=0)

    # y limits: IQR-aware, leave room above for brackets
    all_vals = np.concatenate([np.asarray(a) for a in data if len(a)])
    q05, q95 = np.nanquantile(all_vals, [0.025, 0.975])
    med, iqr = np.nanmedian(all_vals), np.nanquantile(all_vals,0.75)-np.nanquantile(all_vals,0.25)
    lo = min(q05, med - 3*iqr); hi = max(q95, med + 3*iqr)
    span = hi - lo if hi > lo else 1
    bracket_pad = span * 0.16
    ax.set_ylim(lo - span*0.04, hi + bracket_pad)

    # significance brackets -- significant contrasts only, separate row per biome
    rows = cont[cont.metric == mlabel]
    y_top = hi
    y_off = span * 0.045
    # marine first (top row of brackets), then terrestrial (bottom row)
    for k, biome in enumerate(biomes):
        b_rows = rows[(rows.biome == biome) & (rows.p_wilcox < 0.05)]
        for j, (_, row) in enumerate(b_rows.iterrows()):
            polar_reg = "north" if row.contrast.startswith("north") else "south"
            eq_idx    = regions.index("eq")    * 2 + biomes.index(biome)
            polar_idx = regions.index(polar_reg) * 2 + biomes.index(biome)
            x_eq, x_pol = positions[eq_idx], positions[polar_idx]
            y_br = y_top + y_off * (1.0 + k*1.5 + j*0.9)
            ax.plot([x_eq, x_eq, x_pol, x_pol],
                    [y_br - y_off*0.18, y_br, y_br, y_br - y_off*0.18],
                    color=colors[eq_idx], linewidth=0.8)
            stars = "***" if row.p_wilcox<0.001 else "**" if row.p_wilcox<0.01 else "*"
            ax.text((x_eq+x_pol)/2, y_br + y_off*0.05,
                    f"{stars} $\\delta={row.cliff_delta:+.2f}$",
                    ha="center", va="bottom", fontsize=7.5, color=colors[eq_idx])

# panel labels
for i, ax in enumerate(axes):
    ax.text(-0.10, 1.04, "abc"[i], transform=ax.transAxes,
            fontsize=12, fontweight="bold", va="bottom", ha="left")

# legend
from matplotlib.patches import Patch
handles = [Patch(facecolor=biome_col["marine"],      alpha=0.6, edgecolor="k", label="marine"),
           Patch(facecolor=biome_col["terrestrial"], alpha=0.6, edgecolor="k", label="terrestrial")]
fig.legend(handles=handles, loc="upper center", frameon=False,
           bbox_to_anchor=(0.5, 1.03), ncol=2)
fig.suptitle("Tree-shape statistics across latitudinal bands  (per-SRA medians, $n=120$)",
             y=1.10, fontsize=10)

# save
out_pdf = os.path.join(HERE, "figure_treeshape.pdf")
out_png = os.path.join(HERE, "figure_treeshape.png")
fig.savefig(out_pdf, bbox_inches="tight")
fig.savefig(out_png, bbox_inches="tight", dpi=300)
print("wrote", out_pdf)
print("wrote", out_png)
