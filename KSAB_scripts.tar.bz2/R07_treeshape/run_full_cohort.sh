#!/usr/bin/env bash
# R07 -- full-cohort sweep using the fast pure-Python tree-shape parser.
#
# Two flavours of runner are shipped:
#
#   * treeshape_fast.py        - sequential, processes a whole tarball.
#                                Fastest; assumes well-formed .tar.gz.
#   * treeshape_fast_iter.py   - slice-aware iterator, tolerates truncated
#                                .tar.gz, accepts start/end member indices.
#                                Two cohort tarballs (SRR24091367,
#                                SRR30952025) have ~4 x 10^5 members each
#                                and a truncated EOF marker; use _iter on
#                                those.

set -euo pipefail
source "$(dirname "$0")/../config.sh"
OUT="${REV_OUT}/R07_treeshape"; mkdir -p "${OUT}"
CSV="${OUT}/treeshape_long.csv"
echo "biome,region,sra,cophse_id,n_tip,gamma,colless_z,sackin_z" > "${CSV}"

# Tarballs we know are truncated -- process with iterator + slicing.
HUGE_SLICED=( "SRR24091367" "SRR30952025" )
huge_match() {
  for h in "${HUGE_SLICED[@]}"; do [[ "$1" == "$h" ]] && return 0; done
  return 1
}

for biome in marine terrestrial; do
  for region in eq north south; do
    d="${HMMER_DIR}/${biome}_${region}"
    [[ ! -d "$d" ]] && continue
    for sra in $(ls "$d"); do
      tar="$d/$sra/hits_trees.tar.gz"
      [[ -f "$tar" ]] || continue
      if huge_match "$sra"; then
        # process in 100k-member slices to bound wall-time
        for start in 0 100000 200000 300000; do
          python3 "$(dirname "$0")/treeshape_fast_iter.py" \
              "$tar" "$biome" "$region" "$sra" "$CSV" \
              "$start" $((start+100000))
        done
      else
        python3 "$(dirname "$0")/treeshape_fast.py" \
            "$tar" "$biome" "$region" "$sra" "$CSV"
      fi
    done
  done
done

echo "[R07] full cohort written to $CSV  ($(($(wc -l < "$CSV")-1)) rows)"

python3 "$(dirname "$0")/sample_level_treeshape.py" "$CSV" \
        "${OUT}/sample_level_contrasts.csv" "${OUT}/per_sra_medians.csv"
echo "[R07] sample-level contrasts written"
