#!/usr/bin/env python3
"""Slice-aware, iter-based variant of treeshape_fast.py.

Differences vs treeshape_fast.py:
  * Accepts <start_idx> <end_idx> (0-based, half-open) member indices
    so a tarball can be processed in pieces.
  * Uses tarfile.open(..., mode='r|*') and a single forward pass, so
    truncated .tar.gz files (where the EOF marker is missing) still
    yield rows up to the truncation point.  Two of the 120 cohort
    tarballs were truncated at production time; this iterator processes
    them without raising.

Usage:
    python3 treeshape_fast_iter.py <tarball> <biome> <region> <sra> \\
                                    <out_csv> <start_idx> <end_idx>

    end_idx == -1  ->  process to end of tarball.

Outputs one CSV row per CoPHSe with cols
    biome, region, sra, cophse_id, n_tip, gamma, colless_z, sackin_z
appended to <out_csv>.
"""
import os, sys, tarfile, csv, math, re, time

# ---- Newick parser ---------------------------------------------------------
def parse_newick(txt):
    parent=[]; blen=[]; is_leaf=[]; children=[]
    cur=None; stack=[]; pos=0; n=len(txt)
    while pos < n:
        c = txt[pos]
        if c == '(':
            i = len(parent)
            parent.append(cur); blen.append(0.0); is_leaf.append(False)
            children.append([])
            if cur is not None: children[cur].append(i)
            stack.append(cur); cur = i; pos += 1
        elif c == ',':
            pos += 1
        elif c == ')':
            cur = stack.pop(); pos += 1
            m = re.match(r'([^:,();]*)', txt[pos:])
            if m and m.group(0):
                pos += len(m.group(0))
            if pos < n and txt[pos] == ':':
                pos += 1
                m = re.match(r'([0-9.eE+\-]+)', txt[pos:])
                if m:
                    last = children[cur][-1] if cur is not None else (len(parent)-1)
                    blen[last] = float(m.group(1)); pos += len(m.group(0))
        elif c == ';':
            break
        else:
            m = re.match(r'([^:,();]+)', txt[pos:])
            if not m: pos += 1; continue
            pos += len(m.group(0))
            i = len(parent)
            parent.append(cur); blen.append(0.0); is_leaf.append(True)
            children.append([])
            if cur is not None: children[cur].append(i)
            if pos < n and txt[pos] == ':':
                pos += 1
                m = re.match(r'([0-9.eE+\-]+)', txt[pos:])
                if m: blen[i] = float(m.group(1)); pos += len(m.group(0))
    return parent, blen, is_leaf, children

def depth_from_root(parent, blen):
    d = [0.0]*len(parent)
    for i in range(len(parent)):
        if parent[i] is not None: d[i] = d[parent[i]] + blen[i]
    return d

def pybus_gamma(parent, blen, is_leaf):
    d = depth_from_root(parent, blen)
    internal = sorted(d[i] for i in range(len(parent)) if not is_leaf[i])
    n_leaf = sum(1 for x in is_leaf if x)
    if n_leaf < 5: return None
    tree_depth = max(d)
    g = [internal[i+1]-internal[i] for i in range(len(internal)-1)]
    g.append(tree_depth - internal[-1])
    g = [x for x in g if x > 0]
    if len(g) < 4: return None
    T = sum((i+2)*g[i] for i in range(len(g)))
    Tsum = sum(sum((k+2)*g[k] for k in range(i+1)) for i in range(len(g)-1))
    num = (Tsum/(len(g)-1)) - T/2
    den = T * math.sqrt(1.0/(12*(len(g)-1)))
    return num/den if den else None

def colless_yule(children, is_leaf, n_leaf):
    if n_leaf < 4: return None
    cnt = [0]*len(children)
    for i in range(len(children)-1, -1, -1):
        cnt[i] = 1 if is_leaf[i] else sum(cnt[c] for c in children[i])
    cl = 0
    for i in range(len(children)):
        ch = children[i]
        if len(ch) == 2: cl += abs(cnt[ch[0]] - cnt[ch[1]])
    n = n_leaf
    E = n*math.log(n) + (0.5772156649015329-1-math.log(2))*n
    V = (3.0 - math.pi**2/6 - math.log(2))*n
    return (cl-E)/math.sqrt(V) if V > 0 else None

def sackin_yule(parent, is_leaf, n_leaf):
    if n_leaf < 4: return None
    s = 0
    for i in range(len(parent)):
        if is_leaf[i]:
            p = parent[i]; depth = 0
            while p is not None: depth += 1; p = parent[p]
            s += depth
    Sinv = 2*sum(1.0/k for k in range(2, n_leaf+1))
    E = n_leaf * Sinv
    V = n_leaf**2 * sum(1.0/k**2 for k in range(2, n_leaf+1)) - n_leaf*Sinv
    return (s-E)/math.sqrt(V) if V > 0 else None

# ---- main ------------------------------------------------------------------
if __name__ == "__main__":
    tar, biome, region, sra, out_csv, s, e = sys.argv[1:8]
    s = int(s); e = int(e)
    t0 = time.time(); written = 0; idx = -1; tries = 0
    try:
        with tarfile.open(tar, mode='r|*') as tf, open(out_csv, "a") as fh:
            w = csv.writer(fh)
            for m in tf:
                if not m.name.endswith(".trees"): continue
                idx += 1
                if idx < s: continue
                if e != -1 and idx >= e: break
                tries += 1
                try:
                    txt = tf.extractfile(m).read().decode()
                    P,BL,L,C = parse_newick(txt)
                except Exception: continue
                n_leaf = sum(L)
                if n_leaf < 6: continue
                try:
                    g  = pybus_gamma(P, BL, L)
                    cl = colless_yule(C, L, n_leaf)
                    sk = sackin_yule(P, L, n_leaf)
                except Exception: continue
                w.writerow([biome, region, sra,
                            os.path.basename(m.name).replace(".trees",""),
                            n_leaf, g, cl, sk])
                written += 1
    except tarfile.ReadError as ex:
        # Truncated .tar.gz -- whatever we read is preserved.
        sys.stderr.write(f"[{sra}] tar truncated at idx~{idx}: {ex}\n")
    print(f"{biome}_{region:5s} {sra} [{s}:{e}] tried={tries} wrote={written} "
          f"in {time.time()-t0:.1f}s")
