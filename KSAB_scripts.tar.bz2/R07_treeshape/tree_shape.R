#!/usr/bin/env Rscript
# R07 -- Per-CoPHSe tree-shape statistics across strata:
#         * gamma  (Pybus & Harvey 2000)  -- timing of branching events
#         * Colless imbalance              -- topological balance
#         * Sackin index                   -- alternative imbalance index
#
# Trees are stored in the existing hmmer_align/{biome}_{region}/{SRA}/hits_trees.tar.gz
# We stream-extract Newick files instead of inflating the whole archive.
#
# Output : revision_outputs/R07_treeshape/treeshape_long.csv  (one row per tree)
#          plus a mixed-model summary (region fixed, marker tree as random).

suppressPackageStartupMessages({
  library(ape); library(apTreeshape); library(dplyr); library(tidyr)
  library(parallel); library(ggplot2); library(lme4); library(lmerTest)
})
rev_out <- Sys.getenv("REV_OUT")
hmmer   <- Sys.getenv("HMMER_DIR")
out     <- file.path(rev_out, "R07_treeshape"); dir.create(out, showWarnings = FALSE, recursive = TRUE)

# Build the list of per-sample tarballs
grid <- expand.grid(biome  = c("marine", "terrestrial"),
                    region = c("eq", "north", "south"),
                    stringsAsFactors = FALSE)
records <- list()
for (i in seq_len(nrow(grid))) {
  d <- file.path(hmmer, paste0(grid$biome[i], "_", grid$region[i]))
  if (!dir.exists(d)) next
  for (sra in list.files(d)) {
    tarp <- file.path(d, sra, "hits_trees.tar.gz")
    if (!file.exists(tarp)) next
    records[[length(records) + 1L]] <- list(biome = grid$biome[i],
                                            region = grid$region[i],
                                            sra = sra, tar = tarp)
  }
}

shape_one <- function(rec) {
  td <- tempfile(); dir.create(td)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  untar(rec$tar, exdir = td, extras = "--strip-components 1")
  files <- list.files(td, pattern = "\\.trees$", full.names = TRUE)
  if (!length(files)) return(NULL)
  res <- vector("list", length(files))
  for (k in seq_along(files)) {
    tr <- tryCatch(read.tree(files[k]), error = function(e) NULL)
    if (is.null(tr) || Ntip(tr) < 6) next
    # FastTree output is unrooted + may be multifurcating: midpoint-root
    # and resolve polytomies before tree-shape statistics.
    tr <- tryCatch(phangorn::midpoint(tr), error = function(e) tr)
    tr <- tryCatch(ape::multi2di(tr, random = FALSE), error = function(e) tr)
    ts <- tryCatch(as.treeshape(tr), error = function(e) NULL)
    if (is.null(ts)) next
    res[[k]] <- data.frame(
      biome   = rec$biome,
      region  = rec$region,
      sra     = rec$sra,
      tree_id = sub("\\.trees$", "", basename(files[k])),
      n_tip   = Ntip(tr),
      gamma   = gammaStat(tr),
      colless = colless(ts, norm = "yule"),
      sackin  = sackin(ts,  norm = "yule"))
  }
  do.call(rbind, res)
}

cl  <- makeCluster(min(parallel::detectCores(), 16))
clusterEvalQ(cl, { library(ape); library(apTreeshape) })
res <- do.call(rbind, parLapply(cl, records, shape_one))
stopCluster(cl)
write.csv(res, file.path(out, "treeshape_long.csv"), row.names = FALSE)

# ---- mixed model: gamma ~ region * biome + (1 | sra) ------------------------
fit <- lmer(gamma ~ region * biome + (1 | sra), data = res)
sink(file.path(out, "mixed_model_summary.txt"))
print(summary(fit)); print(anova(fit))
sink()

# ---- violin plot ------------------------------------------------------------
res$region <- factor(res$region, levels = c("eq", "north", "south"))
ggplot(res, aes(region, gamma, fill = biome)) +
  geom_violin(scale = "width", alpha = 0.6, position = position_dodge(0.6)) +
  geom_boxplot(width = 0.12, outlier.size = 0.3, position = position_dodge(0.6)) +
  scale_fill_manual(values = c(marine = "#1f78b4", terrestrial = "#33a02c")) +
  geom_hline(yintercept = 0, lty = 2, colour = "grey50") +
  labs(y = expression(gamma~"statistic (negative = deeper-branch trees)"),
       x = NULL) +
  theme_classic(base_size = 11)
ggsave(file.path(out, "gamma_by_region.pdf"), width = 7, height = 4)
