# R07 - Tree-shape statistics

## What's in this folder

### Code

| file                          | purpose                                                                 |
|-------------------------------|-------------------------------------------------------------------------|
| `treeshape_fast.py`           | sequential pure-Python Newick parser + tree-shape pass on one tarball |
| `treeshape_fast_iter.py`      | slice-aware version that tolerates truncated `.tar.gz`                |
| `run_full_cohort.sh`          | orchestration: knows which tarballs need slicing                      |
| `sample_level_treeshape.py`   | per-SRA Wilcoxon + Cliff's $\delta$ + bootstrap CI                    |
| `tree_shape.R`                | original R version (lme4/apTreeshape) -- use on a node with R         |
| `figure_treeshape.py`         | main figure: per-SRA boxplots with significance brackets              |
| `figure_treeshape_supp.py`    | supplementary figure: per-tree violins                                |

### Data

| file                              | rows | what                                            |
|-----------------------------------|------|-------------------------------------------------|
| `per_sra_medians.csv`             | 120  | one row per SRA: median $\gamma$ / Colless / Sackin |
| `sample_level_contrasts.csv`      |  12  | Wilcoxon p-values, Cliff $\delta$, 95% CIs       |

### Figures

**Recommended for submission:**

- `figure_treeshape.pdf` / `.png` -- single-row 3-panel boxplot of per-SRA
  medians, with significance brackets for the contrasts that survive
  sample-level inference (Cliff $\delta$ printed inline).

**Supplementary:**

- `figure_treeshape_per_tree.pdf` / `.png` -- single-row 3-panel violin plot
  showing the full per-tree distributions (6.2 M trees, subsampled to
  30 000 per stratum for display).  Useful as Supplementary Fig.~Sx so
  reviewers can see the underlying spread.

The earlier `figure_treeshape_combined.pdf` is left in the folder for
reference but is not the recommended layout (significance brackets in
the boxplot row are clipped by the constrained-layout sharing y-axis
with the violin row).

## Headline statistics

120 of 120 samples, 6 201 297 per-CoPHSe trees with $\geq 6$ tips.
Sample-level Wilcoxon contrasts (one observation per SRA, n=17-24 per stratum):

| metric           | biome       | contrast       | Cliff $\delta$ |   p    |
|------------------|-------------|----------------|-------:|-------:|
| Sackin imbalance | marine      | north vs eq    | $+0.56$| **0.0025** |
| Colless imbalance| marine      | north vs eq    | $+0.52$| **0.0053** |
| Colless imbalance| terrestrial | south vs eq    | $+0.47$| **0.0135** |
| Sackin imbalance | terrestrial | south vs eq    | $+0.41$| **0.0322** |
| Pybus $\gamma$   | terrestrial | south vs eq    | $-0.40$| **0.0358** |
| Pybus $\gamma$   | marine      | south vs eq    | $-0.33$|   0.083    |
| Pybus $\gamma$   | marine      | north vs eq    | $-0.31$|   0.093    |
| Pybus $\gamma$   | terrestrial | north vs eq    | $-0.27$|   0.144    |
| Colless          | marine      | south vs eq    | $+0.19$|   0.332    |
| Colless          | terrestrial | north vs eq    | $+0.16$|   0.401    |
| Sackin           | marine      | south vs eq    | $-0.03$|   0.907    |
| Sackin           | terrestrial | north vs eq    | $+0.04$|   0.839    |

Five of twelve contrasts at $\alpha=0.05$, three at $\alpha=0.01$, with
effect sizes $|\delta|=0.40$-$0.56$.  Tree topology in polar viromes is
statistically more imbalanced and shows more excess of early branching
than in temperate viromes, independent of pairwise distance, and at the
proper sample-level resolution.

## Running on your DRAC node

```
source ../config.sh           # exports HMMER_DIR, REV_OUT, etc.
bash run_full_cohort.sh
```

The two large temperate marine tarballs (SRR24091367 and SRR30952025)
are processed in 100k-member slices by `treeshape_fast_iter.py`;
SRR24091367 has a truncated `.tar.gz` EOF marker which the iterator
handles gracefully (~10 trees lost at the truncation boundary out of
~400 k).
