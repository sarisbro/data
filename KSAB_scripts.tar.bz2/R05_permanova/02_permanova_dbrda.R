#!/usr/bin/env Rscript
# R05.02 -- PERMANOVA + db-RDA of viral community divergence on environmental
#           variables, with latitude as a covariate.  This separates "how much
#           of polar-ness is latitude per se" from "how much is temperature /
#           salinity / season."

suppressPackageStartupMessages({
  library(vegan); library(dplyr); library(tidyr); library(ggplot2)
})

rev_out <- Sys.getenv("REV_OUT")
votu    <- read.delim(file.path(rev_out, "R02_rarefaction", "sample_votu_long.tsv"))
meta    <- read.delim(file.path(rev_out, "R05_permanova", "biosample_metadata.tsv"))

wide <- votu %>% tidyr::pivot_wider(names_from = votu, values_from = count, values_fill = 0L)
samp <- wide$sample; m <- as.matrix(wide[, -1]); rownames(m) <- samp

# coerce metadata
parse_temp <- function(x) suppressWarnings(as.numeric(sub("[^0-9.\\-].*$", "", x)))
parse_lat  <- function(x) suppressWarnings({
  v <- strsplit(x, " ")[[1]]; if (length(v) < 2) NA else
  as.numeric(v[1]) * ifelse(grepl("^S", v[2], ignore.case = TRUE), -1, 1)
})
meta$temperature <- sapply(meta$temperature, parse_temp)
meta$salinity    <- sapply(meta$salinity,    parse_temp)
meta$depth       <- sapply(meta$depth,       parse_temp)
meta$lat         <- sapply(meta$lat_lon,     parse_lat)
meta$sample      <- paste0(meta$biome, "_", meta$region, "__", meta$sra)

meta <- meta[match(samp, meta$sample), ]
keep <- complete.cases(meta[, c("temperature", "lat")])

# Bray-Curtis on Hellinger-transformed counts
hel  <- decostand(m[keep, ], "hellinger")
dst  <- vegdist(hel, method = "bray")

# PERMANOVA: marginal effects of temperature, salinity, depth, biome, |lat|
ad   <- adonis2(dst ~ biome + abs(lat) + temperature + salinity + depth,
                data = meta[keep, ], by = "margin", permutations = 999)
write.csv(as.data.frame(ad), file.path(rev_out, "R05_permanova", "permanova_marginal.csv"))

# db-RDA, condition out latitude band (eq/north/south) to ask if environmental
# drivers explain residual community variation
rda <- capscale(hel ~ temperature + salinity + depth + Condition(region),
                data = meta[keep, ], distance = "bray")
print(anova(rda, by = "term", permutations = 999))
pdf(file.path(rev_out, "R05_permanova", "dbrda_ordination.pdf"), 7, 6)
plot(rda, type = "n", main = "db-RDA conditioned on latitudinal band")
points(rda, pch = 21, bg = c("#1b9e77", "#d95f02", "#7570b3")[as.factor(meta$region[keep])])
text(rda, "bp", col = "red")
legend("topleft", legend = levels(as.factor(meta$region[keep])),
       pt.bg = c("#1b9e77", "#d95f02", "#7570b3"), pch = 21)
dev.off()
