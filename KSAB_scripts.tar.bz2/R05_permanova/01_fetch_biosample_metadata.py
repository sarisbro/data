#!/usr/bin/env python3
# R05.01 -- For every SRA accession in the study, fetch the linked BioSample
#           record from NCBI Entrez and extract environmental attributes
#           (temperature, salinity, depth, pH, collection_date, biome).
#
# Writes : revision_outputs/R05_permanova/biosample_metadata.tsv
import os, sys, time, csv
from xml.etree import ElementTree as ET
from Bio import Entrez

Entrez.email = "sarisbro@uottawa.ca"
Entrez.api_key = os.environ.get("NCBI_API_KEY", "")

ROOT = os.environ["CONTIGS_DIR"]
OUT  = os.path.join(os.environ["REV_OUT"], "R05_permanova")
os.makedirs(OUT, exist_ok=True)

# Collect all SRA accessions from contigs_by_region/
srs = []
for biome in ("marine", "terrestrial"):
    for region in ("eq", "north", "south"):
        d = os.path.join(ROOT, biome, region)
        if os.path.isdir(d):
            for sra in sorted(os.listdir(d)):
                if not sra.startswith("."):
                    srs.append((biome, region, sra))

FIELDS = ["temperature", "salinity", "depth", "ph", "collection_date",
          "geo_loc_name", "lat_lon", "env_biome", "env_feature", "env_material"]

with open(os.path.join(OUT, "biosample_metadata.tsv"), "w", newline="") as fh:
    w = csv.writer(fh, delimiter="\t")
    w.writerow(["biome", "region", "sra", "biosample"] + FIELDS)
    for biome, region, sra in srs:
        try:
            # SRA -> BioSample link
            h  = Entrez.elink(dbfrom="sra", db="biosample", id=sra)
            r  = Entrez.read(h)
            bs = r[0]["LinkSetDb"][0]["Link"][0]["Id"]
            h  = Entrez.efetch(db="biosample", id=bs, rettype="xml")
            tr = ET.fromstring(h.read())
            attrs = {a.attrib.get("attribute_name", "").lower(): a.text
                     for a in tr.iter("Attribute")}
            row = [biome, region, sra, bs] + [attrs.get(f, "") for f in FIELDS]
            w.writerow(row)
        except Exception as e:
            sys.stderr.write(f"[{sra}] {e}\n")
        time.sleep(0.2)        # be polite
