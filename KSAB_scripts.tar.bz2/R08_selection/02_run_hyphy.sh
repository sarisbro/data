#!/usr/bin/env bash
# R08.02 -- For each codon alignment with > 6 tips and both polar+temperate
#           branches labelled, run HyPhy aBSREL (branch-site selection) and
#           BUSTED (overall episodic positive selection).
#
# Branch labels: tips whose name begins with "<biome>_<region>__" are tagged
# {Polar} if region in {north, south}, {Temperate} otherwise. aBSREL is told
# to test the {Polar} clade for positive selection.

set -euo pipefail
source "$(dirname "$0")/../config.sh"
WD="${REV_OUT}/R08_selection"
LOG="${WD}/hyphy_log.tsv"
echo -e "tree\tn_tip\taBSREL_p\tBUSTED_p\tomega_polar\tomega_temp" > "${LOG}"

for aln in "${WD}/codon_aln"/*/cds.codon.aln; do
  d=$(dirname "$aln")
  # tag tips
  python3 - <<PY > "${d}/labels.txt"
import re
tips = []
for ln in open("$aln"):
    if ln.startswith(">"):
        t = ln[1:].strip()
        tag = "Polar" if re.search(r"_(north|south)__", t) else "Temperate"
        tips.append(f"{t}\t{tag}")
print("\n".join(tips))
PY
  # build a starting tree on the alignment
  FastTree -gtr -nt "$aln" > "${d}/start.tree" 2>/dev/null || continue
  # branch-labelled NEXUS for HyPhy
  python3 "$(dirname "$0")/_label_tree.py" "${d}/start.tree" "${d}/labels.txt" "${d}/labeled.tree"

  # aBSREL on the Polar set
  hyphy absrel --alignment "$aln" --tree "${d}/labeled.tree" \
         --branches Polar --output "${d}/absrel.json" > "${d}/absrel.log" 2>&1 || continue
  # BUSTED
  hyphy busted --alignment "$aln" --tree "${d}/labeled.tree" \
         --branches Polar --output "${d}/busted.json" > "${d}/busted.log" 2>&1 || true

  python3 "$(dirname "$0")/_summarise_hyphy.py" \
        "${d}/absrel.json" "${d}/busted.json" "$aln" >> "${LOG}"
done

echo "[R08.02] HyPhy summary -> ${LOG}"
