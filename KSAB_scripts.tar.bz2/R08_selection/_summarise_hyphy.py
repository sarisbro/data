#!/usr/bin/env python3
"""One-line summary per tree: aBSREL p-value (uncorrected), BUSTED p, polar omega."""
import sys, json, os
absrel_json, busted_json, aln = sys.argv[1:]
def safe(d, *keys, default="NA"):
    for k in keys:
        if d is None: return default
        d = d.get(k) if isinstance(d, dict) else None
    return default if d is None else d
a = json.load(open(absrel_json)) if os.path.getsize(absrel_json) else {}
b = json.load(open(busted_json)) if os.path.exists(busted_json) and os.path.getsize(busted_json) else {}
ntip = sum(1 for ln in open(aln) if ln.startswith(">"))
absrel_p = min(
    [v.get("Corrected P-value", 1.0)
     for v in a.get("branch attributes", {}).get("0", {}).values()
     if isinstance(v, dict)] or [1.0])
busted_p = safe(b, "test results", "p-value")
omega    = safe(a, "fits", "Unconstrained model", "Rate Distributions")
print(f"{os.path.dirname(absrel_json)}\t{ntip}\t{absrel_p}\t{busted_p}\t{omega}\tNA")
