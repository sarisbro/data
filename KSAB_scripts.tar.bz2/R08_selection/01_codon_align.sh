#!/usr/bin/env bash
# R08.01 -- For each CoPHSe that contains *both* polar and temperate
#           environmental sequences, build a codon-aware alignment with
#           MACSE v2, ready for HyPhy aBSREL.
#
# Why MACSE: handles stop codons, frameshifts, and partial CDS from MAGs
# without losing reading frame -- common with short polar contigs.

set -euo pipefail
source "$(dirname "$0")/../config.sh"
OUT="${REV_OUT}/R08_selection"
mkdir -p "${OUT}/codon_aln"

MACSE_JAR="${MACSE_JAR:-/opt/macse_v2.06.jar}"

# Discover CoPHSe with mixed polar/temperate membership using the per-tree CSVs
python3 - <<'PY' > "${OUT}/mixed_trees.txt"
import os, glob, csv
hmmer = os.environ["HMMER_DIR"]
mixed = []
for grp_dir in glob.glob(os.path.join(hmmer, "*_*")):
    grp = os.path.basename(grp_dir)               # e.g. marine_north
    for sra_dir in glob.glob(os.path.join(grp_dir, "*")):
        cd = os.path.join(sra_dir, "hits_trees_clade_distance_patristic.csv")
        if not os.path.isfile(cd):
            continue
        # we'll need to know which trees include polar+temperate -> done in step 2;
        # for now, emit every (group, sra, tree) candidate.
        with open(cd) as fh:
            rdr = csv.DictReader(fh)
            for row in rdr:
                if int(row["n_gene"] or 0) >= 4:
                    mixed.append(f"{grp}\t{os.path.basename(sra_dir)}\t{row['member']}")
print("\n".join(mixed))
PY

# Pull the corresponding nucleotide CDS for each tree's tips (from
# genomad_results/{grp}/{sra}_genomad/.../final.contigs_virus.fna +
# .../final.contigs_virus_genes.tsv giving CDS coordinates) and
# pair with reference IMG/VR CDS (when available) — wrapper does both.

while IFS=$'\t' read -r grp sra tree; do
  wkd="${OUT}/codon_aln/${grp}__${sra}__${tree//[\/]/__}"
  mkdir -p "$wkd"
  python3 "$(dirname "$0")/_gather_cds.py" "$grp" "$sra" "$tree" "$wkd/cds.fna"
  [[ ! -s "${wkd}/cds.fna" ]] && continue
  java -jar "${MACSE_JAR}" -prog alignSequences \
        -seq "${wkd}/cds.fna" -out_NT "${wkd}/cds.macse.fna" \
        -out_AA "${wkd}/cds.macse.faa" -fs_term_subst -
  # filter to in-frame, gap-trimmed alignment
  trimal -in "${wkd}/cds.macse.fna" -out "${wkd}/cds.codon.aln" -gappyout
done < "${OUT}/mixed_trees.txt"
