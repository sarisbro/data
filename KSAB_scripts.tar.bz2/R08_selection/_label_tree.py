#!/usr/bin/env python3
"""Append {Polar} / {Temperate} HyPhy branch labels to tips of a Newick tree."""
import sys
tree, labels, out = sys.argv[1:]
tag = {}
for ln in open(labels):
    t, g = ln.rstrip().split("\t"); tag[t] = g
nw = open(tree).read()
for t, g in tag.items():
    nw = nw.replace(t, f"{t}{{{g}}}")
open(out, "w").write(nw)
