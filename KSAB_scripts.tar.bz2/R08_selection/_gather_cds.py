#!/usr/bin/env python3
"""Reconstruct nucleotide CDS for the tips of a single CoPHSe tree.

Args : group  (e.g. marine_north)
       sra
       tree   (e.g. hits_trees/170676.trees)
       out_fna

Reads geNomad's virus_genes.tsv to map protein-id -> contig:start..end and
slices the corresponding nucleotide CDS out of the virus.fna assembly.
"""
import os, sys, gzip, re
from Bio import SeqIO

grp, sra, tree, out_fna = sys.argv[1:]
GENOMAD = os.environ["GENOMAD_DIR"]
HMMER   = os.environ["HMMER_DIR"]
import subprocess, tempfile, tarfile

# 1. read the tree to get tip names
import io
with tarfile.open(os.path.join(HMMER, grp, sra, "hits_trees.tar.gz")) as tf:
    member = tf.getmember(tree)
    newick = tf.extractfile(member).read().decode()
tips = re.findall(r"[A-Za-z0-9_.|:-]+", newick)
tips = [t for t in tips if not re.match(r"^[\d.eE+-]+$", t)]

# 2. resolve each tip to a (contig, start, end, strand)
genes_tsv = os.path.join(GENOMAD, grp, f"{sra}_genomad",
                         "final.contigs_summary", "final.contigs_virus_genes.tsv")
contigs_fna = os.path.join(GENOMAD, grp, f"{sra}_genomad",
                           "final.contigs_summary", "final.contigs_virus.fna")
if not os.path.isfile(genes_tsv):
    sys.exit(0)
loc = {}
with open(genes_tsv) as fh:
    hdr = fh.readline().rstrip().split("\t")
    for line in fh:
        v = dict(zip(hdr, line.rstrip().split("\t")))
        loc[v["gene"]] = (v["seq_name"], int(v["start"]), int(v["end"]), int(v["strand"]))

seqs = {r.id: r.seq for r in SeqIO.parse(contigs_fna, "fasta")}

with open(out_fna, "w") as out:
    for tip in tips:
        # tips look like "ENV|<sra>|<gene_id>"  or IMG/VR "REF|<imgvr_id>"
        gid = tip.split("|")[-1]
        if gid not in loc:
            continue
        ctg, s, e, strand = loc[gid]
        sub = seqs[ctg][s-1:e]
        if strand == -1:
            sub = sub.reverse_complement()
        out.write(f">{tip}\n{sub}\n")
