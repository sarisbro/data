#!/usr/bin/env Rscript
# R09 -- companion: PCA of tetranucleotide frequencies; ENC-GC3 plot;
#                   per-CoPHSe outlier detection (Mahalanobis distance > X)
suppressPackageStartupMessages({ library(dplyr); library(ggplot2); library(robustbase) })
rev <- Sys.getenv("REV_OUT")
d   <- read.delim(file.path(rev, "R09_composition", "composition.tsv"))

# ENC vs GC3 panel (the classical Wright plot)
ggplot(d, aes(GC3, ENC, colour = region)) +
  geom_point(alpha = 0.25, size = 0.7) +
  facet_wrap(~ biome) +
  scale_colour_manual(values = c(eq="#999", north="#1f78b4", south="#e31a1c")) +
  labs(title = "ENC vs GC3 — codon-usage signature by region") +
  theme_classic(base_size = 11)
ggsave(file.path(rev, "R09_composition", "ENC_GC3.pdf"), width = 7, height = 4)

# PCA of tetranucleotide frequencies
k  <- grep("^f_", names(d), value = TRUE)
mat <- as.matrix(d[, k])
pc <- prcomp(mat, scale. = TRUE, rank. = 5)
pl <- data.frame(d[, 1:4], pc$x[, 1:2])
ggplot(pl, aes(PC1, PC2, colour = region)) +
  geom_point(alpha = 0.25, size = 0.7) + facet_wrap(~ biome) +
  scale_colour_manual(values = c(eq="#999", north="#1f78b4", south="#e31a1c")) +
  labs(title = "Tetranucleotide PCA") + theme_classic(base_size = 11)
ggsave(file.path(rev, "R09_composition", "tetranuc_PCA.pdf"), width = 8, height = 4)

# robust Mahalanobis outliers
mc <- covMcd(pc$x[, 1:5])
d$mahal <- mahalanobis(pc$x[, 1:5], mc$center, mc$cov)
d$outlier <- d$mahal > qchisq(0.999, df = 5)
write.csv(d[d$outlier, c("biome", "region", "sra", "contig", "mahal")],
          file.path(rev, "R09_composition", "tetranuc_outliers.csv"), row.names = FALSE)
