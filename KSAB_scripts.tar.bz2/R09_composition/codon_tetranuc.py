#!/usr/bin/env python3
# R09 -- Two orthogonal compositional fingerprints per viral contig:
#         (a) codon-usage: ENC (Wright 1990), GC3, RSCU vector
#         (b) tetranucleotide frequency vector (z-normalised within contig)
#
# Use cases:
#   1. compositional outliers within a CoPHSe -> chimeric / mis-binned
#   2. polar vs. temperate signatures: PCA + LDA in R09_plots.R below

import os, sys, glob, math
from collections import Counter
from Bio import SeqIO

GENOMAD = os.environ["GENOMAD_DIR"]
REV_OUT = os.environ["REV_OUT"]
OUT     = os.path.join(REV_OUT, "R09_composition")
os.makedirs(OUT, exist_ok=True)

SYN = {  # synonymous codon families (excl. Met, Trp)
  "F":["TTT","TTC"], "L":["TTA","TTG","CTT","CTC","CTA","CTG"],
  "I":["ATT","ATC","ATA"], "V":["GTT","GTC","GTA","GTG"],
  "S":["TCT","TCC","TCA","TCG","AGT","AGC"], "P":["CCT","CCC","CCA","CCG"],
  "T":["ACT","ACC","ACA","ACG"], "A":["GCT","GCC","GCA","GCG"],
  "Y":["TAT","TAC"], "H":["CAT","CAC"], "Q":["CAA","CAG"],
  "N":["AAT","AAC"], "K":["AAA","AAG"], "D":["GAT","GAC"], "E":["GAA","GAG"],
  "C":["TGT","TGC"], "R":["CGT","CGC","CGA","CGG","AGA","AGG"],
  "G":["GGT","GGC","GGA","GGG"]}

def enc(codon_counts):
    """Wright 1990 effective number of codons."""
    f = {}
    for aa, codons in SYN.items():
        n = sum(codon_counts.get(c, 0) for c in codons)
        if n < 2: continue
        pi2 = sum((codon_counts.get(c, 0) / n) ** 2 for c in codons)
        f.setdefault(len(codons), []).append((n * pi2 - 1) / (n - 1) if n > 1 else None)
    val = 2  # Met + Trp
    for k in (2, 3, 4, 6):
        vals = [x for x in f.get(k, []) if x not in (None, 0)]
        if not vals: continue
        val += len(vals) / (sum(vals) / len(vals))
    return val

def gc3(seq):
    third = [seq[i+2] for i in range(0, len(seq)-2, 3)]
    return sum(c in "GC" for c in third) / max(1, len(third))

def tetra(seq):
    n = Counter(seq[i:i+4] for i in range(len(seq)-3))
    total = sum(n.values())
    return {k: v/total for k, v in n.items() if "N" not in k}

def _revcomp(s):
    t = str.maketrans("ACGTNacgtn", "TGCANtgcan")
    return s.translate(t)[::-1]

def proc_cds(fna, genes_tsv):
    """Yield one row per CDS (not per contig) using geNomad gene coords.
    Falls back to whole-contig frame-1 if genes_tsv is missing.
    """
    seqs = {r.id: str(r.seq).upper() for r in SeqIO.parse(fna, "fasta")}
    rows = []
    if os.path.isfile(genes_tsv):
        with open(genes_tsv) as fh:
            hdr = fh.readline().rstrip().split("\t")
            for line in fh:
                v = dict(zip(hdr, line.rstrip().split("\t")))
                gene  = v["gene"]
                contig = gene.rsplit("_", 1)[0]
                if contig not in seqs: continue
                s = int(v["start"]) - 1; e = int(v["end"])
                strand = int(v["strand"])
                cds = seqs[contig][s:e]
                if strand == -1: cds = _revcomp(cds)
                if len(cds) < 150 or "N" in cds: continue
                codons = [cds[i:i+3] for i in range(0, len(cds)-2, 3)]
                cc = Counter(c for c in codons if len(c) == 3)
                rows.append((gene, len(cds), gc3(cds), enc(cc), tetra(cds)))
    else:
        for cid, s in seqs.items():
            if len(s) < 300 or "N" in s[:300]: continue
            codons = [s[i:i+3] for i in range(0, len(s)-2, 3)]
            cc = Counter(c for c in codons if len(c) == 3)
            rows.append((cid, len(s), gc3(s), enc(cc), tetra(s)))
    return rows

with open(os.path.join(OUT, "composition.tsv"), "w") as fh:
    fh.write("biome\tregion\tsra\tcontig\tlength\tGC3\tENC\t" +
             "\t".join(f"f_{a}{b}{c}{d}" for a in "ACGT" for b in "ACGT"
                                          for c in "ACGT" for d in "ACGT") + "\n")
    for grp in glob.glob(os.path.join(GENOMAD, "*_*")):
        biome, region = os.path.basename(grp).split("_")
        for s in glob.glob(os.path.join(grp, "*_genomad")):
            sra = os.path.basename(s).replace("_genomad", "")
            fna = os.path.join(s, "final.contigs_summary", "final.contigs_virus.fna")
            gtsv = os.path.join(s, "final.contigs_summary", "final.contigs_virus_genes.tsv")
            if not os.path.isfile(fna): continue
            for cid, L, g3, e, tt in proc_cds(fna, gtsv):
                base = [biome, region, sra, cid, str(L), f"{g3:.4f}", f"{e:.3f}"]
                kmers = "\t".join(f"{tt.get(a+b+c+d, 0):.5f}"
                                  for a in "ACGT" for b in "ACGT"
                                  for c in "ACGT" for d in "ACGT")
                fh.write("\t".join(base) + "\t" + kmers + "\n")

print(f"[R09] written {OUT}/composition.tsv")
