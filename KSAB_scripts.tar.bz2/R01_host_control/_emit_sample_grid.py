#!/usr/bin/env python3
"""Emit one TSV row per (biome, region, SRA) using the contigs_by_region/ tree."""
import os, sys
ROOT = os.environ.get("CONTIGS_DIR")
for biome in ("marine", "terrestrial"):
    for region in ("eq", "north", "south"):
        d = os.path.join(ROOT, biome, region)
        if not os.path.isdir(d):
            continue
        for sra in sorted(os.listdir(d)):
            if sra.startswith("."):
                continue
            print(f"{biome}\t{region}\t{sra}")
