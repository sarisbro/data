#!/usr/bin/env bash
# R01.01 -- Extract bacterial single-copy marker genes (rpoB + 14 GTDB markers)
#           from the same 120 metagenomes used for the virome analysis.
#
# Rationale: If polar > temperate divergence is also observed for bacterial hosts,
#            the viral pattern is inherited from host community structure.
#            If not, the viral signal is virus-specific.
#
# Tool: SingleM (https://github.com/wwood/singlem) -- it pulls reads matching
#       14 conserved single-copy ribosomal protein HMMs, then aligns and ANI-
#       clusters them at the same operational unit as the virome pipeline.
#
# Inputs : raw paired-end reads in $SRA_FASTQ (one .fastq.gz pair per sample)
# Outputs: per-sample SingleM "otu_table.tsv" + concatenated alignment FASTAs
#          per marker gene; downstream R picks these up.

set -euo pipefail
source "$(dirname "$0")/../config.sh"

# ------- where the raw reads live (adjust if you stored them elsewhere) ------
SRA_FASTQ="${SRA_FASTQ:-${PROJ_ROOT}/raw_reads}"   # e.g. ${SRA_FASTQ}/${SRA}_1.fastq.gz
OUT="${REV_OUT}/R01_host_control"
mkdir -p "${OUT}/per_sample" "${OUT}/aln_by_marker"

# Activate a conda env that contains singlem + mafft + hmmer + trimal + fasttree
# (see revision_scripts/envs/singlem.yml for a reproducible recipe)
# conda activate singlem-env

# ------- iterate over every biome / region / sample ---------------------------
while IFS=$'\t' read -r biome region sra; do
    fq1="${SRA_FASTQ}/${sra}_1.fastq.gz"
    fq2="${SRA_FASTQ}/${sra}_2.fastq.gz"
    [[ ! -s "$fq1" ]] && { echo "skip $sra (no reads)"; continue; }

    sample_out="${OUT}/per_sample/${biome}_${region}__${sra}"
    mkdir -p "$sample_out"

    singlem pipe \
        --forward "$fq1" --reverse "$fq2" \
        --otu-table "${sample_out}/otu_table.tsv" \
        --output-extras \
        --threads "$THREADS" \
        --assignment-method scann_then_diamond \
        --working-directory "${sample_out}/_work"
done < <(python3 "$(dirname "$0")/_emit_sample_grid.py")    # tsv: biome region sra

# ------- concatenate per-marker alignments across all samples -----------------
# SingleM writes one FASTA per marker per sample in $_work/aln; collect them.
for marker in $(singlem makedb --list_markers 2>/dev/null | awk 'NR>1{print $1}'); do
    cat ${OUT}/per_sample/*/_work/aln/${marker}*.fa > "${OUT}/aln_by_marker/${marker}.faa" 2>/dev/null || true
done

echo "[R01.01] done.  Per-marker alignments under ${OUT}/aln_by_marker/"
