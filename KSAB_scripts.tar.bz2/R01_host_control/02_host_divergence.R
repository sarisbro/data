#!/usr/bin/env Rscript
# R01.02 -- Build per-marker bacterial trees with the same pipeline as the
#           virome (MAFFT --auto -> trimAl gappyout -> FastTree LG), then
#           compute MPDs per region exactly the way the virome MPDs were
#           computed (existing code: 08_Bridging_edge_IMGVR.R).
#
# Output : revision_outputs/R01_host_control/host_mpd_by_region.csv
#          + a side-by-side panel comparing host vs. virus MPDs.

suppressPackageStartupMessages({
  library(ape); library(phangorn); library(dplyr); library(tidyr)
  library(parallel); library(ggplot2); library(broom)
})
args   <- commandArgs(trailingOnly = TRUE)
indir  <- args[1] %||% Sys.getenv("REV_OUT")
indir  <- file.path(indir, "R01_host_control")
alnd   <- file.path(indir, "aln_by_marker")
outd   <- indir
mafft  <- Sys.which("mafft");  trimal <- Sys.which("trimal");  ft <- Sys.which("FastTree")
stopifnot(nzchar(mafft), nzchar(trimal), nzchar(ft))

# ---- helper: produce a per-tree MPD stratified by region label in header ----
mpd_by_region <- function(aln_file) {
  base  <- tools::file_path_sans_ext(basename(aln_file))
  trim  <- tempfile(); tree <- tempfile()
  system2(mafft, c("--auto", aln_file), stdout = trim)
  system2(trimal, c("-in", trim, "-out", trim, "-gappyout"))
  system2(ft,    c("-lg", "-quiet", trim), stdout = tree)
  tr <- read.tree(tree)
  if (is.null(tr) || Ntip(tr) < 6) return(NULL)

  # label format expected:  ${biome}_${region}__${SRA}__contig${i}
  meta <- do.call(rbind, strsplit(tr$tip.label, "__", fixed = TRUE))
  region <- sub("^[a-z]+_", "", meta[, 1])     # eq / north / south
  biome  <- sub("_.*$",    "", meta[, 1])

  d  <- cophenetic.phylo(tr)
  out <- list()
  for (b in unique(biome)) for (r in unique(region)) {
    keep <- which(biome == b & region == r)
    if (length(keep) < 3) next
    sub <- d[keep, keep]
    out[[paste(b, r, sep = "_")]] <- mean(sub[upper.tri(sub)])
  }
  data.frame(marker = base, stratum = names(out), mpd = unlist(out))
}

aln <- list.files(alnd, pattern = "\\.faa$", full.names = TRUE)
res <- do.call(rbind, mclapply(aln, mpd_by_region, mc.cores = parallel::detectCores()))
write.csv(res, file.path(outd, "host_mpd_by_region.csv"), row.names = FALSE)

# ---- statistical comparison: linear mixed model, marker as random effect ----
res <- tidyr::separate(res, stratum, c("biome", "region"), sep = "_")
m   <- lme4::lmer(mpd ~ region + biome + (1 | marker), data = res)
summary(m); confint(m, parm = "beta_", method = "Wald")

# ---- side-by-side host vs. virus MPDs ---------------------------------------
virome <- read.csv(file.path(Sys.getenv("HMMER_DIR"), "_summary",
                             "hits_trees_clade_distance_patristic.summary.csv"))
virome <- virome[virome$row_type == "per_sra", ]
virome$biome  <- sub("_.*$",    "", virome$region)
virome$region <- sub("^[a-z]+_", "", virome$region)
v <- virome %>% group_by(biome, region) %>% summarise(mpd = median(mean_gene_mpd, na.rm = TRUE),
                                                      domain = "viral", .groups = "drop")
h <- res    %>% group_by(biome, region) %>% summarise(mpd = median(mpd),
                                                      domain = "bacterial host", .groups = "drop")
panel <- bind_rows(v, h)

ggplot(panel, aes(region, mpd, fill = domain)) +
  geom_col(position = position_dodge(0.7), width = 0.6) +
  facet_wrap(~ biome) +
  scale_fill_manual(values = c("bacterial host" = "#888", "viral" = "#c8102e")) +
  labs(y = "median MPD (subs/site)", x = NULL,
       caption = "Host control: if bacterial bars track viral bars, the polar signal\n
                  is inherited from host community structure.") +
  theme_classic(base_size = 11)
ggsave(file.path(outd, "host_vs_virus_mpd.pdf"), width = 7, height = 4)
