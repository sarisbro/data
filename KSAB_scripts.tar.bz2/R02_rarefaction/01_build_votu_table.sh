#!/usr/bin/env bash
# R02.01 -- Build a vOTU x sample presence/absence matrix following MIUViG
#           guidance (Roux et al. 2018, NatBiotech):
#             1. concatenate CheckV-passing viral contigs (med/high quality)
#             2. dereplicate at >= 95% ANI / >= 85% AF with skani + aniclust.py
#             3. map each input contig back to its vOTU representative
#             4. write a sparse matrix (sample x vOTU)

set -euo pipefail
source "$(dirname "$0")/../config.sh"
OUT="${REV_OUT}/R02_rarefaction"
mkdir -p "${OUT}"

ALL_VIR="${OUT}/all_viral_contigs.fna"
LABELS="${OUT}/contig_sample_map.tsv"
: > "${ALL_VIR}"; : > "${LABELS}"

# 1. concatenate, prefix headers with biome_region__SRA;
#    keep only medium/high-quality + complete (MIUViG filter)
for biome in marine terrestrial; do
  for region in eq north south; do
    cv_dir="${CHECKV_DIR}/${biome}_${region}"
    [[ ! -d "$cv_dir" ]] && continue
    for s in "${cv_dir}"/*_checkv; do
      sra=$(basename "$s" _checkv)
      vfile="${s}/viruses.fna"
      qfile="${s}/quality_summary.tsv"
      [[ ! -s "$vfile" || ! -s "$qfile" ]] && continue
      # build allow-list of contig ids that pass QC
      keep=$(awk -F'\t' 'NR>1 && ($8=="Medium-quality"||$8=="High-quality"||$8=="Complete"){print $1}' \
             "$qfile" | sort -u)
      [[ -z "$keep" ]] && continue
      awk -v tag="${biome}_${region}__${sra}" -v keep="$keep" -v lf="${LABELS}" '
        BEGIN{ n=split(keep,a,"\n"); for(i=1;i<=n;i++) ok[a[i]]=1; want=0 }
        /^>/ { id=substr($0,2); sub(/[ \t].*$/,"",id);
               if(id in ok){ want=1; print ">"tag"|"id; print tag"\t"id >> lf } else want=0; next }
        { if(want) print }
      ' "${vfile}" >> "${ALL_VIR}"
    done
  done
done

# 2. dereplicate at vOTU level (skani is much faster than blastn for >>1 M contigs)
skani sketch "${ALL_VIR}" -o "${OUT}/sk_db" -t "${THREADS}"
skani search "${OUT}/sk_db"/* --qi -t "${THREADS}" \
    --min-af 85 -s 95 -o "${OUT}/ani.tsv"

# Roux's aniclust.py groups contigs into vOTUs; ship a copy under utils/
python3 "$(dirname "$0")/../utils/aniclust.py" \
    --fna "${ALL_VIR}" --ani "${OUT}/ani.tsv" \
    --min_ani 95 --min_tcov 85 --min_qcov 0 \
    --out "${OUT}/votu_clusters.tsv"

# 3. produce sample x vOTU long-format presence table
python3 - <<'PY'
import os, sys, collections, csv
out = os.environ["REV_OUT"] + "/R02_rarefaction"
votu = {}
for line in open(out + "/votu_clusters.tsv"):
    rep, members = line.rstrip().split("\t")
    for m in members.split(","):
        votu[m] = rep
counts = collections.Counter()
for line in open(out + "/contig_sample_map.tsv"):
    sample, contig = line.rstrip().split("\t")
    full = f"{sample}|{contig.split()[0]}"
    if full in votu:
        counts[(sample, votu[full])] += 1
with open(out + "/sample_votu_long.tsv", "w") as fh:
    fh.write("sample\tvotu\tcount\n")
    for (s, v), n in counts.items():
        fh.write(f"{s}\t{v}\t{n}\n")
PY

echo "[R02.01] vOTU table at ${OUT}/sample_votu_long.tsv"
