#!/usr/bin/env Rscript
# R02.02 -- Sample- and coverage-based rarefaction with iNEXT plus asymptotic
#           richness estimators (Chao1, ACE) per biome x region.
#
# Goal: respond to the reviewer prior "polar viromes look diverse only because
#       they are undersampled."  If extrapolated richness is higher in polar
#       strata at COMMON COVERAGE, the LDG challenge gains an honest richness
#       leg in addition to the branch-length leg.

suppressPackageStartupMessages({
  library(iNEXT); library(dplyr); library(tidyr); library(ggplot2)
  library(vegan)
})

inp <- file.path(Sys.getenv("REV_OUT"), "R02_rarefaction", "sample_votu_long.tsv")
d   <- read.delim(inp, header = TRUE)
d$biome  <- sub("_.*$",   "", d$sample)
d$region <- sub("^[a-z]+_", "", sub("__.*$", "", d$sample))

# wide site x vOTU matrix (counts)
mat <- d %>% pivot_wider(names_from = votu, values_from = count, values_fill = 0L)
strat <- mat[, c("sample", "biome", "region")]
mat   <- as.matrix(mat[, -(1:3)]); storage.mode(mat) <- "integer"
rownames(mat) <- strat$sample

# group counts by stratum into incidence_raw (vegan-style)
strata <- split(rownames(mat), paste(strat$biome, strat$region, sep = "_"))
inc    <- lapply(strata, function(samps) {
  m <- mat[samps, , drop = FALSE] > 0
  c(length(samps), colSums(m))         # iNEXT incidence_raw format
})
out <- iNEXT(inc, q = 0, datatype = "incidence_freq",
             size = seq(1, 30, by = 1), nboot = 100)

# asymptotic estimators
asym <- ChaoRichness(inc, datatype = "incidence_freq")
write.csv(asym, file.path(dirname(inp), "chao_richness_by_stratum.csv"), row.names = TRUE)

# panel
p <- ggiNEXT(out, type = 1) + theme_classic(base_size = 11) +
     labs(x = "sampling units", y = "vOTU richness",
          title = "Sample-based rarefaction with Chao1 extrapolation")
ggsave(file.path(dirname(inp), "rarefaction_inext.pdf"), p, width = 8, height = 5)

# coverage-based comparison at common coverage = min(SC_obs)
sc_obs <- sapply(out$iNextEst$size_based, function(x) max(x$SC[x$Method == "Observed"]))
target <- min(sc_obs) * 0.95
cov_est <- estimateD(inc, q = 0, datatype = "incidence_freq",
                     base = "coverage", level = target, nboot = 100)
write.csv(cov_est, file.path(dirname(inp), "coverage_balanced_richness.csv"), row.names = FALSE)

# Wilcoxon: polar vs. temperate richness at the common coverage level
cat("\n--- Coverage-balanced richness (vOTUs at SC = ", round(target, 3), ") ---\n", sep="")
print(cov_est)
