#!/usr/bin/env Rscript
# R11.02 -- For each NCLDV marker tree:
#   * extract monophyletic clades (Caudo style)
#   * tag clades by majority origin (polar / temperate / mixed)
#   * test polar enrichment with a permutation test (relabel tips 999x)
#
# Output : clade table + a marker-by-marker bar plot

suppressPackageStartupMessages({
  library(ape); library(phytools); library(ggplot2); library(dplyr)
})
rev_out <- Sys.getenv("REV_OUT")
out     <- file.path(rev_out, "R11_ncldv")
markers <- c("polB", "A32", "D5", "MCP")

clade_tab <- list()
for (m in markers) {
  tr <- read.tree(file.path(out, "aln", paste0(m, ".nwk")))
  tags <- ifelse(grepl("_north__|_south__", tr$tip.label), "polar", "temperate")
  # cut tree into clusters at fixed depth (e.g., 1.0 subs/site)
  cl <- cutree(as.hclust.phylo(tr), h = 1.0)
  clade_tab[[m]] <- data.frame(marker = m,
                                tip = tr$tip.label,
                                tag = tags,
                                clade = cl)
  obs_polar <- tapply(tags, cl, function(x) mean(x == "polar"))
  # permutation
  perm <- replicate(999, {
    s <- sample(tags); tapply(s, cl, function(x) mean(x == "polar"))
  })
  p <- mean(perm >= matrix(obs_polar, nrow = nrow(perm), ncol = ncol(perm), byrow = TRUE),
            na.rm = TRUE)
  cat(m, "global polar-clade enrichment perm p =", signif(p, 3), "\n")
}
clade_df <- bind_rows(clade_tab)
write.csv(clade_df, file.path(out, "ncldv_clades.csv"), row.names = FALSE)

summary_df <- clade_df %>%
  group_by(marker, clade) %>%
  summarise(n = n(),
            polar_frac = mean(tag == "polar"),
            .groups = "drop") %>%
  mutate(type = case_when(polar_frac > 0.8 ~ "polar-dominant",
                          polar_frac < 0.2 ~ "temperate-dominant",
                          TRUE             ~ "mixed"))

ggplot(summary_df, aes(marker, fill = type)) +
  geom_bar(position = "fill") +
  scale_fill_manual(values = c("polar-dominant" = "#1f78b4",
                                "temperate-dominant" = "#999",
                                "mixed" = "#ddd")) +
  labs(y = "fraction of clades", x = NULL,
       title = "NCLDV marker clades by majority origin") +
  theme_classic(base_size = 11)
ggsave(file.path(out, "ncldv_clade_composition.pdf"), width = 6, height = 4)
