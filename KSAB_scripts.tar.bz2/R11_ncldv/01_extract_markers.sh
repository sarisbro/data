#!/usr/bin/env bash
# R11.01 -- Extract NCLDV (Nucleocytoviricota) marker proteins (PolB, A32,
#           D5/SF3, MCP) from the same geNomad protein files, using the
#           Giant-Virus Database (GVDB) HMM profiles.
#
# Why: Polar giant viruses are a very active sub-field (Meng 2023; Pitot 2024;
#      Schulz 2020); a focused NCLDV side-panel makes the paper land in that
#      literature instead of floating as "DNA viruses in general."

set -euo pipefail
source "$(dirname "$0")/../config.sh"
OUT="${REV_OUT}/R11_ncldv"; mkdir -p "${OUT}/aln" "${OUT}/hits"

GVDB_DIR="${GVDB_DIR:-${PROJ_ROOT}/gvdb_hmm}"           # download from doi:10.5281/zenodo.10630646
if [[ ! -d "$GVDB_DIR" ]]; then
  mkdir -p "$GVDB_DIR" && cd "$GVDB_DIR"
  wget -q https://zenodo.org/records/10630646/files/GVOG_HMM_database.tar.gz
  tar xf GVOG_HMM_database.tar.gz
fi

declare -A MARKERS=( [polB]=GVOGm0054 [A32]=GVOGm0023 [D5]=GVOGm0013 [MCP]=GVOGm0003 )

for marker in "${!MARKERS[@]}"; do
  hmm="${GVDB_DIR}/${MARKERS[$marker]}.hmm"
  : > "${OUT}/hits/${marker}.faa"
  for grp in marine_eq marine_north marine_south \
             terrestrial_eq terrestrial_north terrestrial_south; do
    for s in "${GENOMAD_DIR}/${grp}"/*_genomad; do
      sra=$(basename "$s" _genomad)
      faa="${s}/final.contigs_summary/final.contigs_virus_proteins.faa"
      [[ ! -s "$faa" ]] && continue
      hmmsearch -E 1e-15 --tblout /dev/stdout --noali "$hmm" "$faa" \
        | awk -v tag="${grp}__${sra}" '!/^#/{print tag"|"$1}' > "${OUT}/_tmp.ids"
      seqkit grep -f "${OUT}/_tmp.ids" "$faa" \
        | sed "s/^>/>${grp}__${sra}|/" >> "${OUT}/hits/${marker}.faa"
    done
  done
  mafft --auto --thread "${THREADS}" "${OUT}/hits/${marker}.faa" > "${OUT}/aln/${marker}.aln"
  trimal -in "${OUT}/aln/${marker}.aln" -out "${OUT}/aln/${marker}.trim" -gappyout
  FastTree -lg -quiet "${OUT}/aln/${marker}.trim" > "${OUT}/aln/${marker}.nwk"
done
