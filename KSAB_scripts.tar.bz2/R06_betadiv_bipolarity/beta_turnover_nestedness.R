#!/usr/bin/env Rscript
# R06 -- Baselga decomposition of Sorensen dissimilarity into turnover (b_SIM)
#        and nestedness (b_NES); plus a bipolarity test (vOTUs shared between
#        Arctic and Antarctic relative to either pole vs. temperate).
#
# Speaks directly to the reviewer question:
#   "Are polar viromes truly distinct (turnover) or merely sparser samples
#    of temperate diversity (nestedness)?"

suppressPackageStartupMessages({
  library(betapart); library(dplyr); library(tidyr); library(ggplot2)
})

rev_out <- Sys.getenv("REV_OUT")
votu    <- read.delim(file.path(rev_out, "R02_rarefaction", "sample_votu_long.tsv"))
wide    <- votu %>% pivot_wider(names_from = votu, values_from = count, values_fill = 0L)
samp    <- wide$sample
pa      <- (as.matrix(wide[, -1]) > 0) * 1
rownames(pa) <- samp

meta <- data.frame(sample = samp,
                   biome  = sub("_.*$",    "", samp),
                   region = sub("^[a-z]+_", "", sub("__.*$", "", samp)))

# ------------------ Baselga decomposition per stratum ------------------------
strat <- split(meta$sample, paste(meta$biome, meta$region, sep = "_"))
dec   <- lapply(strat, function(samps) {
  if (length(samps) < 3) return(NULL)
  bp <- beta.multi(pa[samps, ], index.family = "sorensen")
  data.frame(stratum = NA, beta_SIM = bp$beta.SIM,
             beta_SNE = bp$beta.SNE, beta_SOR = bp$beta.SOR)
})
dec <- bind_rows(Map(function(d, n) { d$stratum <- n; d }, dec, names(dec)))
write.csv(dec, file.path(rev_out, "R06_betadiv_bipolarity",
                         "baselga_decomposition.csv"), row.names = FALSE)
dir.create(dirname(file.path(rev_out, "R06_betadiv_bipolarity", "x")),
           showWarnings = FALSE, recursive = TRUE)

dec_long <- dec %>% pivot_longer(c(beta_SIM, beta_SNE),
                                 names_to = "component", values_to = "value")
ggplot(dec_long, aes(stratum, value, fill = component)) +
  geom_col() +
  scale_fill_manual(values = c(beta_SIM = "#d95f02", beta_SNE = "#7570b3"),
                    labels = c("turnover (SIM)", "nestedness (SNE)")) +
  labs(y = "Sorensen dissimilarity (multi-site)") +
  theme_classic(base_size = 11) +
  theme(axis.text.x = element_text(angle = 30, hjust = 1))
ggsave(file.path(rev_out, "R06_betadiv_bipolarity", "baselga_panel.pdf"),
       width = 7, height = 5)

# ------------------ Bipolarity: Arctic vs Antarctic shared vOTUs -------------
pool <- function(reg) colSums(pa[meta$region == reg, , drop = FALSE]) > 0
arct <- pool("north"); anta <- pool("south"); temp <- pool("eq")
bipolarity <- data.frame(
  comparison = c("Arctic & Antarctic", "Arctic & Temperate", "Antarctic & Temperate"),
  shared     = c(sum(arct & anta), sum(arct & temp), sum(anta & temp)),
  jaccard    = c(sum(arct & anta) / sum(arct | anta),
                 sum(arct & temp) / sum(arct | temp),
                 sum(anta & temp) / sum(anta | temp)))
write.csv(bipolarity, file.path(rev_out, "R06_betadiv_bipolarity",
                                "bipolarity_jaccard.csv"), row.names = FALSE)
print(bipolarity)
