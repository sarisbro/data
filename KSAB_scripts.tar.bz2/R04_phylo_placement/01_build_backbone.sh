#!/usr/bin/env bash
# R04.01 -- Build curated marker-gene reference trees for EPA-ng placement.
#
# Markers:  TerL  (terminase large subunit)  -- Caudoviricetes
#           MCP   (major capsid protein)     -- Caudoviricetes + NCLDV
#           PolB  (DNA polymerase B)         -- NCLDV / Mimiviridae allies
#
# Source of references:  NCBI virus RefSeq (curated) + ICTV exemplars.
# We pull them from the EggNOG / Pfam HMMs and back-fetch the seed alignments
# rather than re-curating by hand.

set -euo pipefail
source "$(dirname "$0")/../config.sh"
BB="${REV_OUT}/R04_phylo_placement/backbone"; mkdir -p "${BB}"

declare -A PFAM=(
  [terL]=PF03237        # Terminase_GpA
  [mcp]=PF05065         # Phage_capsid
  [polB]=PF03175        # DNA_pol_B_2 / NCLDV PolB
)

for marker in "${!PFAM[@]}"; do
  acc="${PFAM[$marker]}"
  wkd="${BB}/${marker}"; mkdir -p "$wkd"
  # Pfam seed alignment (Stockholm)  -> FASTA
  wget -q -O "${wkd}/${acc}.sto" \
    "https://www.ebi.ac.uk/interpro/wwwapi//entry/pfam/${acc}/?annotation=alignment:seed"
  esl-reformat afa "${wkd}/${acc}.sto" > "${wkd}/${acc}.faa"

  # restrict to viral taxa (NCBI taxid root 10239) using a one-liner filter
  # (assumes downstream uses sequence headers; we keep all references and tag
  # them with "REF__" so the placement step can colour them.)
  sed -i 's/^>/>REF__/' "${wkd}/${acc}.faa"

  # build the backbone ML tree once
  mafft --auto --thread "${THREADS}" "${wkd}/${acc}.faa" > "${wkd}/${acc}.aln"
  trimal -in "${wkd}/${acc}.aln" -out "${wkd}/${acc}.trim" -gappyout
  raxml-ng --all --msa "${wkd}/${acc}.trim" --model LG+G \
           --threads "${THREADS}" --seed 42 --prefix "${wkd}/${marker}"
  cp "${wkd}/${marker}.raxml.bestTree"  "${BB}/${marker}.reftree"
  cp "${wkd}/${marker}.raxml.bestModel" "${BB}/${marker}.refmodel"
  cp "${wkd}/${acc}.trim"               "${BB}/${marker}.refaln"
done

echo "[R04.01] backbones built under ${BB}"
