#!/usr/bin/env bash
# R04.02 -- For each marker (TerL, MCP, PolB):
#             a) HMM-search the marker against per-sample geNomad proteins
#             b) extract hits, align onto the backbone with hmmalign
#             c) place with EPA-ng on the backbone tree
#             d) summarise placements by latitude (gappa examine)
#
# The output panel for the paper is a fan tree of the backbone with placement
# pie charts coloured by polar / temperate origin.

set -euo pipefail
source "$(dirname "$0")/../config.sh"
BB="${REV_OUT}/R04_phylo_placement/backbone"
OUT="${REV_OUT}/R04_phylo_placement/placements"; mkdir -p "${OUT}"

for marker in terL mcp polB; do
  pfam_hmm="${BB}/${marker}/$(basename ${BB}/${marker}/PF*.sto .sto).hmm"
  hmmbuild "${pfam_hmm}" "${BB}/${marker}/$(basename ${pfam_hmm} .hmm).sto"

  cat /dev/null > "${OUT}/${marker}_queries.faa"
  for grp in marine_eq marine_north marine_south \
             terrestrial_eq terrestrial_north terrestrial_south; do
    for s in "${GENOMAD_DIR}/${grp}"/*_genomad; do
      sra=$(basename "$s" _genomad)
      faa="${s}/final.contigs_summary/final.contigs_virus_proteins.faa"
      [[ ! -s "$faa" ]] && continue
      hmmsearch --cut_ga --noali --tblout /dev/stdout "${pfam_hmm}" "$faa" \
        | awk -v tag="${grp}__${sra}" '!/^#/{print tag"|"$1}' > "${OUT}/_hits_${marker}_${grp}_${sra}.ids"
      seqkit grep -f "${OUT}/_hits_${marker}_${grp}_${sra}.ids" "$faa" \
        | sed "s/^>/>${grp}__${sra}|/" >> "${OUT}/${marker}_queries.faa"
    done
  done

  # align queries onto backbone seed
  hmmalign --trim --outformat afa --mapali "${BB}/${marker}.refaln" \
           "${pfam_hmm}" "${OUT}/${marker}_queries.faa" > "${OUT}/${marker}_all.aln"
  # split into ref vs query for EPA-ng
  python3 "$(dirname "$0")/_split_ref_query.py" \
      "${OUT}/${marker}_all.aln" "${OUT}/${marker}.refaln" "${OUT}/${marker}.qry.aln"

  # place
  epa-ng --redo \
         --tree "${BB}/${marker}.reftree" \
         --ref-msa "${OUT}/${marker}.refaln" \
         --query   "${OUT}/${marker}.qry.aln" \
         --out-dir "${OUT}/${marker}_epa"

  # latitudinal summary via gappa
  gappa examine assign \
        --jplace-path "${OUT}/${marker}_epa/epa_result.jplace" \
        --taxon-file  "$(dirname "$0")/lat_taxon_table_${marker}.tsv" \
        --out-dir     "${OUT}/${marker}_gappa" --allow-file-overwriting
done

echo "[R04.02] placements + per-latitude summaries under ${OUT}"
