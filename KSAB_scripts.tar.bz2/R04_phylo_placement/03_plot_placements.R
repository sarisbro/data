#!/usr/bin/env Rscript
# R04.03 -- Visualise EPA-ng placements as fan trees with per-edge pie charts
#           coloured by polar / temperate origin of the placed queries.
#
# Output : revision_outputs/R04_phylo_placement/placement_panel.pdf

suppressPackageStartupMessages({
  library(jsonlite); library(ape); library(ggtree); library(ggplot2)
  library(dplyr); library(tidyr); library(treeio)
})

rev_out <- Sys.getenv("REV_OUT")
markers <- c("terL", "mcp", "polB")
plots   <- list()

for (m in markers) {
  jpl <- jsonlite::fromJSON(
    file.path(rev_out, "R04_phylo_placement", "placements",
              paste0(m, "_epa"), "epa_result.jplace"))
  tr  <- read.tree(text = jpl$tree)
  # placements per query: best edge and latitude tag from query name
  pl  <- jpl$placements
  best <- do.call(rbind, lapply(seq_len(nrow(pl)), function(i) {
    rows <- as.data.frame(pl$p[[i]])
    rows <- rows[which.max(rows[, "like_weight_ratio"]), , drop = FALSE]
    data.frame(edge = rows[, "edge_num"],
               query = pl$nm[[i]][[1]])
  }))
  best$tag <- sub("^([a-z]+)_([a-z]+)__.*$", "\\1_\\2", best$query)
  best$lat <- factor(sub("^[a-z]+_", "", best$tag),
                     levels = c("eq", "north", "south"))

  # aggregate placements per edge
  agg <- best %>% group_by(edge, lat) %>% summarise(n = n(), .groups = "drop")

  p <- ggtree(tr, layout = "fan", open.angle = 10) %<+% agg +
    geom_tippoint(aes(size = n, fill = lat), shape = 21, alpha = 0.8) +
    scale_fill_manual(values = c(eq = "#999", north = "#1f78b4", south = "#e31a1c"),
                      drop = FALSE) +
    labs(title = paste0("Backbone + placements: ", m)) +
    theme(legend.position = "right")
  plots[[m]] <- p
}

ggsave(file.path(rev_out, "R04_phylo_placement", "placement_panel.pdf"),
       cowplot::plot_grid(plotlist = plots, ncol = 1),
       width = 9, height = 12)
