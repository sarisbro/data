#!/usr/bin/env python3
"""Split a combined MSA into reference (REF__*) and query (*) FASTAs."""
import sys
from Bio import SeqIO
combined, ref_out, qry_out = sys.argv[1:]
refs, qrys = [], []
for r in SeqIO.parse(combined, "fasta"):
    (refs if r.id.startswith("REF__") else qrys).append(r)
SeqIO.write(refs, ref_out, "fasta")
SeqIO.write(qrys, qry_out, "fasta")
