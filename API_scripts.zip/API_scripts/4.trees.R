# qsub -N clean_aln -q abaqus.q -l mem_free=50.0G -cwd -b y -j y ~/bin/R-3.2.3/bin/R CMD BATCH 4.trees.R

# just to make sure...
rm(list = ls())

# load packages
library(ape)
library(seqinr)
library(phytools)
library(Biostrings)

virtype_lst <- list.files(pattern = ".csv")
virtype_lst <- sort(virtype_lst, decreasing = T)

# estimate phylogenetic trees
curdir <- getwd()
#i <- virtype_lst[1]
for(i in virtype_lst){
	virtype <- read.csv(i)
	dir_name <- sub("human_viruses_clean_", "", i)
	dir_name <- sub(".csv", "", dir_name)
	setwd(paste0(curdir, "/", dir_name))
	dir.create("_trees")
	dir.create("_tmp")
	dir.create("_trees_midpoint_rooted")
	dir.create("_nexus_aln_tre")
	raw_aln_files <- list.files(path="_aln_files_ok/", pattern = ".fas")
	n_raw_aln_files <- length(raw_aln_files)

	for(j in 1:n_raw_aln_files){
		# estimate, read, reroot, and save tree, w/ and w/out support values
		tmp_tree <- tmp_tree_r <- tmp_aln <- tmp_aln1 <- tmp_aln_aa <- tmp_nex <- NULL
		system(paste0("fasttree -nt -gtr -gamma _aln_files_ok/", raw_aln_files[j], " > _trees/", raw_aln_files[j], ".trees"))
		tmp_tree <- read.tree(paste0("_trees/", raw_aln_files[j], ".trees"))
		
		if(sum(tmp_tree$edge.length) > 0){
			tmp_tree_r <- midpoint.root(tmp_tree)
			write.tree(tmp_tree_r , file=paste0("_trees_midpoint_rooted/", raw_aln_files[j], ".rooted.trees"))
			tmp_tree_r$node.label <- NULL
			write.tree(tmp_tree_r , file=paste0("_trees_midpoint_rooted/", raw_aln_files[j], ".rooted.nosupport.trees"))
					##################
					## AA alignment ##
					##################
			# get AA alignment (again, but after Gblocks)
			system(paste0("perl ../translatorx.pl -i _aln_files_ok/",  raw_aln_files[j], " -o _tmp/", raw_aln_files[j],".fas -p M -t T -w 1 -c 5"))
			tmp_aln <- read.alignment(paste0("_tmp/", raw_aln_files[j],".fas.aaseqs.fasta"), format="fasta")
			tmp_aln$nam <- paste(tmp_aln$nam, " ")
			# write nexus file, including alignment and tree -- from scratch!
			nex_bas <- readLines(paste0(curdir, "/nexus_base"))
			#tmp_nex <- readLines(paste0("_tmp/", raw_aln_files[j]))
			tmp_tree_r <- readLines(paste0("_trees_midpoint_rooted/", raw_aln_files[j], ".rooted.nosupport.trees"))
			# write to file...
			cat(paste0(nex_bas, "

BEGIN DATA;
DIMENSIONS  NTAX=", length(tmp_aln$seq)," NCHAR=", nchar(tmp_aln$seq[[1]]),";
FORMAT DATATYPE=PROTEIN GAP=- MISSING=?;
MATRIX

"),
				file = paste0("_nexus_aln_tre/", raw_aln_files[j], ".AA.nex"))
			for(k in 1:length(tmp_aln$seq)){
				cat(paste0(tmp_aln$nam[k], sep="  "), file = paste0("_nexus_aln_tre/", raw_aln_files[j], ".AA.nex"), append=T)
				cat(paste0(tmp_aln$seq[[k]], sep="\n"), file = paste0("_nexus_aln_tre/", raw_aln_files[j], ".AA.nex"), append=T)
			}
			cat(";

END;

BEGIN TREES;
    Tree Current_Tree = ", file = paste0("_nexus_aln_tre/", raw_aln_files[j], ".AA.nex"), append=T)
		cat(tmp_tree_r, sep="\n", file = paste0("_nexus_aln_tre/", raw_aln_files[j], ".AA.nex"), append=T)
		cat("END;

", file = paste0("_nexus_aln_tre/", raw_aln_files[j], ".AA.nex"), append=T)

					###################
					## NUC alignment ##
					###################
			# same thing, w/ DNA alignment
			tmp_aln <- read.alignment(paste0("_aln_files_ok/", raw_aln_files[j]), format="fasta")
			tmp_aln$nam <- paste(tmp_aln$nam, " ")
			# write nexus file, including alignment and tree -- from scratch!
			nex_bas <- readLines(paste0(curdir, "/nexus_base"))
			#tmp_nex <- readLines(paste0("_tmp/", raw_aln_files[j]))
			tmp_tree_r <- readLines(paste0("_trees_midpoint_rooted/", raw_aln_files[j], ".rooted.nosupport.trees"))
			for(k in 1:length(tmp_aln$seq)){
				tmp_aln$seq[[k]] <- gsub(" ", "", tmp_aln$seq[[k]])
			}
			# write to file...
			cat(paste0(nex_bas, "

BEGIN DATA;
DIMENSIONS  NTAX=", length(tmp_aln$seq)," NCHAR=", nchar(tmp_aln$seq[[1]]),";
FORMAT DATATYPE=DNA GAP=- MISSING=?;
MATRIX

"),
				file = paste0("_nexus_aln_tre/", raw_aln_files[j], ".NUC.nex"))
			for(k in 1:length(tmp_aln$seq)){
				cat(paste0(tmp_aln$nam[k], sep="  "), file = paste0("_nexus_aln_tre/", raw_aln_files[j], ".NUC.nex"), append=T)
				cat(paste0(tmp_aln$seq[[k]], sep="\n"), file = paste0("_nexus_aln_tre/", raw_aln_files[j], ".NUC.nex"), append=T)
			}
			cat(";

END;

BEGIN TREES;
    Tree Current_Tree = ", file = paste0("_nexus_aln_tre/", raw_aln_files[j], ".NUC.nex"), append=T)
		cat(tmp_tree_r, sep="\n", file = paste0("_nexus_aln_tre/", raw_aln_files[j], ".NUC.nex"), append=T)
		cat("END;

", file = paste0("_nexus_aln_tre/", raw_aln_files[j], ".NUC.nex"), append=T)


		}

		
	}
	setwd(curdir)
}


########################
#save.image("2.blastData.RData")
q(save="no")
########################





