# qsub -N getDat -q abaqus.q -l mem_free=50.0G -cwd -b y -j y ~/bin/R-3.2.3/bin/R CMD BATCH 1.getData.R

# just to make sure...
rm(list = ls())

# load packages
library(ape)
library(seqinr)
library(muscle)
library(ShortRead)

# get lists of virus types, and read gene list
virtype_lst <- list.files(pattern = ".csv")
system("unzip genes.fasta.zip")
gene_lst <- read.dna("genes.fasta", format="fasta")
file.remove("genes.fasta")

names(gene_lst) <- gsub("/", "_", names(gene_lst))
names(gene_lst) <- gsub(" ", "_", names(gene_lst))
names(gene_lst) <- gsub("\\(", "_", names(gene_lst))
names(gene_lst) <- gsub(")", "_", names(gene_lst))

# creates all the individual fasta files for blast searches
for(i in virtype_lst){
	virtype <- read.csv(i)
	dir_name <- sub("human_viruses_clean_", "", i)
	dir_name <- sub(".csv", "", dir_name)
	dir.create(dir_name)
	nb_samples <- length(virtype[,1])
	for(j in 1:nb_samples){
		vir_name <- as.character(virtype[j,1])
		vir_name <- gsub("/", "_", vir_name)
		vir_name <- gsub(" ", "_", vir_name)
		vir_name <- gsub("\\(", "_", vir_name)
		vir_name <- gsub(")", "_", vir_name)
		print(paste0("Now doing ", dir_name, ": ", vir_name))
		gene_pos <- grep(vir_name, names(gene_lst))
		nb_genes <- length(gene_pos)
		# check if there is a hit
		if(length(gene_pos) > 0){
			for(k in 1:nb_genes){
				# check length seq > 0
				if(dim(as.matrix(gene_lst[gene_pos[k]]))[2] > 0){
					write.dna(gene_lst[gene_pos[k]], file=paste0(dir_name, "/", vir_name, "_", k, ".fasta"), format="fasta")
				}
			}
		}
	}
}

# from here, what is needed (as of Aug 31, 2017):
# 1. get a copy of viral (vrl) nt: wget ftp://ftp.ncbi.nih.gov/genbank/gbvrl*.seq.gz
## instead of the 38.2 GB	8/28/17, 7:01:00 AM of nt
# 2. gunzip gbvrl*.seq.gz
# 2. cat *.seq > gbvrl.seq
# 2. wget http://iubio.bio.indiana.edu/soft/molbio/readseq/java/readseq.jar
# 2. java -cp readseq.jar run -feat=CDS -f=8 gbvrl.seq -o gbvrl.seq.fas
# 3. use blast # at CAC
# 4. /opt/blast/2.6.0+/ncbi-blast-2.6.0+/bin/makeblastdb -in gbvrl.seq.fas -dbtype nucl -out all_nt

# reads the DB file
system("wget ftp://ftp.ncbi.nih.gov/genbank/gbvrl*.seq.gz")
system("gunzip gbvrl*.seq.gz")
system("cat *.seq > gbvrl.seq")
system("wget http://iubio.bio.indiana.edu/soft/molbio/readseq/java/readseq.jar")
system("java -cp readseq.jar run -feat=CDS -f=8 gbvrl.seq -o gbvrl.seq.fas")
all_seq <- read.dna("gbvrl.seq.fas", format="fasta")
all_seq_names <- attributes(all_seq)$names

system("zip -9r query_seq.zip ds*/ ss*/")

########################
save(all_seq, all_seq_names, file="1.getData.RData")
q(save="no")
########################








