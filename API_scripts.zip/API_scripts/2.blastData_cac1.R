# qsub -N blastDat1 -pe dist.pe 20 -q abaqus.q -l mem_free=100.0G -cwd -b y -j y ~/bin/R-3.2.3/bin/R CMD BATCH 2.blastData_cac1.R
# qsub -N blastDat1 -pe shm.pe 20 -q abaqus.q -l mem_free=100.0G -cwd -b y -j y ~/bin/R-3.2.3/bin/R CMD BATCH 2.blastData_cac1.R
# qsub -N blastDat1 -q abaqus.q -l mem_free=200.0G -cwd -b y -j y ~/bin/R-3.2.3/bin/R CMD BATCH 2.blastData_cac1.R

# just to make sure...
rm(list = ls())
load("1.getData.RData")

# load packages
library(ape)
library(seqinr)
library(doMC)
registerDoMC(cores=20)

virtype_lst <- list.files(pattern = ".csv")
virtype_lst <- sort(virtype_lst, decreasing = T)

# performs blast searches
curdir <- getwd()
i <- virtype_lst[1]
#for(i in virtype_lst){
	virtype <- read.csv(i)
	dir_name <- sub("human_viruses_clean_", "", i)
	dir_name <- sub(".csv", "", dir_name)
	setwd(paste0(curdir, "/", dir_name))
	dir.create("_aln_files")
	dir.create("_processed_ok_files")
	dir.create("_processed_fail_files")
	dir.create("_unprocessed_files")
	query_files <- list.files(pattern = ".fasta")
	n_query_files <- length(query_files)
	# do blast
	blast_res <- foreach(j = 1:n_query_files, .combine=rbind)%dopar%{
	#for(j in 1:n_query_files){
		# BLASTn gene j of virus type i
		#system(paste0("/opt/blast/2.6.0+/ncbi-blast-2.6.0+/bin/blastn -query ", j," -db ~/db/all_nt -task blastn -evalue 1.e-10 -dust no -outfmt \"7 qseqid sseqid evalue bitscore\" -max_target_seqs 100 > ", j,".blastn.out"))
		system(paste0("/opt/blast/2.6.0+/ncbi-blast-2.6.0+/bin/blastn -query ", query_files[j]," -db ~/db/all_nt -task blastn -evalue 1.e-100 -dust no -outfmt \"7 qseqid sseqid evalue bitscore qcovs\" -max_target_seqs 100 > ", query_files[j],".blastn.out"))
		#system(paste0("blastn -query ", query_files[j]," -db ../all_nt -task blastn -evalue 1.e-100 -dust no -outfmt \"7 qseqid sseqid evalue bitscore qcovs\" -max_target_seqs 100 > ", query_files[j],".blastn.out"))
		Sys.sleep(60)
		if(file.exists(paste0( query_files[j],".blastn.out"))){
			blastn_res <- read.table(paste0( query_files[j],".blastn.out"))
			
			# limit wrt coverage (80%)
			blastn_res <- blastn_res[blastn_res[,5] > 80, ]
			
			# get corresponding sequences from all_seq
			blast_acc <- paste0(as.character(blastn_res[,2]), " ")
			n_blast_acc <- length(blast_acc)
			
			# proceed only if > 10 results
			if(n_blast_acc > 10){
				gene_pos <- NULL
				for(k in 1:n_blast_acc){
					gene_pos <- c(gene_pos, grep(blast_acc[k], all_seq_names, fixed=T))
				}
				unaligned_seq <- all_seq[gene_pos]
				
				# cleanup seq names
				names(unaligned_seq) <- substr(names(unaligned_seq), 1, 15)
				names(unaligned_seq) <- gsub(" ", "_", names(unaligned_seq))
				names(unaligned_seq) <- make.unique(names(unaligned_seq))
				
				# write alignment
				write.dna(unaligned_seq, paste0( query_files[j],".unaligned_seq"), format="fasta", colsep="")
				#system(paste0("perl ../translatorx.pl -i ",  query_files[j], ".unaligned_seq -o ", query_files[j],".aln -p M -t F -w 1 -c 5"))
				system(paste0("~/bin/muscle -in ",  query_files[j], ".unaligned_seq -out ", query_files[j],".aln.nt_ali.fasta"))
				system(paste0("mv ", query_files[j], ".aln.nt_ali.fasta _aln_files/."))
				system(paste0("mv ", query_files[j], "* _processed_ok_files/."))
			}else{
				system(paste0("mv ", query_files[j], "* _processed_fail_files/."))
			}
		}else{
			system(paste0("mv ", query_files[j], "* _unprocessed_files/."))
		}
	}
#}


########################
#save.image("2.blastData.RData")
q(save="no")
########################








