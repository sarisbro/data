# qsub -N postSM -q abaqus.q -l mem_free=100.0G -cwd -b y -j y ~/bin/R-3.2.3/bin/R CMD BATCH 7.postSpiderMonkey.R

# just to make sure...
rm(list = ls())

# load packages
library(ape)

virtype_lst <- list.files(pattern = ".csv")
virtype_lst <- sort(virtype_lst, decreasing = T)
SM_all_res <- NULL

curdir <- getwd()
#i <- virtype_lst[1]
for(i in virtype_lst){
	virtype <- read.csv(i)
	dir_name <- sub("human_viruses_clean_", "", i)
	dir_name <- sub(".csv", "", dir_name)
	setwd(paste0(curdir, "/", dir_name))
	nexus_files <- list.files(path="_nexus_aln_tre/", pattern = ".fas.NUC.nex")
	n_nexus_files <- length(nexus_files)

	for(j in 1:n_nexus_files){
		if(file.exists(paste0("_SpiderMonkey/", nexus_files[j], "/my_data_file.csv"))){
			print(paste0("Doing ", dir_name, "(", which(virtype_lst == i), ")", ": ", nexus_files[j]))
			# read res
			SM_res <- headers <- dat <- NULL
			SM_res <- read.csv(paste0("_SpiderMonkey/", nexus_files[j], "/my_data_file.csv"), header=T)
			dat <- read.nexus(paste0("_SpiderMonkey/", nexus_files[j], "/my_data_file.nex"))
			nex_aln <- readLines(paste0("_SpiderMonkey/", nexus_files[j], "/my_data_file.nex"), n=4)
			seq_len <- as.numeric(sub(";", "", unlist(strsplit(nex_aln[4], "NCHAR="))[2])) / 3
			headers <- colnames(SM_res)
			SM_res <- cbind(which(virtype_lst == i), j, SM_res, length(dat$tip.label), seq_len, nexus_files[j])
			colnames(SM_res) <-c("VirType", "Data_ID", headers, "NbSeq", "NbCodons", "geneName")
			SM_all_res <- rbind(SM_all_res, SM_res)
		}
		
		setwd(paste0(curdir, "/", dir_name))
	}
	setwd(curdir)
}


########################
save.image("7.postSpiderMonkey.RData")
q(save="no")
########################





