LD_LIBRARY_PATH=/opt/gcc/5.4.0/lib64/:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH
(echo 1; echo 1; echo my_data_file.nex; echo 1; echo Y; echo my_data_file.fit; echo 3; echo 10; echo 1; echo 1; echo 2; echo 100000; echo 10000; echo 1000; echo 1; echo my_data_file.csv; echo my_data_file.dot) | ~/bin/bin/HYPHYMP QuickSelectionDetection.bf 

