(echo 1; echo my_data_file.nex; echo 1; echo 0.1) | HYPHYMP MEME.bf 

