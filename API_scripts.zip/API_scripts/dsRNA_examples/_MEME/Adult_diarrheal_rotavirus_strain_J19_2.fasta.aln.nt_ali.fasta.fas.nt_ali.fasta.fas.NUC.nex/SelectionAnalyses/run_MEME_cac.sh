LD_LIBRARY_PATH=/opt/gcc/5.4.0/lib64/:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH
(echo 1; echo my_data_file.nex; echo 1; echo 0.1) | ~/bin/bin/HYPHYMP MEME.bf 

