# sbatch -J tar_all -c 1 -t 14-0:0:0 tar -jcf res_SM_MEME2.tar.bz2 ss*/ ds*/

# qsub -N tar_all -q abaqus.q -cwd -b y -j y tar -jcf res_SM_MEME.tar.bz2 ss*/ ds*/
# qsub -N postMEME -q abaqus.q -l mem_free=100.0G -cwd -b y -j y ~/bin/R-3.2.3/bin/R CMD BATCH 7.postMEME.R

# just to make sure...
rm(list = ls())

# load packages
library(jsonlite)
library(ape)

virtype_lst <- list.files(pattern = ".csv")
virtype_lst <- sort(virtype_lst, decreasing = T)
MEME_all_res <- NULL

curdir <- getwd()
#i <- virtype_lst[1]
for(i in virtype_lst){
	virtype <- read.csv(i)
	dir_name <- sub("human_viruses_clean_", "", i)
	dir_name <- sub(".csv", "", dir_name)
	setwd(paste0(curdir, "/", dir_name))
	nexus_files <- list.files(path="_nexus_aln_tre/", pattern = ".fas.NUC.nex")
	n_nexus_files <- length(nexus_files)

	for(j in 1:n_nexus_files){
		if(file.exists(paste0("_MEME/", nexus_files[j], "/SelectionAnalyses/my_data_file.nex.MEME.json"))){
			print(paste0("Doing ", dir_name, "(", which(virtype_lst == i), ")", ": ", nexus_files[j]))
			# read res
			MEME_res <- headers <- res_mat <- dat <- nex_aln <- seq_len <- NULL
			nex_aln <- readLines(paste0("_MEME/", nexus_files[j], "/SelectionAnalyses/my_data_file.nex"), n=4)
			seq_len <- as.numeric(sub(";", "", unlist(strsplit(nex_aln[4], "NCHAR="))[2])) / 3
			MEME_res <- fromJSON(paste0("_MEME/", nexus_files[j], "/SelectionAnalyses/my_data_file.nex.MEME.json"), flatten=T)
			dat <- read.nexus(paste0("_MEME/", nexus_files[j], "/SelectionAnalyses/my_data_file.nex"))
			headers <- MEME_res$MLE$headers[,1]
			res_mat <- MEME_res$MLE$content$`0`
			res_mat <- cbind(which(virtype_lst == i), j, res_mat, length(dat$tip.label), seq_len, 1:seq_len, nexus_files[j])
			colnames(res_mat) <-c("VirType", "Data_ID", headers, "NbSeq", "NbCodons", "SiteID", "geneName")
			MEME_all_res <- rbind(MEME_all_res, res_mat)
		}

		setwd(paste0(curdir, "/", dir_name))
	}
	setwd(curdir)
}


########################
save.image("7.postMEME.RData")
q(save="no")
########################





