# qsub -N clean_aln -q abaqus.q -l mem_free=50.0G -cwd -b y -j y ~/bin/R-3.2.3/bin/R CMD BATCH 3.clean_aln.R

# just to make sure...
rm(list = ls())

# load packages
library(ape)
library(seqinr)
library(stringr)

virtype_lst <- list.files(pattern = ".csv")
virtype_lst <- sort(virtype_lst, decreasing = T)

# check, cleanup alignments
stop_codons <- c("taa", "tag", "tga")
curdir <- getwd()
#i <- virtype_lst[1]
for(i in virtype_lst){
	virtype <- read.csv(i)
	dir_name <- sub("human_viruses_clean_", "", i)
	dir_name <- sub(".csv", "", dir_name)
	setwd(paste0(curdir, "/", dir_name))
	unlink("_aln_files_ok")
	unlink("_aln_files_not_ok")
	dir.create("_aln_files_ok")
	dir.create("_aln_files_not_ok")
	raw_aln_files <- list.files(path="_aln_files/", pattern = ".fasta")
	n_raw_aln_files <- length(raw_aln_files)
	# check ORF position
	for(j in 1:n_raw_aln_files){
		cur_aln <- first_seq <- NULL
		cur_aln <- read.fasta(paste0("_aln_files/", raw_aln_files[j]))
		names(cur_aln) <- gsub("\\.", "", names(cur_aln))
		first_seq <- c2s(cur_aln[[1]][1:length(cur_aln[[1]])])
		len_first_seq <- nchar(first_seq)
		first_seq_begin <- substr(first_seq, 1, 3)
		first_seq_end <- substr(first_seq, len_first_seq-2, len_first_seq)
		if(!(len_first_seq %% 3) & (first_seq_begin == "atg") & (first_seq_end %in% stop_codons)){
			system(paste0("gblocks _aln_files/", raw_aln_files[j], " -t=c -e=.fas"))
			system(paste0("cp _aln_files/", raw_aln_files[j], ".fas _aln_files_ok/."))
		}else{
			system(paste0("cp _aln_files/", raw_aln_files[j], " _aln_files_not_ok/."))
			# eliminate seq w/ too many indels
			n_indels <- c()
			for(k in 1:length(cur_aln)){
				n_indels[k] <- str_count(c2s(cur_aln[[k]][1:length(cur_aln[[k]])]), pattern = "-")
			}
			mean_n_indels <- mean(n_indels)
			sd_n_indels <- sqrt(var(n_indels))
			upper_limt_n_indels <- mean_n_indels + sd_n_indels
			seq2rm <- which(n_indels > upper_limt_n_indels)
			if(length(seq2rm) > 0){
				clean_cur_aln <- cur_aln[-seq2rm]
			}else{
				clean_cur_aln <- cur_aln
			}
			# rm indels
			for(k in 1:length(clean_cur_aln)){
				site2rm <- which(clean_cur_aln[[k]] == "-")
				clean_cur_aln[[k]] <- clean_cur_aln[[k]][-site2rm]
			}
			write.fasta(sequences = clean_cur_aln, names = names(clean_cur_aln), nbchar = 80, file.out = paste0("_aln_files_not_ok/", raw_aln_files[j], "_clean"))
			# re-align with translatorx
			system(paste0("perl ../translatorx.pl -i _aln_files_not_ok/",  raw_aln_files[j], "_clean -o _aln_files_not_ok/", raw_aln_files[j],".fas -p M -t T -w 1 -c 5"))
			system(paste0("gblocks _aln_files_not_ok/", raw_aln_files[j], ".fas.nt_ali.fasta -t=c -e=.fas"))
			system(paste0("mv _aln_files_not_ok/", raw_aln_files[j], ".fas.nt_ali.fasta.fas _aln_files_ok/."))
			# use??? https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter7.html
		}
	}
	setwd(curdir)
}


########################
#save.image("2.blastData.RData")
q(save="no")
########################








