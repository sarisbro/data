# qsub -N postSM -q abaqus.q -l mem_free=100.0G -cwd -b y -j y ~/bin/R-3.2.3/bin/R CMD BATCH 8.post_analyses.R

# just to make sure...
rm(list = ls())

# load packages
#library(locfit)
library(ggplot2)
library(gridExtra)
library(plyr)
library(robust)
library(MASS) 
library(mgcv)
library(VennDiagram)
library(gridExtra)
library(ape)
library(topGO)
library(RColorBrewer)
library(colorspace)
library(GOplot)
library(goProfiles)

# load("8.post_analyses.RData")

virtype_lst <- list.files(pattern = ".csv")
#virtype_lst <- sort(virtype_lst, decreasing = T)
virtype_lst <- sort(virtype_lst, decreasing = F)

vir_lst <- gsub("human_viruses_clean_", "", virtype_lst)
vir_lst <- gsub(".csv", "", vir_lst)

												###############
												# basic stats #
												###############

genome_len <- n_genes <- n_prots <- n_rna <- list()
for(i in virtype_lst){
	dat <- read.csv(i, header=T)
	dat$Genome.length <- gsub(" \\(\\d+ segments\\)", "", as.character(dat$Genome.length))
	dat$Genome.length <- gsub(",", "", as.character(dat$Genome.length))
	dat$Genome.length <- as.numeric(dat$Genome.length)
	genome_len[[i]] <- dat$Genome.length
	n_genes[[i]] <- dat$Genes
	n_prots[[i]] <- dat$Proteins
	n_rna[[i]] <- dat$RNAs
}

#mycol <- brewer.pal(4, "Paired")
mycol <- diverge_hsv(7)[c(1,2,6,7)]


# genome lengths
max_y <- max(log10(unlist(genome_len)))
min_y <- min(log10(unlist(genome_len)))
p_glen1 <- list()
for(i in 1:4){
	glen <- data.frame(log10(genome_len[[i]]))
	colnames(glen) <- "GenomeLength"
	p_glen1[[i]] <- ggplot(glen, aes(x= vir_lst[i], y= GenomeLength)) +
		     geom_boxplot(outlier.colour=NA, fill="grey90", colour="grey40") +
		     geom_point(aes(fill= mycol[i]), size=2, shape=21, colour= "black", fill= mycol[i],
		                position=position_jitter(width=0.2, height=0.1)) +
		     scale_y_continuous(limits = c(min_y, max_y)) +
		     theme_bw() + theme(legend.position="none")
}

#pdf("stats_glen.pdf", height=4, width=6)
#grid.arrange(p_glen1[[1]], p_glen1[[2]], p_glen1[[3]], p_glen1[[4]], nrow=1)
#dev.off()


t.test(c(genome_len[[1]], genome_len[[2]]), c(genome_len[[3]], genome_len[[4]]))


# n_gene
max_y <- max((unlist(n_genes)))
min_y <- min((unlist(n_genes)))
p_glen2 <- list()
for(i in 1:4){
	glen <- data.frame((n_genes[[i]]))
	colnames(glen) <- "NbGenes"
	p_glen2[[i]] <- ggplot(glen, aes(x= vir_lst[i], y= NbGenes)) +
		     geom_boxplot(outlier.colour=NA, fill="grey90", colour="grey40") +
		     geom_point(aes(fill= mycol[i]), size=2, shape=21, colour= "black", fill= mycol[i],
		                position=position_jitter(width=0.2, height=0.1)) +
		     scale_y_continuous(limits = c(min_y, max_y)) +
		     theme_bw() + theme(legend.position="none")
}

#pdf("stats_ngenes.pdf", height=4, width=6)
#grid.arrange(p_glen2[[1]], p_glen2[[2]], p_glen2[[3]], p_glen2[[4]], nrow=1)
#dev.off()

# n_prots
max_y <- max((unlist(n_prots)))
min_y <- min((unlist(n_prots)))
p_glen3 <- list()
for(i in 1:4){
	glen <- data.frame((n_prots[[i]]))
	colnames(glen) <- "NbProts"
	p_glen3[[i]] <- ggplot(glen, aes(x= vir_lst[i], y= NbProts)) +
		     geom_boxplot(outlier.colour=NA, fill="grey90", colour="grey40") +
		     geom_point(aes(fill= mycol[i]), size=2, shape=21, colour= "black", fill= mycol[i],
		                position=position_jitter(width=0.2, height=0.1)) +
		     scale_y_continuous(limits = c(min_y, max_y)) +
		     theme_bw() + theme(legend.position="none")
}

#pdf("stats_nprots.pdf", height=4, width=6)
#grid.arrange(p_glen3[[1]], p_glen3[[2]], p_glen3[[3]], p_glen3[[4]], nrow=1)
#dev.off()

# n_rna
max_y <- max((unlist(n_rna)))
min_y <- min((unlist(n_rna)))
p_glen4 <- list()
for(i in 1:4){
	glen <- data.frame((n_rna[[i]]))
	colnames(glen) <- "NbRNAs"
	p_glen4[[i]] <- ggplot(glen, aes(x= vir_lst[i], y= NbRNAs)) +
		     geom_boxplot(outlier.colour=NA, fill="grey90", colour="grey40") +
		     geom_point(aes(fill= mycol[i]), size=2, shape=21, colour= "black", fill= mycol[i],
		                position=position_jitter(width=0.2, height=0.1)) +
		     scale_y_continuous(limits = c(min_y, max_y)) +
		     theme_bw() + theme(legend.position="none")
}

#pdf("stats_nrna.pdf", height=4, width=6)
#grid.arrange(p_glen4[[1]], p_glen4[[2]], p_glen4[[3]], p_glen4[[4]], nrow=1)
#dev.off()

pdf("stats_all.pdf", height=8, width=12)
grid.arrange(
	p_glen1[[1]], p_glen1[[2]], p_glen1[[3]], p_glen1[[4]], 
	p_glen2[[1]], p_glen2[[2]], p_glen2[[3]], p_glen2[[4]], 
	p_glen3[[1]], p_glen3[[2]], p_glen3[[3]], p_glen3[[4]], 
	p_glen4[[1]], p_glen4[[2]], p_glen4[[3]], p_glen4[[4]], 
	nrow=4)
dev.off()



											##########################
											# extraction of GO terms #
											##########################

download.file("ftp.ebi.ac.uk/pub/databases/Pfam/current_release/Pfam-A.hmm.gz", "Pfam-A.hmm.gz")
#trying URL 'ftp.ebi.ac.uk/pub/databases/Pfam/current_release/Pfam-A.hmm.gz'
#Content type 'unknown' length 257664436 bytes (245.7 MB)
#==================================================
system("gunzip Pfam-A.hmm.gz")
system("hmmpress Pfam-A.hmm") # to format DB
#Pressed and indexed 16712 HMMs (16712 names and 16712 accessions).
#Models pressed into binary file:   Pfam-A.hmm.h3m
#SSI index for binary model file:   Pfam-A.hmm.h3i
#Profiles (MSV part) pressed into:  Pfam-A.hmm.h3f
#Profiles (remainder) pressed into: Pfam-A.hmm.h3p
system("rm Pfam-A.hmm")

for(i in vir_lst){
	nexus_lst <- list.files(path=paste0(i, "/_nexus_aln_tre"), pattern = ".fas.AA.nex")
	system(paste0("mkdir ", i, "/GO_terms"))
	for(j in 1:length(nexus_lst)){
		dat <- readLines(paste0(i, "/_nexus_aln_tre/", nexus_lst[j]))
		vir_name <- sub(".fasta.aln.nt_ali.fasta.fas.AA.nex", "", nexus_lst[j])
		vir_name <- sub(".fasta.aln.nt_ali.fasta.fas.nt_ali.fasta.fas.AA.nex", "", vir_name)
		if(!(dir.exists(paste0(i, "/GO_terms/", vir_name)))){
			system(paste0("mkdir ", i, "/GO_terms/", vir_name))
			for(k in 8:(length(dat) - 8)){ # this loop over seuences in the alignment is to help when E-values are terrible
				curseq <- toupper(unlist(strsplit(dat[k], "\\s+"))[2])
				cat(paste0(">", vir_name, "\n", curseq)
				, file=paste0(i, "/GO_terms/", vir_name, "/genes.fasta"))
				system(paste0("hmmer2go run -i ", i, "/GO_terms/", vir_name, "/genes.fasta -d Pfam-A.hmm -o ", i, "/GO_terms/", vir_name, "/genes_orf_Pfam-A.tblout"))
				system(paste0("hmmer2go mapterms -i ", i, "/GO_terms/", vir_name, "/genes_orf_Pfam-A.tblout -o  ", i, "/GO_terms/", vir_name, "/genes_orf_Pfam-A_GO.tsv --map"))
				if(file.exists(paste0(i, "/GO_terms/", vir_name, "/genes_orf_Pfam-A_GO_GOterm_mapping.tsv"))){
					if(file.size(paste0(i, "/GO_terms/", vir_name, "/genes_orf_Pfam-A_GO_GOterm_mapping.tsv")) > 0){
						break
					}else{
						system(paste0("rm ", i, "/GO_terms/", vir_name, "/*.tsv"))
						system(paste0("rm ", i, "/GO_terms/", vir_name, "/*.tblout"))
					}
				}else{
					break
				}
			}
		}
	}
}

system("tar -jcf GO_terms.tar.bz2 ds*/GO* ss*/GO*")

# https://github.com/sestaton/HMMER2GO/wiki/Tutorial
# Some statistical analysis packages, such as Ontologizer, require a GAF file as input. This can be created with the hmmer2go map2gaf command.
# hmmer2go map2gaf -i genes_orfs_Pfam-A_GO_GOterm_mapping.tsv -o genes_orfs_Pfam-A_GO_GOterm_mapping.gaf -s 'Helianthus annuus'



# read GO terms specific to each gene
ssRNA <- ssDNA <- dsRNA <- dsDNA <- list()
go_terms <- list(ssRNA = ssRNA, ssDNA = ssDNA, dsRNA = dsRNA, dsDNA = dsDNA)
for(i in vir_lst){
	nexus_lst <- list.files(path=paste0(i, "/_nexus_aln_tre"), pattern = ".fas.AA.nex")
	for(j in 1:length(nexus_lst)){
		vir_name <- sub(".fasta.aln.nt_ali.fasta.fas.AA.nex", "", nexus_lst[j])
		vir_name <- sub(".fasta.aln.nt_ali.fasta.fas.nt_ali.fasta.fas.AA.nex", "", vir_name)
		print(vir_name)
		if(file.exists(paste0(i, "/GO_terms/", vir_name, "/genes_orf_Pfam-A_GO_GOterm_mapping.tsv"))){
			if(file.size(paste0(i, "/GO_terms/", vir_name, "/genes_orf_Pfam-A_GO_GOterm_mapping.tsv")) > 0){
				curGOterms <- read.csv(paste0(i, "/GO_terms/", vir_name, "/genes_orf_Pfam-A_GO_GOterm_mapping.tsv"), header=F, colClasses=c("character"))
				curGOterms[1] <- gsub("curgene\t", "", curGOterms[1])
				names(curGOterms) <- NULL
				curGOterms <- as.character(curGOterms)
				if(i == "ssRNA"){
					go_terms$ssRNA[[j]] <- curGOterms
				}
				if(i == "dsRNA"){
					go_terms$dsRNA[[j]] <- curGOterms
				}
				if(i == "ssDNA"){
					go_terms$ssDNA[[j]] <- curGOterms
				}
				if(i == "dsDNA"){
					go_terms$dsDNA[[j]] <- curGOterms
				}
			}
		}
	}
}

# create translation table virtyp / gene # / gene name
trans_tbl <- c()
for(i in vir_lst){
	nexus_lst <- list.files(path=paste0(i, "/_nexus_aln_tre"), pattern = ".fas.AA.nex")
	for(j in 1:length(nexus_lst)){
		vir_name <- sub(".fasta.aln.nt_ali.fasta.fas.AA.nex", "", nexus_lst[j])
		vir_name <- sub(".fasta.aln.nt_ali.fasta.fas.nt_ali.fasta.fas.AA.nex", "", vir_name)
		print(vir_name)
		trans_tbl <- rbind(trans_tbl, c(i, which(vir_lst == i), j, vir_name))
	}
}
colnames(trans_tbl) <- c("virTyp", "virCode", "geneCode", "geneName")
trans_tbl <- data.frame(trans_tbl)

# read annotations
#system("cat */GO_terms/*/*_GO.tsv > GO.tsv")
#GO.ann <- read.table("GO.tsv", header = F, sep="\t", fill=T)
#GO.ann <- GO.ann[unique(GO.ann[,5]),]

################################
# GO enrichment test -- 181214 #
################################

geneID2GO <- readMappings("GO_mapping.tsv")
GO2geneID <- inverseList(geneID2GO)
geneNames <- names(geneID2GO)

gene_list0 <- trans_tbl$geneName
gene_list1 <- trans_tbl$geneName[trans_tbl$virTyp == "dsDNA"]
gene_list2 <- trans_tbl$geneName[trans_tbl$virTyp == "ssRNA"]

local_geneNames <- geneNames
geneList1 <- factor(as.integer(local_geneNames %in% gene_list1))
names(geneList1) <- local_geneNames
geneList2 <- factor(as.integer(local_geneNames %in% gene_list2))
names(geneList2) <- local_geneNames

# MF-1
GOdata_MF_1 <- new("topGOdata", ontology = "MF", allGenes = geneList1, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF_1, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF_1, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF_1 <- GenTable(GOdata_MF_1, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF_1
write.csv(allRes_MF_1, "GO_ALL_MF_dsDNA.csv", quote=F, row.names=F)
pdf("8.GO1_MF_ssDNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF_1, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# MF-2
GOdata_MF_2 <- new("topGOdata", ontology = "MF", allGenes = geneList2, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF_2, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF_2, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF_2 <- GenTable(GOdata_MF_2, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF_2
write.csv(allRes_MF_2, "GO_ALL_MF_ssRNA.csv", quote=F, row.names=F)
pdf("8.GO1_MF_ssRNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF_2, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()

# BP-1
GOdata_BP_1 <- new("topGOdata", ontology = "BP", allGenes = geneList1, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP_1, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP_1, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP_1 <- GenTable(GOdata_BP_1, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP_1
write.csv(allRes_BP_1, "GO_ALL_BP_dsDNA.csv", quote=F, row.names=F)
pdf("8.GO1_BP_ssDNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP_1, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# BP-2
GOdata_BP_2 <- new("topGOdata", ontology = "BP", allGenes = geneList2, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP_2, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP_2, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP_2 <- GenTable(GOdata_BP_2, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP_2
write.csv(allRes_BP_2, "GO_ALL_BP_ssRNA.csv", quote=F, row.names=F)
pdf("8.GO1_BP_ssRNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP_2, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()

# CC-1
GOdata_CC_1 <- new("topGOdata", ontology = "CC", allGenes = geneList1, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC_1, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC_1, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC_1 <- GenTable(GOdata_CC_1, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC_1
write.csv(allRes_CC_1, "GO_ALL_CC_dsDNA.csv", quote=F, row.names=F)
pdf("8.GO1_CC_ssDNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC_1, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# CC-2
GOdata_CC_2 <- new("topGOdata", ontology = "CC", allGenes = geneList2, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC_2, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC_2, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC_2 <- GenTable(GOdata_CC_2, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC_2
write.csv(allRes_CC_2, "GO_ALL_CC_ssRNA.csv", quote=F, row.names=F)
pdf("8.GO1_CC_ssRNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC_2, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()


######################
# GO enrichment test #
######################

system("cat */GO_terms/*/*mapping.tsv > GO_mapping.tsv")
geneID2GO <- readMappings("GO_mapping.tsv")
GO2geneID <- inverseList(geneID2GO)
geneNames <- names(geneID2GO)

# create lists of genes to compare
gene_list1 <- trans_tbl$geneName[trans_tbl$virTyp == "ssDNA"]
gene_list2 <- trans_tbl$geneName[trans_tbl$virTyp == "ssRNA"]
local_geneNames <- geneNames[(geneNames %in% gene_list1) | (geneNames %in% gene_list2)]
geneList <- factor(as.integer(local_geneNames %in% gene_list1))
names(geneList) <- local_geneNames
# MF
GOdata_MF <- new("topGOdata", ontology = "MF", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF <- GenTable(GOdata_MF, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF
pdf("8.GO1_MF_ssDNA-ssRNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# BP
GOdata_BP <- new("topGOdata", ontology = "BP", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP <- GenTable(GOdata_BP, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP
pdf("8.GO1_BP_ssDNA-ssRNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# CC
GOdata_CC <- new("topGOdata", ontology = "CC", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC <- GenTable(GOdata_CC, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC
pdf("8.GO1_CC_ssDNA-ssRNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()



# create lists of genes to compare
gene_list1 <- trans_tbl$geneName[trans_tbl$virTyp == "dsDNA"]
gene_list2 <- trans_tbl$geneName[trans_tbl$virTyp == "ssRNA"]
local_geneNames <- geneNames[(geneNames %in% gene_list1) | (geneNames %in% gene_list2)]
geneList <- factor(as.integer(local_geneNames %in% gene_list1))
names(geneList) <- local_geneNames
# MF
GOdata_MF <- new("topGOdata", ontology = "MF", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF <- GenTable(GOdata_MF, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF
pdf("8.GO1_MF_dsDNA-ssRNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# BP
GOdata_BP <- new("topGOdata", ontology = "BP", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP <- GenTable(GOdata_BP, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP
pdf("8.GO1_BP_dsDNA-ssRNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# CC
GOdata_CC <- new("topGOdata", ontology = "CC", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC <- GenTable(GOdata_CC, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC
pdf("8.GO1_CC_dsDNA-ssRNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()



# create lists of genes to compare
gene_list1 <- trans_tbl$geneName[trans_tbl$virTyp == "dsDNA"]
gene_list2 <- trans_tbl$geneName[trans_tbl$virTyp == "ssDNA"]
local_geneNames <- geneNames[(geneNames %in% gene_list1) | (geneNames %in% gene_list2)]
geneList <- factor(as.integer(local_geneNames %in% gene_list1))
names(geneList) <- local_geneNames
# MF
GOdata_MF <- new("topGOdata", ontology = "MF", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF <- GenTable(GOdata_MF, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF
pdf("8.GO1_MF_dsDNA-ssDNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# BP
GOdata_BP <- new("topGOdata", ontology = "BP", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP <- GenTable(GOdata_BP, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP
pdf("8.GO1_BP_dsDNA-ssDNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# CC
GOdata_CC <- new("topGOdata", ontology = "CC", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC <- GenTable(GOdata_CC, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC
pdf("8.GO1_CC_dsDNA-ssDNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()



# create lists of genes to compare
gene_list1 <- trans_tbl$geneName[trans_tbl$virTyp == "dsRNA"]
gene_list2 <- trans_tbl$geneName[trans_tbl$virTyp == "ssRNA"]
local_geneNames <- geneNames[(geneNames %in% gene_list1) | (geneNames %in% gene_list2)]
geneList <- factor(as.integer(local_geneNames %in% gene_list1))
names(geneList) <- local_geneNames
# MF
GOdata_MF <- new("topGOdata", ontology = "MF", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF <- GenTable(GOdata_MF, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF
pdf("8.GO1_MF_dsRNA-ssRNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# BP
GOdata_BP <- new("topGOdata", ontology = "BP", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP <- GenTable(GOdata_BP, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP
pdf("8.GO1_BP_dsRNA-ssRNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# CC
GOdata_CC <- new("topGOdata", ontology = "CC", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC <- GenTable(GOdata_CC, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC
pdf("8.GO1_CC_dsRNA-ssRNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()



												################
												# SpiderMonkey #
												################
load("7.postSpiderMonkey.RData")

# convert data from data frame
SM_all_res <- data.frame(VirType = factor(SM_all_res[,1], labels= vir_lst),
				Data_ID = as.numeric(SM_all_res[,2]),
				Site1 = as.numeric(SM_all_res[,3]),
				Site2 = as.numeric(SM_all_res[,4]),
				Site1to2 =  as.numeric(SM_all_res[,5]),
				Site2to1 =  as.numeric(SM_all_res[,6]),
				PostProb = as.numeric(SM_all_res[,7]),
				NbSeq = as.numeric(SM_all_res[,8]),
				NbCodons = as.numeric(SM_all_res[,9]),
				geneName = SM_all_res[,10]
				)

SM_all_res$geneName <- gsub(".fasta.aln.nt_ali.fasta.fas.NUC.nex", "", SM_all_res$geneName)
SM_all_res$geneName <- gsub(".fasta.aln.nt_ali.fasta.fas.nt_ali.fasta.fas.NUC.nex", "", SM_all_res$geneName)
# just to check
levels(as.factor(SM_all_res$geneName))

# eliminate data w/ > 100 seq
#SM_all_res <- SM_all_res[SM_all_res[,8] <= 100,]

# for some reason, some PP are > 1: eliminate these as errors
SM_all_res <- SM_all_res[SM_all_res[,7] <= 1.0,]

##########################################################################################
# do we have more statistical evidence for correlated evolution in RNA than DNA viruses? #
##########################################################################################

df1 <- SM_all_res
df1$VirType <- factor(df1$VirType, labels= vir_lst)
df1$Data_ID <- factor(df1$Data_ID)

ggplot(df1,aes(x = PostProb, colour = VirType, fill = VirType)) +
  geom_density(alpha=0.25) +
  #scale_x_continuous(limits = c(0, .25)) +
  #scale_x_continuous(limits = c(.05, 1)) +
  xlab("Posterior probability") +  ylab ("Density") + 
  #scale_fill_brewer() +
  scale_fill_manual(values=c("red", "#56B4E9", "#E69F00", "blue")) +
  scale_colour_manual(values=c("red", "#56B4E9", "#E69F00", "blue")) +
  theme_minimal()
ggsave("8.SM_dens2_all.pdf", plot = last_plot(), width = 6, height = 4)


ggplot(df1,aes(x = PostProb, colour = VirType, fill = VirType)) +
  geom_density(alpha=0.25) +
  scale_x_continuous(limits = c(.25, 1)) +
  xlab("Posterior probability") +  ylab ("Density") + 
  #scale_fill_brewer() +
  scale_fill_manual(values=c("red", "#56B4E9", "#E69F00", "blue")) +
  scale_colour_manual(values=c("red", "#56B4E9", "#E69F00", "blue")) +
  theme_minimal()
ggsave("8.SM_dens2_zoom_hi.pdf", plot = last_plot(), width = 6, height = 4)


ggplot(df1,aes(x = PostProb, colour = VirType, fill = VirType)) +
  geom_density(alpha=0.25) +
  scale_x_continuous(limits = c(0, .25)) +
  xlab("Posterior probability") +  ylab ("Density") + 
  #scale_fill_brewer() +
  scale_fill_manual(values=c("red", "#56B4E9", "#E69F00", "blue")) +
  scale_colour_manual(values=c("red", "#56B4E9", "#E69F00", "blue")) +
  theme_minimal()
ggsave("8.SM_dens2_zoom_lo.pdf", plot = last_plot(), width = 6, height = 4)


####################################################################################
# do we have more genes w/ signal of correlated evolution in RNA than DNA viruses? #
####################################################################################

# ID genes with strong signal of correlated evolution -- Genes of Interest
alpha_PP <- .95
SM_GOI <- NULL
for(i in 1:length(SM_all_res[,7])){
	if(SM_all_res[i,7] > alpha_PP){
		#print(i)
		SM_GOI <- rbind(SM_GOI, c(SM_all_res[i,1], SM_all_res[i,2], SM_all_res[i,3], SM_all_res[i,4], SM_all_res[i,7], SM_all_res[i,10]))
	}
}

SM_GOI <- data.frame(VirType = factor(SM_GOI[,1], labels= vir_lst),
				Data_ID = as.numeric(SM_GOI[,2]),
				Site1 = as.numeric(SM_GOI[,3]),
				Site2 = as.numeric(SM_GOI[,4]),
				PostProb = as.numeric(SM_GOI[,5]),
				geneName = SM_GOI[,6]
				)


SM_GOI_lst <- list()
for(i in vir_lst){
	SM_GOI_lst[[i]] <- unique(SM_GOI[,2][SM_GOI[,1] == i])
}
SM_GOI_counts <- unlist(lapply(SM_GOI_lst, length))
# total number of genes
all_lst <- list()
for(i in vir_lst){
	all_lst[[i]] <- unique(SM_all_res[,2][SM_all_res[,1] == i])
}
all_counts <- unlist(lapply(all_lst, length))
noSM_counts <- all_counts - SM_GOI_counts


# http://www.sthda.com/english/wiki/ggplot2-barplots-quick-start-guide-r-software-and-data-visualization
# all four virus types
chisq.test(matrix(c(SM_GOI_counts, noSM_counts), ncol = 4, byrow=T))
# df2 <- data.frame(virtyp = c(vir_lst, vir_lst), log10_n_genes =log10(c(all_counts, SM_GOI_counts)), n_genes = c(all_counts, SM_GOI_counts), SM = c(rep("all",4), rep("SM",4)))
# ggplot(data=df2, aes(x= virtyp, y= log10_n_genes, fill= SM)) +
#   geom_bar(stat="identity", position=position_dodge())+
#   geom_text(aes(label= n_genes), vjust=1.6, color="white",
#             position = position_dodge(0.9), size=3.5)+
#   scale_fill_brewer(palette="Paired")+
#   theme_minimal()
# ggsave("8.SM_barplot_all.pdf", plot = last_plot(), width = 6, height = 4)
  

df2prop <- data.frame(virtyp = c(vir_lst, vir_lst), prop_genes =c(100*noSM_counts/all_counts, 100*SM_GOI_counts/all_counts), n_genes = c(noSM_counts, SM_GOI_counts), SM = c(rep("noCorrEvol",4), rep("CorrEvol",4)))
df2prop_sorted <- arrange(df2prop, virtyp, SM) 
df2_cumsum <- ddply(df2prop_sorted, "virtyp", transform, label_ypos=c(98,55))
ggplot(data= df2_cumsum, aes(x= virtyp, y= prop_genes, fill= SM)) +
   geom_bar(stat="identity") +
   geom_text(aes(y=label_ypos, label= n_genes), vjust=1.6, 
             color="white", size=3.5) +
   scale_fill_brewer(palette="Paired", direction=-1) +
   theme_minimal()
ggsave("8.SM_barplot_all.pdf", plot = last_plot(), width = 6, height = 4)


# RNA vs DNA viruses
chisq.test(matrix(c(sum(SM_GOI_counts[c(1,3)]), sum(SM_GOI_counts[c(2,4)]), sum(noSM_counts[c(1,3)]), sum(noSM_counts[c(2,4)])), ncol = 2, byrow=T))

# ssRNA vs dsDNA viruses
chisq.test(matrix(c(sum(SM_GOI_counts[c(1)]), sum(SM_GOI_counts[c(4)]), sum(noSM_counts[c(1)]), sum(noSM_counts[c(4)])), ncol = 2, byrow=T))

# ss vs ds viruses
#chisq.test(matrix(c(sum(SM_GOI_counts[c(1)]), sum(SM_GOI_counts[c(4)]), sum(noSM_counts[c(1)]), sum(noSM_counts[c(4)])), ncol = 2, byrow=T))

# dna vs rna viruses
chisq.test(matrix(c(sum(SM_GOI_counts[c(2,4)]), sum(SM_GOI_counts[c(1,3)]), sum(noSM_counts[c(2,4)]), sum(noSM_counts[c(1,3)])), ncol = 2, byrow=T))

# dna vs dna viruses
chisq.test(matrix(c(sum(SM_GOI_counts[c(4)]), sum(SM_GOI_counts[c(2)]), sum(noSM_counts[c(4)]), sum(noSM_counts[c(2)])), ncol = 2, byrow=T))

# rna vs rna viruses
chisq.test(matrix(c(sum(SM_GOI_counts[c(1)]), sum(SM_GOI_counts[c(3)]), sum(noSM_counts[c(1)]), sum(noSM_counts[c(3)])), ncol = 2, byrow=T))

# ss vs ds viruses
chisq.test(matrix(c(sum(SM_GOI_counts[c(2,4)]), sum(SM_GOI_counts[c(1,3)]), sum(noSM_counts[c(2,4)]), sum(noSM_counts[c(1,3)])), ncol = 2, byrow=T))


################################
# GO enrichment test -- 181214 #
################################

geneID2GO <- readMappings("GO_mapping.tsv")
GO2geneID <- inverseList(geneID2GO)
geneNames <- names(geneID2GO)


local_geneNames <- geneNames
MEME1_geneName <- unique(SM_GOI$geneName[SM_GOI$VirType == vir_lst[4]])
geneList1 <- factor(as.integer(local_geneNames %in% MEME1_geneName))
names(geneList1) <- local_geneNames
MEME2_geneName <- unique(SM_GOI$geneName[SM_GOI$VirType == vir_lst[1]])
geneList2 <- factor(as.integer(local_geneNames %in% MEME2_geneName))
names(geneList2) <- local_geneNames


# MF-1
GOdata_MF_1 <- new("topGOdata", ontology = "MF", allGenes = geneList1, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF_1, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF_1, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF_1 <- GenTable(GOdata_MF_1, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF_1
write.csv(allRes_MF_1, "GO_SM_MF_dsDNA.csv", quote=F, row.names=F)
pdf("8.GO1_MF_ssDNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF_1, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# MF-2
GOdata_MF_2 <- new("topGOdata", ontology = "MF", allGenes = geneList2, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF_2, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF_2, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF_2 <- GenTable(GOdata_MF_2, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF_2
write.csv(allRes_MF_2, "GO_SM_MF_ssRNA.csv", quote=F, row.names=F)
pdf("8.GO1_MF_ssRNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF_2, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()

# BP-1
GOdata_BP_1 <- new("topGOdata", ontology = "BP", allGenes = geneList1, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP_1, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP_1, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP_1 <- GenTable(GOdata_BP_1, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP_1
write.csv(allRes_BP_1, "GO_SM_BP_dsDNA.csv", quote=F, row.names=F)
pdf("8.GO1_BP_ssDNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP_1, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# BP-2
GOdata_BP_2 <- new("topGOdata", ontology = "BP", allGenes = geneList2, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP_2, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP_2, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP_2 <- GenTable(GOdata_BP_2, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP_2
write.csv(allRes_BP_2, "GO_SM_BP_ssRNA.csv", quote=F, row.names=F)
pdf("8.GO1_BP_ssRNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP_2, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()

# CC-1
GOdata_CC_1 <- new("topGOdata", ontology = "CC", allGenes = geneList1, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC_1, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC_1, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC_1 <- GenTable(GOdata_CC_1, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC_1
write.csv(allRes_CC_1, "GO_SM_CC_dsDNA.csv", quote=F, row.names=F)
pdf("8.GO1_CC_ssDNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC_1, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# CC-2
GOdata_CC_2 <- new("topGOdata", ontology = "CC", allGenes = geneList2, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC_2, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC_2, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC_2 <- GenTable(GOdata_CC_2, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC_2
write.csv(allRes_CC_2, "GO_SM_CC_ssRNA.csv", quote=F, row.names=F)
pdf("8.GO1_CC_ssRNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC_2, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()


# GO enrichment test: all the genes that show SM evidence vs. the others, across all virTypes
# create lists of genes to compare
SM_geneName <- unique(SM_GOI$geneName)
local_geneNames <- geneNames
geneList <- factor(as.integer(local_geneNames %in% SM_geneName))
names(geneList) <- local_geneNames
# MF
GOdata_MF <- new("topGOdata", ontology = "MF", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF <- GenTable(GOdata_MF, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF
pdf("8.GO1_MF_SM.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# BP
GOdata_BP <- new("topGOdata", ontology = "BP", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP <- GenTable(GOdata_BP, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP
pdf("8.GO1_BP_SM.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# CC
GOdata_CC <- new("topGOdata", ontology = "CC", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC <- GenTable(GOdata_CC, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC
pdf("8.GO1_CC_SM.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()


# GO enrichment test: all the genes that show SM evidence within each virType
# create lists of genes to compare
SM1_geneName <- unique(SM_GOI$geneName[SM_GOI$VirType == vir_lst[1]])
local_geneNames <- unique(SM_all_res$geneName[SM_all_res$VirType == vir_lst[1]])
geneList <- factor(as.integer(local_geneNames %in% SM1_geneName))
names(geneList) <- local_geneNames
# MF
GOdata_MF <- new("topGOdata", ontology = "MF", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF <- GenTable(GOdata_MF, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF
pdf("8.GO1_MF_SM1.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# BP
GOdata_BP <- new("topGOdata", ontology = "BP", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP <- GenTable(GOdata_BP, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP
pdf("8.GO1_BP_SM1.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# CC
GOdata_CC <- new("topGOdata", ontology = "CC", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC <- GenTable(GOdata_CC, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC
pdf("8.GO1_CC_SM1.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()


SM2_geneName <- unique(SM_GOI$geneName[SM_GOI$VirType == vir_lst[2]])
local_geneNames <- unique(SM_all_res$geneName[SM_all_res$VirType == vir_lst[2]])
geneList <- factor(as.integer(local_geneNames %in% SM2_geneName))
names(geneList) <- local_geneNames
# MF
GOdata_MF <- new("topGOdata", ontology = "MF", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF <- GenTable(GOdata_MF, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF
pdf("8.GO1_MF_SM2.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# BP
GOdata_BP <- new("topGOdata", ontology = "BP", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP <- GenTable(GOdata_BP, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP
pdf("8.GO1_BP_SM2.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# CC
GOdata_CC <- new("topGOdata", ontology = "CC", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC <- GenTable(GOdata_CC, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC
pdf("8.GO1_CC_SM2.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()



SM3_geneName <- unique(SM_GOI$geneName[SM_GOI$VirType == vir_lst[3]])
local_geneNames <- unique(SM_all_res$geneName[SM_all_res$VirType == vir_lst[3]])
geneList <- factor(as.integer(local_geneNames %in% SM3_geneName))
names(geneList) <- local_geneNames
# MF
GOdata_MF <- new("topGOdata", ontology = "MF", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF <- GenTable(GOdata_MF, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF
pdf("8.GO1_MF_SM3.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# BP
GOdata_BP <- new("topGOdata", ontology = "BP", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP <- GenTable(GOdata_BP, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP
pdf("8.GO1_BP_SM3.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# CC
GOdata_CC <- new("topGOdata", ontology = "CC", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC <- GenTable(GOdata_CC, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC
pdf("8.GO1_CC_SM3.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()


SM4_geneName <- unique(SM_GOI$geneName[SM_GOI$VirType == vir_lst[4]])
local_geneNames <- unique(SM_all_res$geneName[SM_all_res$VirType == vir_lst[4]])
geneList <- factor(as.integer(local_geneNames %in% SM4_geneName))
names(geneList) <- local_geneNames
# MF
GOdata_MF <- new("topGOdata", ontology = "MF", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF <- GenTable(GOdata_MF, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF
pdf("8.GO1_MF_SM4.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# BP
GOdata_BP <- new("topGOdata", ontology = "BP", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP <- GenTable(GOdata_BP, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP
pdf("8.GO1_BP_SM4.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# CC
GOdata_CC <- new("topGOdata", ontology = "CC", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC <- GenTable(GOdata_CC, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC
pdf("8.GO1_CC_SM4.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()


												########
												# MEME #
												########
load("7.postMEME.RData")


# convert data from data frame
MEME_all_res <- data.frame(VirType = factor(MEME_all_res[,1], labels= rev(vir_lst)),
				Data_ID = as.numeric(MEME_all_res[,2]),
				alpha = as.numeric(MEME_all_res[,3]),
				beta_m = as.numeric(MEME_all_res[,4]),
				p_m =  as.numeric(MEME_all_res[,5]),
				beta_p =  as.numeric(MEME_all_res[,6]),
				p_p = as.numeric(MEME_all_res[,7]),
				lrt = as.numeric(MEME_all_res[,8]),
				pvalue = as.numeric(MEME_all_res[,9]),
				nbr = as.numeric(MEME_all_res[,10]),
				brlen = as.numeric(MEME_all_res[,11]),
				NbSeq = as.numeric(MEME_all_res[,12]),
				NbCodons = as.numeric(MEME_all_res[,13]),
				SiteID = as.numeric(MEME_all_res[,14]),
				geneName = MEME_all_res[,15]
				)

MEME_all_res$geneName <- gsub(".fasta.aln.nt_ali.fasta.fas.NUC.nex", "", MEME_all_res$geneName)
MEME_all_res$geneName <- gsub(".fasta.aln.nt_ali.fasta.fas.nt_ali.fasta.fas.NUC.nex", "", MEME_all_res$geneName)
# just to check
levels(as.factor(MEME_all_res$geneName))

# eliminate data w/ > 100 seq
#MEME_all_res <- MEME_all_res[MEME_all_res[,12] <= 100,]

#####################################################################################################
# do we have more statistical evidence for episodic diversifying selection in RNA than DNA viruses? #
#####################################################################################################

# basic visualizations
pdf("8.MEME_dens1.pdf", width=6, height=4)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
plot(density(-log10(MEME_all_res[,9][MEME_all_res[,1] == vir_lst[1]]), n=5000), xlab="-log10(P-value)", col="red", lty=1, xlim=c(0,.25), ylim=c(0,35), main="")
lines(density(-log10(MEME_all_res[,9][MEME_all_res[,1] == vir_lst[2]]), n=5000), col="blue", lty=1)
lines(density(-log10(MEME_all_res[,9][MEME_all_res[,1] == vir_lst[3]]), n=5000), col="red", lty=2)
lines(density(-log10(MEME_all_res[,9][MEME_all_res[,1] == vir_lst[4]]), n=5000), col="blue", lty=2)
legend("topright", vir_lst, col=c("red","blue","red","blue"), lty=c(1,1,2,2), cex=.7, bty = "n")
dev.off()

# https://www.r-bloggers.com/part-3a-plotting-with-ggplot2/
df1 <- MEME_all_res
df1$p.value <- -log10(df1$pvalue)
ggplot(df1,aes(x = VirType, y = p.value)) +
  geom_point(aes(size =log10(NbSeq)), colour = "blue", position = "jitter") +
  geom_violin(fill = "orange", trim=T) +
  xlab("Virus type") +  ylab ("-log10 P")

ggplot(df1,aes(x = p.value, colour = VirType, fill = VirType)) +
  geom_density(alpha=0.25) +
  scale_x_continuous(limits = c(0, .25)) +
  xlab("-log10 P") +  ylab ("Density") + 
  #scale_fill_brewer() +
  scale_fill_manual(values= mycol) +
  scale_colour_manual(values= mycol) +
  theme_minimal() + theme(legend.position="none")
ggsave("8.MEME_dens2.pdf", plot = last_plot(), width = 6, height = 4)

ggplot(df1,aes(x = p.value, colour = VirType, fill = VirType)) +
  geom_density(alpha=0.25) +
  scale_x_continuous(limits = c(0, .25)) +
  xlab("-log10 P") +  ylab ("Density") + 
  #scale_fill_brewer() +
  scale_fill_manual(values= mycol) +
  scale_colour_manual(values= mycol) +
  theme_minimal()
ggsave("8.MEME_dens2a.pdf", plot = last_plot(), width = 6, height = 4)


mycol <- diverge_hsv(7)[c(1,2,6,7)]
  

# basic linear model
mlog10p_m <- -log10(MEME_all_res[,9])
virtype <- factor(MEME_all_res[,1])
gene_ID <- factor(paste0(as.character(MEME_all_res[,1]),"_",as.character(MEME_all_res[,2])))
br_len <- MEME_all_res[,11]
n_seq <- MEME_all_res[,12]
nbcodons <- MEME_all_res[,13]
#aov_m <- aov(mlog10p_m ~ virtype + gene_ID + br_len + n_seq)
aov_m <- aov(mlog10p_m ~ virtype * br_len * n_seq * nbcodons)
summary(aov_m)

###########################################################################################
# do we have more genes under episodic diversifying selection in RNA than in DNA viruses? #
###########################################################################################

# ID genes with p < 0.001 (.1%) -- Genes of Interest
alpha <- 0.01 #0.001
MEME_GOI <- NULL
for(i in 1:length(MEME_all_res[,9])){
	if(MEME_all_res[i,9] < alpha){
		#print(i)
		MEME_GOI <- rbind(MEME_GOI, c(MEME_all_res[i,1], MEME_all_res[i,2], MEME_all_res[i,12], MEME_all_res[i,13], MEME_all_res[i,14], MEME_all_res[i,9], MEME_all_res[i,15]))
	}
}


MEME_GOI <- data.frame(VirType = factor(MEME_GOI[,1], labels= vir_lst),
				Data_ID = as.numeric(MEME_GOI[,2]),
				NbSeq = as.numeric(MEME_GOI[,3]),
				NbCodons = as.numeric(MEME_GOI[,4]),
				SiteID = as.numeric(MEME_GOI[,5]),
				pvalue = as.numeric(MEME_GOI[,6]),
				geneName = MEME_GOI[,7]
				)

MEME_GOI_lst <- list()
for(i in vir_lst){
	MEME_GOI_lst[[i]] <- unique(MEME_GOI[,2][MEME_GOI[,1] == i])
}
MEME_GOI_counts <- unlist(lapply(MEME_GOI_lst, length))
# total number of genes
all_lst <- list()
for(i in vir_lst){
	all_lst[[i]] <- unique(MEME_all_res[,2][MEME_all_res[,1] == i])
}
all_counts <- unlist(lapply(all_lst, length))
noMEME_counts <- all_counts - MEME_GOI_counts


# http://www.sthda.com/english/wiki/ggplot2-barplots-quick-start-guide-r-software-and-data-visualization
# all four virus types
chisq.test(matrix(c(MEME_GOI_counts, noMEME_counts), ncol = 4, byrow=T))
# df2 <- data.frame(virtyp = c(vir_lst, vir_lst), log10_n_genes =log10(c(all_counts, MEME_GOI_counts)), n_genes = c(all_counts, MEME_GOI_counts), MEME = c(rep("all",4), rep("MEME",4)))
# ggplot(data=df2, aes(x= virtyp, y= log10_n_genes, fill= MEME)) +
#   geom_bar(stat="identity", position=position_dodge())+
#   geom_text(aes(label= n_genes), vjust=1.6, color="white",
#             position = position_dodge(0.9), size=3.5)+
#   scale_fill_brewer(palette="Paired")+
#   theme_minimal()
# ggsave("8.MEME_barplot_all.pdf", plot = last_plot(), width = 6, height = 4)
  

df2prop <- data.frame(virtyp = c(vir_lst, vir_lst), prop_genes =c(100*noMEME_counts/all_counts, 100*MEME_GOI_counts/all_counts), n_genes = c(noMEME_counts, MEME_GOI_counts), MEME = c(rep("noSel",4), rep("MEME",4)))
df2prop_sorted <- arrange(df2prop, virtyp, MEME) 
df2_cumsum <- ddply(df2prop_sorted, "virtyp", transform, label_ypos=c(98,55))
ggplot(data= df2_cumsum, aes(x= virtyp, y= prop_genes, fill= MEME)) +
   geom_bar(stat="identity") +
   geom_text(aes(y=label_ypos, label= n_genes), vjust=1.6, 
             color="white", size=3.5) +
   scale_fill_brewer(palette="Paired", direction=-1) +
   theme_minimal()
ggsave("8.MEME_barplot_all.pdf", plot = last_plot(), width = 6, height = 4)



# df2_sorted <- arrange(df2, virtyp, MEME) 
# df2_cumsum <- ddply(df2_sorted, "virtyp", transform, label_ypos=cumsum(log10_n_genes))
# ggplot(data= df2_cumsum, aes(x= virtyp, y= n_genes, fill= MEME)) +
#   geom_bar(stat="identity")+
#   geom_text(aes(y=label_ypos, label= n_genes), vjust=1.6, 
#             color="white", size=3.5)+
#   scale_fill_brewer(palette="Paired")+
#   theme_minimal()
  
# RNA vs DNA viruses
chisq.test(matrix(c(sum(MEME_GOI_counts[c(1,3)]), sum(MEME_GOI_counts[c(2,4)]), sum(noMEME_counts[c(1,3)]), sum(noMEME_counts[c(2,4)])), ncol = 2, byrow=T))
# df2a <- data.frame(virtyp = c(paste(vir_lst[c(1,3)], collapse="+"), paste(vir_lst[c(2,4)], collapse="+")), log10_n_genes =log10(c(sum(noMEME_counts[c(1,3)]), sum(noMEME_counts[c(2,4)]), sum(MEME_GOI_counts[c(1,3)]), sum(MEME_GOI_counts[c(2,4)]))), n_genes = c(sum(noMEME_counts[c(1,3)]), sum(noMEME_counts[c(2,4)]), sum(MEME_GOI_counts[c(1,3)]), sum(MEME_GOI_counts[c(2,4)])), MEME = c(rep("all",2), rep("MEME",2)))
# ggplot(data=df2a, aes(x= virtyp, y= log10_n_genes, fill= MEME)) +
#   geom_bar(stat="identity", position=position_dodge())+
#   geom_text(aes(label= n_genes), vjust=1.6, color="white",
#             position = position_dodge(0.9), size=3.5)+
#   scale_fill_brewer(palette="Paired")+
#   theme_minimal()
# ggsave("8.MEME_barplot_RNA_DNA.pdf", plot = last_plot(), width = 4, height = 4)

# ssRNA vs dsDNA viruses
chisq.test(matrix(c(sum(MEME_GOI_counts[c(1)]), sum(MEME_GOI_counts[c(4)]), sum(noMEME_counts[c(1)]), sum(noMEME_counts[c(4)])), ncol = 2, byrow=T))
# df2b <- data.frame(virtyp = c(vir_lst[1], vir_lst[4]), log10_n_genes =log10(c(sum(noMEME_counts[c(1)]), sum(noMEME_counts[c(4)]), sum(MEME_GOI_counts[c(1)]), sum(MEME_GOI_counts[c(4)]))), n_genes = c(sum(noMEME_counts[c(1)]), sum(noMEME_counts[c(4)]), sum(MEME_GOI_counts[c(1)]), sum(MEME_GOI_counts[c(4)])), MEME = c(rep("all",2), rep("MEME",2)))
# ggplot(data=df2b, aes(x= virtyp, y= log10_n_genes, fill= MEME)) +
#   geom_bar(stat="identity", position=position_dodge())+
#   geom_text(aes(label= n_genes), vjust=1.6, color="white",
#             position = position_dodge(0.9), size=3.5)+
#   scale_fill_brewer(palette="Paired")+
#   theme_minimal()
# ggsave("8.MEME_barplot_ssRNA_dsDNA.pdf", plot = last_plot(), width = 4, height = 4)


# ss vs ds viruses
chisq.test(matrix(c(sum(MEME_GOI_counts[c(1,2)]), sum(MEME_GOI_counts[c(3,4)]), sum(noMEME_counts[c(1,2)]), sum(noMEME_counts[c(3,4)])), ncol = 2, byrow=T))

# ss vs ss viruses
chisq.test(matrix(c(sum(MEME_GOI_counts[c(1)]), sum(MEME_GOI_counts[c(2)]), sum(noMEME_counts[c(1)]), sum(noMEME_counts[c(2)])), ncol = 2, byrow=T))

# ss vs ss viruses
chisq.test(matrix(c(sum(MEME_GOI_counts[c(3)]), sum(MEME_GOI_counts[c(4)]), sum(noMEME_counts[c(3)]), sum(noMEME_counts[c(4)])), ncol = 2, byrow=T))



# SN / MEME / both
chisq.test(matrix(c(194, 171, 475,
					6,5,6,
					22,13,14,
					192,31,54), ncol = 3, byrow=T))


################################
# GO enrichment test -- 181214 #
################################

geneID2GO <- readMappings("GO_mapping.tsv")
GO2geneID <- inverseList(geneID2GO)
geneNames <- names(geneID2GO)


local_geneNames <- geneNames
MEME1_geneName <- unique(MEME_GOI$geneName[MEME_GOI$VirType == vir_lst[4]])
geneList1 <- factor(as.integer(local_geneNames %in% MEME1_geneName))
names(geneList1) <- local_geneNames
MEME2_geneName <- unique(MEME_GOI$geneName[MEME_GOI$VirType == vir_lst[1]])
geneList2 <- factor(as.integer(local_geneNames %in% MEME2_geneName))
names(geneList2) <- local_geneNames



# MF-1
GOdata_MF_1 <- new("topGOdata", ontology = "MF", allGenes = geneList1, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF_1, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF_1, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF_1 <- GenTable(GOdata_MF_1, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF_1
write.csv(allRes_MF_1, "GO_MEME_MF_dsDNA.csv", quote=F, row.names=F)
pdf("8.GO1_MF_ssDNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF_1, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# MF-2
GOdata_MF_2 <- new("topGOdata", ontology = "MF", allGenes = geneList2, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF_2, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF_2, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF_2 <- GenTable(GOdata_MF_2, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF_2
write.csv(allRes_MF_2, "GO_MEME_MF_ssRNA.csv", quote=F, row.names=F)
pdf("8.GO1_MF_ssRNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF_2, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()

# BP-1
GOdata_BP_1 <- new("topGOdata", ontology = "BP", allGenes = geneList1, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP_1, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP_1, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP_1 <- GenTable(GOdata_BP_1, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP_1
write.csv(allRes_BP_1, "GO_MEME_BP_dsDNA.csv", quote=F, row.names=F)
pdf("8.GO1_BP_ssDNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP_1, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# BP-2
GOdata_BP_2 <- new("topGOdata", ontology = "BP", allGenes = geneList2, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP_2, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP_2, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP_2 <- GenTable(GOdata_BP_2, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP_2
write.csv(allRes_BP_2, "GO_MEME_BP_ssRNA.csv", quote=F, row.names=F)
pdf("8.GO1_BP_ssRNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP_2, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()

# CC-1
GOdata_CC_1 <- new("topGOdata", ontology = "CC", allGenes = geneList1, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC_1, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC_1, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC_1 <- GenTable(GOdata_CC_1, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC_1
write.csv(allRes_CC_1, "GO_MEME_CC_dsDNA.csv", quote=F, row.names=F)
pdf("8.GO1_CC_ssDNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC_1, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# CC-2
GOdata_CC_2 <- new("topGOdata", ontology = "CC", allGenes = geneList2, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC_2, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC_2, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC_2 <- GenTable(GOdata_CC_2, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC_2
write.csv(allRes_CC_2, "GO_MEME_CC_ssRNA.csv", quote=F, row.names=F)
pdf("8.GO1_CC_ssRNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC_2, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()



# GO enrichment test: all the genes that show MEME evidence vs. the others, across all virTypes
# create lists of genes to compare
MEME_geneName <- unique(MEME_GOI$geneName)

local_geneNames <- geneNames
geneList <- factor(as.integer(local_geneNames %in% MEME_geneName))
names(geneList) <- local_geneNames
# MF
GOdata_MF <- new("topGOdata", ontology = "MF", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF <- GenTable(GOdata_MF, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF
pdf("8.GO1_MF_MEME.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# BP
GOdata_BP <- new("topGOdata", ontology = "BP", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP <- GenTable(GOdata_BP, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP
pdf("8.GO1_BP_MEME.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# CC
GOdata_CC <- new("topGOdata", ontology = "CC", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC <- GenTable(GOdata_CC, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC
pdf("8.GO1_CC_MEME.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()


# GO enrichment test: all the genes that show MEME evidence within each virType
# create lists of genes to compare
MEME1_geneName <- unique(MEME_GOI$geneName[MEME_GOI$VirType == vir_lst[1]])
local_geneNames <- unique(MEME_all_res$geneName[MEME_all_res$VirType == vir_lst[1]])
geneList <- factor(as.integer(local_geneNames %in% MEME1_geneName))
names(geneList) <- local_geneNames
# MF
GOdata_MF <- new("topGOdata", ontology = "MF", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF <- GenTable(GOdata_MF, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF
pdf("8.GO1_MF_MEME1.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# BP
GOdata_BP <- new("topGOdata", ontology = "BP", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP <- GenTable(GOdata_BP, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP
pdf("8.GO1_BP_MEME1.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# CC
GOdata_CC <- new("topGOdata", ontology = "CC", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC <- GenTable(GOdata_CC, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC
pdf("8.GO1_CC_MEME1.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()



MEME2_geneName <- unique(MEME_GOI$geneName[MEME_GOI$VirType == vir_lst[2]])
local_geneNames <- unique(MEME_all_res$geneName[MEME_all_res$VirType == vir_lst[2]])
geneList <- factor(as.integer(local_geneNames %in% MEME2_geneName))
names(geneList) <- local_geneNames
# MF
GOdata_MF <- new("topGOdata", ontology = "MF", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF <- GenTable(GOdata_MF, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF
pdf("8.GO1_MF_MEME2.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# BP
GOdata_BP <- new("topGOdata", ontology = "BP", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP <- GenTable(GOdata_BP, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP
pdf("8.GO1_BP_MEME2.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# CC
GOdata_CC <- new("topGOdata", ontology = "CC", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC <- GenTable(GOdata_CC, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC
pdf("8.GO1_CC_MEME2.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()



MEME3_geneName <- unique(MEME_GOI$geneName[MEME_GOI$VirType == vir_lst[3]])
local_geneNames <- unique(MEME_all_res$geneName[MEME_all_res$VirType == vir_lst[3]])
geneList <- factor(as.integer(local_geneNames %in% MEME3_geneName))
names(geneList) <- local_geneNames
# MF
GOdata_MF <- new("topGOdata", ontology = "MF", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF <- GenTable(GOdata_MF, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF
pdf("8.GO1_MF_MEME3.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# BP
GOdata_BP <- new("topGOdata", ontology = "BP", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP <- GenTable(GOdata_BP, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP
pdf("8.GO1_BP_MEME3.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# CC
GOdata_CC <- new("topGOdata", ontology = "CC", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC <- GenTable(GOdata_CC, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC
pdf("8.GO1_CC_MEME3.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()



MEME4_geneName <- unique(MEME_GOI$geneName[MEME_GOI$VirType == vir_lst[4]])
local_geneNames <- unique(MEME_all_res$geneName[MEME_all_res$VirType == vir_lst[4]])
geneList <- factor(as.integer(local_geneNames %in% MEME4_geneName))
names(geneList) <- local_geneNames
# MF
GOdata_MF <- new("topGOdata", ontology = "MF", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF <- GenTable(GOdata_MF, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF
pdf("8.GO1_MF_MEME4.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# BP
GOdata_BP <- new("topGOdata", ontology = "BP", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP <- GenTable(GOdata_BP, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP
pdf("8.GO1_BP_MEME4.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# CC
GOdata_CC <- new("topGOdata", ontology = "CC", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC <- GenTable(GOdata_CC, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC
pdf("8.GO1_CC_MEME4.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()


######################################################################################################
# do we have more amino acid sites under episodic diversifying selection in RNA than in DNA viruses? #
######################################################################################################
# this is really the # of episodes of diversifying selection per gene...

nb_meme_episod_per_gene <- mean_nb_meme_episod_per_gene <- prop_meme_episod_per_gene <- mean_prop_meme_episod_per_gene <- list()
nb_epi_per_gene <- nb_codon_per_gene <- list()

for(i in vir_lst){
	nb_meme_episod_per_gene[[i]] <- table(MEME_GOI[,2][MEME_GOI[,1] == i])
	mean_nb_meme_episod_per_gene[[i]] <- mean(nb_meme_episod_per_gene[[i]])
	
	gene_names <- as.numeric(names(nb_meme_episod_per_gene[[i]]))
	n_episodes <- nb_codons <- NULL
	for(j in gene_names){
		n_episodes <- c(n_episodes, as.numeric(nb_meme_episod_per_gene[[i]][names(nb_meme_episod_per_gene[[i]]) == j]))
		nb_codons  <- c(nb_codons, MEME_GOI[,4][(MEME_GOI[,1] == i) & (MEME_GOI[,2] == j)][1])
	}
	nb_epi_per_gene[[i]] <- n_episodes
	nb_codon_per_gene[[i]] <- nb_codons
}

for(i in vir_lst){
	prop_meme_episod_per_gene[[i]] <- nb_epi_per_gene[[i]] / nb_codon_per_gene[[i]]
	mean_prop_meme_episod_per_gene[[i]] <- mean(prop_meme_episod_per_gene[[i]])
}

# estimate quantiles by bootstrap
sd_prop_epi_up <- sd_prop_epi_lo <- sd_nb_epi_up <- sd_nb_epi_lo <- list()
n_boot <- 10000
boot_prop <- boot_nb <- c()
for(i in vir_lst){
	for(j in 1:n_boot){
		boot_prop[j] <- sample(prop_meme_episod_per_gene[[i]], length(prop_meme_episod_per_gene[[i]]), replace=T)
		boot_nb[j] <- sample(nb_meme_episod_per_gene[[i]], length(nb_meme_episod_per_gene[[i]]), replace=T)
	}
	sd_prop_epi_up[[i]] <- quantile(boot_prop, probs=.95)
	sd_prop_epi_lo[[i]] <- quantile(boot_prop, probs=.05)
	sd_nb_epi_up[[i]] <- quantile(boot_nb, probs=.95)
	sd_nb_epi_lo[[i]] <- quantile(boot_nb, probs=.05)
}

df3a <- data.frame(virtyp = vir_lst, prop =unlist(mean_prop_meme_episod_per_gene), up95 =unlist(sd_prop_epi_up), lo05 =unlist(sd_prop_epi_lo), Type = c("RNA", "DNA", "RNA", "DNA"))
ggplot(df3a, aes(x= vir_lst, y= prop, fill= Type)) + 
	geom_bar(stat="identity", position=position_dodge()) +
	geom_errorbar(aes(ymin= prop-lo05, ymax= prop + up95), width=.1, position=position_dodge(.9)) +
	scale_fill_brewer(palette="Reds") + 
	theme_minimal()
ggsave("8.MEME_barplot_prop.pdf", plot = last_plot(), width = 6, height = 4)

df3b <- data.frame(virtyp = vir_lst, nb =unlist(mean_nb_meme_episod_per_gene), up95 =unlist(sd_nb_epi_up), lo05 =unlist(sd_nb_epi_lo), Type = c("RNA", "DNA", "RNA", "DNA"))
ggplot(df3b, aes(x= vir_lst, y= nb, fill= Type)) + 
	geom_bar(stat="identity", position=position_dodge()) +
	geom_errorbar(aes(ymin= nb-lo05, ymax= nb + up95), width=.1, position=position_dodge(.9)) +
	scale_fill_brewer(palette="Reds") + 
	theme_minimal()
ggsave("8.MEME_barplot_nb.pdf", plot = last_plot(), width = 6, height = 4)



													#############
													# SM / MEME #
													#############

#############################################################
# Are the MEME genes also involved in correlated evolution? #
#############################################################


count_tot_meme_gene <- count_tot_sm_gene <- count_shared_meme2sm <- c()
SM_MEME_geneName <- c()
com_genes <- com_genes_names <- list()
for(i in vir_lst){
	# MEME
	all_meme_genes <- MEME_GOI[,7][MEME_GOI[,1] == i]
	meme_gene_list <- unique(all_meme_genes)
	count_tot_meme_gene[which(vir_lst == i)] <- length(meme_gene_list)
	# SM
	all_sm_genes <- SM_GOI[,6][SM_GOI[,1] == i]
	sm_gene_list <- unique(all_sm_genes)
	count_tot_sm_gene[which(vir_lst == i)] <- length(sm_gene_list)
	# intersect
	com_genes[[i]] <- intersect(meme_gene_list, sm_gene_list)
	count_shared_meme2sm[which(vir_lst == i)] <- length(com_genes[[i]])
	# http://www.dartistics.com/example3.html
	g <- draw.pairwise.venn(area1 = count_tot_meme_gene[which(vir_lst == i)],
	                   area2 = count_tot_sm_gene[which(vir_lst == i)],
	                   cross.area = count_shared_meme2sm[which(vir_lst == i)],
	                   category = c("MEME GOIs","SM GOIs"),
	                   fill = c("#F29B05","#A1D490"),
	                   ext.text = TRUE,
	                   ext.percent = c(0.1,0.1,0.1),
	                   ext.length = 0.6,
	                   label.col = rep("gray10",3),
	                   lwd = 0,
	                   cex = 1.5,
	                   fontface = rep("bold",3),
	                   fontfamily = rep("sans",3), 
	                   cat.cex = 1.25,
	                   cat.fontface = rep("plain",2),
	                   cat.fontfamily = rep("sans",2),
	                   cat.pos = c(0, 0),
	                   print.mode = c("percent","raw"), plot=F
	                   )
	pdf(paste0("8.shared_MEME_SM_", i,".pdf"), width=6, height=4)
	#par(oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
	grid.arrange(gTree(children=g), top= i)
	dev.off()
}

SM_MEME_geneName <- as.character(unlist(com_genes))

SM_MEME_geneName_dsDNA <- as.character(unlist(com_genes$dsDNA))
SM_MEME_geneName_ssRNA <- as.character(unlist(com_genes$ssRNA))

################################
# GO enrichment test -- 181214 #
################################

geneID2GO <- readMappings("GO_mapping.tsv")
GO2geneID <- inverseList(geneID2GO)
geneNames <- names(geneID2GO)


local_geneNames <- geneNames
geneList1 <- factor(as.integer(local_geneNames %in% SM_MEME_geneName_ssDNA))
names(geneList1) <- local_geneNames
geneList2 <- factor(as.integer(local_geneNames %in% SM_MEME_geneName_ssRNA))
names(geneList2) <- local_geneNames



# MF-1
GOdata_MF_1 <- new("topGOdata", ontology = "MF", allGenes = geneList1, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF_1, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF_1, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF_1 <- GenTable(GOdata_MF_1, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF_1
write.csv(allRes_MF_1, "GO_SM-MEME__MF_dsDNA.csv", quote=F, row.names=F)
pdf("8.GO1_MF_ssDNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF_1, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# MF-2
GOdata_MF_2 <- new("topGOdata", ontology = "MF", allGenes = geneList2, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF_2, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF_2, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF_2 <- GenTable(GOdata_MF_2, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF_2
write.csv(allRes_MF_2, "GO_SM-MEME__MF_ssRNA.csv", quote=F, row.names=F)
pdf("8.GO1_MF_ssRNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF_2, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()

# BP-1
GOdata_BP_1 <- new("topGOdata", ontology = "BP", allGenes = geneList1, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP_1, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP_1, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP_1 <- GenTable(GOdata_BP_1, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP_1
write.csv(allRes_BP_1, "GO_SM-MEME__BP_dsDNA.csv", quote=F, row.names=F)
pdf("8.GO1_BP_ssDNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP_1, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# BP-2
GOdata_BP_2 <- new("topGOdata", ontology = "BP", allGenes = geneList2, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP_2, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP_2, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP_2 <- GenTable(GOdata_BP_2, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP_2
write.csv(allRes_BP_2, "GO_SM-MEME__BP_ssRNA.csv", quote=F, row.names=F)
pdf("8.GO1_BP_ssRNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP_2, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()

# CC-1
GOdata_CC_1 <- new("topGOdata", ontology = "CC", allGenes = geneList1, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC_1, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC_1, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC_1 <- GenTable(GOdata_CC_1, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC_1
write.csv(allRes_CC_1, "GO_SM-MEME__CC_dsDNA.csv", quote=F, row.names=F)
pdf("8.GO1_CC_ssDNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC_1, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# CC-2
GOdata_CC_2 <- new("topGOdata", ontology = "CC", allGenes = geneList2, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC_2, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC_2, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC_2 <- GenTable(GOdata_CC_2, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC_2
write.csv(allRes_CC_2, "GO_SM-MEME__CC_ssRNA.csv", quote=F, row.names=F)
pdf("8.GO1_CC_ssRNA.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC_2, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()


# GO enrichment test: all the genes that show SM/MEME evidence vs. the others, across all virTypes
# create lists of genes to compare

local_geneNames <- geneNames
geneList <- factor(as.integer(local_geneNames %in% SM_MEME_geneName))
names(geneList) <- local_geneNames
# MF
GOdata_MF <- new("topGOdata", ontology = "MF", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF <- GenTable(GOdata_MF, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF
pdf("8.GO1_MF_SM_MEME.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# BP
GOdata_BP <- new("topGOdata", ontology = "BP", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP <- GenTable(GOdata_BP, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP
pdf("8.GO1_BP_SM_MEME.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# CC
GOdata_CC <- new("topGOdata", ontology = "CC", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC <- GenTable(GOdata_CC, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC
pdf("8.GO1_CC_SM_MEME.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()



# GO enrichment test: all the genes that show MEME evidence within each virType
# create lists of genes to compare
MEME1_geneName <- com_genes[[1]]

local_geneNames <- trans_tbl$geneName[trans_tbl$virCode == 1]
geneList <- factor(as.integer(local_geneNames %in% MEME1_geneName))
names(geneList) <- local_geneNames
# MF
GOdata_MF <- new("topGOdata", ontology = "MF", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF <- GenTable(GOdata_MF, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF
pdf("8.GO1_MF_SM_MEME1.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# BP
GOdata_BP <- new("topGOdata", ontology = "BP", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP <- GenTable(GOdata_BP, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP
pdf("8.GO1_BP_SM_MEME1.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# CC
GOdata_CC <- new("topGOdata", ontology = "CC", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC <- GenTable(GOdata_CC, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC
pdf("8.GO1_CC_SM_MEME1.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()



MEME2_geneName <- com_genes[[2]]

local_geneNames <- trans_tbl$geneName[trans_tbl$virCode == 2]
geneList <- factor(as.integer(local_geneNames %in% MEME2_geneName))
names(geneList) <- local_geneNames
# MF
GOdata_MF <- new("topGOdata", ontology = "MF", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF <- GenTable(GOdata_MF, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF
pdf("8.GO1_MF_SM_MEME2.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# BP
GOdata_BP <- new("topGOdata", ontology = "BP", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP <- GenTable(GOdata_BP, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP
pdf("8.GO1_BP_SM_MEME2.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# CC
GOdata_CC <- new("topGOdata", ontology = "CC", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC <- GenTable(GOdata_CC, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC
pdf("8.GO1_CC_SM_MEME2.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()



MEME3_geneName <- com_genes[[3]]

local_geneNames <- trans_tbl$geneName[trans_tbl$virCode == 3]
geneList <- factor(as.integer(local_geneNames %in% MEME3_geneName))
names(geneList) <- local_geneNames
# MF
GOdata_MF <- new("topGOdata", ontology = "MF", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF <- GenTable(GOdata_MF, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF
pdf("8.GO1_MF_SM_MEME3.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# BP
GOdata_BP <- new("topGOdata", ontology = "BP", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP <- GenTable(GOdata_BP, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP
pdf("8.GO1_BP_SM_MEME3.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# CC
GOdata_CC <- new("topGOdata", ontology = "CC", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC <- GenTable(GOdata_CC, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC
pdf("8.GO1_CC_SM_MEME3.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()



MEME4_geneName <- com_genes[[4]]

local_geneNames <- trans_tbl$geneName[trans_tbl$virCode == 4]
geneList <- factor(as.integer(local_geneNames %in% MEME4_geneName))
names(geneList) <- local_geneNames
# MF
GOdata_MF <- new("topGOdata", ontology = "MF", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_MF, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_MF, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_MF <- GenTable(GOdata_MF, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_MF
pdf("8.GO1_MF_SM_MEME4.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_MF, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# BP
GOdata_BP <- new("topGOdata", ontology = "BP", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_BP, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_BP, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_BP <- GenTable(GOdata_BP, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_BP
pdf("8.GO1_BP_SM_MEME4.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_BP, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()
# CC
GOdata_CC <- new("topGOdata", ontology = "CC", allGenes = geneList, annot = annFUN.gene2GO, gene2GO = geneID2GO)
resultFisher_c <- runTest(GOdata_CC, algorithm = "classic", statistic = "fisher")
resultFisher_c
resultFisher_e <- runTest(GOdata_CC, algorithm = "elim", statistic = "fisher")
resultFisher_e
allRes_CC <- GenTable(GOdata_CC, classicFisher = resultFisher_c, elimFisher = resultFisher_e, orderBy = "elimFisher", ranksOf = "classicFisher", topNodes = 10)
allRes_CC
pdf("8.GO1_CC_SM_MEME4.pdf", width=6, height=6)
par (oma = c(0,0,0,0), mar = c(4, 4, 1, 1),mfrow=c(1,1))
showSigOfNodes(GOdata_CC, score(resultFisher_c), firstSigNodes = 5, useInfo ='all')
dev.off()



#############################################################
# Are the MEME sites also involved in correlated evolution? #
#############################################################

sm_site_pp <- list()
sm_site_matching_pval <- list()
for(i in 1:length(MEME_GOI[,1])){
	cur_vir_typ <- MEME_GOI[i,1]
	cur_data_id <- MEME_GOI[i,7]
	cur_site_id <- MEME_GOI[i,5]
	cur_meme_pp <- MEME_GOI[i,6]
	sm_site_pp[[i]] <- SM_all_res[,7][(SM_all_res[,1] == cur_vir_typ) & (SM_all_res[,10] == cur_data_id) & (SM_all_res[,3] == cur_site_id | SM_all_res[,4] == cur_site_id)] 
	sm_site_matching_pval[[i]] <- cur_meme_pp
}

max_sm_site_pp <- lapply(sm_site_pp, FUN=max)
mean_sm_site_pp <- lapply(sm_site_pp, FUN=mean)


df10 <- data.frame(SM_meanPP = unlist(mean_sm_site_pp), SM_maxPP = unlist(max_sm_site_pp), MEME_log10P = -log10(unlist(sm_site_matching_pval)))
df10 <- df10[complete.cases(df10), ]
df10d <- data.frame(df10, d = densCols(df10$MEME_log10P, df10$SM_maxPP, colramp = colorRampPalette(rev(rainbow(10, end = 4/6)))))


lm1 <- lm(df10$SM_maxPP ~ df10$MEME_log10P)
summary(lm1)
lm1rob <- lmRob(df10$SM_maxPP ~ df10$MEME_log10P)
summary(lm1rob)


# https://wresch.github.io/2012/11/06/ggplot2-smoothscatter.html
# https://wahani.github.io/2015/12/smoothScatter-with-ggplot2/
# https://stats.idre.ucla.edu/r/faq/how-can-i-explore-different-smooths-in-ggplot2/
ggplot(df10d, aes(x=MEME_log10P, y=SM_maxPP)) +
	stat_density2d(aes(fill = ..density..^0.25), geom = "tile", contour = FALSE, n = 200) +
	scale_fill_continuous(low = "white", high = "dodgerblue4") +
    #geom_point(aes(MEME_log10P, SM_maxPP, col = d), size = 1) +
    geom_point(alpha = 0.9, shape = 20, col = df10d$d) +
    scale_color_identity() +
    geom_vline(xintercept = -log10(alpha), col="gray", linetype=2) +
    geom_smooth(method="rlm", col="red") +
    geom_smooth(method="lm", col="blue") +
    #geom_smooth(method = "gam", formula = y ~ s(x), size = 1, col="orange") +
    scale_y_continuous(limits = c(0.0, 1.0)) +
    theme_minimal()
ggsave("8.MEME_SM_match.pdf", plot = last_plot(), width = 8, height = 4)






###################################################
# Are the SM sites also under episodic selection? #
###################################################

meme_site_pval <- list()
meme_site_matching_pp <- list()
for(i in 1:length(SM_GOI[,1])){
	cur_vir_typ <- SM_GOI[i,1]
	cur_data_id <- SM_GOI[i,6]
	cur_site_01 <- SM_GOI[i,3]
	meme_site_pval[[i]] <- MEME_all_res[,9][(MEME_all_res[,1] == cur_vir_typ) & (MEME_all_res[,15] == cur_data_id) & (MEME_all_res[,14] == cur_site_01)]

	cur_site_02 <- SM_GOI[i,4]
	meme_site_pval[[i]] <- c(meme_site_pval[[i]], MEME_all_res[,9][(MEME_all_res[,1] == cur_vir_typ) & (MEME_all_res[,15] == cur_data_id) & (MEME_all_res[,14] == cur_site_02)]) 
	
	meme_site_matching_pp[[i]] <- SM_GOI[i,5]
}

max_meme_site_p <- lapply(meme_site_pval, FUN=max)
meme_site_match_pp <- unlist(meme_site_matching_pp)

df20 <- data.frame(MEME_log10P = -log10(unlist(max_meme_site_p)), SM_PP = meme_site_match_pp)
df20 <- df20[complete.cases(df20), ]
df20d <- data.frame(df20, d = densCols(df20$MEME_log10P, df20$SM_PP, colramp = colorRampPalette(rev(rainbow(10, end = 4/6)))))

lm2 <- lm(df20$SM_PP ~ df20$MEME_log10P)
summary(lm2)
lm2rob <- lmRob(df20$SM_PP ~ df20$MEME_log10P)
summary(lm2rob)


ggplot(df20d, aes(x=MEME_log10P, y= SM_PP)) +
	stat_density2d(aes(fill = ..density..^0.25), geom = "tile", contour = FALSE, n = 200) +
	scale_fill_continuous(low = "white", high = "dodgerblue4") +
    #geom_point(aes(MEME_log10P, SM_maxPP, col = d), size = 1) +
    geom_point(alpha = 0.9, shape = 20, col = df20d$d) +
    scale_color_identity() +
    geom_vline(xintercept = -log10(alpha), col="gray", linetype=2) +
    geom_smooth(method="rlm", col="red") +
    geom_smooth(method="lm", col="blue") +
    #geom_smooth(method = "gam", formula = y ~ s(x), size = 1, col="orange") +
    scale_y_continuous(limits = c(.95, 1.0)) +
    theme_minimal()
ggsave("8.SM_MEME_match.pdf", plot = last_plot(), width = 8, height = 4)



#####################################################################################################
# is there evidence for the opposite relationship: btw sites under neg sel and correlted evolution? #
#####################################################################################################

omega_neg <- MEME_all_res[,4] / MEME_all_res[,3] # beta- / alpha
omega_prop <- MEME_all_res[,5]

df30 <- data.frame(VirTyp = MEME_all_res[,1], Data_ID = MEME_all_res[,15], omega_n = omega_neg, omega_p = omega_prop, site = MEME_all_res[,14])
df30 <- df30[complete.cases(df30), ]

thresh_neg <- 0.25 # dN/dS for neg selection

MEME_NEG <- df30[(df30$omega_n < thresh_neg) & (df30$omega_p > .95), ]

sm_site_neg_pp <- list()
sm_site_neg_matching_pval <- list()
for(i in 1:length(MEME_NEG[,1])){
	cur_vir_typ <- MEME_NEG[i,1]
	cur_data_id <- MEME_NEG[i,2]
	cur_site_id <- MEME_NEG[i,5]
	cur_meme_pp <- MEME_NEG[i,4]
	sm_site_neg_pp[[i]] <- SM_all_res[,7][(SM_all_res[,1] == cur_vir_typ) & (SM_all_res[,10] == cur_data_id) & (SM_all_res[,3] == cur_site_id | SM_all_res[,4] == cur_site_id)] 
	sm_site_neg_matching_pval[[i]] <- cur_meme_pp
}

max_sm_site_neg_pp <- lapply(sm_site_neg_pp, FUN=max)
mean_sm_site_neg_pp <- lapply(sm_site_neg_pp, FUN=mean)


#df11 <- data.frame(SM_meanPP = unlist(mean_sm_site_neg_pp), SM_maxPP = unlist(max_sm_site_neg_pp), MEME_log10P = -log10(unlist(sm_site_neg_matching_pval)))
df11 <- data.frame(SM_meanPP = unlist(mean_sm_site_neg_pp), SM_maxPP = unlist(max_sm_site_neg_pp), MEME_log10P = (unlist(sm_site_neg_matching_pval)))
df11 <- df11[complete.cases(df11), ]
df11d <- data.frame(df11, d = densCols(df11$MEME_log10P, df11$SM_maxPP, colramp = colorRampPalette(rev(rainbow(10, end = 4/6)))))


lm3_neg <- lm(df11$SM_maxPP ~ df11$MEME_log10P)
summary(lm3_neg)
lm3_negrob <- lmRob(df11$SM_maxPP ~ df11$MEME_log10P)
summary(lm3_negrob)


# https://wresch.github.io/2012/11/06/ggplot2-smoothscatter.html
# https://wahani.github.io/2015/12/smoothScatter-with-ggplot2/
# https://stats.idre.ucla.edu/r/faq/how-can-i-explore-different-smooths-in-ggplot2/
ggplot(df11d, aes(x=MEME_log10P, y=SM_maxPP)) +
	stat_density2d(aes(fill = ..density..^0.25), geom = "tile", contour = FALSE, n = 200) +
	scale_fill_continuous(low = "white", high = "dodgerblue4") +
    #geom_point(aes(MEME_log10P, SM_maxPP, col = d), size = 1) +
    geom_point(alpha = 0.9, shape = 20, col = df11d$d) +
    scale_color_identity() +
    #geom_vline(xintercept = -log10(alpha), col="gray", linetype=2) +
    geom_smooth(method="rlm", col="red") +
    geom_smooth(method="lm", col="blue") +
    #geom_smooth(method = "gam", formula = y ~ s(x), size = 1, col="orange") +
    #scale_y_continuous(limits = c(0.0, 1.0)) +
    theme_minimal()
ggsave("8.MEME_SM_neg_match.pdf", plot = last_plot(), width = 6, height = 4)


########################
save.image("8.post_analyses.RData")
q(save="no")
########################



















