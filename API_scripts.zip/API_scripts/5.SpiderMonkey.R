# qsub -N clean_aln -q abaqus.q -l mem_free=100.0G -cwd -b y -j y ~/bin/R-3.2.3/bin/R CMD BATCH 5.SpiderMonkey.R

# just to make sure...
rm(list = ls())

# load packages
library(ape)
library(seqinr)
library(phytools)
library(Biostrings)

virtype_lst <- list.files(pattern = ".csv")
virtype_lst <- sort(virtype_lst, decreasing = T)

curdir <- getwd()
#i <- virtype_lst[1]
for(i in virtype_lst){
	virtype <- read.csv(i)
	dir_name <- sub("human_viruses_clean_", "", i)
	dir_name <- sub(".csv", "", dir_name)
	setwd(paste0(curdir, "/", dir_name))
	dir.create("_SpiderMonkey")
	nexus_files <- list.files(path="_nexus_aln_tre/", pattern = ".fas.NUC.nex")
	n_nexus_files <- length(nexus_files)

	for(j in 1:n_nexus_files){
		# run SM
		system(paste0("mkdir _SpiderMonkey/", nexus_files[j]))
		system(paste0("cp ../hyphy_SpiderMonkey.zip _SpiderMonkey/", nexus_files[j]))
		setwd(paste0(curdir, "/", dir_name, "/_SpiderMonkey/", nexus_files[j]))
		system("unzip hyphy_SpiderMonkey.zip")
		system("rm hyphy_SpiderMonkey.zip")
		setwd(paste0(curdir, "/", dir_name, "/_SpiderMonkey/", nexus_files[j]))
		system(paste0("cp ", curdir, "/", dir_name, "/_nexus_aln_tre/", nexus_files[j], " ./my_data_file.nex"))
		system("./run_bgm.sh")
		setwd(paste0(curdir, "/", dir_name))
	}
	setwd(curdir)
}


########################
#save.image("2.blastData.RData")
q(save="no")
########################





