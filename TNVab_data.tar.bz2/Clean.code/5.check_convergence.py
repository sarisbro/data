#!/usr/bin/env python3
"""
check_convergence.py
--------------------
Per-province MCMC diagnostics for BEAST runs in run1/ and run2/.

For every parameter in each *_04_final.log file (and for the combined
posterior of run1 + run2) this script reports:

    * post-burnin sample size
    * posterior mean, SD, and 95% HPD
    * effective sample size (ESS), Tracer-style initial-monotone-sequence
      autocorrelation estimator
    * Gelman-Rubin potential scale reduction R-hat across the two runs

A parameter is flagged when ESS < 200 (Tracer's standard threshold) or
when R-hat > 1.05.

Outputs:
    convergence_summary.tsv     long-format diagnostics, one row per
                                (province, parameter, run)
    convergence_flags.tsv       only the rows that failed a check
"""

from __future__ import annotations

import os
import sys
import math
from pathlib import Path

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# configuration
# ---------------------------------------------------------------------------
HERE        = Path(__file__).resolve().parent
RUN1_DIR    = HERE / "run1"
RUN2_DIR    = HERE / "run2"
CHAIN_LEN   = 100_000_000          # states per BEAST run
BURNIN      = CHAIN_LEN // 2       # 50% burnin → 50,000,000 states
ESS_FLOOR   = 200                  # Tracer's "good mixing" threshold
RHAT_CEIL   = 1.05                 # PSRF acceptance cut-off

# columns we don't want to diagnose (state index, identical-by-construction
# numbers, or quantities that are constant for this BEAST setup).
SKIP_COLS = {"state", "branchRates"}


# ---------------------------------------------------------------------------
# loading
# ---------------------------------------------------------------------------
def read_beast_log(path: Path, burnin_states: int) -> pd.DataFrame:
    """Read a BEAST .log file, drop comment lines, drop burnin by state."""
    df = pd.read_csv(path, sep="\t", comment="#")
    df = df[df["state"] >= burnin_states].reset_index(drop=True)
    return df


# ---------------------------------------------------------------------------
# ESS: initial monotone sequence estimator (Geyer 1992; used by Tracer)
# ---------------------------------------------------------------------------
def ess(x: np.ndarray) -> float:
    """Effective sample size of a 1-D MCMC trace."""
    x = np.asarray(x, dtype=float)
    n = x.size
    if n < 4 or np.all(x == x[0]):
        return float(n)

    x_centred = x - x.mean()
    var = np.dot(x_centred, x_centred) / n
    if var == 0.0:
        return float(n)

    max_lag = min(n - 1, 2000)

    # autocorrelations rho_k for k = 1 .. max_lag
    rho = np.empty(max_lag + 1)
    rho[0] = 1.0
    for k in range(1, max_lag + 1):
        rho[k] = np.dot(x_centred[:n - k], x_centred[k:]) / (n * var)

    # Geyer initial monotone sequence: pair up (rho_{2k}+rho_{2k+1}),
    # stop when the running pair sum becomes non-positive or stops decreasing.
    s = 0.0
    prev_pair = math.inf
    for k in range(0, max_lag, 2):
        if k + 1 > max_lag:
            break
        pair = rho[k] + rho[k + 1]
        if pair <= 0.0:
            break
        pair = min(pair, prev_pair)   # enforce monotone
        s += pair
        prev_pair = pair
        if k > 0 and pair < 1e-6:
            break

    tau = -1.0 + 2.0 * s              # integrated autocorrelation time
    if tau <= 0.0:
        return float(n)
    return n / tau


# ---------------------------------------------------------------------------
# 95% HPD interval
# ---------------------------------------------------------------------------
def hpd95(x: np.ndarray) -> tuple[float, float]:
    x = np.sort(np.asarray(x, dtype=float))
    n = x.size
    if n == 0:
        return (math.nan, math.nan)
    k = max(int(math.floor(0.95 * n)), 1)
    if k >= n:
        return (float(x[0]), float(x[-1]))
    widths = x[k:] - x[:n - k]
    i = int(np.argmin(widths))
    return (float(x[i]), float(x[i + k]))


# ---------------------------------------------------------------------------
# Gelman-Rubin R-hat for two equal-length chains
# ---------------------------------------------------------------------------
def rhat_two_chains(a: np.ndarray, b: np.ndarray) -> float:
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    n = min(a.size, b.size)
    if n < 4:
        return math.nan
    a, b = a[:n], b[:n]
    means = np.array([a.mean(), b.mean()])
    vars_ = np.array([a.var(ddof=1), b.var(ddof=1)])
    W = vars_.mean()
    if W == 0.0:
        return 1.0 if means[0] == means[1] else math.nan
    B = n * means.var(ddof=1)
    var_hat = (1 - 1 / n) * W + B / n
    return math.sqrt(var_hat / W)


# ---------------------------------------------------------------------------
# per-province driver
# ---------------------------------------------------------------------------
def diagnose_province(prov: str) -> list[dict]:
    log1 = RUN1_DIR / f"{prov}_04_final.log"
    log2 = RUN2_DIR / f"{prov}_04_final.log"
    if not (log1.exists() and log2.exists()):
        return []

    d1 = read_beast_log(log1, BURNIN)
    d2 = read_beast_log(log2, BURNIN)

    params = [c for c in d1.columns if c not in SKIP_COLS and c in d2.columns]
    rows: list[dict] = []

    for p in params:
        x1 = d1[p].to_numpy()
        x2 = d2[p].to_numpy()
        xC = np.concatenate([x1, x2])

        try:
            rhat = rhat_two_chains(x1, x2)
        except Exception:
            rhat = math.nan

        for run_label, x in (("run1", x1), ("run2", x2), ("combined", xC)):
            mu  = float(np.mean(x))
            sd  = float(np.std(x, ddof=1)) if x.size > 1 else math.nan
            lo, hi = hpd95(x)
            e   = ess(x)
            rows.append({
                "province": prov,
                "parameter": p,
                "run": run_label,
                "n_samples": int(x.size),
                "mean": mu,
                "sd": sd,
                "hpd95_lo": lo,
                "hpd95_hi": hi,
                "ess": e,
                "rhat_run1_vs_run2": rhat if run_label == "combined" else math.nan,
            })

    return rows


def main() -> int:
    provinces = sorted({
        p.name.split("_04_final.log")[0]
        for p in RUN1_DIR.glob("*_04_final.log")
    })
    if not provinces:
        print(f"No log files found in {RUN1_DIR}", file=sys.stderr)
        return 1

    all_rows: list[dict] = []
    for prov in provinces:
        print(f"[diagnose] {prov}", file=sys.stderr)
        all_rows.extend(diagnose_province(prov))

    df = pd.DataFrame(all_rows)
    out_long = HERE / "convergence_summary.tsv"
    df.to_csv(out_long, sep="\t", index=False, float_format="%.6g")
    print(f"wrote {out_long}", file=sys.stderr)

    # flags: low ESS, or R-hat above ceiling on the combined row
    bad_ess  = (df["ess"] < ESS_FLOOR)
    bad_rhat = (df["run"] == "combined") & (df["rhat_run1_vs_run2"] > RHAT_CEIL)
    flags = df[bad_ess | bad_rhat].copy()
    out_flags = HERE / "convergence_flags.tsv"
    flags.to_csv(out_flags, sep="\t", index=False, float_format="%.6g")
    print(f"wrote {out_flags}  ({len(flags)} flagged rows)", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
