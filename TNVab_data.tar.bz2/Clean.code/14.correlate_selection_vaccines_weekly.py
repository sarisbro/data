"""
Weekly-resolution lagged-correlation analysis of episodic-selection
events vs vaccine deployment, after partialling out a national
SARS-CoV-2 variant-of-concern (VOC) dominance covariate.

This is the (b) + (c) extension of correlate_selection_vaccines.py.
Item (a) — fetching the PHAC weekly per-province coverage time series —
could not be completed because the relevant data domains were still
egress-blocked at runtime; the script is structured so that, when a
file `phac_coverage_dose1_weekly.csv` is dropped into the working
directory, the cumulative-coverage column is used in preference to the
sparse first-dose impulse train.

Pipeline
--------
1. Build a weekly date index (Monday-anchored) covering the full
   selection-event window plus padding.
2. Per province, build:
       s_weekly     : count of strict episodic-selection events whose
                      child_date_iso falls in that week.
       v_imp_weekly : impulse train of distinct vaccine products with a
                      first-dose date in that week (per the curated
                      vaccine_timeline CSV).
       v_smooth     : v_imp_weekly convolved with a 4-week-sigma
                      Gaussian (≈one calendar month each side).
       v_cov        : weekly cumulative ≥1-dose coverage (proportion)
                      from the optional PHAC drop-in file.
3. Build a national variant-phase covariate as one-hot phase
   indicators on the same weekly grid (wildtype/B.1, alpha, delta,
   omicron BA.1, BA.2, BA.5, post-BA.5, XBB era, JN.1).
4. Partial each per-province series against phase one-hot via OLS;
   keep residuals.
5. Compute Pearson r at lags from -8 to +24 weeks (negative = vaccine
   leads selection by |lag|; positive = selection leads vaccine).
   *Convention note:* this script uses the inverse sign convention from
   the monthly run — positive lag means selection follows vaccine,
   which is the more common epidemiology reading. The figure caption
   states this explicitly.
6. Permutation null: 1,000 circular shifts of the (residualised)
   vaccine series; the 95th percentile of the resulting max-r
   distribution is plotted as a dotted threshold line.

Outputs
-------
selection_vs_vaccine_ccf_weekly.tsv     long-format per-(prov, lag) Pearson r
selection_vs_vaccine_ccf_weekly.pdf     six-panel CCF figure (publication PDF)
selection_vs_vaccine_ccf_weekly.png     preview at 180 dpi
"""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

HERE          = Path(__file__).resolve().parent
SEL_TSV       = HERE / "selection_events.tsv"
VAX_CSV       = HERE / "canadian_vaccine_timeline.csv"
# Optional drop-in files, in preference order. The CCODWG / PHAC long-form
# administration table is preferred when present.
PHAC_ADMIN    = HERE / "vaccine_administration_dose_1_pt.csv"   # ccodwg/CovidTimelineCanada
PHAC_OPTIONAL = HERE / "phac_coverage_dose1_weekly.csv"          # legacy fallback
OUT_TSV       = HERE / "selection_vs_vaccine_ccf_weekly.tsv"
OUT_PDF       = HERE / "selection_vs_vaccine_ccf_weekly.pdf"
OUT_PNG       = HERE / "selection_vs_vaccine_ccf_weekly.png"

# StatCan 2021 mid-year provincial population estimates; used only to
# render the deployment series as "weekly new dose-1 per 100k population"
# so that the figure annotation is comparable across provinces. Pearson
# CCF is scale-invariant so the *correlation* values do not depend on
# this normalisation.
PROV_POP_2021 = {
    "BC": 5_214_805, "AB": 4_442_879, "SK": 1_179_844, "MB": 1_383_765,
    "ON": 14_755_211, "QC": 8_604_495,
    "NB": 789_225, "NS": 992_055, "PE": 164_318, "NL": 522_103,
}

LAGS_WEEKS              = list(range(-8, 25))   # negative = vaccine leads
KERNEL_SIGMA_WEEKS      = 4.0
N_PERM                  = 1_000
RNG                     = np.random.default_rng(20260502)
WEEK_FREQ               = "W-MON"               # weeks anchored on Monday

# ---- variant phase schedule (national, ~50% dominance threshold) ---------
# Sources: PHAC variant updates, NCCID variant timeline, BMC Inf Dis 2024
# retrospective wastewater + clinical analysis (Springer link returned by
# our earlier search), and CIDRAP / NACI documents. Dates are nominal
# starting points; transitions take 2-4 weeks in practice.
VOC_PHASES: list[tuple[str, str]] = [
    ("B1_wildtype",   "2020-01-01"),
    ("alpha",         "2021-03-01"),
    ("delta",         "2021-07-01"),
    ("omicron_BA1",   "2021-12-15"),
    ("omicron_BA2",   "2022-03-01"),
    ("omicron_BA5",   "2022-07-01"),
    ("omicron_postBA5","2022-11-01"),
    ("XBB",           "2023-04-01"),
    ("JN1",           "2023-11-01"),
]

# ---- load -----------------------------------------------------------------

sel = pd.read_csv(SEL_TSV, sep="\t")
sel["date"] = pd.to_datetime(sel["child_date_iso"], errors="coerce")
sel = sel.dropna(subset=["date"])

vax = pd.read_csv(VAX_CSV)
vax["date"] = pd.to_datetime(vax["event_date"], errors="coerce")
vax_first = vax[
    (vax["event_type"] == "first_dose_administered_in_province")
    & vax["date"].notna()
].copy()

provinces = sorted(sel["province"].unique())   # BC, AB, SK, MB, ON, QC

# Weekly grid over the selection-event window + padding for lags
t_lo = (sel["date"].min() - pd.Timedelta(weeks=12)).to_period("W-MON").start_time
t_hi = (sel["date"].max() + pd.Timedelta(weeks=12)).to_period("W-MON").start_time
weeks = pd.date_range(t_lo, t_hi, freq=WEEK_FREQ)
print(f"Weekly grid : {weeks[0].date()} -> {weeks[-1].date()}  ({len(weeks)} weeks)")
print(f"Provinces   : {provinces}")
print(f"Lag span    : {min(LAGS_WEEKS):+d} .. {max(LAGS_WEEKS):+d} weeks "
      f"(positive = selection follows vaccine)")

# ---- variant-phase one-hot covariate ------------------------------------

phase_starts = pd.to_datetime([d for _, d in VOC_PHASES])
phase_names  = [n for n, _ in VOC_PHASES]
def phase_for(date: pd.Timestamp) -> str:
    idx = np.searchsorted(phase_starts.values, np.datetime64(date), side="right") - 1
    return phase_names[max(0, idx)]
phase_series = pd.Series([phase_for(w) for w in weeks], index=weeks, name="phase")
phase_oh     = pd.get_dummies(phase_series, prefix="phase").astype(float)
print(f"VOC phases   : {list(phase_oh.columns)}")
print("Phase distribution (weeks):")
print(phase_series.value_counts().reindex(phase_names).fillna(0).astype(int).to_string())

# ---- optional PHAC / CCODWG administration drop-in -----------------------

phac_admin_weekly = None     # DataFrame indexed by week, columns = provinces
phac_kind         = None
if PHAC_ADMIN.exists():
    raw = pd.read_csv(PHAC_ADMIN)
    raw["date"] = pd.to_datetime(raw["date"], errors="coerce")
    raw = raw.dropna(subset=["date"])
    # The ccodwg file is long-form: name, region, date, value (cumulative),
    # value_daily (newly administered that day). We aggregate value_daily
    # to weekly sums per province. Any negative daily values (rare data
    # corrections in source) are clipped to zero.
    raw["value_daily"] = raw["value_daily"].clip(lower=0)
    weekly_sum = (raw.groupby(["region",
                               pd.Grouper(key="date", freq=WEEK_FREQ)])
                     ["value_daily"].sum()
                     .unstack("region", fill_value=0))
    phac_admin_weekly = weekly_sum
    phac_kind = "PHAC dose-1 administrations / week (per-100k normalised)"
    print(f"PHAC admin drop-in detected: {PHAC_ADMIN.name}  "
          f"date range {raw['date'].min().date()} -> "
          f"{raw['date'].max().date()}, provinces = "
          f"{sorted(raw['region'].unique())}")
elif PHAC_OPTIONAL.exists():
    phac_admin_weekly = pd.read_csv(PHAC_OPTIONAL)
    phac_admin_weekly["date"] = pd.to_datetime(phac_admin_weekly["date"], errors="coerce")
    phac_kind = "PHAC coverage_dose1 (legacy drop-in)"
    print(f"Legacy PHAC drop-in detected: {PHAC_OPTIONAL.name}")
else:
    print(f"No PHAC drop-in detected; vaccine signal = "
          "Gaussian-smoothed first-dose impulse train.")

# ---- helpers --------------------------------------------------------------

def gaussian_smooth(impulse_train: np.ndarray, sigma: float) -> np.ndarray:
    grid = np.arange(len(impulse_train))
    out  = np.zeros_like(impulse_train, dtype=float)
    nz   = np.flatnonzero(impulse_train)
    for i in nz:
        out += impulse_train[i] * np.exp(-0.5 * ((grid - i) / sigma) ** 2)
    return out

def residualise(y: np.ndarray, X: np.ndarray) -> np.ndarray:
    """Return residuals of y on X (X already includes design columns).
    Uses lstsq for numerical stability with one-hot/collinear designs."""
    coef, *_ = np.linalg.lstsq(X, y, rcond=None)
    return y - X @ coef

def lagged_pearson(s: np.ndarray, v: np.ndarray, lag: int) -> float:
    """Pearson r between s[t] and v[t - lag]; positive lag => v leads s."""
    if lag >= 0:
        if lag >= len(s):
            return np.nan
        a, b = s[lag:], v[:len(v) - lag]
    else:
        L = -lag
        if L >= len(s):
            return np.nan
        a, b = s[:len(s) - L], v[L:]
    if len(a) < 12 or np.std(a) == 0 or np.std(b) == 0:
        return np.nan
    return float(np.corrcoef(a, b)[0, 1])

def perm_max_r(s: np.ndarray, v: np.ndarray, lags, n_perm: int) -> np.ndarray:
    n   = len(v)
    out = np.empty(n_perm)
    for k in range(n_perm):
        shift = RNG.integers(8, n - 8)
        v_perm = np.roll(v, shift)
        rs = [lagged_pearson(s, v_perm, lag) for lag in lags]
        out[k] = np.nanmax(rs)
    return out

# ---- per-province pipeline -----------------------------------------------

X_phase = phase_oh.values     # (W, P) one-hot national variant phase

results: dict[str, dict] = {}
ccf_rows: list[dict]     = []

for prov in provinces:
    sel_p = sel[sel["province"] == prov]
    vax_p = vax_first[vax_first["jurisdiction"] == prov]

    # Weekly selection count
    s_raw = (sel_p.set_index("date")
                  .resample(WEEK_FREQ).size()
                  .reindex(weeks, fill_value=0)
                  .values.astype(float))

    # Vaccine series (preference order: PHAC weekly admin > legacy
    # coverage drop-in > smoothed first-dose impulses)
    n_evt_used = None
    if phac_admin_weekly is not None and prov in phac_admin_weekly.columns:
        v_raw = (phac_admin_weekly[prov]
                 .reindex(weeks, fill_value=0)
                 .values.astype(float))
        # Per-100k normalisation (cosmetic only; CCF is scale-invariant)
        if prov in PROV_POP_2021:
            v_raw = v_raw / PROV_POP_2021[prov] * 100_000.0
        v_kind = "PHAC weekly new dose-1 (per 100k pop)"
    else:
        if len(vax_p):
            imp = (vax_p.set_index("date")
                         .resample(WEEK_FREQ).size()
                         .reindex(weeks, fill_value=0)
                         .values.astype(float))
        else:
            imp = np.zeros(len(weeks))
        v_raw = gaussian_smooth(imp, KERNEL_SIGMA_WEEKS)
        v_kind = f"Gaussian-smoothed first-dose impulses (sigma = {KERNEL_SIGMA_WEEKS:.0f} wk)"
        n_evt_used = int(len(vax_p))

    # Detrend each series against national variant phase one-hot
    s_resid = residualise(s_raw, X_phase)
    v_resid = residualise(v_raw, X_phase)

    # CCF on residualised series
    ccf = [lagged_pearson(s_resid, v_resid, lag) for lag in LAGS_WEEKS]

    # Permutation null
    null_max = perm_max_r(s_resid, v_resid, LAGS_WEEKS, N_PERM)
    obs_max  = float(np.nanmax(ccf))
    pval     = float((null_max >= obs_max).mean())

    best_i   = int(np.nanargmax(ccf))
    best_lag = LAGS_WEEKS[best_i]
    best_r   = ccf[best_i]

    results[prov] = dict(
        weeks=weeks, s_raw=s_raw, v_raw=v_raw,
        s_resid=s_resid, v_resid=v_resid,
        lags=LAGS_WEEKS, ccf=ccf,
        best_lag=best_lag, best_r=best_r,
        null_max=null_max, pval=pval,
        v_kind=v_kind,
        n_vaccine_events=n_evt_used,
    )

    print(f"  {prov}: best lag = {best_lag:+3d} wk  r = {best_r:+.3f}  "
          f"perm-p = {pval:.3f}   [{v_kind}]")

    for lag, r in zip(LAGS_WEEKS, ccf):
        ccf_rows.append(dict(province=prov, lag_weeks=lag, r_residualised=r))

# ---- save table -----------------------------------------------------------

ccf_df = pd.DataFrame(ccf_rows)
ccf_df.to_csv(OUT_TSV, sep="\t", index=False, float_format="%.4f")
print(f"Wrote {OUT_TSV}")

# ---- figure ---------------------------------------------------------------

fig = plt.figure(figsize=(11.5, 9.0))
gs  = fig.add_gridspec(3, 2, hspace=0.65, wspace=0.18,
                       left=0.075, right=0.97, top=0.91, bottom=0.07)
prov_axes = [fig.add_subplot(gs[i // 2, i % 2]) for i in range(6)]

for ax, prov in zip(prov_axes, provinces):
    res = results[prov]
    lags = res["lags"]

    bars = ax.bar(lags, res["ccf"], width=0.85,
                  color="#7aa6c2", edgecolor="white", linewidth=0.3)
    bars[lags.index(res["best_lag"])].set_color("#c0392b")

    null_q95 = float(np.nanpercentile(res["null_max"], 95))
    ax.axhline( null_q95, color="black", linestyle=":", linewidth=0.7,
                label=f"perm 95% (max-r null) = {null_q95:.2f}")
    ax.axhline(-null_q95, color="black", linestyle=":", linewidth=0.5,
                alpha=0.5)
    ax.axhline(0, color="gray", linewidth=0.5)
    ax.axvline(0, color="black", linewidth=0.6, linestyle="--", alpha=0.5)

    n_evt = res["n_vaccine_events"]
    n_str = f"n = {n_evt} 1st-dose events" if n_evt is not None else "PHAC weekly admin"
    ax.set_title(
        f"{prov}   best lag = {res['best_lag']:+d} wk, "
        f"r = {res['best_r']:+.2f}, perm-p = {res['pval']:.3f}   "
        f"({n_str})",
        fontsize=10, loc="left")
    ax.set_xlim(min(lags) - 0.6, max(lags) + 0.6)
    ax.set_ylim(-1, 1)
    ax.set_xlabel("Lag (weeks) — positive = selection follows vaccine deployment",
                  fontsize=8.5)
    ax.set_ylabel("Pearson r (residualised)", fontsize=8.5)
    ax.tick_params(axis="both", labelsize=8)
    ax.legend(loc="lower right", fontsize=7, frameon=False)
    for s_ in ("top", "right"):
        ax.spines[s_].set_visible(False)

src_note = ("Vaccine series: " +
            results[provinces[0]]["v_kind"] +
            "; one-hot national VOC phase covariate partialled out before CCF.")
fig.suptitle("Per-province cross-correlation, weekly resolution, "
             "after detrending against national variant-phase indicator\n"
             + src_note,
             fontsize=11, fontweight="bold", y=0.985)

fig.savefig(OUT_PDF, format="pdf", bbox_inches="tight")
fig.savefig(OUT_PNG, dpi=180, bbox_inches="tight")
print(f"Wrote {OUT_PDF}\nWrote {OUT_PNG}")
