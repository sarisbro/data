"""
Three-panel publication figure summarising episodic-selection events
dated against BEAST MAP trees.

This is the *full-spike* variant of plot_selection_events.py: Panel A
spans the entire 1,273-aa spike in one strip rather than being split
into NTD/RBD zooms. Empty province rows (NS, NL, PE) are not displayed.

Inputs:  selection_events.tsv  (one row per strict event)
Outputs: selection_events_figure_fullwidth.pdf
         selection_events_figure_fullwidth.png

Panels
------
A : codon-site recurrence map across the full spike (x = codon site
    1..1273). For every site with >=1 strict event, stack one square
    per province that hit it, coloured by province. SARS-CoV-2 spike
    domain track sits underneath. Tall columns (>=3 provinces) are
    labelled with the well-known amino-acid identity where available.
C : monthly histogram of strict events, stacked by province (shares
    x-axis with B).
B : provincial swimlane: one dot per event at child_date_iso, coloured
    by recurrent (>=2-province) site, sized by log10(EBF), with a faint
    horizontal whisker spanning the 95% HPD on the child date. NS, NL
    and PE rows are omitted (no strict events; PE's BEAST run did not
    converge).

Figure target: 9.0 in wide, portrait, vector PDF.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib import gridspec
from matplotlib.dates import DateFormatter, MonthLocator, YearLocator
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle

# -------------------------------------------------------------------- config

HERE       = Path(__file__).resolve().parent
EVENTS_TSV = HERE / "selection_events.tsv"
OUT_PDF    = HERE / "selection_events_figure_fullwidth.pdf"
OUT_PNG    = HERE / "selection_events_figure_fullwidth.png"

PROVINCE_ORDER = ["BC", "AB", "SK", "MB", "ON", "QC", "NS", "NL", "PE"]

SPIKE_LEN = 1273
SPIKE_DOMAINS = [
    ("SP",  1,    13,   "#cccccc"),
    ("NTD", 14,   305,  "#5b8db8"),
    ("RBD", 319,  541,  "#e07a5f"),
    ("FCS", 681,  685,  "#c0392b"),
    ("FP",  816,  833,  "#f4a261"),
    ("HR1", 908,  985,  "#81b29a"),
    ("HR2", 1162, 1213, "#a9a3c2"),
]

VARIANT_LINES = [
    ("Alpha (B.1.1.7)",   "2020-12-01"),
    ("Delta (B.1.617.2)", "2021-04-01"),
    ("Omicron (BA.1)",    "2021-11-26"),
]

AA_LABELS = {
    5:    "L5F",
    18:   "L18F",
    20:   "T20N",
    67:   "A67V",
    69:   "H69-",
    75:   "D75N",
    95:   "T95I",
    222:  "A222V",
    367:  "V367F",
    371:  "S371",
    452:  "L452R",
    477:  "S477N",
    484:  "E484K",
    501:  "N501Y",
    614:  "D614G",
    681:  "P681H/R",
    950:  "D950N",
    1078: "A1078V",
}

EBF_LOG_MIN, EBF_LOG_MAX = 2.0, 12.0
DOT_MIN, DOT_MAX         = 14.0, 110.0

# -------------------------------------------------------------------- load

def load_events(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path, sep="\t")
    df["child_date"]   = pd.to_datetime(df["child_date_iso"],   errors="coerce")
    df["child_HPD_lo"] = pd.to_datetime(df["child_HPD_lo_iso"], errors="coerce")
    df["child_HPD_hi"] = pd.to_datetime(df["child_HPD_hi_iso"], errors="coerce")
    ebf = df["EBF"].replace([np.inf, -np.inf], np.nan)
    df["log10_EBF"]    = np.log10(ebf.where(ebf > 0))
    df.loc[~np.isfinite(df["log10_EBF"]), "log10_EBF"] = EBF_LOG_MAX
    df["log10_EBF"]    = df["log10_EBF"].clip(EBF_LOG_MIN, EBF_LOG_MAX)
    return df

def ebf_to_size(log_ebf: pd.Series) -> pd.Series:
    frac = (log_ebf - EBF_LOG_MIN) / (EBF_LOG_MAX - EBF_LOG_MIN)
    return DOT_MIN + frac * (DOT_MAX - DOT_MIN)

# -------------------------------------------------------------------- palettes

def province_palette(provinces: list[str]) -> dict[str, str]:
    base = list(mpl.colormaps["tab10"].colors) + list(mpl.colormaps["tab20"].colors[10:])
    return {p: base[i % len(base)] for i, p in enumerate(provinces)}

def site_palette(recurrent_sites: list[int]) -> dict[int, tuple]:
    cm = mpl.colormaps["turbo"](np.linspace(0.05, 0.95, max(1, len(recurrent_sites))))
    return {s: tuple(cm[i]) for i, s in enumerate(sorted(recurrent_sites))}

# -------------------------------------------------------------------- panel A

def draw_panel_A(ax: plt.Axes, df: pd.DataFrame,
                 prov_colors: dict[str, str]) -> None:
    """Codon-site recurrence stack with spike domain track."""
    presence = (df.groupby(["codon_site_1based", "province"])
                  .size().reset_index(name="n"))
    sites_in_order = sorted(presence["codon_site_1based"].unique())
    site_height = presence.groupby("codon_site_1based")["province"].nunique()

    SQ_W = 7.0
    SQ_H = 0.85
    for site in sites_in_order:
        provs_here = sorted(
            presence.loc[presence["codon_site_1based"] == site, "province"].unique(),
            key=lambda p: PROVINCE_ORDER.index(p) if p in PROVINCE_ORDER else 99,
        )
        for k, prov in enumerate(provs_here):
            ax.add_patch(Rectangle(
                (site - SQ_W / 2, k + (1 - SQ_H) / 2), SQ_W, SQ_H,
                facecolor=prov_colors[prov],
                edgecolor="white", linewidth=0.4,
            ))

    # AA labels for tall columns (>=3 provinces)
    for site, h in site_height.items():
        if h >= 3 and site in AA_LABELS:
            ax.text(site, h + 0.2, AA_LABELS[site],
                    ha="center", va="bottom",
                    fontsize=7, fontweight="bold")

    # Domain track underneath
    track_y = -1.6
    track_h = 0.9
    ax.add_patch(Rectangle((1, track_y), SPIKE_LEN - 1, track_h,
                           facecolor="#f0f0f0", edgecolor="#888888",
                           linewidth=0.5, zorder=1))
    for name, lo, hi, col in SPIKE_DOMAINS:
        ax.add_patch(Rectangle((lo, track_y), hi - lo, track_h,
                               facecolor=col, edgecolor="black",
                               linewidth=0.4, zorder=2))
        ax.text((lo + hi) / 2, track_y + track_h / 2, name,
                ha="center", va="center", fontsize=7, color="black",
                zorder=3)

    max_h = int(site_height.max()) if len(site_height) else 1
    ax.set_xlim(0, SPIKE_LEN + 1)
    ax.set_ylim(track_y - 0.4, max_h + 1.2)
    ax.set_xlabel("Spike codon site (1-based)")
    ax.set_ylabel("Provinces hit")
    ax.set_yticks(range(0, max_h + 1))
    ax.set_yticklabels([str(i) for i in range(0, max_h + 1)])
    ax.tick_params(axis="x", labelsize=8)
    ax.tick_params(axis="y", labelsize=8)
    ax.set_title("A.  Cross-province recurrence of episodically selected codon sites",
                 loc="left", fontsize=11, fontweight="bold")
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)

    # Province legend below panel
    handles = [Line2D([0], [0], marker="s", linestyle="",
                      markerfacecolor=prov_colors[p], markeredgecolor="white",
                      markersize=8, label=p)
               for p in PROVINCE_ORDER if p in df["province"].unique()]
    ax.legend(handles=handles,
              loc="upper center",
              bbox_to_anchor=(0.5, -0.18),
              ncol=len(handles),
              frameon=False, fontsize=8, handletextpad=0.4,
              columnspacing=1.2,
              title="Province (Panels A & C)", title_fontsize=8)

# -------------------------------------------------------------------- panel C

def draw_panel_C(ax: plt.Axes, df: pd.DataFrame,
                 prov_colors: dict[str, str],
                 prov_order_present: list[str],
                 date_lo, date_hi) -> None:
    """Monthly histogram, stacked by province (NS/NL/PE excluded)."""
    df2 = df.dropna(subset=["child_date"]).copy()
    df2["month"] = df2["child_date"].dt.to_period("M").dt.to_timestamp()
    pivot = (df2.groupby(["month", "province"])
                .size()
                .unstack("province", fill_value=0))
    cols = [p for p in prov_order_present if p in pivot.columns]
    pivot = pivot[cols]

    width_days = 27
    bottom = np.zeros(len(pivot))
    for prov in cols:
        vals = pivot[prov].values
        ax.bar(pivot.index, vals, width=width_days, bottom=bottom,
               color=prov_colors[prov], edgecolor="white", linewidth=0.3,
               label=prov, align="center")
        bottom += vals

    for label, datestr in VARIANT_LINES:
        d = pd.Timestamp(datestr)
        if date_lo <= d <= date_hi:
            ax.axvline(d, color="black", linestyle=":", linewidth=0.8, alpha=0.6)

    ax.set_xlim(date_lo, date_hi)
    ax.set_ylabel("Events / month")
    ax.tick_params(axis="x", labelbottom=False)
    ax.tick_params(axis="y", labelsize=8)
    ax.set_title("C.  Monthly count of strict episodic-selection events (stacked by province)",
                 loc="left", fontsize=11, fontweight="bold")
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)

# -------------------------------------------------------------------- panel B

def draw_panel_B(ax: plt.Axes, df: pd.DataFrame,
                 site_colors: dict[int, tuple],
                 prov_order_present: list[str],
                 date_lo, date_hi) -> None:
    """Provincial swimlane (NS/NL/PE rows omitted)."""
    y_of = {p: i for i, p in enumerate(prov_order_present[::-1])}
    df_loc = df.dropna(subset=["child_date"]).copy()
    df_loc = df_loc[df_loc["province"].isin(y_of.keys())]
    df_loc["is_recurrent"] = df_loc["codon_site_1based"].isin(site_colors)

    # HPD whiskers
    for _, r in df_loc.iterrows():
        y = y_of.get(r["province"])
        if y is None:
            continue
        if pd.notna(r["child_HPD_lo"]) and pd.notna(r["child_HPD_hi"]):
            color = (site_colors[r["codon_site_1based"]]
                     if r["is_recurrent"] else "#bdbdbd")
            ax.hlines(y, r["child_HPD_lo"], r["child_HPD_hi"],
                      colors=color, alpha=0.35, linewidth=1.2,
                      zorder=2 if r["is_recurrent"] else 1)

    sing = df_loc[~df_loc["is_recurrent"]]
    rec  = df_loc[ df_loc["is_recurrent"]]

    if len(sing):
        ys = sing["province"].map(y_of)
        ok = ys.notna()
        ax.scatter(sing.loc[ok, "child_date"], ys[ok],
                   s=ebf_to_size(sing.loc[ok, "log10_EBF"]) * 0.55,
                   c="#bdbdbd", edgecolors="white", linewidths=0.2,
                   alpha=0.55, zorder=3)

    if len(rec):
        ys = rec["province"].map(y_of)
        ok = ys.notna()
        colors = rec.loc[ok, "codon_site_1based"].map(site_colors).tolist()
        ax.scatter(rec.loc[ok, "child_date"], ys[ok],
                   s=ebf_to_size(rec.loc[ok, "log10_EBF"]),
                   c=colors, edgecolors="white", linewidths=0.4,
                   alpha=0.92, zorder=4)

    n_rows = len(prov_order_present)
    for label, datestr in VARIANT_LINES:
        d = pd.Timestamp(datestr)
        if date_lo <= d <= date_hi:
            ax.axvline(d, color="black", linestyle=":", linewidth=0.8, alpha=0.6,
                       zorder=1)
            ax.text(d, n_rows - 0.3, label,
                    rotation=90, va="top", ha="right",
                    fontsize=7, color="black", alpha=0.8)

    ax.set_yticks(list(y_of.values()))
    ax.set_yticklabels(list(y_of.keys()))
    ax.set_ylim(-0.6, n_rows - 0.4)
    ax.set_xlim(date_lo, date_hi)
    ax.xaxis.set_major_locator(YearLocator())
    ax.xaxis.set_minor_locator(MonthLocator(bymonth=[1, 4, 7, 10]))
    ax.xaxis.set_major_formatter(DateFormatter("%Y"))
    ax.tick_params(axis="x", labelsize=8)
    ax.tick_params(axis="y", labelsize=9)
    ax.set_xlabel("Branch (child) date")
    ax.set_title("B.  Timing of strict episodic-selection events per province "
                 "(dot size ∝ log\u2081\u2080 EBF; whiskers = 95% HPD on child date)",
                 loc="left", fontsize=11, fontweight="bold")
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)

    legend_handles = []
    for s in sorted(site_colors):
        lab = f"site {s}" + (f" ({AA_LABELS[s]})" if s in AA_LABELS else "")
        legend_handles.append(Line2D([0], [0], marker="o", linestyle="",
                              markerfacecolor=site_colors[s],
                              markeredgecolor="white",
                              markersize=8, label=lab))
    legend_handles.append(Line2D([0], [0], marker="o", linestyle="",
                          markerfacecolor="#bdbdbd",
                          markeredgecolor="white",
                          markersize=6, label="province-private"))
    ax.legend(handles=legend_handles,
              loc="lower left",
              bbox_to_anchor=(0.0, -0.35),
              ncol=5, frameon=False, fontsize=7.5,
              handletextpad=0.3, columnspacing=0.8)

# -------------------------------------------------------------------- main

def main() -> None:
    df = load_events(EVENTS_TSV)
    if df.empty:
        raise SystemExit(f"No events found in {EVENTS_TSV}")

    site_to_n_prov = df.groupby("codon_site_1based")["province"].nunique()
    recurrent_sites = sorted(site_to_n_prov[site_to_n_prov >= 2].index.tolist())

    provinces_present_set = set(df["province"].unique())
    prov_order_present = [p for p in PROVINCE_ORDER if p in provinces_present_set]

    prov_colors = province_palette(PROVINCE_ORDER)
    site_colors = site_palette(recurrent_sites)

    d_lo = (df["child_date"].min() - pd.Timedelta(days=30)).to_pydatetime()
    d_hi = (df["child_date"].max() + pd.Timedelta(days=30)).to_pydatetime()

    fig = plt.figure(figsize=(9.0, 12.2), constrained_layout=False)
    gs = gridspec.GridSpec(
        nrows=3, ncols=1,
        height_ratios=[1.9, 1.05, 4.6],
        hspace=0.65,
        figure=fig,
        left=0.085, right=0.97, top=0.955, bottom=0.085,
    )
    axA = fig.add_subplot(gs[0, 0])
    axC = fig.add_subplot(gs[1, 0])
    axB = fig.add_subplot(gs[2, 0], sharex=axC)

    draw_panel_A(axA, df, prov_colors)
    draw_panel_C(axC, df, prov_colors, prov_order_present, d_lo, d_hi)
    draw_panel_B(axB, df, site_colors, prov_order_present, d_lo, d_hi)

    fig.suptitle("Episodic positive selection on the SARS-CoV-2 spike, "
                 "dated against per-province BEAST MAP trees",
                 fontsize=12.5, fontweight="bold", y=0.985)

    fig.savefig(OUT_PDF, format="pdf", bbox_inches="tight")
    fig.savefig(OUT_PNG, dpi=200, bbox_inches="tight")
    print(f"Wrote {OUT_PDF}")
    print(f"Wrote {OUT_PNG}")

if __name__ == "__main__":
    main()
