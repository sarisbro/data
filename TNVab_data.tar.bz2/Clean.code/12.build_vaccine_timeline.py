"""
Build a long-format CSV of Canadian COVID-19 vaccine deployment events.

Coverage scope (as agreed with the user):
  Date types     : provincial first-dose date AND coverage milestones
                   (50% / 75% one-dose) per province.
  Vaccines       : original primary series (Pfizer-BioNTech BNT162b2,
                   Moderna mRNA-1273, AstraZeneca/Covishield ChAdOx1,
                   Janssen Ad26.COV2.S, Novavax Nuvaxovid),
                   bivalent boosters (Moderna BA.1, Pfizer BA.4/5,
                   Moderna BA.4/5), and XBB.1.5 monovalent updates
                   (Pfizer, Moderna).
  Jurisdictions  : 10 provinces (BC, AB, SK, MB, ON, QC, NB, NS, PE, NL)
                   plus federal-level rows (CA) for Health Canada
                   authorizations and national milestones.

Provenance & data-quality conventions:
  - date_precision: "exact" (specific date in source), "week_of" (only
    week is documented), "approximate" (month + qualitative cue),
    "not_documented_in_search" (PHAC/covid19tracker were blocked from
    this run; row left as a placeholder so the schema is complete).
  - Each row carries a primary source URL when one was found.
"""

from __future__ import annotations

import csv
from pathlib import Path

OUT_CSV = Path(__file__).resolve().parent / "canadian_vaccine_timeline.csv"

# ---- canonical vocabulary -------------------------------------------------

PROVINCES = ["BC", "AB", "SK", "MB", "ON", "QC", "NB", "NS", "PE", "NL"]

VACCINES_PRIMARY  = ["pfizer_bnt162b2", "moderna_mrna1273",
                     "astrazeneca_covishield", "janssen", "novavax"]
VACCINES_BIVALENT = ["moderna_ba1_bivalent", "pfizer_ba45_bivalent",
                     "moderna_ba45_bivalent"]
VACCINES_XBB      = ["pfizer_xbb15", "moderna_xbb15"]

EVENT_FIRST_DOSE       = "first_dose_administered_in_province"
EVENT_FIRST_PAUSE      = "first_doses_paused_in_province"
EVENT_FED_AUTH         = "health_canada_authorization"
EVENT_SHIPMENT_ARRIVED = "shipment_arrived"
EVENT_ELIG_GENERAL     = "eligible_general_population"
EVENT_COV_50           = "coverage_50pct_one_dose"
EVENT_COV_75           = "coverage_75pct_one_dose"

# Source URL aliases for compactness
S = {
    "hc_pfizer":   "https://www.canada.ca/en/health-canada/services/drugs-health-products/covid19-industry/drugs-vaccines-treatments/authorization/list-drugs.html",
    "hc_moderna":  "https://www.canada.ca/en/health-canada/services/drugs-health-products/covid19-industry/drugs-vaccines-treatments/vaccines/moderna.html",
    "hc_astra":    "https://www.canada.ca/en/health-canada/services/drugs-health-products/covid19-industry/drugs-vaccines-treatments/vaccines/astrazeneca.html",
    "hc_janssen":  "https://www.canada.ca/en/health-canada/services/drugs-health-products/covid19-industry/drugs-vaccines-treatments/vaccines/janssen.html",
    "hc_novavax":  "https://www.canada.ca/en/health-canada/news/2022/02/health-canada-authorizes-novavaxs-nuvaxovid-covid-19-vaccine.html",
    "hc_biv_ba1":  "https://www.canada.ca/en/health-canada/news/2022/09/health-canada-authorizes-first-bivalent-covid-19-booster-for-adults-18-years-and-older.html",
    "hc_biv_ba45_pfizer": "https://www.cbc.ca/amp/1.6609699",
    "hc_biv_ba45_moderna": "https://www.canada.ca/en/public-health/services/publications/vaccines-immunization/summary-national-advisory-committee-immunization-november-3-2022-recommendations-use-moderna-spikevax-bivalent-mrna-50-mcg-covid-19-booster-vaccine-adults.html",
    "hc_xbb_pfizer": "https://www.pfizer.ca/en/media-centre/pfizer-and-biontech-receive-health-canada-authorization-for-xbb15-adapted-monovalent-covid-19-vaccine",
    "hc_xbb_naci":   "https://www.canada.ca/en/public-health/services/publications/vaccines-immunization/national-advisory-committee-immunization-addendum-guidance-use-covid-19-vaccines-fall-2023.html",
    "globe_50pct":   "https://www.theglobeandmail.com/canada/article-scientists-laud-vaccine-milestone-of-50-per-cent-of-canadians-with-one/",
    "globalnews_75": "https://globalnews.ca/news/7954768/canada-vaccine-target-covid/",
    "npr_first":     "https://www.npr.org/sections/coronavirus-live-updates/2020/12/14/946301025/canada-administers-its-1st-covid-19-vaccine-shots",
    "ns_release":    "https://news.novascotia.ca/en/2020/12/15/nova-scotia-receives-covid-19-vaccine",
    "mccarthy":      "https://www.mccarthy.ca/en/covid-19-vaccine-tracker-updates-december-4-2020-march-31-2021",
    "bc_astra":      "https://news.gov.bc.ca/releases/2021HLTH0061-000595",
    "globe_astra":   "https://www.theglobeandmail.com/canada/article-more-provinces-turn-away-from-astrazeneca-covid-19-vaccine/",
    "cbc_on_astra":  "https://www.cbc.ca/news/canada/toronto/ontario-update-astrazeneca-vaccine-1.6022545",
    "cbc_qc_astra":  "https://www.cbc.ca/news/canada/montreal/astrazeneca-vaccine-quebec-1.6025187",
    "sk_jj":         "https://www.saskatchewan.ca/government/news-and-media/2021/november/16/stick-it-to-covid-johnson--johnson-vaccinations-available-starting-november-17",
    "globalnews_biv":"https://globalnews.ca/news/9131811/covid-bivalent-omicron-booster-rollout-canada/",
    "cbc_qc_biv":    "https://cbc.ca/amp/1.6574377",
    "globalnews_xbb":"https://globalnews.ca/news/9939065/updated-covid-boosters-approved-health-canada/",
    "qc_xbb_paper":  "https://www.medrxiv.org/content/10.1101/2024.11.13.24317190v1.full",
    "kawartha_xbb":  "https://kawarthanow.com/2023/09/27/updated-moderna-covid-19-vaccine-will-soon-be-available-for-ontario-residents/",
    "cbc_xbb":       "https://www.cbc.ca/news/health/covid-vaccines-1.7313045",
    "novavax_arrived":"https://ir.novavax.com/press-releases/Novavax-Statement-on-Arrival-of-its-COVID-19-Vaccine-in-Canada",
    "qc_75":         "https://pmc.ncbi.nlm.nih.gov/articles/PMC9746470/",
}

# ---- rows -----------------------------------------------------------------

rows: list[dict] = []

def add(jurisdiction, vaccine, event_type, event_date,
        date_precision, notes, source_key):
    rows.append({
        "jurisdiction":   jurisdiction,
        "vaccine":        vaccine,
        "event_type":     event_type,
        "event_date":     event_date,
        "date_precision": date_precision,
        "notes":          notes,
        "source_url":     S.get(source_key, source_key),
    })

# ---- Health Canada federal authorizations --------------------------------
add("CA", "pfizer_bnt162b2",         EVENT_FED_AUTH, "2020-12-09", "exact",
    "First COVID-19 vaccine authorized in Canada (Comirnaty, BNT162b2)",
    "hc_pfizer")
add("CA", "moderna_mrna1273",        EVENT_FED_AUTH, "2020-12-23", "exact",
    "Spikevax mRNA-1273", "hc_moderna")
add("CA", "astrazeneca_covishield",  EVENT_FED_AUTH, "2021-02-26", "exact",
    "Vaxzevria/Covishield ChAdOx1-S", "hc_astra")
add("CA", "janssen",                 EVENT_FED_AUTH, "2021-03-05", "exact",
    "Janssen Ad26.COV2.S (single-dose)", "hc_janssen")
add("CA", "novavax",                 EVENT_FED_AUTH, "2022-02-17", "exact",
    "Nuvaxovid; first protein-subunit COVID-19 vaccine in Canada",
    "hc_novavax")
add("CA", "moderna_ba1_bivalent",    EVENT_FED_AUTH, "2022-09-01", "approximate",
    "Health Canada news release dated 2022-09; first bivalent (original + BA.1) approved for adults 18+",
    "hc_biv_ba1")
add("CA", "pfizer_ba45_bivalent",    EVENT_FED_AUTH, "2022-10-07", "exact",
    "Comirnaty BA.4/5 bivalent for ages 12+", "hc_biv_ba45_pfizer")
add("CA", "moderna_ba45_bivalent",   EVENT_FED_AUTH, "2022-11-03", "exact",
    "Spikevax 50 mcg BA.4/5 bivalent for adults 18+", "hc_biv_ba45_moderna")
add("CA", "moderna_xbb15",           EVENT_FED_AUTH, "2023-09-12", "exact",
    "NACI addendum date for XBB.1.5-containing mRNA vaccines (6 mo+); Moderna authorized first",
    "hc_xbb_naci")
add("CA", "pfizer_xbb15",            EVENT_FED_AUTH, "2023-09-28", "exact",
    "Pfizer-BioNTech XBB.1.5-adapted monovalent", "hc_xbb_pfizer")

# ---- National coverage milestones -----------------------------------------
add("CA", "all_vaccines", EVENT_COV_50, "2021-05-22", "exact",
    "50.01% of Canadian population had >=1 dose (Globe and Mail; ~20.6 M doses)",
    "globe_50pct")
add("CA", "all_vaccines", EVENT_COV_75, "2021-06-23", "exact",
    "75% partially vaccinated milestone (>=12 yr); 25,029,378 first doses",
    "globalnews_75")

# ---- Pfizer-BioNTech first dose by province ------------------------------
# All 10 provinces received their first 1,950-dose Pfizer shipment in
# the week of Dec 14, 2020 from the 14 cold-chain distribution sites.
add("ON", "pfizer_bnt162b2", EVENT_FIRST_DOSE, "2020-12-14", "exact",
    "Anita Quidangen, PSW at Toronto's Rekai Centre; first dose in Canada (tied with QC)",
    "npr_first")
add("QC", "pfizer_bnt162b2", EVENT_FIRST_DOSE, "2020-12-14", "exact",
    "Gisèle Lévesque (89), Saint-Antoine LTC, Quebec City; ~11:30 a.m.",
    "npr_first")
add("AB", "pfizer_bnt162b2", EVENT_FIRST_DOSE, "2020-12-15", "exact",
    "First Albertans vaccinated in Calgary and Edmonton (RT, ICU, LTC staff)",
    "mccarthy")
add("SK", "pfizer_bnt162b2", EVENT_FIRST_DOSE, "2020-12-15", "exact",
    "1,950 doses administered at Regina General Hospital",
    "mccarthy")
add("MB", "pfizer_bnt162b2", EVENT_FIRST_DOSE, "2020-12-15", "exact",
    "First Manitoba doses received and administered the same day",
    "mccarthy")
add("BC", "pfizer_bnt162b2", EVENT_FIRST_DOSE, "2020-12-15", "approximate",
    "First round of 4,000 doses began week of Dec 14 at two Lower Mainland sites",
    "mccarthy")
add("NS", "pfizer_bnt162b2", EVENT_FIRST_DOSE, "2020-12-16", "exact",
    "390 first doses administered to health-care workers in Halifax",
    "ns_release")
add("PE", "pfizer_bnt162b2", EVENT_FIRST_DOSE, "2020-12-16", "exact",
    "First doses administered in Charlottetown",
    "mccarthy")
add("NB", "pfizer_bnt162b2", EVENT_FIRST_DOSE, "2020-12-19", "week_of",
    "Shipment of 1,950 doses arrived during week of Dec 14, 2020; first dose date approximate",
    "mccarthy")
add("NL", "pfizer_bnt162b2", EVENT_FIRST_DOSE, "2020-12-19", "approximate",
    "972 doses administered by Dec 19, 2020 (per CMOH); first dose approx Dec 16-19",
    "mccarthy")

# ---- Moderna first dose by province --------------------------------------
# Federal authorization Dec 23, 2020; first provincial shipments arrived
# late Dec 2020 with administration generally beginning early Jan 2021.
add("AB", "moderna_mrna1273", EVENT_SHIPMENT_ARRIVED, "2020-12-29", "exact",
    "First Moderna shipment arrived in Alberta", "mccarthy")
for p in PROVINCES:
    add(p, "moderna_mrna1273", EVENT_FIRST_DOSE, "", "not_documented_in_search",
        "Moderna doses arrived in provinces late Dec 2020; first-dose dates not nailed down by web search (PHAC infobase blocked from this run)",
        "hc_moderna")

# ---- AstraZeneca/Covishield first dose by province -----------------------
# Pilot/eligible-age rollouts in March 2021; widespread first-dose pause
# starting May 11-13, 2021 after rare TTS reports.
add("ON", "astrazeneca_covishield", EVENT_FIRST_DOSE, "2021-03-10", "exact",
    "Pilot at 325 pharmacies in Toronto / Windsor / Kingston; ages 60-64",
    "globe_astra")
add("MB", "astrazeneca_covishield", EVENT_FIRST_DOSE, "2021-03-10", "approximate",
    "18,000 doses sent to 190 clinics/pharmacies; shipment received Mar 9",
    "globe_astra")
add("AB", "astrazeneca_covishield", EVENT_FIRST_DOSE, "2021-03-10", "approximate",
    "Pharmacy rollout in mid-March; later expanded to ages 40+ in April",
    "globe_astra")
add("BC", "astrazeneca_covishield", EVENT_FIRST_DOSE, "2021-03-31", "exact",
    "Lower Mainland pharmacy rollout to ages 55-65 (Wed Mar 31, 2021)",
    "bc_astra")
add("QC", "astrazeneca_covishield", EVENT_FIRST_DOSE, "2021-03-15", "approximate",
    "Mid-March 2021 rollout; minimum age dropped to 45 in late April",
    "globe_astra")
add("SK", "astrazeneca_covishield", EVENT_FIRST_DOSE, "2021-03-15", "approximate",
    "Mid-March 2021 rollout; total of 89,042 SK doses by suspension",
    "globe_astra")
add("NS", "astrazeneca_covishield", EVENT_FIRST_DOSE, "2021-03-15", "approximate",
    "Mid-March 2021 rollout (date inferred from federal cohort)",
    "globe_astra")
add("NB", "astrazeneca_covishield", EVENT_FIRST_DOSE, "", "not_documented_in_search",
    "AstraZeneca rollout in NB not specifically dated in web search",
    "globe_astra")
add("NL", "astrazeneca_covishield", EVENT_FIRST_DOSE, "", "not_documented_in_search",
    "AstraZeneca rollout in NL not specifically dated in web search",
    "globe_astra")
add("PE", "astrazeneca_covishield", EVENT_FIRST_DOSE, "", "not_documented_in_search",
    "AstraZeneca rollout in PE not specifically dated in web search",
    "globe_astra")

# AstraZeneca first-dose pauses (May 2021)
for p, d in [("ON","2021-05-11"), ("AB","2021-05-11"), ("MB","2021-05-11"),
             ("NS","2021-05-11"), ("SK","2021-05-12"), ("QC","2021-05-13")]:
    add(p, "astrazeneca_covishield", EVENT_FIRST_PAUSE, d, "exact",
        "First-dose appointments suspended after reports of rare thrombosis with thrombocytopenia (TTS); second doses continued",
        "cbc_qc_astra" if p == "QC" else "cbc_on_astra")

# ---- Janssen first dose by province --------------------------------------
# First Canadian shipment was held back in April-Aug 2021 over manufacturer
# QC concerns. Saskatchewan was the first province to actually administer.
add("SK", "janssen", EVENT_FIRST_DOSE, "2021-11-17", "exact",
    "Walk-in clinics in Regina, Saskatoon, Estevan, Prince Albert, Melfort, Swift Current, North Battleford, Lloydminster; 2,500 doses first batch",
    "sk_jj")
for p in [x for x in PROVINCES if x != "SK"]:
    add(p, "janssen", EVENT_FIRST_DOSE, "", "not_documented_in_search",
        "Janssen uptake nationally was very low; only Saskatchewan launched a publicized rollout (Nov 2021). Other provinces' first-dose dates not surfaced by web search",
        "sk_jj")

# ---- Novavax first dose by province --------------------------------------
add("CA", "novavax", EVENT_SHIPMENT_ARRIVED, "2022-03-29", "exact",
    "First Novavax doses arrived in Canada; release procedures underway",
    "novavax_arrived")
for p in PROVINCES:
    add(p, "novavax", EVENT_FIRST_DOSE, "", "not_documented_in_search",
        "Provincial Novavax first-dose dates (likely April 2022) not specifically documented in this search",
        "novavax_arrived")

# ---- Moderna BA.1 bivalent first dose by province ------------------------
add("QC", "moderna_ba1_bivalent", EVENT_FIRST_DOSE, "2022-09-08", "exact",
    "Available from noon Thursday Sep 8 in QC; first province to deploy",
    "cbc_qc_biv")
add("ON", "moderna_ba1_bivalent", EVENT_FIRST_DOSE, "2022-09-12", "exact",
    "Eligibility opened Sep 12 (vulnerable); general 18+ from Sep 26",
    "globalnews_biv")
add("BC", "moderna_ba1_bivalent", EVENT_FIRST_DOSE, "2022-09-19", "exact",
    "~517 pharmacies first; health-authority clinics started Sep 19",
    "globalnews_biv")
add("AB", "moderna_ba1_bivalent", EVENT_FIRST_DOSE, "2022-09-21", "exact",
    "Bookings & first administration began Sep 21",
    "globalnews_biv")
for p in ["SK","MB","NB","NS","PE","NL"]:
    add(p, "moderna_ba1_bivalent", EVENT_FIRST_DOSE, "", "not_documented_in_search",
        "Provincial first-dose date for Moderna BA.1 bivalent not specifically surfaced by web search",
        "globalnews_biv")

# ---- Pfizer BA.4/5 bivalent first dose by province -----------------------
for p in PROVINCES:
    add(p, "pfizer_ba45_bivalent", EVENT_FIRST_DOSE, "", "not_documented_in_search",
        "Pfizer BA.4/5 bivalent rolled out to provinces in mid-October 2022 after federal authorization Oct 7; province-specific first-dose dates not in this search",
        "hc_biv_ba45_pfizer")

# ---- Moderna BA.4/5 bivalent first dose by province ----------------------
for p in PROVINCES:
    add(p, "moderna_ba45_bivalent", EVENT_FIRST_DOSE, "", "not_documented_in_search",
        "Moderna BA.4/5 bivalent rolled out from early November 2022 after federal authorization Nov 3; province-specific first-dose dates not in this search",
        "hc_biv_ba45_moderna")

# ---- XBB.1.5 monovalent (Pfizer + Moderna) first dose by province --------
add("ON", "moderna_xbb15", EVENT_SHIPMENT_ARRIVED, "2023-09-22", "exact",
    "First Ontario shipment of Moderna XBB.1.5 vaccine",
    "kawartha_xbb")
add("ON", "moderna_xbb15", EVENT_ELIG_GENERAL, "2023-10-30", "exact",
    "General-public eligibility in Ontario from Oct 30; high-risk earlier",
    "kawartha_xbb")
add("QC", "moderna_xbb15", EVENT_FIRST_DOSE, "2023-09-29", "exact",
    "Long-term care and other congregate-living facilities from Sep 29",
    "qc_xbb_paper")
add("QC", "moderna_xbb15", EVENT_ELIG_GENERAL, "2023-10-10", "exact",
    "General population eligibility in Quebec from Oct 10",
    "qc_xbb_paper")
for p in [x for x in PROVINCES if x not in ("ON", "QC")]:
    add(p, "moderna_xbb15", EVENT_FIRST_DOSE, "2023-10", "approximate",
        "Province-specific date not surfaced by search; rollout broadly mid- to late October 2023 in alignment with influenza programme",
        "globalnews_xbb")
for p in PROVINCES:
    add(p, "pfizer_xbb15", EVENT_FIRST_DOSE, "2023-10", "approximate",
        "Pfizer XBB.1.5 authorized Sep 28, 2023; provinces deployed in October alongside Moderna",
        "hc_xbb_pfizer")

# ---- Provincial coverage milestones (50% / 75% one-dose) -----------------
# Quebec: documented in CMAJ Open / PMC paper.
add("QC", "all_vaccines", EVENT_COV_75, "2021-06-06", "exact",
    "75% of eligible Quebecers (>=12 yr) had >=1 dose by Jun 6, 2021; reached 83% by Jul 1",
    "qc_75")

# Provincial 50% / 75% one-dose dates per province were maintained on the
# PHAC Health Infobase and the third-party covid19tracker.ca; both were
# blocked by the egress proxy in this session, so per-province milestone
# dates beyond Quebec are left as placeholders for the user to fill in
# from the PHAC archive (https://health-infobase.canada.ca/covid-19/
# vaccination-coverage/) when accessed locally.
for p in PROVINCES:
    if p == "QC":
        continue
    add(p, "all_vaccines", EVENT_COV_50, "", "not_documented_in_search",
        "Per-province 50%-one-dose date is in PHAC Health Infobase historical data; that source was unreachable in this run",
        "https://health-infobase.canada.ca/covid-19/vaccination-coverage/")
for p in PROVINCES:
    if p == "QC":
        continue
    add(p, "all_vaccines", EVENT_COV_75, "", "not_documented_in_search",
        "Per-province 75%-one-dose date is in PHAC Health Infobase historical data; that source was unreachable in this run",
        "https://health-infobase.canada.ca/covid-19/vaccination-coverage/")

# ---- write ----------------------------------------------------------------

cols = ["jurisdiction", "vaccine", "event_type", "event_date",
        "date_precision", "notes", "source_url"]

with OUT_CSV.open("w", newline="", encoding="utf-8") as fh:
    w = csv.DictWriter(fh, fieldnames=cols)
    w.writeheader()
    # Sort rows by jurisdiction (CA first), then vaccine, then date.
    rows.sort(key=lambda r: (r["jurisdiction"] != "CA",
                             r["jurisdiction"],
                             r["vaccine"],
                             r["event_date"] or "9999-99-99"))
    w.writerows(rows)

print(f"Wrote {OUT_CSV}  ({len(rows)} rows)")
