#!/usr/bin/env bash
# ----------------------------------------------------------------------------
# run_combine_annotate.sh
#
# For each province with BEAST output in run1/ and run2/:
#   (1) concatenate the .log  files from both runs with logcombiner,
#       discarding the first 50% of each run as burnin (50,000,000 of
#       100,000,000 states per run);
#   (2) concatenate the .trees files from both runs with logcombiner under
#       the same burnin rule;
#   (3) summarize the combined posterior tree distribution with
#       treeannotator (MAP / MCC tree, median node heights).
#
# Provinces are processed in parallel.  Province-level work is independent,
# so the natural unit of parallelism is one province per worker.  With 9
# provinces and 16 cores everything runs concurrently; MAX_JOBS can be
# overridden from the environment if you grow the dataset later.
#
# Inspired by run_trannot.sh.
# ----------------------------------------------------------------------------

set -uo pipefail        # NB: not -e; we want to keep harvesting other
                        # provinces' results even if one fails.

# ---- configuration --------------------------------------------------------
RUN1_DIR="run1"
RUN2_DIR="run2"
OUT_DIR="combined"
LOG_DIR="${OUT_DIR}/_worker_logs"

CHAIN_LENGTH=100000000          # states per individual run
BURNIN=$(( CHAIN_LENGTH / 2 ))  # 50,000,000 states per run

# Concurrency: default to min(nproc, n_provinces, 16).  User can override:
#   MAX_JOBS=4 ./run_combine_annotate.sh
detect_cores() {
    if command -v nproc >/dev/null 2>&1;  then nproc
    elif command -v sysctl >/dev/null 2>&1; then sysctl -n hw.ncpu
    else echo 8
    fi
}

# Provinces are inferred from files actually present in run1/.
# (NB has a FASTA but no BEAST run, so it is correctly excluded.)
PROVINCES=$(
    ls "${RUN1_DIR}"/*_04_final.log 2>/dev/null \
    | xargs -n1 basename \
    | sed 's/_04_final\.log$//' \
    | sort -u
)
N_PROV=$(echo "${PROVINCES}" | wc -w | tr -d ' ')

if [[ -z "${PROVINCES}" || "${N_PROV}" -eq 0 ]]; then
    echo "ERROR: no run1/*_04_final.log files found." >&2
    exit 1
fi

CORES=$(detect_cores)
DEFAULT_JOBS=$(( CORES < N_PROV ? CORES : N_PROV ))
(( DEFAULT_JOBS > 16 )) && DEFAULT_JOBS=16
MAX_JOBS="${MAX_JOBS:-${DEFAULT_JOBS}}"

mkdir -p "${OUT_DIR}" "${LOG_DIR}"

# ---- helpers --------------------------------------------------------------
have() { command -v "$1" >/dev/null 2>&1; }

# treeannotator binary: prefer the *_big variant used in run_trannot.sh,
# fall back to plain treeannotator.
if   have treeannotator_big; then TANNOT=treeannotator_big
elif have treeannotator;     then TANNOT=treeannotator
else
    echo "ERROR: neither treeannotator_big nor treeannotator is on PATH." >&2
    exit 1
fi

if ! have logcombiner; then
    echo "ERROR: logcombiner is not on PATH." >&2
    exit 1
fi

# ---- per-province worker --------------------------------------------------
# Runs in a subshell from the dispatch loop below.  Anything written here
# goes to the worker's own log file; on failure the function returns 1 so
# the dispatcher can record the province in failed.list.
process_province() {
    local P="$1"
    local LOG1="${RUN1_DIR}/${P}_04_final.log"
    local LOG2="${RUN2_DIR}/${P}_04_final.log"
    local TRE1="${RUN1_DIR}/${P}_04_final.trees"
    local TRE2="${RUN2_DIR}/${P}_04_final.trees"
    local OUT_LOG="${OUT_DIR}/${P}_combined.log"
    local OUT_TRE="${OUT_DIR}/${P}_combined.trees"
    local OUT_MAP="${OUT_DIR}/${P}_combined.map.trees"

    set -e   # within the worker, fail fast on the first command that errors

    for F in "${LOG1}" "${LOG2}" "${TRE1}" "${TRE2}"; do
        if [[ ! -s "${F}" ]]; then
            echo "ERROR: ${F} missing or empty; cannot process ${P}." >&2
            return 1
        fi
    done

    echo "[$(date '+%F %T')]  ${P}  start"

    echo "--- combining log files (burnin = ${BURNIN} states / run) ---"
    logcombiner -burnin "${BURNIN}" "${LOG1}" "${LOG2}" "${OUT_LOG}"

    echo "--- combining tree files (burnin = ${BURNIN} states / run) ---"
    logcombiner -trees -burnin "${BURNIN}" "${TRE1}" "${TRE2}" "${OUT_TRE}"

    echo "--- summarizing MAP tree (treeannotator) ---"
    "${TANNOT}" -burnin 0 -heights mean "${OUT_TRE}" "${OUT_MAP}"

    echo "[$(date '+%F %T')]  ${P}  done"
    return 0
}

# Make the worker visible to subshells (we invoke it via `bash -c`).
export -f process_province
export RUN1_DIR RUN2_DIR OUT_DIR BURNIN TANNOT

# ---- dispatcher -----------------------------------------------------------
echo "=========================================================="
echo " run_combine_annotate.sh"
echo "   provinces : ${N_PROV} (${PROVINCES//$'\n'/ })"
echo "   cores     : ${CORES}"
echo "   parallel  : ${MAX_JOBS} concurrent provinces"
echo "   burnin    : ${BURNIN} states / run"
echo "   logs      : ${LOG_DIR}/<P>.log"
echo "=========================================================="

FAIL_FILE="${LOG_DIR}/.failed.list"
: > "${FAIL_FILE}"

# Launch a worker per province, throttled to MAX_JOBS at a time.
declare -A PID_PROV=()
for P in ${PROVINCES}; do
    # If at capacity, wait for any one running job to finish before launching the next.
    while (( $(jobs -rp | wc -l) >= MAX_JOBS )); do
        wait -n 2>/dev/null || true
    done

    (
        if ! process_province "${P}" \
                > "${LOG_DIR}/${P}.log" 2>&1
        then
            echo "${P}" >> "${FAIL_FILE}"
        fi
    ) &
    PID_PROV[$!]="${P}"
    echo "  dispatched ${P}  (pid $!)"
done

# Wait for every dispatched job to complete.
wait

# ---- summary --------------------------------------------------------------
echo
echo "=========================================================="
echo " summary"
echo "=========================================================="
N_FAIL=0
if [[ -s "${FAIL_FILE}" ]]; then
    N_FAIL=$(wc -l < "${FAIL_FILE}" | tr -d ' ')
fi
N_OK=$(( N_PROV - N_FAIL ))
echo "  succeeded : ${N_OK} / ${N_PROV}"
if (( N_FAIL > 0 )); then
    echo "  failed    : ${N_FAIL}"
    while IFS= read -r p; do
        echo "    - ${p}   (see ${LOG_DIR}/${p}.log)"
    done < "${FAIL_FILE}"
fi
echo "  outputs in ${OUT_DIR}/"

# Non-zero exit if any province failed, so the script is friendly to make /
# CI / SLURM wrappers.
exit $(( N_FAIL > 0 ? 1 : 0 ))
