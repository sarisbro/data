#!/usr/bin/env python3
"""
compare_provinces.py
--------------------
Cross-province posterior comparison from BEAST .log files.

For each province (AB, BC, MB, NL, NS, ON, PE, QC, SK) the script reads
run1/<P>_04_final.log and run2/<P>_04_final.log, discards the first 50%
of each chain as burnin, pools the remaining samples, and reports the
posterior mean and 95% HPD for the parameters that matter for a viral
molecular-clock comparison:

    clock.rate              substitutions / site / year
    treeModel.rootHeight    age of the root, in years before the youngest tip
    age(root)               calendar date of the root
    constant.popSize        coalescent Ne · generation length
    kappa                   ts/tv
    alpha                   gamma shape on rate heterogeneity
    treeLength              total tree length

Outputs:
    province_posterior_summary.tsv
    province_posterior_summary.xlsx     (formatted, with a "Diagnostics" sheet)
"""

from __future__ import annotations

import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.formatting.rule import CellIsRule


# ---------------------------------------------------------------------------
HERE       = Path(__file__).resolve().parent
RUN1_DIR   = HERE / "run1"
RUN2_DIR   = HERE / "run2"
CHAIN_LEN  = 500_000_000
BURNIN     = CHAIN_LEN // 2

PARAMS = [
    "clock.rate",
    "treeModel.rootHeight",
    "age(root)",
    "constant.popSize",
    "kappa",
    "alpha",
    "treeLength",
]

# Map province codes to readable names (handy for plots / reports).
PROVINCE_NAMES = {
    "AB": "Alberta",
    "BC": "British Columbia",
    "MB": "Manitoba",
    "NB": "New Brunswick",
    "NL": "Newfoundland & Labrador",
    "NS": "Nova Scotia",
    "ON": "Ontario",
    "PE": "Prince Edward Island",
    "QC": "Quebec",
    "SK": "Saskatchewan",
}


# ---------------------------------------------------------------------------
def hpd95(x: np.ndarray) -> tuple[float, float]:
    x = np.sort(np.asarray(x, dtype=float))
    n = x.size
    if n == 0:
        return (math.nan, math.nan)
    k = max(int(math.floor(0.95 * n)), 1)
    if k >= n:
        return (float(x[0]), float(x[-1]))
    widths = x[k:] - x[:n - k]
    i = int(np.argmin(widths))
    return (float(x[i]), float(x[i + k]))


def read_combined(prov: str) -> pd.DataFrame | None:
    log1 = RUN1_DIR / f"{prov}_04_final.log"
    log2 = RUN2_DIR / f"{prov}_04_final.log"
    if not (log1.exists() and log2.exists()):
        return None
    d1 = pd.read_csv(log1, sep="\t", comment="#")
    d2 = pd.read_csv(log2, sep="\t", comment="#")
    d1 = d1[d1["state"] >= BURNIN]
    d2 = d2[d2["state"] >= BURNIN]
    return pd.concat([d1, d2], ignore_index=True)


# ---------------------------------------------------------------------------
def build_summary() -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return (long_df, wide_df).  Wide is one row per province."""
    provinces = sorted({
        p.name.split("_04_final.log")[0]
        for p in RUN1_DIR.glob("*_04_final.log")
    })

    long_rows: list[dict] = []
    wide_rows: list[dict] = []

    for prov in provinces:
        df = read_combined(prov)
        if df is None or df.empty:
            continue
        n_seq = "NA"  # placeholder; could parse XML if needed
        wide: dict = {
            "province_code": prov,
            "province_name": PROVINCE_NAMES.get(prov, prov),
            "n_post_burnin": int(df.shape[0]),
        }
        for p in PARAMS:
            if p not in df.columns:
                continue
            x  = df[p].to_numpy(dtype=float)
            mu = float(x.mean())
            sd = float(x.std(ddof=1)) if x.size > 1 else math.nan
            lo, hi = hpd95(x)
            long_rows.append({
                "province": prov,
                "parameter": p,
                "mean": mu,
                "sd": sd,
                "hpd95_lo": lo,
                "hpd95_hi": hi,
            })
            wide[f"{p}__mean"]     = mu
            wide[f"{p}__hpd_lo"]   = lo
            wide[f"{p}__hpd_hi"]   = hi
        wide_rows.append(wide)

    return pd.DataFrame(long_rows), pd.DataFrame(wide_rows)


# ---------------------------------------------------------------------------
# xlsx writer
# ---------------------------------------------------------------------------
HDR_FONT  = Font(name="Arial", bold=True, color="FFFFFF")
HDR_FILL  = PatternFill("solid", start_color="305496")
SUB_FILL  = PatternFill("solid", start_color="D9E1F2")
THIN      = Side(style="thin", color="BFBFBF")
BOX       = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
CENTER    = Alignment(horizontal="center", vertical="center")


def _write_header(ws, headers: list[tuple[str, int]], row: int = 1) -> int:
    col = 1
    for label, span in headers:
        ws.cell(row=row, column=col, value=label).font = HDR_FONT
        ws.cell(row=row, column=col).fill = HDR_FILL
        ws.cell(row=row, column=col).alignment = CENTER
        if span > 1:
            ws.merge_cells(
                start_row=row, start_column=col,
                end_row=row,   end_column=col + span - 1,
            )
        for c in range(col, col + span):
            ws.cell(row=row, column=c).fill = HDR_FILL
        col += span
    return col - 1


def write_xlsx(long_df: pd.DataFrame, wide_df: pd.DataFrame, path: Path) -> None:
    wb = Workbook()

    # --- Sheet 1: Summary (one row per province, parameters as column groups)
    ws = wb.active
    ws.title = "Summary"

    top_headers = [("Province", 2), ("n", 1)]
    for p in PARAMS:
        top_headers.append((p, 3))
    _write_header(ws, top_headers, row=1)

    sub_labels = ["code", "name", "n"] + ["mean", "HPD lo", "HPD hi"] * len(PARAMS)
    for j, lab in enumerate(sub_labels, start=1):
        c = ws.cell(row=2, column=j, value=lab)
        c.font = Font(name="Arial", bold=True)
        c.fill = SUB_FILL
        c.alignment = CENTER
        c.border = BOX

    # body
    for i, row in enumerate(wide_df.itertuples(index=False), start=3):
        ws.cell(row=i, column=1, value=row.province_code).font = Font(name="Arial", bold=True)
        ws.cell(row=i, column=2, value=row.province_name).font = Font(name="Arial")
        ws.cell(row=i, column=3, value=row.n_post_burnin).font = Font(name="Arial")
        col = 4
        for p in PARAMS:
            for suffix in ("__mean", "__hpd_lo", "__hpd_hi"):
                key = f"{p}{suffix}"
                val = getattr(row, key, None)
                cell = ws.cell(row=i, column=col, value=val)
                cell.font = Font(name="Arial")
                if p in ("clock.rate",):
                    cell.number_format = "0.00E+00"
                elif p in ("constant.popSize", "alpha", "treeLength"):
                    cell.number_format = "0.000"
                elif p == "kappa":
                    cell.number_format = "0.000"
                elif p == "age(root)":
                    cell.number_format = "0.00"
                else:  # treeModel.rootHeight
                    cell.number_format = "0.000"
                col += 1

    # column widths
    widths = [6, 26, 8] + [12, 12, 12] * len(PARAMS)
    for j, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(j)].width = w
    ws.freeze_panes = "D3"

    # --- Sheet 2: Long format (one row per province × parameter)
    ws2 = wb.create_sheet("Long")
    headers = ["province", "parameter", "mean", "sd", "hpd95_lo", "hpd95_hi"]
    for j, h in enumerate(headers, start=1):
        c = ws2.cell(row=1, column=j, value=h)
        c.font = HDR_FONT
        c.fill = HDR_FILL
        c.alignment = CENTER
    for i, row in enumerate(long_df.itertuples(index=False), start=2):
        ws2.cell(row=i, column=1, value=row.province).font = Font(name="Arial", bold=True)
        ws2.cell(row=i, column=2, value=row.parameter).font = Font(name="Arial")
        for k, val in enumerate((row.mean, row.sd, row.hpd95_lo, row.hpd95_hi), start=3):
            cell = ws2.cell(row=i, column=k, value=float(val))
            cell.font = Font(name="Arial")
            cell.number_format = "0.0000E+00" if row.parameter == "clock.rate" else "0.0000"
    for j, w in enumerate([6, 22, 14, 14, 14, 14], start=1):
        ws2.column_dimensions[get_column_letter(j)].width = w
    ws2.freeze_panes = "A2"

    # --- Sheet 3: Diagnostics (joined from convergence_summary.tsv if present)
    diag = HERE / "convergence_summary.tsv"
    if diag.exists():
        d = pd.read_csv(diag, sep="\t")
        d = d[(d["run"] == "combined") & (d["parameter"].isin(PARAMS))].copy()
        d = d[["province", "parameter", "n_samples", "ess", "rhat_run1_vs_run2"]]
        ws3 = wb.create_sheet("Diagnostics")
        for j, h in enumerate(d.columns, start=1):
            c = ws3.cell(row=1, column=j, value=h)
            c.font = HDR_FONT
            c.fill = HDR_FILL
            c.alignment = CENTER
        for i, row in enumerate(d.itertuples(index=False), start=2):
            for k, val in enumerate(row, start=1):
                cell = ws3.cell(row=i, column=k, value=val)
                cell.font = Font(name="Arial")
                if isinstance(val, float):
                    cell.number_format = "0.000"
        # conditional formatting: red for ESS < 200, red for R-hat > 1.05
        red_fill = PatternFill("solid", start_color="F8CBAD")
        n = d.shape[0] + 1
        ws3.conditional_formatting.add(
            f"D2:D{n}",
            CellIsRule(operator="lessThan", formula=["200"], fill=red_fill),
        )
        ws3.conditional_formatting.add(
            f"E2:E{n}",
            CellIsRule(operator="greaterThan", formula=["1.05"], fill=red_fill),
        )
        for j, w in enumerate([10, 22, 12, 12, 18], start=1):
            ws3.column_dimensions[get_column_letter(j)].width = w
        ws3.freeze_panes = "A2"

    wb.save(path)


# ---------------------------------------------------------------------------
def main() -> int:
    long_df, wide_df = build_summary()
    if long_df.empty:
        print("No log files found.", file=sys.stderr)
        return 1

    out_tsv = HERE / "province_posterior_summary.tsv"
    long_df.to_csv(out_tsv, sep="\t", index=False, float_format="%.6g")
    print(f"wrote {out_tsv}", file=sys.stderr)

    out_xlsx = HERE / "province_posterior_summary.xlsx"
    write_xlsx(long_df, wide_df, out_xlsx)
    print(f"wrote {out_xlsx}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
