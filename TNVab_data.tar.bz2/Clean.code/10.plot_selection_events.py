"""
Three-panel publication figure summarising episodic-selection events
dated against BEAST MAP trees.

Inputs:  selection_events.tsv  (one row per strict event)
Outputs: selection_events_figure.pdf
         selection_events_figure.png  (screen-friendly preview)

Panels
------
A : codon-site recurrence on the spike protein.
    A.0 (overview) : compact full-spike strip showing the SP/NTD/RBD/FCS/FP/
                     HR1/HR2 domain track and a small triangle marker at every
                     cross-province (>=2-province) site, coloured by site.
                     Dashed brackets indicate the two zoom regions.
    A.1 (NTD zoom) : codons 1-310, recurrence stack (one square per province
                     hit), AA labels above each column.
    A.2 (RBD/FCS)  : codons 319-700, same encoding. This region also covers
                     site 614 (D614G) and the furin cleavage site (681).

C : monthly histogram (x = calendar date, shared with B). Stacked bar per
    month, segments coloured by province.

B : provincial swimlane (x = calendar date, y = province). Each strict event
    is one dot at child_date_iso. The 95% HPD on the child date is drawn as a
    faint horizontal whisker under the dot. Cross-province sites get distinct
    colours; province-private sites are small grey dots so the eye locks onto
    the recurrent ones. Size: log10(EBF), capped. Vertical reference lines
    mark Alpha / Delta / Omicron emergence.

    Empty province rows (NS, NL, PE) are not displayed; PE's BEAST run did not
    converge so its single suggestive event would be misleading anyway.

Figure target: 7.2 in (~183 mm, double-column journal width), portrait,
vector PDF.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib import gridspec
from matplotlib.dates import DateFormatter, MonthLocator, YearLocator
from matplotlib.lines import Line2D
from matplotlib.patches import FancyBboxPatch, Rectangle

# -------------------------------------------------------------------- config

HERE       = Path(__file__).resolve().parent
EVENTS_TSV = HERE / "selection_events.tsv"
OUT_PDF    = HERE / "selection_events_figure.pdf"
OUT_PNG    = HERE / "selection_events_figure.png"

# Province display order (canonical: west -> east).
PROVINCE_ORDER = ["BC", "AB", "SK", "MB", "ON", "QC", "NS", "NL", "PE"]

# Spike domain annotations (1-based codon coords on the 1,273-aa S protein).
SPIKE_LEN = 1273
SPIKE_DOMAINS = [
    ("SP",  1,    13,   "#cccccc"),
    ("NTD", 14,   305,  "#5b8db8"),
    ("RBD", 319,  541,  "#e07a5f"),
    ("FCS", 681,  685,  "#c0392b"),
    ("FP",  816,  833,  "#f4a261"),
    ("HR1", 908,  985,  "#81b29a"),
    ("HR2", 1162, 1213, "#a9a3c2"),
]

# Zoom regions for Panel A.1 / A.2.
ZOOM_NTD = (1,   310, "NTD zoom (codons 1–310)")
ZOOM_RBD = (319, 700, "RBD/FCS zoom (codons 319–700)")
ZOOM_REGIONS = [ZOOM_NTD, ZOOM_RBD]

# Variant emergence reference dates (approximate, calendar).
VARIANT_LINES = [
    ("Alpha (B.1.1.7)",   "2020-12-01"),
    ("Delta (B.1.617.2)", "2021-04-01"),
    ("Omicron (BA.1)",    "2021-11-26"),
]

# Hand-curated amino-acid labels for well-known spike sites.
AA_LABELS = {
    5:    "L5F",
    18:   "L18F",
    20:   "T20N",
    67:   "A67V",
    69:   "H69-",
    75:   "D75N",
    95:   "T95I",
    222:  "A222V",
    367:  "V367F",
    371:  "S371",
    452:  "L452R",
    477:  "S477N",
    484:  "E484K",
    501:  "N501Y",
    614:  "D614G",
    681:  "P681H/R",
    950:  "D950N",
    1078: "A1078V",
}

# EBF -> dot-size scaling (log10, clamped).
EBF_LOG_MIN, EBF_LOG_MAX = 2.0, 12.0
DOT_MIN, DOT_MAX         = 11.0, 80.0    # smaller for double-column layout

# Font baseline for double-column layout.
FONT_TITLE  = 9.5
FONT_LABEL  = 8.0
FONT_TICK   = 7.0
FONT_AA     = 6.0
FONT_LEGEND = 6.5
FONT_DOMAIN = 6.0

# -------------------------------------------------------------------- load

def load_events(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path, sep="\t")
    df["child_date"]   = pd.to_datetime(df["child_date_iso"],   errors="coerce")
    df["child_HPD_lo"] = pd.to_datetime(df["child_HPD_lo_iso"], errors="coerce")
    df["child_HPD_hi"] = pd.to_datetime(df["child_HPD_hi_iso"], errors="coerce")
    ebf = df["EBF"].replace([np.inf, -np.inf], np.nan)
    df["log10_EBF"]    = np.log10(ebf.where(ebf > 0))
    df.loc[~np.isfinite(df["log10_EBF"]), "log10_EBF"] = EBF_LOG_MAX
    df["log10_EBF"]    = df["log10_EBF"].clip(EBF_LOG_MIN, EBF_LOG_MAX)
    return df

def ebf_to_size(log_ebf: pd.Series) -> pd.Series:
    frac = (log_ebf - EBF_LOG_MIN) / (EBF_LOG_MAX - EBF_LOG_MIN)
    return DOT_MIN + frac * (DOT_MAX - DOT_MIN)

# -------------------------------------------------------------------- palettes

def province_palette(provinces: list[str]) -> dict[str, str]:
    base = list(mpl.colormaps["tab10"].colors) + list(mpl.colormaps["tab20"].colors[10:])
    return {p: base[i % len(base)] for i, p in enumerate(provinces)}

def site_palette(recurrent_sites: list[int]) -> dict[int, tuple]:
    cm = mpl.colormaps["turbo"](np.linspace(0.05, 0.95, max(1, len(recurrent_sites))))
    return {s: tuple(cm[i]) for i, s in enumerate(sorted(recurrent_sites))}

# -------------------------------------------------------------------- A.0

def draw_overview(ax: plt.Axes,
                  df: pd.DataFrame,
                  site_colors: dict[int, tuple]) -> None:
    """Compact full-spike strip with domain track, hot-site triangles and
    dashed brackets around the zoom regions."""
    track_y = 0.0
    track_h = 0.85
    # Background of full spike
    ax.add_patch(Rectangle((1, track_y), SPIKE_LEN - 1, track_h,
                           facecolor="#f4f4f4", edgecolor="#888888",
                           linewidth=0.5, zorder=1))
    # Domain blocks
    for name, lo, hi, col in SPIKE_DOMAINS:
        ax.add_patch(Rectangle((lo, track_y), hi - lo, track_h,
                               facecolor=col, edgecolor="black",
                               linewidth=0.4, zorder=2))
        ax.text((lo + hi) / 2, track_y + track_h / 2, name,
                ha="center", va="center",
                fontsize=FONT_DOMAIN, color="black", zorder=3)

    # Cross-province site triangles
    sites_in_zooms = {s for s in site_colors
                      if any(lo <= s <= hi for (lo, hi, _) in ZOOM_REGIONS)}
    marker_y = 1.55
    for site, color in site_colors.items():
        ax.scatter([site], [marker_y], marker="v", s=20, color=color,
                   edgecolor="white", linewidth=0.4, zorder=4)
        # Label only sites that fall OUTSIDE both zoom regions, to avoid
        # duplicate labelling. The zoomed sites get full AA labels below.
        if site not in sites_in_zooms:
            txt = (f"{site}\n{AA_LABELS[site]}"
                   if site in AA_LABELS else str(site))
            ax.text(site, marker_y + 0.18, txt,
                    ha="center", va="bottom",
                    fontsize=FONT_AA, fontweight="bold")

    # Dashed brackets around zoom regions
    bracket_y0 = -0.05
    bracket_h  = track_h + 0.10
    for lo, hi, _name in ZOOM_REGIONS:
        ax.add_patch(Rectangle((lo, bracket_y0), hi - lo, bracket_h,
                               facecolor="none", edgecolor="black",
                               linewidth=0.9, linestyle=(0, (3, 2)),
                               zorder=5))

    ax.set_xlim(0, SPIKE_LEN + 1)
    ax.set_ylim(-0.15, 2.6)
    ax.set_yticks([])
    ax.set_xlabel("Spike codon site", fontsize=FONT_LABEL)
    ax.tick_params(axis="x", labelsize=FONT_TICK)
    for s in ("top", "right", "left"):
        ax.spines[s].set_visible(False)
    ax.set_title("A.  Cross-province recurrence of episodically selected "
                 "codon sites on the SARS-CoV-2 spike",
                 loc="left", fontsize=FONT_TITLE, fontweight="bold")

# -------------------------------------------------------------------- A.1/A.2

def draw_zoom(ax: plt.Axes,
              df: pd.DataFrame,
              prov_colors: dict[str, str],
              xmin: int, xmax: int, title: str,
              show_ylabel: bool = True) -> None:
    """Recurrence-stack zoom for codons in [xmin, xmax].

    Markers are drawn with ``ax.scatter`` so their on-page size is set in
    points (display space), not codon units; this keeps closely-spaced
    sites (e.g., 18 vs 20 in the NTD zoom, or 367 vs 371 in the RBD
    zoom) visible as separate stacks rather than collapsing into a
    single fat column.
    """
    presence = (df.groupby(["codon_site_1based", "province"])
                  .size()
                  .reset_index(name="n"))
    presence = presence[(presence["codon_site_1based"] >= xmin)
                      & (presence["codon_site_1based"] <= xmax)]
    sites_in_order = sorted(presence["codon_site_1based"].unique())
    site_height = (presence.groupby("codon_site_1based")["province"].nunique()
                   if len(presence) else pd.Series(dtype=int))

    # Display-space square markers (s in pt^2). ~4.4 pt side at this size,
    # so two sites 2 codons apart still resolve as adjacent squares.
    MARKER_S = 22
    xs, ys, cs = [], [], []
    for site in sites_in_order:
        provs_here = sorted(
            presence.loc[presence["codon_site_1based"] == site,
                         "province"].unique(),
            key=lambda p: PROVINCE_ORDER.index(p) if p in PROVINCE_ORDER else 99,
        )
        for k, prov in enumerate(provs_here):
            xs.append(site)
            ys.append(k + 0.5)
            cs.append(prov_colors[prov])
    if xs:
        ax.scatter(xs, ys, marker="s", s=MARKER_S,
                   c=cs, edgecolors="white", linewidths=0.45,
                   zorder=3)

    # AA labels above each labelled column. Drawn rotated 55° so each
    # label occupies its own diagonal channel and clusters of nearby
    # sites (e.g., 18/20 in the NTD or 367/371 in the RBD) remain
    # individually legible.
    labelled = [s for s in sites_in_order if s in AA_LABELS]
    for s in labelled:
        h = site_height[s]
        ax.text(s, h + 0.30, AA_LABELS[s],
                ha="left", va="bottom",
                rotation=55, rotation_mode="anchor",
                fontsize=FONT_AA, fontweight="bold")

    # Domain track underneath, restricted to [xmin, xmax]
    track_y = -1.25
    track_h = 0.85
    ax.add_patch(Rectangle((xmin, track_y), xmax - xmin, track_h,
                           facecolor="#f4f4f4", edgecolor="#888888",
                           linewidth=0.5, zorder=1))
    for name, lo, hi, col in SPIKE_DOMAINS:
        if hi < xmin or lo > xmax:
            continue
        lo_c, hi_c = max(lo, xmin), min(hi, xmax)
        ax.add_patch(Rectangle((lo_c, track_y), hi_c - lo_c, track_h,
                               facecolor=col, edgecolor="black",
                               linewidth=0.4, zorder=2))
        if (hi_c - lo_c) >= 25:    # only label wide enough domains
            ax.text((lo_c + hi_c) / 2, track_y + track_h / 2, name,
                    ha="center", va="center",
                    fontsize=FONT_DOMAIN, color="black", zorder=3)

    max_h = int(site_height.max()) if len(site_height) else 1
    ax.set_xlim(xmin, xmax)
    # Extra y-headroom for the diagonally-rotated AA labels.
    ax.set_ylim(track_y - 0.4, max_h + 2.4)
    ax.set_xlabel("Codon site", fontsize=FONT_LABEL)
    if show_ylabel:
        ax.set_ylabel("Provinces hit", fontsize=FONT_LABEL)
    ax.set_yticks(range(0, max_h + 1))
    ax.set_yticklabels([str(i) for i in range(0, max_h + 1)])
    ax.tick_params(axis="x", labelsize=FONT_TICK)
    ax.tick_params(axis="y", labelsize=FONT_TICK)
    ax.set_title(title, loc="left", fontsize=FONT_TITLE - 1, fontweight="bold")
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)

# -------------------------------------------------------------------- C

def draw_panel_C(ax: plt.Axes, df: pd.DataFrame,
                 prov_colors: dict[str, str],
                 prov_order_present: list[str],
                 date_lo, date_hi) -> None:
    """Monthly histogram, stacked by province."""
    df2 = df.dropna(subset=["child_date"]).copy()
    df2["month"] = df2["child_date"].dt.to_period("M").dt.to_timestamp()
    pivot = (df2.groupby(["month", "province"])
                .size()
                .unstack("province", fill_value=0))
    cols = [p for p in prov_order_present if p in pivot.columns]
    pivot = pivot[cols]

    width_days = 27
    bottom = np.zeros(len(pivot))
    for prov in cols:
        vals = pivot[prov].values
        ax.bar(pivot.index, vals, width=width_days, bottom=bottom,
               color=prov_colors[prov], edgecolor="white", linewidth=0.3,
               label=prov, align="center")
        bottom += vals

    for label, datestr in VARIANT_LINES:
        d = pd.Timestamp(datestr)
        if date_lo <= d <= date_hi:
            ax.axvline(d, color="black", linestyle=":", linewidth=0.7,
                       alpha=0.6)

    ax.set_xlim(date_lo, date_hi)
    ax.set_ylabel("Events / month", fontsize=FONT_LABEL)
    ax.tick_params(axis="x", labelbottom=False)
    ax.tick_params(axis="y", labelsize=FONT_TICK)
    ax.set_title("C.  Monthly count of strict episodic-selection events "
                 "(stacked by province)",
                 loc="left", fontsize=FONT_TITLE, fontweight="bold")
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)

# -------------------------------------------------------------------- B

def draw_panel_B(ax: plt.Axes, df: pd.DataFrame,
                 site_colors: dict[int, tuple],
                 prov_order_present: list[str],
                 date_lo, date_hi) -> None:
    """Provincial swimlane: one dot per event, coloured by recurrent site."""
    y_of = {p: i for i, p in enumerate(prov_order_present[::-1])}
    df_loc = df.dropna(subset=["child_date"]).copy()
    df_loc = df_loc[df_loc["province"].isin(y_of.keys())]
    df_loc["is_recurrent"] = df_loc["codon_site_1based"].isin(site_colors)

    # HPD whiskers
    for _, r in df_loc.iterrows():
        y = y_of.get(r["province"])
        if y is None:
            continue
        if pd.notna(r["child_HPD_lo"]) and pd.notna(r["child_HPD_hi"]):
            color = (site_colors[r["codon_site_1based"]]
                     if r["is_recurrent"] else "#bdbdbd")
            ax.hlines(y, r["child_HPD_lo"], r["child_HPD_hi"],
                      colors=color, alpha=0.35, linewidth=1.0,
                      zorder=2 if r["is_recurrent"] else 1)

    # Dots: singletons (grey) under recurrent (coloured)
    sing = df_loc[~df_loc["is_recurrent"]]
    rec  = df_loc[ df_loc["is_recurrent"]]

    if len(sing):
        ys = sing["province"].map(y_of)
        ok = ys.notna()
        ax.scatter(sing.loc[ok, "child_date"], ys[ok],
                   s=ebf_to_size(sing.loc[ok, "log10_EBF"]) * 0.55,
                   c="#bdbdbd", edgecolors="white", linewidths=0.2,
                   alpha=0.55, zorder=3)

    if len(rec):
        ys = rec["province"].map(y_of)
        ok = ys.notna()
        colors = rec.loc[ok, "codon_site_1based"].map(site_colors).tolist()
        ax.scatter(rec.loc[ok, "child_date"], ys[ok],
                   s=ebf_to_size(rec.loc[ok, "log10_EBF"]),
                   c=colors, edgecolors="white", linewidths=0.4,
                   alpha=0.92, zorder=4)

    # Variant emergence lines + top labels
    n_rows = len(prov_order_present)
    for label, datestr in VARIANT_LINES:
        d = pd.Timestamp(datestr)
        if date_lo <= d <= date_hi:
            ax.axvline(d, color="black", linestyle=":", linewidth=0.7,
                       alpha=0.6, zorder=1)
            ax.text(d, n_rows - 0.35, label,
                    rotation=90, va="top", ha="right",
                    fontsize=FONT_AA + 0.5, color="black", alpha=0.85)

    ax.set_yticks(list(y_of.values()))
    ax.set_yticklabels(list(y_of.keys()))
    ax.set_ylim(-0.6, n_rows - 0.4)
    ax.set_xlim(date_lo, date_hi)
    ax.xaxis.set_major_locator(YearLocator())
    ax.xaxis.set_minor_locator(MonthLocator(bymonth=[1, 4, 7, 10]))
    ax.xaxis.set_major_formatter(DateFormatter("%Y"))
    ax.tick_params(axis="x", labelsize=FONT_TICK)
    ax.tick_params(axis="y", labelsize=FONT_TICK + 0.5)
    ax.set_xlabel("Branch (child) date", fontsize=FONT_LABEL)
    ax.set_title("B.  Timing of strict episodic-selection events per "
                 "province (dot size ∝ log\u2081\u2080 EBF; whiskers = 95% "
                 "HPD on child date)",
                 loc="left", fontsize=FONT_TITLE, fontweight="bold")
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)

    # Site legend (recurrent sites + private)
    legend_handles = []
    for s in sorted(site_colors):
        lab = f"site {s}" + (f" ({AA_LABELS[s]})" if s in AA_LABELS else "")
        legend_handles.append(Line2D([0], [0], marker="o", linestyle="",
                              markerfacecolor=site_colors[s],
                              markeredgecolor="white",
                              markersize=7, label=lab))
    legend_handles.append(Line2D([0], [0], marker="o", linestyle="",
                          markerfacecolor="#bdbdbd",
                          markeredgecolor="white",
                          markersize=5, label="province-private"))
    ax.legend(handles=legend_handles,
              loc="upper left",
              bbox_to_anchor=(0.0, -0.18),
              ncol=4, frameon=False, fontsize=FONT_LEGEND,
              handletextpad=0.3, columnspacing=0.8,
              title="Cross-province sites (Panels A & B)",
              title_fontsize=FONT_LEGEND)

# -------------------------------------------------------------------- main

def main() -> None:
    df = load_events(EVENTS_TSV)
    if df.empty:
        raise SystemExit(f"No events found in {EVENTS_TSV}")

    # Recurrent sites = >=2 provinces in the strict set.
    site_to_n_prov = df.groupby("codon_site_1based")["province"].nunique()
    recurrent_sites = sorted(site_to_n_prov[site_to_n_prov >= 2].index.tolist())

    # Provinces actually present with strict events; preserve canonical order.
    provinces_present_set = set(df["province"].unique())
    prov_order_present = [p for p in PROVINCE_ORDER if p in provinces_present_set]

    prov_colors = province_palette(PROVINCE_ORDER)
    site_colors = site_palette(recurrent_sites)

    # X-range for time panels: month-padded around the data
    d_lo = (df["child_date"].min() - pd.Timedelta(days=30)).to_pydatetime()
    d_hi = (df["child_date"].max() + pd.Timedelta(days=30)).to_pydatetime()

    # ---- figure layout: double-column journal width
    fig = plt.figure(figsize=(7.2, 9.6), constrained_layout=False)
    gs = gridspec.GridSpec(
        nrows=4, ncols=1,
        height_ratios=[0.85, 1.95, 1.05, 3.55],
        hspace=0.85,
        figure=fig,
        left=0.085, right=0.97, top=0.945, bottom=0.115,
    )
    gs_zoom = gs[1].subgridspec(
        nrows=1, ncols=2,
        wspace=0.22,
        # NTD width 309 codons, RBD/FCS 381 codons -> use those ratios
        width_ratios=[ZOOM_NTD[1] - ZOOM_NTD[0],
                      ZOOM_RBD[1] - ZOOM_RBD[0]],
    )
    ax_overview = fig.add_subplot(gs[0, 0])
    ax_NTD      = fig.add_subplot(gs_zoom[0, 0])
    ax_RBD      = fig.add_subplot(gs_zoom[0, 1])
    ax_C        = fig.add_subplot(gs[2, 0])
    ax_B        = fig.add_subplot(gs[3, 0], sharex=ax_C)

    draw_overview(ax_overview, df, site_colors)
    draw_zoom(ax_NTD, df, prov_colors,
              xmin=ZOOM_NTD[0], xmax=ZOOM_NTD[1],
              title=f"A.1  {ZOOM_NTD[2]}", show_ylabel=True)
    draw_zoom(ax_RBD, df, prov_colors,
              xmin=ZOOM_RBD[0], xmax=ZOOM_RBD[1],
              title=f"A.2  {ZOOM_RBD[2]}", show_ylabel=False)

    draw_panel_C(ax_C, df, prov_colors, prov_order_present, d_lo, d_hi)
    draw_panel_B(ax_B, df, site_colors, prov_order_present, d_lo, d_hi)

    # Province legend (Panels A.zoom + C) placed between zooms and Panel C
    prov_handles = [Line2D([0], [0], marker="s", linestyle="",
                           markerfacecolor=prov_colors[p],
                           markeredgecolor="white",
                           markersize=7, label=p)
                    for p in prov_order_present]
    fig.legend(handles=prov_handles,
               loc="center",
               bbox_to_anchor=(0.5, 0.482),
               ncol=len(prov_handles),
               frameon=False, fontsize=FONT_LEGEND,
               handletextpad=0.4, columnspacing=1.2,
               title="Province (Panels A.1/A.2 & C)",
               title_fontsize=FONT_LEGEND)

    fig.suptitle("Episodic positive selection on the SARS-CoV-2 spike, "
                 "dated against per-province BEAST MAP trees",
                 fontsize=FONT_TITLE + 1.5, fontweight="bold", y=0.985)

    fig.savefig(OUT_PDF, format="pdf", bbox_inches="tight")
    fig.savefig(OUT_PNG, dpi=220, bbox_inches="tight")
    print(f"Wrote {OUT_PDF}")
    print(f"Wrote {OUT_PNG}")

if __name__ == "__main__":
    main()
