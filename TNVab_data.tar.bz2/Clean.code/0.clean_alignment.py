from numba import njit
import numpy as np
from needletail import parse_fastx_file
import sys
from time import perf_counter

#convert 2D array of str to 2D array of int (faster computations with numpy and numba)
#0= nucleotide
#1= ambiguous
#2= gap
def encode_msa(msa):

    nt_map = {b'a':0, b'c':0, b'g':0, b't':0, b'u':0, b'n':1, b'-':2, b'.':1, b'r':1,
     b'y':1, b's':1, b'w':1, b'k':1, b'm':1, b'b':1, b'd':1, b'h':1, b'v':1}
    vfunc = np.vectorize(lambda x: nt_map[x.encode()])
    return vfunc(msa)

@njit
def compute_resoverlap(seq, nt, undet, gaps, total_seq):
    
    resoverlap=[]
    #for each position in the sequence compute the overlap
    for i, current_nt in enumerate(seq):

        if current_nt==0:
            resoverlap.append(nt[i]/total_seq)
        
        elif current_nt==1:
            resoverlap.append(undet[i]/total_seq)
        
        else:
            resoverlap.append(gaps[i]/total_seq)
    
    return resoverlap

@njit
def keep_sequence(seq, res_threshold, seq_threshold):
    
    #array of bool with True if seq[i] > threshold
    res_over_thresh = (seq > res_threshold)
    
    #counts number of True and divide by length of sequence
    percent_good_res= np.count_nonzero(res_over_thresh)/len(seq)

    #return True if sequence is good and False otherwise
    if percent_good_res > seq_threshold:
        return True
    
    else:
        return False


file= sys.argv[1]
file_to_save= sys.argv[2]
#threshold to be considered a good residue [0-1]
res_threshold= float(sys.argv[3])
#threshold to be considered a good sequence [0-1]
seq_threshold= float(sys.argv[4])

#parse fasta file
records= parse_fastx_file(file)

#convert MSA into a 2D numpy array
sequences= np.array([list(record.seq.lower()) for record in records])
sequences= encode_msa(sequences)

nt= []
undet= []
gaps= []
total= sequences.shape[0]

#for each column of the MSA count the number of nt, undetermined and gaps
for i in range(sequences.shape[1]):

    bool_nt= (sequences[:,i]==0)
    nt.append(np.count_nonzero(bool_nt))

    bool_undet= (sequences[:,i]==1)
    undet.append(np.count_nonzero(bool_undet))

    bool_gaps= (sequences[:,i]==2)
    gaps.append(np.count_nonzero(bool_gaps))

#convert to np arrays for numba
nt= np.array(nt)
undet= np.array(undet)
gaps= np.array(gaps)

sequences_resoverlap=[]

#for each sequence compute the overlap of each position
for seq in sequences:
    resoverlap= compute_resoverlap(seq, nt, undet, gaps, total)
    sequences_resoverlap.append(resoverlap)

#for each sequence check if the fraction of good position is above threshold 
seq_to_keep= []
for seq in sequences_resoverlap:
    
    seq_to_keep.append(keep_sequence(np.array(seq), res_threshold, seq_threshold))

# write sequences above threshold to a new file
with open(file_to_save,'w') as f:
    for i, record in enumerate(parse_fastx_file(file)):
        if seq_to_keep[i]:
            f.write(f">{record.id}\n")
            f.write(f"{record.seq}\n")
        




