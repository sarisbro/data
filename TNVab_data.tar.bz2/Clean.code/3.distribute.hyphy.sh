# To run all analyses:
  cd /Users/admin/Desktop/_tmp.work_/260312/province_fastas && bash run_hyphy.sh
  # or on a SLURM cluster:
  # cd /Users/admin/Desktop/_tmp.work_/260312/province_fastas
  # for bf in *_meme.bf *_busted.bf; do
  #   sbatch --wrap="hyphy $bf"
  # done
