#!/usr/bin/env python3
"""
date_selection_events.py
------------------------
Combine HyPhy MEME / BUSTED output (province_fastas/*) with the
time-calibrated MAP trees from BEAST (clock_analyses/combined/*) to
date episodes of episodic positive selection on the SARS-CoV-2 spike
gene per Canadian province.

Pipeline (per province):
  1. Read the BEAST MCC/MAP tree, extract per-node calendar dates and
     95% HPDs (heights are converted to dates relative to the youngest
     tip date parsed from tip names).
  2. Read MEME JSON: per-site mixture weights (prior on the positive
     omega class) and per-branch posterior probabilities.  Compute the
     Empirical Bayes Factor (EBF) for every (site, branch) pair:
            EBF = (post / (1 - post))  /  (prior / (1 - prior))
  3. Read BUSTED JSON: gene-wide LRT p-value.
  4. Match HyPhy branches to BEAST branches by *tip set* (the set of
     leaves descending from a branch is invariant under topology
     rearrangements that preserve clades).  HyPhy normalises hyphens to
     underscores in tip names; BEAST uses the original.  We compare
     tips after a case-insensitive, separator-blind normalisation.
  5. Emit a (province, site, branch, EBF, parent date, child date with
     HPDs) row for every event passing user-configurable thresholds.

Defaults are HyPhy's conventional cutoffs:
    site MEME p-value < 0.1
    branch EBF >= 100
A relaxed pass (suggestive_p) is also produced.

Outputs are written to clock_analyses/:
    selection_events.tsv               long-format, all events
    selection_events_suggestive.tsv    relaxed p-value pass
    selection_events_summary.xlsx      multi-sheet workbook
"""

from __future__ import annotations

import json
import math
import re
import sys
from datetime import datetime, timedelta
from pathlib import Path

import dendropy
import numpy as np
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.formatting.rule import CellIsRule


# ---------------------------------------------------------------------------
HERE       = Path(__file__).resolve().parent
HYPHY_DIR  = HERE.parent / "province_fastas"
BEAST_DIR  = HERE / "combined"

PROVINCE_NAMES = {
    "AB": "Alberta", "BC": "British Columbia", "MB": "Manitoba",
    "NB": "New Brunswick", "NL": "Newfoundland & Labrador",
    "NS": "Nova Scotia", "ON": "Ontario", "PE": "Prince Edward Island",
    "QC": "Quebec", "SK": "Saskatchewan",
}

# Significance thresholds (HyPhy defaults)
P_STRICT      = 0.10
P_SUGGESTIVE  = 0.20
EBF_THRESHOLD = 100.0


# ---------------------------------------------------------------------------
# Tip-name normalization.
#
# HyPhy and BEAST tip labels for the same sequence differ in two
# annoying ways:
#   - HyPhy upper-cases everything (HCOV-19_...) while BEAST keeps the
#     original case (hCoV-19_...).
#   - HyPhy's tip names carry a trailing `_NN` token after the sampling
#     date that the BEAST tree does not have, e.g.
#         HyPhy:   HCOV-19_CANADA_NL-NML-1386_2020_2020-03-24_20
#         BEAST:   hCoV-19_Canada_NL-NML-1386_2020_2020-03-24
#
# Strategy: case-fold, swap every non-alphanumeric run for an
# underscore, then truncate at the FIRST embedded YYYY_MM_DD date so
# the trailing flag (or any other suffix) is dropped from both sides.
# ---------------------------------------------------------------------------
_NORM_RE      = re.compile(r"[^a-z0-9]+")
_DATE_TAIL_RE = re.compile(r"(\d{4}_\d{2}_\d{2})")
def norm_name(s: str) -> str:
    s = _NORM_RE.sub("_", s.lower()).strip("_")
    m = _DATE_TAIL_RE.search(s)
    if m:
        s = s[: m.end()]   # keep the prefix up to and including the date
    return s


# ---------------------------------------------------------------------------
# Tip dates: parse from tip names containing YYYY-MM-DD or YYYY_MM_DD.
# ---------------------------------------------------------------------------
_DATE_RE = re.compile(r"(\d{4})[-_/](\d{2})[-_/](\d{2})")
def tip_date(name: str) -> float | None:
    m = _DATE_RE.search(name)
    if not m:
        return None
    y, mo, da = int(m[1]), int(m[2]), int(m[3])
    try:
        d = datetime(y, mo, da)
    except ValueError:
        return None
    return y + (d.timetuple().tm_yday - 1) / 365.25


def decimal_to_iso(dec_year: float) -> str:
    """Convert a decimal year to ISO date.  Returns ``""`` for NaN /
    None and an explicit ``out-of-range`` token for years that fall
    outside the datetime-supported window (1..9999) — this happens for
    BEAST runs that have not converged and produced absurd node heights
    (e.g. PE, whose root height ≈ 1.5 × 10⁶ years).  We do NOT raise
    here so a single province with a degenerate tree does not abort
    the whole pipeline."""
    if dec_year is None or math.isnan(dec_year):
        return ""
    if dec_year < 1 or dec_year > 9999:
        return "out-of-range"
    y = int(dec_year)
    rem = dec_year - y
    days = round(rem * 365.25)
    try:
        return (datetime(y, 1, 1) + timedelta(days=days)).strftime("%Y-%m-%d")
    except (ValueError, OverflowError):
        return "out-of-range"


# ---------------------------------------------------------------------------
# BEAST MAP tree → per-edge date intervals
# ---------------------------------------------------------------------------
def load_beast_tree(path: Path) -> tuple[dendropy.Tree, float]:
    """Return (tree, youngest_tip_date_decimal)."""
    tree = dendropy.Tree.get(
        path=str(path), schema="nexus",
        extract_comment_metadata=True,
        preserve_underscores=True,
    )
    dates = [tip_date(t.taxon.label) for t in tree.leaf_nodes()]
    dates = [d for d in dates if d is not None]
    if not dates:
        raise RuntimeError(f"no parseable tip dates in {path}")
    youngest = max(dates)
    return tree, youngest


def node_height_with_hpd(node) -> tuple[float, tuple[float, float]]:
    h = node.annotations.get_value("height")
    hpd = node.annotations.get_value("height_95%_HPD")
    h = float(h) if h is not None else 0.0
    if hpd is None:
        hpd_lo, hpd_hi = h, h
    else:
        hpd_lo, hpd_hi = float(hpd[0]), float(hpd[1])
    return h, (hpd_lo, hpd_hi)


def build_branch_index(tree: dendropy.Tree, youngest_date: float) -> dict:
    """
    Map frozenset(normalized tip labels under this node) → dict with
    parent / child calendar dates and HPDs.  Excludes the root (no parent).
    """
    idx = {}
    # Cache: each non-root node's tip set
    for nd in tree.preorder_node_iter():
        nd._tipset = frozenset(
            norm_name(t.taxon.label) for t in nd.leaf_iter()
        )
    for nd in tree.preorder_node_iter():
        if nd.parent_node is None:
            continue
        ch_h, ch_hpd = node_height_with_hpd(nd)
        pa_h, pa_hpd = node_height_with_hpd(nd.parent_node)

        ch_date    = youngest_date - ch_h
        pa_date    = youngest_date - pa_h
        ch_lo, ch_hi = youngest_date - ch_hpd[1], youngest_date - ch_hpd[0]
        pa_lo, pa_hi = youngest_date - pa_hpd[1], youngest_date - pa_hpd[0]

        idx[nd._tipset] = {
            "is_tip"       : nd.is_leaf(),
            "tipset_size"  : len(nd._tipset),
            "child_date"   : ch_date,
            "child_hpd_lo" : ch_lo,
            "child_hpd_hi" : ch_hi,
            "parent_date"  : pa_date,
            "parent_hpd_lo": pa_lo,
            "parent_hpd_hi": pa_hi,
            "tip_label"    : nd.taxon.label if nd.is_leaf() else None,
        }
    return idx


# ---------------------------------------------------------------------------
# MEME parsing
# ---------------------------------------------------------------------------
def load_meme(path: Path) -> dict:
    """Return parsed MEME structure with per-branch tip sets and EBFs."""
    raw = json.load(path.open())
    # Site-level table
    headers = [h[0] for h in raw["MLE"]["headers"]]
    content = raw["MLE"]["content"]["0"]
    site_tab = pd.DataFrame(content, columns=headers).rename(columns={
        "&alpha;": "alpha",
        "&beta;<sup>1</sup>": "beta_neg",
        "p<sup>1</sup>": "p_neg",
        "&beta;<sup>+</sup>": "beta_pos",
        "p<sup>+</sup>": "p_pos",
        "LRT": "LRT",
        "p-value": "p_value",
        "# branches under selection": "n_branches_EBF100",
        "Total branch length": "total_bl",
    })

    # Per-branch posteriors and original names
    ba = raw["branch attributes"]["0"]
    n_sites = raw["input"]["number of sites"]

    # tip set per branch — we only have the HyPhy tree string, so parse it
    # to recover the topology and produce a tip set for each labelled branch
    # (tips and Node*) that matches names appearing in branch attributes.
    tree_str = list(raw["input"]["trees"].values())[0]
    hyphy_tree = dendropy.Tree.get(data=tree_str + ";",
                                   schema="newick",
                                   preserve_underscores=True)
    # original-name lookup: HyPhy normalised tip → original tip name
    orig_lookup = {k: ba[k].get("original name", k) for k in ba}

    branch_tipset = {}
    for nd in hyphy_tree.preorder_node_iter():
        if nd.taxon is None and nd.label is None:
            continue
        # tips: nd.taxon.label is HyPhy-normalised name
        if nd.is_leaf():
            label = nd.taxon.label
            tips_below = [label]
        else:
            label = nd.label  # Node1, Node2, ...
            if label is None:
                continue
            tips_below = [t.taxon.label for t in nd.leaf_iter()]
        # remap to ORIGINAL names (BEAST-side spelling), then normalise
        tips_orig = [orig_lookup.get(t, t) for t in tips_below]
        branch_tipset[label] = frozenset(norm_name(t) for t in tips_orig)

    return {
        "site_tab": site_tab,
        "branch_attrs": ba,
        "branch_tipset": branch_tipset,
        "n_sites": n_sites,
    }


def per_branch_ebf(meme: dict, branch_label: str, site_idx: int) -> float:
    """Empirical Bayes Factor for a single (branch, site)."""
    attrs = meme["branch_attrs"].get(branch_label)
    if attrs is None:
        return float("nan")
    pp = attrs.get("Posterior prob omega class by site")
    if pp is None or len(pp) < 2:
        return float("nan")
    # pp[1][site] = posterior probability of the positive omega class
    post = float(pp[1][site_idx])
    prior = float(meme["site_tab"]["p_pos"].iloc[site_idx])
    if prior <= 0.0 or prior >= 1.0:
        return float("nan")
    if post >= 1.0:
        return float("inf")
    if post <= 0.0:
        return 0.0
    odds_post  = post / (1.0 - post)
    odds_prior = prior / (1.0 - prior)
    return odds_post / odds_prior


# ---------------------------------------------------------------------------
# BUSTED parsing
# ---------------------------------------------------------------------------
def load_busted(path: Path) -> dict:
    raw = json.load(path.open())
    test = raw.get("test results", {})
    rd_un = (raw.get("fits", {})
                .get("Unconstrained model", {})
                .get("Rate Distributions", {})
                .get("Test", {}))
    omegas = []
    for k in sorted(rd_un.keys()):
        omegas.append((float(rd_un[k].get("omega", math.nan)),
                       float(rd_un[k].get("proportion", math.nan))))
    return {
        "LRT"      : float(test.get("LRT", math.nan)),
        "p_value"  : float(test.get("p-value", math.nan)),
        "omega_classes": omegas,        # [(omega, proportion), ...]
    }


# ---------------------------------------------------------------------------
# Match HyPhy branches → BEAST branches via tip-set
# ---------------------------------------------------------------------------
def match_branches(meme: dict, beast_idx: dict) -> dict:
    """Return HyPhy branch label → BEAST branch info, where matched."""
    out = {}
    matched_tipsets = set()
    for hb_label, hb_set in meme["branch_tipset"].items():
        if hb_set in beast_idx:
            out[hb_label] = beast_idx[hb_set]
            matched_tipsets.add(hb_set)
    return out, matched_tipsets


# ---------------------------------------------------------------------------
# per-province driver
# ---------------------------------------------------------------------------
def find_provinces() -> list[str]:
    """Return provinces with both populated MEME JSON and a BEAST MAP tree."""
    have_beast = {p.name.split("_combined.map.trees")[0]
                  for p in BEAST_DIR.glob("*_combined.map.trees")}
    ready = []
    for p in sorted(have_beast):
        meme   = HYPHY_DIR / f"{p}_hyphy.MEME.json"
        busted = HYPHY_DIR / f"{p}_hyphy.BUSTED.json"
        if meme.exists() and meme.stat().st_size > 0 and \
           busted.exists() and busted.stat().st_size > 0:
            ready.append(p)
    return ready


def date_one_province(prov: str,
                      p_strict: float = P_STRICT,
                      p_relaxed: float = P_SUGGESTIVE,
                      ebf_min: float = EBF_THRESHOLD) -> dict:
    print(f"[{prov}] loading inputs", file=sys.stderr)
    meme   = load_meme  (HYPHY_DIR / f"{prov}_hyphy.MEME.json")
    busted = load_busted(HYPHY_DIR / f"{prov}_hyphy.BUSTED.json")
    tree, youngest = load_beast_tree(BEAST_DIR / f"{prov}_combined.map.trees")
    beast_idx = build_branch_index(tree, youngest)

    matched, matched_sets = match_branches(meme, beast_idx)
    n_meme    = len(meme["branch_tipset"])
    n_matched = len(matched)
    print(f"[{prov}] tree topologies: matched {n_matched}/{n_meme} HyPhy "
          f"branches to BEAST branches  (youngest tip = {decimal_to_iso(youngest)})",
          file=sys.stderr)

    # iterate sites
    site_tab = meme["site_tab"]
    rows_strict, rows_relaxed = [], []
    for site_i, site in site_tab.iterrows():
        p_value = site["p_value"]
        if not (p_value < p_relaxed):
            continue
        for hb_label, beast_b in matched.items():
            ebf = per_branch_ebf(meme, hb_label, site_i)
            if math.isnan(ebf) or ebf < ebf_min:
                continue
            row = {
                "province": prov,
                "codon_site_1based": int(site_i + 1),
                "MEME_p_value": float(p_value),
                "MEME_LRT": float(site["LRT"]),
                "site_alpha": float(site["alpha"]),
                "site_beta_pos": float(site["beta_pos"]),
                "site_p_pos": float(site["p_pos"]),
                "branch_hyphy_label": hb_label,
                "branch_is_tip": bool(beast_b["is_tip"]),
                "branch_n_tips_below": int(beast_b["tipset_size"]),
                "branch_tip_label_if_tip": beast_b["tip_label"] or "",
                "EBF": float(ebf),
                "parent_date_dec": beast_b["parent_date"],
                "parent_date_iso": decimal_to_iso(beast_b["parent_date"]),
                "parent_HPD_lo_dec": beast_b["parent_hpd_lo"],
                "parent_HPD_lo_iso": decimal_to_iso(beast_b["parent_hpd_lo"]),
                "parent_HPD_hi_dec": beast_b["parent_hpd_hi"],
                "parent_HPD_hi_iso": decimal_to_iso(beast_b["parent_hpd_hi"]),
                "child_date_dec": beast_b["child_date"],
                "child_date_iso": decimal_to_iso(beast_b["child_date"]),
                "child_HPD_lo_dec": beast_b["child_hpd_lo"],
                "child_HPD_lo_iso": decimal_to_iso(beast_b["child_hpd_lo"]),
                "child_HPD_hi_dec": beast_b["child_hpd_hi"],
                "child_HPD_hi_iso": decimal_to_iso(beast_b["child_hpd_hi"]),
                "branch_midpoint_iso": decimal_to_iso(
                    0.5 * (beast_b["parent_date"] + beast_b["child_date"])),
            }
            if p_value < p_strict:
                rows_strict.append(row)
            rows_relaxed.append(row)

    return {
        "province"         : prov,
        "n_seqs"           : int(meme["site_tab"].shape[0]) and int(json.load(open(HYPHY_DIR/f"{prov}_hyphy.MEME.json"))["input"]["number of sequences"]),
        "n_sites"          : int(meme["n_sites"]),
        "n_meme_branches"  : n_meme,
        "n_matched_branches": n_matched,
        "youngest_tip_iso" : decimal_to_iso(youngest),
        "BUSTED_LRT"       : busted["LRT"],
        "BUSTED_p"         : busted["p_value"],
        "BUSTED_omega_classes": busted["omega_classes"],
        "rows_strict"      : rows_strict,
        "rows_relaxed"     : rows_relaxed,
    }


# ---------------------------------------------------------------------------
# Output writers
# ---------------------------------------------------------------------------
def write_xlsx(per_prov: list[dict], path: Path) -> None:
    wb = Workbook()
    HDR_FONT = Font(name="Arial", bold=True, color="FFFFFF")
    HDR_FILL = PatternFill("solid", start_color="305496")
    SUB_FILL = PatternFill("solid", start_color="D9E1F2")
    BAD_FILL = PatternFill("solid", start_color="F8CBAD")
    OK_FILL  = PatternFill("solid", start_color="C6EFCE")

    # ---- Sheet: Summary
    ws = wb.active
    ws.title = "Summary"
    headers = [
        ("province", 1), ("name", 1), ("n_seqs", 1), ("n_sites", 1),
        ("youngest tip", 1), ("HyPhy/BEAST branch match", 1),
        ("BUSTED LRT", 1), ("BUSTED p", 1),
        ("episodic events (p<{:.2f}, EBF≥{:.0f})".format(P_STRICT, EBF_THRESHOLD), 1),
        ("suggestive events (p<{:.2f})".format(P_SUGGESTIVE), 1),
    ]
    for j, (h, _) in enumerate(headers, start=1):
        c = ws.cell(row=1, column=j, value=h)
        c.font, c.fill, c.alignment = HDR_FONT, HDR_FILL, Alignment(horizontal="center")
    for i, p in enumerate(per_prov, start=2):
        ws.cell(row=i, column=1, value=p["province"]).font = Font(name="Arial", bold=True)
        ws.cell(row=i, column=2, value=PROVINCE_NAMES.get(p["province"], "")).font = Font(name="Arial")
        ws.cell(row=i, column=3, value=p["n_seqs"]).font = Font(name="Arial")
        ws.cell(row=i, column=4, value=p["n_sites"]).font = Font(name="Arial")
        ws.cell(row=i, column=5, value=p["youngest_tip_iso"]).font = Font(name="Arial")
        ws.cell(row=i, column=6, value=f'{p["n_matched_branches"]}/{p["n_meme_branches"]}').font = Font(name="Arial")
        c = ws.cell(row=i, column=7, value=p["BUSTED_LRT"])
        c.font, c.number_format = Font(name="Arial"), "0.000"
        c = ws.cell(row=i, column=8, value=p["BUSTED_p"])
        c.font, c.number_format = Font(name="Arial"), "0.0000"
        c.fill = OK_FILL if p["BUSTED_p"] < 0.05 else BAD_FILL if p["BUSTED_p"] >= 0.5 else PatternFill()
        ws.cell(row=i, column=9, value=len(p["rows_strict"])).font = Font(name="Arial")
        ws.cell(row=i, column=10, value=len(p["rows_relaxed"])).font = Font(name="Arial")
    for j, w in enumerate([8, 24, 8, 8, 14, 18, 12, 10, 30, 24], start=1):
        ws.column_dimensions[get_column_letter(j)].width = w
    ws.freeze_panes = "A2"

    # ---- Sheet: Master events (strict)
    long_cols = ["province","codon_site_1based","MEME_p_value","EBF",
                 "branch_hyphy_label","branch_is_tip","branch_n_tips_below",
                 "branch_tip_label_if_tip",
                 "parent_date_iso","parent_HPD_lo_iso","parent_HPD_hi_iso",
                 "child_date_iso","child_HPD_lo_iso","child_HPD_hi_iso",
                 "branch_midpoint_iso",
                 "site_alpha","site_beta_pos","site_p_pos","MEME_LRT"]
    ws2 = wb.create_sheet("Events_strict")
    for j, h in enumerate(long_cols, start=1):
        c = ws2.cell(row=1, column=j, value=h)
        c.font, c.fill = HDR_FONT, HDR_FILL
    r = 2
    for p in per_prov:
        for row in p["rows_strict"]:
            for j, h in enumerate(long_cols, start=1):
                v = row.get(h, "")
                cell = ws2.cell(row=r, column=j, value=v)
                cell.font = Font(name="Arial")
                if h in ("MEME_p_value","MEME_LRT","site_alpha",
                         "site_beta_pos","site_p_pos"):
                    cell.number_format = "0.0000"
                elif h == "EBF":
                    cell.number_format = "0.0"
            r += 1
    ws2.freeze_panes = "A2"

    # ---- Sheet: Master events (suggestive, includes strict)
    ws3 = wb.create_sheet("Events_suggestive")
    for j, h in enumerate(long_cols, start=1):
        c = ws3.cell(row=1, column=j, value=h)
        c.font, c.fill = HDR_FONT, HDR_FILL
    r = 2
    for p in per_prov:
        for row in p["rows_relaxed"]:
            for j, h in enumerate(long_cols, start=1):
                v = row.get(h, "")
                cell = ws3.cell(row=r, column=j, value=v)
                cell.font = Font(name="Arial")
                if h in ("MEME_p_value","MEME_LRT","site_alpha",
                         "site_beta_pos","site_p_pos"):
                    cell.number_format = "0.0000"
                elif h == "EBF":
                    cell.number_format = "0.0"
            r += 1
    ws3.freeze_panes = "A2"

    # column widths for both event sheets
    widths = [8, 8, 11, 10, 16, 8, 8, 30,
              12, 12, 12, 12, 12, 12, 14,
              10, 11, 10, 10]
    for ws_ in (ws2, ws3):
        for j, w in enumerate(widths, start=1):
            ws_.column_dimensions[get_column_letter(j)].width = w

    # ---- Sheet per province: per-site MEME table with date annotation
    for p in per_prov:
        if not p["rows_relaxed"]:
            continue
        sn = p["province"]
        wsP = wb.create_sheet(sn)
        for j, h in enumerate(long_cols, start=1):
            c = wsP.cell(row=1, column=j, value=h)
            c.font, c.fill = HDR_FONT, HDR_FILL
        r = 2
        for row in p["rows_relaxed"]:
            for j, h in enumerate(long_cols, start=1):
                v = row.get(h, "")
                cell = wsP.cell(row=r, column=j, value=v)
                cell.font = Font(name="Arial")
                if h in ("MEME_p_value","MEME_LRT","site_alpha",
                         "site_beta_pos","site_p_pos"):
                    cell.number_format = "0.0000"
                elif h == "EBF":
                    cell.number_format = "0.0"
            # highlight strict-significance rows
            if row["MEME_p_value"] < P_STRICT:
                for j in range(1, len(long_cols)+1):
                    wsP.cell(row=r, column=j).fill = OK_FILL
            r += 1
        for j, w in enumerate(widths, start=1):
            wsP.column_dimensions[get_column_letter(j)].width = w
        wsP.freeze_panes = "A2"

    wb.save(path)


# ---------------------------------------------------------------------------
def main() -> int:
    provinces = find_provinces()
    if not provinces:
        print("No provinces have both BEAST MAP tree and populated MEME/BUSTED JSON.",
              file=sys.stderr)
        return 1
    print(f"ready provinces: {provinces}", file=sys.stderr)

    per_prov = []
    for prov in provinces:
        try:
            per_prov.append(date_one_province(prov))
        except Exception as e:
            print(f"[{prov}] FAILED: {e}", file=sys.stderr)

    # Long-format TSVs
    long_strict  = [r for p in per_prov for r in p["rows_strict"]]
    long_relaxed = [r for p in per_prov for r in p["rows_relaxed"]]
    cols_tsv = ["province","codon_site_1based","MEME_p_value","EBF",
                "branch_hyphy_label","branch_is_tip","branch_n_tips_below",
                "branch_tip_label_if_tip",
                "parent_date_iso","parent_HPD_lo_iso","parent_HPD_hi_iso",
                "child_date_iso","child_HPD_lo_iso","child_HPD_hi_iso",
                "branch_midpoint_iso",
                "site_alpha","site_beta_pos","site_p_pos","MEME_LRT"]
    pd.DataFrame(long_strict,  columns=cols_tsv).to_csv(
        HERE / "selection_events.tsv", sep="\t", index=False, float_format="%.6g")
    pd.DataFrame(long_relaxed, columns=cols_tsv).to_csv(
        HERE / "selection_events_suggestive.tsv", sep="\t", index=False, float_format="%.6g")

    write_xlsx(per_prov, HERE / "selection_events_summary.xlsx")

    # Headline numbers
    print("---- summary ----", file=sys.stderr)
    for p in per_prov:
        print(f"  {p['province']}: BUSTED p={p['BUSTED_p']:.4f}  "
              f"strict events: {len(p['rows_strict']):4d}  "
              f"suggestive events: {len(p['rows_relaxed']):4d}  "
              f"matched {p['n_matched_branches']}/{p['n_meme_branches']} branches",
              file=sys.stderr)

    return 0


if __name__ == "__main__":
    sys.exit(main())
