#!/usr/bin/env python3
"""
clean_codon_alignment.py
------------------------
Prepare a codon alignment for HyPhy (MEME / BUSTED) by:

  (1) imputing every IUPAC-ambiguous nucleotide (N, Y, R, K, M, W, S,
      B, D, H, V) using the column-wise consensus computed from the
      unambiguous A/C/G/T bases ONLY, restricted to the set of bases
      that are IUPAC-compatible with the original ambiguity code (so
      Y is resolved to whichever of {C, T} is more common at that
      column, never to A or G);

  (2) replacing every internal stop codon (TAA, TAG, TGA in the
      standard genetic code) with the column-consensus codon at that
      codon position; if the consensus codon would itself be a stop
      (effectively never, but checked) the codon is written as ``NNN``
      so HyPhy treats it as fully missing.

The script preserves alignment length and codon frame, never inserts
or deletes columns, and never touches positions that are already a
clean A/C/G/T base in a non-stop codon.

Usage
-----
    python3 clean_codon_alignment.py INPUT.fasta [OUTPUT.fasta]

If OUTPUT is omitted, ``<INPUT_basename>_clean.fasta`` is written next
to INPUT.

Notes
-----
* Gaps (``-``) are NOT imputed — they represent real missing columns,
  not low-quality basecalls.  In the BC_04_final.fasta input the
  alignment happens to contain no gaps anyway.
* The original case of the file is normalised to uppercase on output.
"""

from __future__ import annotations

import sys
from collections import Counter
from pathlib import Path


# ---------------------------------------------------------------------------
STOP_CODONS = {"TAA", "TAG", "TGA"}

# IUPAC nucleotide ambiguity → set of permissible bases.
IUPAC: dict[str, frozenset[str]] = {
    "A": frozenset("A"), "C": frozenset("C"),
    "G": frozenset("G"), "T": frozenset("T"), "U": frozenset("T"),
    "R": frozenset("AG"), "Y": frozenset("CT"),
    "K": frozenset("GT"), "M": frozenset("AC"),
    "S": frozenset("GC"), "W": frozenset("AT"),
    "B": frozenset("CGT"), "D": frozenset("AGT"),
    "H": frozenset("ACT"), "V": frozenset("ACG"),
    "N": frozenset("ACGT"),
}
CLEAN_BASES = frozenset("ACGT")


# ---------------------------------------------------------------------------
def read_fasta(path: Path) -> dict[str, str]:
    seqs: dict[str, str] = {}
    name, buf = None, []
    with path.open() as f:
        for line in f:
            line = line.rstrip("\r\n")
            if line.startswith(">"):
                if name is not None:
                    seqs[name] = "".join(buf).upper()
                name = line[1:].split()[0]
                buf = []
            elif line:
                buf.append(line)
    if name is not None:
        seqs[name] = "".join(buf).upper()
    return seqs


def write_fasta(seqs: dict[str, str], path: Path, wrap: int = 80) -> None:
    with path.open("w") as f:
        for name, s in seqs.items():
            f.write(f">{name}\n")
            for i in range(0, len(s), wrap):
                f.write(s[i:i + wrap] + "\n")


# ---------------------------------------------------------------------------
def column_freqs(seqs: dict[str, str], L: int) -> list[Counter]:
    """Return one Counter per column over A/C/G/T only."""
    cols = [Counter() for _ in range(L)]
    for s in seqs.values():
        for i, ch in enumerate(s):
            if ch in CLEAN_BASES:
                cols[i][ch] += 1
    return cols


def best_compatible_base(col: Counter, allowed: frozenset[str]) -> str:
    """Most common base in ``col`` restricted to ``allowed``.
    Ties broken alphabetically.  Falls back to global ACGT order if the
    column has no compatible base at all."""
    best, best_c = None, -1
    for b in sorted(allowed):
        c = col.get(b, 0)
        if c > best_c:
            best, best_c = b, c
    if best is None or best_c == 0:
        # column has no clean ACGT base in the allowed set; pick any
        # ACGT in the column, or A if even that is empty.
        for b in "ACGT":
            if col.get(b, 0) > 0 and b in allowed:
                return b
        return next(iter(sorted(allowed))) if allowed else "A"
    return best


# ---------------------------------------------------------------------------
def clean_alignment(seqs: dict[str, str]) -> tuple[dict[str, str], dict[str, int]]:
    """Return (cleaned, stats)."""
    if not seqs:
        return {}, {}
    L = len(next(iter(seqs.values())))
    if any(len(v) != L for v in seqs.values()):
        raise ValueError("sequences are not all the same length")
    if L % 3 != 0:
        raise ValueError(f"alignment length {L} is not a multiple of 3")

    col_freq = column_freqs(seqs, L)

    n_amb_imputed     = 0
    n_stops_replaced  = 0
    n_codons_recomputed = 0   # codons where a column-consensus codon was used

    # Pre-compute the column-consensus codon for every codon position.
    # When we need to replace a stop, we use this consensus; if the
    # consensus codon itself happens to be a stop, fall back to NNN.
    n_codons = L // 3
    cons_codon = [None] * n_codons
    for k in range(n_codons):
        c0 = best_compatible_base(col_freq[3 * k    ], CLEAN_BASES)
        c1 = best_compatible_base(col_freq[3 * k + 1], CLEAN_BASES)
        c2 = best_compatible_base(col_freq[3 * k + 2], CLEAN_BASES)
        cc = c0 + c1 + c2
        cons_codon[k] = "NNN" if cc in STOP_CODONS else cc

    cleaned: dict[str, str] = {}
    for name, s in seqs.items():
        chars = list(s)

        # Step 1: impute ambiguity codes position-by-position.
        for i, ch in enumerate(chars):
            if ch in CLEAN_BASES or ch == "-":
                continue
            allowed = IUPAC.get(ch)
            if allowed is None:
                # unknown character — treat as fully ambiguous N
                allowed = IUPAC["N"]
            chars[i] = best_compatible_base(col_freq[i], allowed)
            n_amb_imputed += 1

        # Step 2: scan for stop codons and replace with consensus codon.
        for k in range(n_codons):
            j = 3 * k
            cod = chars[j] + chars[j + 1] + chars[j + 2]
            if cod in STOP_CODONS:
                cc = cons_codon[k]
                chars[j], chars[j + 1], chars[j + 2] = cc[0], cc[1], cc[2]
                n_stops_replaced += 1
                n_codons_recomputed += 1

        cleaned[name] = "".join(chars)

    stats = {
        "n_sequences"         : len(seqs),
        "alignment_length"    : L,
        "n_codons_per_seq"    : n_codons,
        "ambiguities_imputed" : n_amb_imputed,
        "stops_replaced"      : n_stops_replaced,
        "consensus_codons_used": n_codons_recomputed,
    }
    return cleaned, stats


# ---------------------------------------------------------------------------
def verify(seqs: dict[str, str]) -> dict[str, int]:
    """Sanity check the cleaned alignment."""
    L = len(next(iter(seqs.values())))
    n_stop = 0
    n_amb  = 0
    for s in seqs.values():
        for i in range(0, L, 3):
            cod = s[i:i + 3]
            if cod in STOP_CODONS:
                n_stop += 1
            if not set(cod) <= (CLEAN_BASES | {"-", "N"}):
                n_amb += 1
    return {"remaining_stops": n_stop, "remaining_ambig_codons": n_amb}


# ---------------------------------------------------------------------------
def main() -> int:
    if len(sys.argv) < 2 or len(sys.argv) > 3:
        print(__doc__.strip(), file=sys.stderr)
        return 2
    in_path  = Path(sys.argv[1]).resolve()
    if len(sys.argv) == 3:
        out_path = Path(sys.argv[2]).resolve()
    else:
        out_path = in_path.with_name(in_path.stem + "_clean.fasta")

    print(f"reading {in_path}", file=sys.stderr)
    seqs = read_fasta(in_path)
    print(f"  {len(seqs)} sequences, length {len(next(iter(seqs.values())))} nt",
          file=sys.stderr)

    cleaned, stats = clean_alignment(seqs)
    check = verify(cleaned)

    print(f"cleaning summary:", file=sys.stderr)
    for k, v in {**stats, **check}.items():
        print(f"  {k:<22s} {v:,}", file=sys.stderr)

    if check["remaining_stops"] != 0:
        print("ERROR: stop codons remained after cleaning.", file=sys.stderr)
        return 1

    write_fasta(cleaned, out_path)
    print(f"wrote {out_path}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
