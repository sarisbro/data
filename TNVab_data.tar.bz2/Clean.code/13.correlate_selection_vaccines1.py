"""
Per-province lagged-correlation analysis:
    monthly count of strict episodic-selection events  vs
    a "vaccine deployment intensity" series built from each province's
    documented first-dose dates.

Three vaccine series are computed for each province because the choice
of representation is itself a modelling decision:

  v_new(t)    impulse train: count of distinct vaccine products whose
              first-dose date in that province falls in month t.
  v_smooth(t) v_new convolved with a 2-month-sigma Gaussian kernel; a
              continuous "deployment intensity" proxy that smears each
              roll-out event over a few months of expected effect.
  v_cum(t)    cumulative number of distinct vaccine products available
              in the province by month t — proxy for the "immune
              landscape pressure" gradient.

For each province we compute Pearson r between the monthly selection
count and each vaccine series at lags from -6 to +18 months, where
*positive lag means the vaccine series leads selection*. The lag that
maximises r is reported, plus a 1,000-sample circular-shift permutation
null distribution to gauge whether the peak is plausibly distinguishable
from noise.

Caveats (flagged in the printed output and in the figure caption):
  - Both series are short (~30-50 monthly observations per province).
  - Variant emergence (Alpha, Delta, Omicron) drives both selection AND
    vaccine demand simultaneously, so any positive lag is at best
    consistent with — not evidence of — a causal vaccine -> selection
    pathway.
  - We have *first-dose dates*, not provincial coverage curves; the
    canonical PHAC coverage data was unreachable from this sandbox.
  - PE is unconverged in BEAST and is omitted.
  - NS and NL have no strict selection events; they are omitted.

Outputs:
    selection_vs_vaccine_ccf.tsv     long-format lag x province table
    selection_vs_vaccine_ccf.pdf     per-province CCF figure (publication)
    selection_vs_vaccine_ccf.png     preview at 180 dpi
"""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

HERE        = Path(__file__).resolve().parent
SEL_TSV     = HERE / "selection_events.tsv"
VAX_CSV     = HERE / "canadian_vaccine_timeline.csv"
OUT_TSV     = HERE / "selection_vs_vaccine_ccf.tsv"
OUT_PDF     = HERE / "selection_vs_vaccine_ccf.pdf"
OUT_PNG     = HERE / "selection_vs_vaccine_ccf.png"

LAGS        = list(range(-6, 19))    # positive lag = vaccine leads selection
KERNEL_SIGMA_MONTHS = 2.0
N_PERM      = 1000
RNG         = np.random.default_rng(20260502)

# ---- load -----------------------------------------------------------------

sel = pd.read_csv(SEL_TSV, sep="\t")
sel["date"] = pd.to_datetime(sel["child_date_iso"], errors="coerce")
sel = sel.dropna(subset=["date"])

vax = pd.read_csv(VAX_CSV)
vax["date"] = pd.to_datetime(vax["event_date"], errors="coerce")
# Keep only provincial first-dose events with concrete dates
vax_first = vax[
    (vax["event_type"] == "first_dose_administered_in_province")
    & vax["date"].notna()
].copy()

provinces = sorted(sel["province"].unique())     # BC, AB, SK, MB, ON, QC
print("Provinces analysed:", provinces)

# Common monthly grid
t_lo = sel["date"].min().to_period("M").to_timestamp()
t_hi = (sel["date"].max() + pd.DateOffset(months=2)).to_period("M").to_timestamp()
months = pd.date_range(t_lo, t_hi, freq="MS")
print(f"Time window: {t_lo.date()}  ->  {t_hi.date()}    ({len(months)} months)")

# ---- helpers --------------------------------------------------------------

def gaussian_smooth(impulse_train: np.ndarray, sigma: float) -> np.ndarray:
    grid = np.arange(len(impulse_train))
    out  = np.zeros_like(impulse_train, dtype=float)
    for i, c in enumerate(impulse_train):
        if c == 0:
            continue
        out += c * np.exp(-0.5 * ((grid - i) / sigma) ** 2)
    return out

def lagged_pearson(s: np.ndarray, v: np.ndarray, lag: int) -> float:
    """Pearson r(s[t], v[t - lag]); positive lag => v leads s."""
    if lag >= 0:
        if lag >= len(s):
            return np.nan
        a, b = s[lag:], v[:len(v) - lag]
    else:
        L = -lag
        if L >= len(s):
            return np.nan
        a, b = s[:len(s) - L], v[L:]
    if len(a) < 6 or np.std(a) == 0 or np.std(b) == 0:
        return np.nan
    return float(np.corrcoef(a, b)[0, 1])

def perm_max_r(s: np.ndarray, v: np.ndarray, lags, n_perm: int) -> np.ndarray:
    """Circular-shift permutation: shuffle v by random integer cyclically,
    record max |r| across lags. Returns array of n_perm max-r values."""
    n = len(v)
    out = np.empty(n_perm)
    for k in range(n_perm):
        shift = RNG.integers(1, n - 1)
        v_perm = np.roll(v, shift)
        rs = [lagged_pearson(s, v_perm, lag) for lag in lags]
        out[k] = np.nanmax(rs)
    return out

# ---- per-province CCF -----------------------------------------------------

results: dict[str, dict] = {}
ccf_rows: list[dict] = []

for prov in provinces:
    sel_p = sel[sel["province"] == prov]
    vax_p = vax_first[vax_first["jurisdiction"] == prov]

    s = (sel_p.set_index("date")
              .resample("MS").size()
              .reindex(months, fill_value=0)
              .values.astype(float))

    if len(vax_p):
        v_new = (vax_p.set_index("date")
                       .resample("MS").size()
                       .reindex(months, fill_value=0)
                       .values.astype(float))
    else:
        v_new = np.zeros(len(months))
    v_smooth = gaussian_smooth(v_new, KERNEL_SIGMA_MONTHS)
    v_cum    = np.cumsum(v_new)

    ccf_new    = [lagged_pearson(s, v_new,    lag) for lag in LAGS]
    ccf_smooth = [lagged_pearson(s, v_smooth, lag) for lag in LAGS]
    ccf_cum    = [lagged_pearson(s, v_cum,    lag) for lag in LAGS]

    # Permutation null on the smoothed series
    null_max = perm_max_r(s, v_smooth, LAGS, N_PERM)
    obs_max  = float(np.nanmax(ccf_smooth))
    pval     = float((null_max >= obs_max).mean())

    best_i   = int(np.nanargmax(ccf_smooth))
    best_lag = LAGS[best_i]
    best_r   = ccf_smooth[best_i]

    results[prov] = dict(months=months, s=s, v_new=v_new,
                         v_smooth=v_smooth, v_cum=v_cum,
                         lags=LAGS, ccf_smooth=ccf_smooth,
                         ccf_new=ccf_new, ccf_cum=ccf_cum,
                         best_lag=best_lag, best_r=best_r,
                         null_max=null_max, pval=pval,
                         n_vaccine_events=int(v_new.sum()))

    print(f"  {prov}: best smoothed-CCF lag = {best_lag:+3d} mo, "
          f"r = {best_r:+.3f}  perm-p = {pval:.3f}  "
          f"(n_vaccine_events = {int(v_new.sum())})")

    for lag, rs, rn, rc in zip(LAGS, ccf_smooth, ccf_new, ccf_cum):
        ccf_rows.append(dict(province=prov, lag_months=lag,
                             r_smoothed=rs, r_impulse=rn, r_cumulative=rc))

# ---- CCF table -----------------------------------------------------------

ccf_df = pd.DataFrame(ccf_rows)
ccf_df.to_csv(OUT_TSV, sep="\t", index=False, float_format="%.4f")
print(f"Wrote {OUT_TSV}")

# ---- figure --------------------------------------------------------------

fig = plt.figure(figsize=(11.0, 8.5))
gs = fig.add_gridspec(3, 2, hspace=0.55, wspace=0.18,
                      left=0.08, right=0.97, top=0.92, bottom=0.07)
prov_axes = [fig.add_subplot(gs[i // 2, i % 2]) for i in range(6)]

for ax, prov in zip(prov_axes, provinces):
    res = results[prov]
    lags = res["lags"]

    # Bars: smoothed CCF
    bars = ax.bar(lags, res["ccf_smooth"], width=0.78,
                  color="#7aa6c2", edgecolor="white", linewidth=0.4)
    # Highlight best lag
    bars[lags.index(res["best_lag"])].set_color("#c0392b")

    # Permutation null 95% upper bound
    null_q95 = float(np.nanpercentile(res["null_max"], 95))
    ax.axhline(null_q95, color="black", linestyle=":", linewidth=0.7,
               label=f"perm 95% (max-r null) = {null_q95:.2f}")
    ax.axhline(0, color="gray", linewidth=0.5)
    ax.axvline(0, color="black", linewidth=0.5, linestyle="--", alpha=0.5)

    ax.set_title(
        f"{prov}   best lag = {res['best_lag']:+d} mo, "
        f"r = {res['best_r']:+.2f}, perm-p = {res['pval']:.3f}   "
        f"(n vaccine events = {res['n_vaccine_events']})",
        fontsize=10, loc="left")
    ax.set_xlim(min(lags) - 0.6, max(lags) + 0.6)
    ax.set_ylim(-1, 1)
    ax.set_xlabel("Lag (months) — positive = vaccine deployment leads selection",
                  fontsize=8.5)
    ax.set_ylabel("Pearson r", fontsize=8.5)
    ax.tick_params(axis="both", labelsize=8)
    ax.legend(loc="lower right", fontsize=7, frameon=False)
    for s_ in ("top", "right"):
        ax.spines[s_].set_visible(False)

fig.suptitle("Per-province cross-correlation: monthly episodic-selection events "
             "vs Gaussian-smoothed vaccine deployments\n"
             "(red bar = lag with maximum r; dotted line = permutation 95% upper bound; "
             "p-value is two-sided over circularly shuffled vaccine series)",
             fontsize=11, fontweight="bold", y=0.985)

fig.savefig(OUT_PDF, format="pdf", bbox_inches="tight")
fig.savefig(OUT_PNG, dpi=180, bbox_inches="tight")
print(f"Wrote {OUT_PDF}\nWrote {OUT_PNG}")
