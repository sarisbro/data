# split_by_province.R
#
# Per-province SARS-CoV-2 pipeline:
#   1. Split source FASTA by province (2-letter code after "Canada/")
#   2. Remove sequences containing indels (gap character '-')
#   3. Cluster at 99% identity with CD-HIT-EST
#   4. Clean headers + trim stop codon  →  final alignment
#   5. Fit ML tree (HKY + Gamma_4) with phangorn, reroot on reference
#   6. Write HyPhy-compatible NEXUS file (alignment + tree in one file)
#
# Output files per province (in <output_dir>/):
#   {PROV}_01_raw.fasta        – raw split (reference + province seqs)
#   {PROV}_02_no_indels.fasta  – after indel removal
#   {PROV}_03_cdhit99.fasta    – after CD-HIT-EST 99% clustering
#   {PROV}_04_final.fasta      – cleaned headers, stop codon trimmed
#   {PROV}_tree.nwk            – rooted ML tree (Newick)
#   {PROV}_hyphy.nex           – HyPhy NEXUS: DATA block + TREES block
#
# Usage:
#   Rscript split_by_province.R <input.fasta> [output_dir]

suppressPackageStartupMessages({
  library(ape)
  library(phangorn)
  library(parallel)
})

# ── Arguments ─────────────────────────────────────────────────────────────────
args       <- commandArgs(trailingOnly = TRUE)
input_file <- if (length(args) >= 1) args[1] else "canada_spike_nt_01_99.fasta"
output_dir <- if (length(args) >= 2) args[2] else "province_fastas"

if (!file.exists(input_file)) stop("Input file not found: ", input_file)
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)

NCORES <- max(1L, detectCores(logical = FALSE))
cat(sprintf("Using %d core(s)\n\n", NCORES))

# ── Helpers ───────────────────────────────────────────────────────────────────
read_fasta <- function(path) {
  lines     <- readLines(path)
  is_header <- startsWith(lines, ">")
  idx       <- which(is_header)
  headers   <- sub("^>", "", lines[idx])
  ends      <- c(idx[-1] - 1L, length(lines))
  seqs      <- mapply(function(s, e) paste(lines[(s + 1L):e], collapse = ""),
                      idx, ends, SIMPLIFY = TRUE)
  list(header = headers, seq = seqs)
}

write_fasta <- function(path, headers, seqs, wrap = 80L) {
  con <- file(path, open = "w")
  on.exit(close(con))
  for (i in seq_along(headers)) {
    writeLines(paste0(">", headers[i]), con)
    s <- seqs[i]; n <- nchar(s)
    for (start in seq(1L, n, by = wrap))
      writeLines(substr(s, start, min(start + wrap - 1L, n)), con)
  }
  invisible(path)
}

# Clean a sequence name:
#   1. Remove the last 8 characters
#   2. Replace any character that is not alphanumeric or '-' with '_'
#   3. Collapse runs of '_' to a single '_'
#   4. Strip leading / trailing '_'
clean_name <- function(x) {
  x <- substr(x, 1L, nchar(x) - 8L)
  x <- gsub("[^A-Za-z0-9-]", "_", x)
  x <- gsub("_+", "_", x)
  x <- gsub("^_|_$", "", x)
  x
}

# Write a HyPhy-compatible NEXUS file combining alignment and rooted ML tree.
# HyPhy requires:
#   - DATA block with uppercase DNA, MISSING=?, GAP=-
#   - TREES block with a single TREE statement using raw tip labels
#     (no TRANSLATE table — avoids integer-label mismatches)
write_hyphy_nexus <- function(path, headers, seqs, tree) {
  ntax  <- length(headers)
  nchar <- unique(nchar(seqs))
  if (length(nchar) != 1L)
    stop("Sequences must be of equal length for NEXUS export.")

  # Maximum label width for alignment padding
  maxw <- max(nchar(headers))

  con <- file(path, open = "w")
  on.exit(close(con))

  # ── DATA block ──────────────────────────────────────────────────────────────
  writeLines("#NEXUS", con)
  writeLines("", con)
  writeLines("BEGIN DATA;", con)
  writeLines(sprintf("  DIMENSIONS NTAX=%d NCHAR=%d;", ntax, nchar), con)
  writeLines("  FORMAT DATATYPE=DNA MISSING=? GAP=- INTERLEAVE=NO;", con)
  writeLines("  MATRIX", con)
  for (i in seq_along(headers)) {
    # Pad label to align columns; HyPhy tolerates (and benefits from) spacing
    label <- formatC(headers[i], width = maxw, flag = "-")
    writeLines(sprintf("    %s  %s", label, toupper(seqs[i])), con)
  }
  writeLines("  ;", con)
  writeLines("END;", con)
  writeLines("", con)

  # ── TREES block ─────────────────────────────────────────────────────────────
  # write.tree() with raw tip labels — no integer translation table
  newick <- write.tree(tree)           # returns the Newick string
  writeLines("BEGIN TREES;", con)
  writeLines(sprintf("  TREE tree1 = %s", newick), con)
  writeLines("END;", con)

  invisible(path)
}

# ── Parse source FASTA ────────────────────────────────────────────────────────
fasta <- read_fasta(input_file)
cat(sprintf("Read %d sequences from %s\n", length(fasta$header), input_file))

# ── Reference sequence ────────────────────────────────────────────────────────
ref_idx <- which(startsWith(fasta$header, "NC_045512.2"))
if (length(ref_idx) == 0) stop("Reference NC_045512.2 not found.")
ref_hdr <- fasta$header[ref_idx[1]]
ref_seq <- fasta$seq[ref_idx[1]]
cat(sprintf("Reference : >%s\n\n", ref_hdr))
ref_hdr_clean <- clean_name(ref_hdr)

# ── Province assignment ───────────────────────────────────────────────────────
has_prov <- grepl("Canada/[A-Za-z]{2}-", fasta$header)
province <- ifelse(has_prov,
                   toupper(sub(".*Canada/([A-Za-z]{2})-.*", "\\1",
                               fasta$header)),
                   NA_character_)
provinces <- sort(unique(na.omit(province)))
cat(sprintf("Provinces : %s\n\n", paste(provinces, collapse = ", ")))

# ── Per-province processing ───────────────────────────────────────────────────
process_province <- function(prov) {

  log <- character(0)
  lg  <- function(...) { log <<- c(log, sprintf(...)) }
  lg("── %s ──────────────────────────────", prov)

  idx_prov <- which(province == prov)
  hdrs <- c(ref_hdr, fasta$header[idx_prov])
  seqs <- c(ref_seq, fasta$seq[idx_prov])
  lg("  [1] Raw          : %d sequences (incl. reference)", length(hdrs))

  # 1 – save raw
  f_raw <- file.path(output_dir, sprintf("%s_01_raw.fasta", prov))
  write_fasta(f_raw, hdrs, seqs)

  # 2 – remove sequences with indels; always keep reference
  keep  <- !grepl("-", seqs); keep[1] <- TRUE
  hdrs2 <- hdrs[keep]; seqs2 <- seqs[keep]
  lg("  [2] No-indels    : %d removed, %d retained",
     sum(!keep), length(hdrs2))

  f_noindel <- file.path(output_dir, sprintf("%s_02_no_indels.fasta", prov))
  write_fasta(f_noindel, hdrs2, seqs2)

  if (length(hdrs2) < 3) {
    lg("  [!] < 3 sequences after indel filter — skipping CD-HIT and tree.")
    return(log)
  }

  # 3 – CD-HIT-EST 99%
  f_cdhit <- file.path(output_dir, sprintf("%s_03_cdhit99.fasta", prov))
  tmp_log <- tempfile(pattern = paste0("cdhit_", prov, "_"), fileext = ".log")
  cmd <- sprintf(
    "cd-hit-est -i %s -o %s -c 1.0 -n 8 -T %d -M 0 -d 0 > %s 2>&1",
    f_noindel, f_cdhit, NCORES, tmp_log
  )
  ret <- system(cmd, intern = FALSE)
  if (ret != 0) {
    lg("  [!] CD-HIT-EST failed (exit %d); log: %s", ret, tmp_log)
    return(log)
  }
  cdhit_fa <- read_fasta(f_cdhit)
  lg("  [3] CD-HIT 99%%   : %d sequences retained", length(cdhit_fa$header))

  if (length(cdhit_fa$header) < 3) {
    lg("  [!] < 3 sequences after CD-HIT — skipping further steps.")
    return(log)
  }

  # 4 – Clean headers + trim stop codon (last 3 nt)
  hdrs4 <- vapply(cdhit_fa$header, clean_name, character(1L))
  seqs4 <- substr(cdhit_fa$seq, 1L, nchar(cdhit_fa$seq) - 3L)

  f_final <- file.path(output_dir, sprintf("%s_04_final.fasta", prov))
  write_fasta(f_final, hdrs4, seqs4)
  lg("  [4] Final clean  : headers sanitised, last 3 nt trimmed -> %s",
     basename(f_final))
  lg("      Example name : %s", hdrs4[min(2L, length(hdrs4))])

  # 5 – ML tree: HKY + Gamma_4
  seq_lens <- nchar(seqs4)
  if (length(unique(seq_lens)) > 1) {
    lg("  [!] Unequal sequence lengths — cannot build tree without re-alignment.")
    return(log)
  }

  tree_ml <- tryCatch({
    dnabin <- as.DNAbin(lapply(
      setNames(as.list(seqs4), hdrs4),
      function(s) strsplit(s, "")[[1]]
    ))
    pdat  <- phyDat(dnabin, type = "DNA")
    dm    <- dist.ml(pdat, model = "F81")
    tree0 <- NJ(dm)

    fit0 <- pml(tree0, pdat)
    fit  <- optim.pml(fit0,
                      model         = "HKY",
                      optGamma      = TRUE,
                      k             = 4L,
                      optInv        = FALSE,
                      rearrangement = "stochastic",
                      control       = pml.control(trace = 0))

    kappa_val <- fit$Q[1] / fit$Q[2]
    lg("  [5] ML tree      : logLik=%.2f  shape=%.4f  kappa=%.4f",
       fit$logLik, fit$shape, kappa_val)

    # Reroot on cleaned reference label
    tr <- fit$tree
    ref_tip <- grep(ref_hdr_clean, tr$tip.label, fixed = TRUE, value = TRUE)
    if (length(ref_tip) == 1) {
      tr <- root(tr, outgroup = ref_tip, resolve.root = TRUE)
      lg("             rooted on: %s", ref_tip)
    } else {
      lg("  [!] Reference tip not uniquely identified — tree saved unrooted.")
    }

    f_tree <- file.path(output_dir, sprintf("%s_tree.nwk", prov))
    write.tree(tr, file = f_tree)
    lg("             saved  -> %s", basename(f_tree))

    tr   # return tree for step 6

  }, error = function(e) {
    lg("  [!] Tree error: %s", conditionMessage(e))
    NULL
  })

  # 6 – HyPhy NEXUS (alignment + tree)
  if (!is.null(tree_ml)) {
    f_nex <- file.path(output_dir, sprintf("%s_hyphy.nex", prov))
    tryCatch({
      write_hyphy_nexus(f_nex, hdrs4, seqs4, tree_ml)
      lg("  [6] HyPhy NEXUS  : DATA + TREES blocks -> %s", basename(f_nex))
    }, error = function(e) {
      lg("  [!] NEXUS write error: %s", conditionMessage(e))
    })
  }

  log
}

# ── Parallel execution ────────────────────────────────────────────────────────
cat("Processing provinces (parallel)...\n\n")
results <- mclapply(provinces, process_province,
                    mc.cores       = NCORES,
                    mc.preschedule = FALSE)

for (log in results) cat(paste(log, collapse = "\n"), "\n\n", sep = "")

# ── Summary ───────────────────────────────────────────────────────────────────
cat("── Summary ──────────────────────────────────────────────────────\n")
files <- sort(list.files(output_dir, pattern = "\\.(fasta|nwk|nex)$"))
for (f in files) {
  fp <- file.path(output_dir, f)
  if (grepl("\\.fasta$", f)) {
    n <- length(grep("^>", readLines(fp)))
    cat(sprintf("  %-50s  %d seqs\n", f, n))
  } else if (grepl("\\.nwk$", f)) {
    cat(sprintf("  %-50s  (Newick tree)\n", f))
  } else if (grepl("\\.nex$", f)) {
    cat(sprintf("  %-50s  (HyPhy NEXUS)\n", f))
  }
}
cat(sprintf("\nDone. All output in '%s/'\n", output_dir))
