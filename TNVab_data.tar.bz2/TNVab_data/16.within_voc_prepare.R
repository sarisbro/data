# within_voc_prepare.R  (step 2 of 3 of the within-VOC MEME re-analysis)
# ======================================================================
# For every (province, phase) sub-alignment written by within_voc_partition.py,
# infer an HKY+Gamma_4 ML tree, reroot on the reference, and write a HyPhy-ready
# NEXUS plus a MEME batch file. The tree-building and NEXUS-writing code is a
# faithful copy of split_by_province.R / generate_hyphy_scripts.R so the
# within-VOC analysis uses exactly the same model and file conventions as the
# whole-alignment analysis in the manuscript.
#
# Requires: ape, phangorn  (the same packages used for the main pipeline).
#
# Usage:
#   Rscript within_voc_prepare.R [within_voc_dir] [hyphy_exec]
# Defaults: within_voc_dir = within_voc ; hyphy_exec = hyphy

suppressPackageStartupMessages({
  library(ape)
  library(phangorn)
})

args    <- commandArgs(trailingOnly = TRUE)
voc_dir <- if (length(args) >= 1) args[1] else "within_voc"
hyphy   <- if (length(args) >= 2) args[2] else "hyphy"
if (!dir.exists(voc_dir)) stop("directory not found: ", voc_dir)

# ---- helpers copied from the main pipeline -------------------------------

read_fasta <- function(path) {
  lines <- readLines(path, warn = FALSE)
  hdr_idx <- grep("^>", lines)
  headers <- sub("^>", "", lines[hdr_idx])
  starts  <- hdr_idx + 1L
  ends    <- c(hdr_idx[-1] - 1L, length(lines))
  seqs    <- vapply(seq_along(hdr_idx),
                    function(i) paste0(lines[starts[i]:ends[i]], collapse = ""),
                    character(1L))
  list(header = headers, seq = seqs)
}

write_hyphy_nexus <- function(path, headers, seqs, tree) {
  ntax  <- length(headers)
  nch   <- unique(nchar(seqs))
  if (length(nch) != 1L) stop("unequal sequence lengths for NEXUS export")
  maxw  <- max(nchar(headers))
  con <- file(path, open = "w"); on.exit(close(con))
  writeLines("#NEXUS", con); writeLines("", con)
  writeLines("BEGIN DATA;", con)
  writeLines(sprintf("  DIMENSIONS NTAX=%d NCHAR=%d;", ntax, nch), con)
  writeLines("  FORMAT DATATYPE=DNA MISSING=? GAP=- INTERLEAVE=NO;", con)
  writeLines("  MATRIX", con)
  for (i in seq_along(headers)) {
    label <- formatC(headers[i], width = maxw, flag = "-")
    writeLines(sprintf("    %s  %s", label, toupper(seqs[i])), con)
  }
  writeLines("  ;", con); writeLines("END;", con); writeLines("", con)
  writeLines("BEGIN TREES;", con)
  writeLines(sprintf("  TREE tree1 = %s", write.tree(tree)), con)
  writeLines("END;", con)
  invisible(path)
}

make_meme_bf <- function(nex_abs, json_abs, tag) {
  sprintf(
'/* HyPhy MEME  -  within-VOC dataset %s
   Mixed Effects Model of Evolution (Murrell et al. 2012).
   CLI equivalent:
     hyphy meme --alignment %s --code Universal --branches All --pvalue 0.1 --output %s
*/
ExecuteAFile (
    HYPHY_LIB_DIRECTORY + "TemplateBatchFiles" + DIRECTORY_SEPARATOR +
    "SelectionAnalyses" + DIRECTORY_SEPARATOR + "MEME.bf",
    { "code":"Universal", "alignment":"%s", "branches":"All",
      "pvalue":"0.1", "output":"%s" }
);
', tag, nex_abs, json_abs, nex_abs, json_abs)
}

# ---- build tree + NEXUS + MEME bf per sub-alignment -----------------------

fastas <- sort(list.files(voc_dir, pattern = "\\.fasta$", full.names = TRUE))
fastas <- fastas[!grepl("manifest", fastas)]
if (length(fastas) == 0) stop("no sub-alignment FASTAs in ", voc_dir,
                              " (run within_voc_partition.py first)")

shell <- c("#!/usr/bin/env bash",
           "# run_within_voc_meme.sh  (auto-generated)",
           sprintf('HYPHY="${HYPHY:-%s}"', hyphy),
           'echo "HyPhy: $HYPHY"', "")

for (fa in fastas) {
  tag  <- sub("\\.fasta$", "", basename(fa))
  cat(sprintf("== %s ==\n", tag))
  d <- read_fasta(fa)
  hdrs <- d$header; seqs <- toupper(d$seq)

  if (length(unique(nchar(seqs))) > 1) {
    cat("  [!] unequal lengths; skipped\n"); next
  }
  tree <- tryCatch({
    dnabin <- as.DNAbin(lapply(setNames(as.list(seqs), hdrs),
                               function(s) strsplit(s, "")[[1]]))
    pdat  <- phyDat(dnabin, type = "DNA")
    tree0 <- NJ(dist.ml(pdat, model = "F81"))
    fit0  <- pml(tree0, pdat)
    fit   <- optim.pml(fit0, model = "HKY", optGamma = TRUE, k = 4L,
                       optInv = FALSE, rearrangement = "stochastic",
                       control = pml.control(trace = 0))
    tr <- fit$tree
    ref_tip <- grep("NC_045512", tr$tip.label, fixed = TRUE, value = TRUE)
    if (length(ref_tip) == 1)
      tr <- root(tr, outgroup = ref_tip, resolve.root = TRUE)
    tr$node.label <- NULL   # drop node labels: rooting can set them to 'NA',
                            # which HyPhy rejects ("no model for node 'NA'")
    write.tree(tr, file = file.path(voc_dir, sprintf("%s_tree.nwk", tag)))
    cat(sprintf("  ML tree logLik=%.1f shape=%.3f\n", fit$logLik, fit$shape))
    tr
  }, error = function(e) { cat("  [!] tree error:", conditionMessage(e), "\n"); NULL })
  if (is.null(tree)) next

  nex <- file.path(voc_dir, sprintf("%s_hyphy.nex", tag))
  write_hyphy_nexus(nex, hdrs, seqs, tree)
  nex_abs  <- normalizePath(nex)
  json_abs <- sub("\\.nex$", ".MEME.json", nex_abs)
  bf <- file.path(voc_dir, sprintf("%s_meme.bf", tag))
  writeLines(make_meme_bf(nex_abs, json_abs, tag), bf)

  shell <- c(shell,
    sprintf('echo "== %s : MEME =="', tag),
    sprintf('$HYPHY meme --alignment "%s" --code Universal --branches All \\', nex_abs),
    sprintf('            --pvalue 0.1 --output "%s"', json_abs), "")
}

sh <- file.path(voc_dir, "run_within_voc_meme.sh")
writeLines(shell, sh); Sys.chmod(sh, "0755")
cat(sprintf("\nWrote NEXUS + MEME .bf for each dataset and %s\n", basename(sh)))
cat(sprintf("Run:  cd %s && bash run_within_voc_meme.sh\n", normalizePath(voc_dir)))
cat("Then: python3 within_voc_summarize.py\n")
