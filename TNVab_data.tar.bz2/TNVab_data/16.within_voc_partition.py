"""
within_voc_partition.py  (step 1 of 3 of the within-VOC MEME re-analysis)
========================================================================
This script partitions each provincial final alignment by VOC dominance phase
(assigned from the collection date, since GISAID Pango calls were not retained
in the tip labels) and writes one codon sub-alignment per (province, phase),
each with the reference sequence injected for rooting.

Phase assignment
----------------
Canadian national dominance windows (same boundaries as the manuscript's
variant-phase covariate). Beta and Gamma never dominated in Canada and so cannot
be separated from the Alpha window by date alone; sequences from that period are
assigned to "Alpha". This is stated as a limitation -- the point of the analysis
is to remove the *phase-defining* substitutions, which the dominance binning
does.

Next steps
----------
  2. within_voc_prepare.R      -> HKY+Gamma4 ML tree + HyPhy NEXUS + MEME .bf
                                  (mirrors split_by_province.R exactly)
  3. run_within_voc_meme.sh    -> runs hyphy meme on every sub-alignment
  4. within_voc_summarize.py   -> tabulates within-VOC selected sites and flags
                                  which are defining OF THAT phase
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent
OUTDIR = HERE / "within_voc"

PROVINCES = ["AB", "BC", "MB", "ON", "QC", "SK"]

# dominance windows [start, end) as (name, start_iso); last window is open-ended
PHASES: list[tuple[str, str]] = [
    ("B1",      "2019-01-01"),   # pre-VOC / wildtype B.1
    ("Alpha",   "2021-01-01"),   # Alpha (also captures minority Beta/Gamma)
    ("Delta",   "2021-07-01"),
    ("Omicron", "2021-12-15"),   # BA.1 and all later Omicron sublineages
]
PHASE_STARTS = pd.to_datetime([d for _, d in PHASES])
PHASE_NAMES = [n for n, _ in PHASES]

DATE_RE = re.compile(r"(\d{4}-\d{2}-\d{2})\D*$")   # trailing ISO date in header


def phase_for(date: pd.Timestamp) -> str:
    import numpy as np
    idx = int(np.searchsorted(PHASE_STARTS.values, np.datetime64(date), "right")) - 1
    return PHASE_NAMES[max(0, idx)]


def read_fasta(path: Path):
    hdr, seq, headers, seqs = None, [], [], []
    with open(path) as fh:
        for line in fh:
            line = line.rstrip("\n")
            if line.startswith(">"):
                if hdr is not None:
                    headers.append(hdr); seqs.append("".join(seq))
                hdr, seq = line[1:], []
            else:
                seq.append(line)
    if hdr is not None:
        headers.append(hdr); seqs.append("".join(seq))
    return headers, seqs


def write_fasta(path: Path, headers, seqs, wrap=80):
    with open(path, "w") as fh:
        for h, s in zip(headers, seqs):
            fh.write(f">{h}\n")
            for i in range(0, len(s), wrap):
                fh.write(s[i:i + wrap] + "\n")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--min-n", type=int, default=40,
                    help="minimum sequences (excl. reference) to emit a "
                         "(province, phase) sub-alignment (default 40)")
    args = ap.parse_args()
    OUTDIR.mkdir(exist_ok=True)

    manifest = []
    for prov in PROVINCES:
        fn = HERE / f"{prov}_04_final.fasta"
        if not fn.exists():
            print(f"[skip] {fn.name} missing"); continue
        headers, seqs = read_fasta(fn)

        # locate reference (kept in every sub-alignment for rooting)
        ref_h = ref_s = None
        for h, s in zip(headers, seqs):
            if h.startswith("NC_045512"):
                ref_h, ref_s = h, s
                break

        buckets: dict[str, list[int]] = {n: [] for n in PHASE_NAMES}
        for i, h in enumerate(headers):
            if h.startswith("NC_045512"):
                continue
            m = DATE_RE.search(h)
            if not m:
                continue
            d = pd.to_datetime(m.group(1), errors="coerce")
            if pd.isna(d):
                continue
            buckets[phase_for(d)].append(i)

        for phase, idx in buckets.items():
            n = len(idx)
            if n < args.min_n:
                print(f"[{prov} {phase:<8}] {n:>4} seqs  (< {args.min_n}, skipped)")
                manifest.append(dict(province=prov, phase=phase, n=n, emitted=False))
                continue
            out_h = ([ref_h] if ref_h else []) + [headers[i] for i in idx]
            out_s = ([ref_s] if ref_s else []) + [seqs[i] for i in idx]
            out = OUTDIR / f"{prov}_{phase}.fasta"
            write_fasta(out, out_h, out_s)
            print(f"[{prov} {phase:<8}] {n:>4} seqs  -> {out.name}")
            manifest.append(dict(province=prov, phase=phase, n=n, emitted=True,
                                 fasta=out.name))

    man = pd.DataFrame(manifest)
    man_out = OUTDIR / "within_voc_manifest.tsv"
    man.to_csv(man_out, sep="\t", index=False)
    n_emit = int(man["emitted"].sum()) if len(man) else 0
    print(f"\n[manifest] {man_out.relative_to(HERE)}  "
          f"({n_emit} sub-alignments emitted)")
    print("[next] Rscript within_voc_prepare.R   # trees + HyPhy NEXUS + MEME .bf")


if __name__ == "__main__":
    main()
