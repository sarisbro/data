"""
panel_build.py
==============
Assemble a *balanced* province x week panel for the two-way fixed-effects
regression that replaces the VOC-residualization / cross-correlation analysis
(Reviewer 2, section 2.1).

The panel has one row per (province, week) and the following columns:

    province            two-letter code (AB, BC, MB, ON, QC, SK)
    week                Monday-anchored week start (ISO date)
    month               calendar month (YYYY-MM-01) -- coarser time FE option
    n_events            outcome: count of strict episodic-selection events whose
                        child_date_iso falls in that week (the same events used
                        in the manuscript)
    vax                 weekly NEW dose-1 administrations per 100k residents
                        (the deployment-INTENSITY regressor; direct analogue of
                        the series in manuscript Fig. 2)
    vax_cum             cumulative dose-1 per 100k up to and including that week
                        (>=1-dose coverage proxy; alternative exposure measure)
    seq                 sequencing effort: number of retained tip sequences with
                        that collection week in the province's final alignment
                        (the sampling-heterogeneity control promised in the
                        abstract; Reviewer 1 also asks for this)
    vax_lag{k}          vax shifted so that vax_lag{k}[t] = vax[t-k], for
                        k in LAGS. Positive k means "selection could follow
                        vaccine deployment by k weeks" -- the biologically
                        plausible immune-escape direction.

Why these choices
-----------------
* The panel is balanced (every province observed in every week of the common
  grid) so the two-way within (fixed-effects) transform is exact.
* vax is expressed per 100k so provinces are comparable in *intensity*; with a
  week fixed effect in the model, a purely national rollout is absorbed and the
  vaccine coefficient is identified only from *cross-provincial* differences in
  timing/intensity within the same week -- exactly the contrast the reviewer
  wants, and strictly finer than the VOC-phase indicator it replaces.
* seq (sequencing effort) is included so the regression can separate
  "vaccination selects for spike substitutions" from "vaccination co-varies with
  the surveillance regime that generates the branches we analyse".

Inputs (all resolved relative to this file's directory)
-------
    selection_events.tsv                    strict events (default outcome)
    selection_events_suggestive.tsv         suggestive events (robustness)
    vaccine_administration_dose_1_pt.csv     CCODWG/PHAC daily dose-1 by region
    AB_04_final.fasta ... SK_04_final.fasta  final per-province alignments

Output
------
    panel_province_week.tsv

Usage
-----
    python3 panel_build.py                       # strict events, default lags
    python3 panel_build.py --events suggestive   # suggestive-threshold outcome
    python3 panel_build.py --max-lag 24 --lag-step 2
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent

# ---- provinces analysed (those contributing strict events in the MS) --------
PROVINCES = ["AB", "BC", "MB", "ON", "QC", "SK"]

# StatCan 2021 mid-year provincial population estimates (for per-100k scaling)
PROV_POP_2021 = {
    "BC": 5_214_805, "AB": 4_442_879, "SK": 1_179_844, "MB": 1_383_765,
    "ON": 14_755_211, "QC": 8_604_495,
    "NB": 789_225, "NS": 992_055, "PE": 164_318, "NL": 522_103,
}

WEEK_FREQ = "W-MON"   # weeks anchored on Monday (matches the manuscript CCF)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--events", choices=["strict", "suggestive"], default="strict",
                   help="which MEME event set to use as the outcome")
    p.add_argument("--events-file", default=None,
                   help="explicit path to an events TSV (overrides --events; e.g. "
                        "selection_events_nondefining.tsv for the Reviewer-1 check)")
    p.add_argument("--max-lag", type=int, default=24,
                   help="maximum vaccine lag in weeks (default 24)")
    p.add_argument("--lag-step", type=int, default=2,
                   help="spacing between lag columns in weeks (default 2)")
    p.add_argument("--pad-weeks", type=int, default=12,
                   help="weeks of padding added around the event window")
    p.add_argument("--out", default="panel_province_week.tsv",
                   help="output TSV filename")
    return p.parse_args()


def load_events(kind: str, events_file: str | None = None) -> pd.DataFrame:
    if events_file:
        fn = Path(events_file)
        if not fn.is_absolute():
            fn = HERE / fn
    else:
        fn = HERE / ("selection_events.tsv" if kind == "strict"
                     else "selection_events_suggestive.tsv")
    if not fn.exists():
        raise FileNotFoundError(f"event file not found: {fn}")
    df = pd.read_csv(fn, sep="\t")
    df["date"] = pd.to_datetime(df["child_date_iso"], errors="coerce")
    df = df.dropna(subset=["date"])
    df = df[df["province"].isin(PROVINCES)].copy()
    print(f"[events]  {fn.name}: {len(df)} events across "
          f"{df['province'].nunique()} provinces "
          f"({df['date'].min().date()} .. {df['date'].max().date()})")
    return df


def load_vaccine_weekly(weeks: pd.DatetimeIndex) -> pd.DataFrame:
    """Weekly NEW dose-1 per 100k, indexed by week, columns = provinces."""
    fn = HERE / "vaccine_administration_dose_1_pt.csv"
    if not fn.exists():
        raise FileNotFoundError(f"vaccine file not found: {fn}")
    raw = pd.read_csv(fn)
    raw.columns = [c.strip().strip('"') for c in raw.columns]
    raw["date"] = pd.to_datetime(raw["date"], errors="coerce")
    raw = raw.dropna(subset=["date"])
    # value_daily = newly administered that day; clip rare negative corrections
    raw["value_daily"] = pd.to_numeric(raw["value_daily"], errors="coerce").fillna(0)
    raw["value_daily"] = raw["value_daily"].clip(lower=0)
    weekly = (raw.groupby(["region", pd.Grouper(key="date", freq=WEEK_FREQ)])
                 ["value_daily"].sum()
                 .unstack("region", fill_value=0))
    weekly = weekly.reindex(weeks, fill_value=0)
    out = pd.DataFrame(index=weeks)
    for prov in PROVINCES:
        col = weekly[prov] if prov in weekly.columns else 0.0
        out[prov] = np.asarray(col, dtype=float) / PROV_POP_2021[prov] * 100_000.0
    print(f"[vaccine] weekly new dose-1 per 100k built for {PROVINCES}")
    return out


def load_seq_effort_weekly(weeks: pd.DatetimeIndex) -> pd.DataFrame:
    """Weekly sequencing effort (tip counts), indexed by week, cols = provinces.

    Collection date is the final underscore-delimited token of each FASTA
    header, e.g.  >hCoV-19_Canada_AB-ABPHL-11851_2021_2021-04-04 -> 2021-04-04.
    The reference sequence (NC_045512...) is skipped.
    """
    out = pd.DataFrame(index=weeks)
    for prov in PROVINCES:
        fn = HERE / f"{prov}_04_final.fasta"
        dates = []
        if fn.exists():
            with open(fn) as fh:
                for line in fh:
                    if not line.startswith(">"):
                        continue
                    if line.startswith(">NC_045512"):
                        continue
                    tok = line.strip().split("_")[-1]      # trailing YYYY-MM-DD
                    d = pd.to_datetime(tok, errors="coerce")
                    if pd.notna(d):
                        dates.append(d)
        else:
            print(f"[seq]     WARNING: {fn.name} missing; seq set to 0 for {prov}")
        if dates:
            s = (pd.Series(1, index=pd.DatetimeIndex(dates))
                   .resample(WEEK_FREQ).size()
                   .reindex(weeks, fill_value=0))
            out[prov] = np.asarray(s, dtype=float)
        else:
            out[prov] = 0.0
        print(f"[seq]     {prov}: {int(out[prov].sum())} dated tips")
    return out


def main() -> None:
    args = parse_args()
    ev = load_events(args.events, args.events_file)

    # ---- common weekly grid (event window + padding) ------------------------
    t_lo = (ev["date"].min() - pd.Timedelta(weeks=args.pad_weeks)
            ).to_period(WEEK_FREQ).start_time
    t_hi = (ev["date"].max() + pd.Timedelta(weeks=args.pad_weeks)
            ).to_period(WEEK_FREQ).start_time
    weeks = pd.date_range(t_lo, t_hi, freq=WEEK_FREQ)
    print(f"[grid]    {weeks[0].date()} .. {weeks[-1].date()}  ({len(weeks)} weeks)")

    vax = load_vaccine_weekly(weeks)
    seq = load_seq_effort_weekly(weeks)

    # ---- per-province weekly outcome ---------------------------------------
    lags = list(range(0, args.max_lag + 1, args.lag_step))
    rows = []
    for prov in PROVINCES:
        ev_p = ev[ev["province"] == prov]
        y = (ev_p.set_index("date").resample(WEEK_FREQ).size()
                 .reindex(weeks, fill_value=0).astype(int).values)
        v = vax[prov].values
        vcum = np.cumsum(v)
        for j, wk in enumerate(weeks):
            row = dict(province=prov,
                       week=wk.date().isoformat(),
                       month=wk.to_period("M").start_time.date().isoformat(),
                       n_events=int(y[j]),
                       vax=float(v[j]),
                       vax_cum=float(vcum[j]),
                       seq=float(seq[prov].values[j]))
            for k in lags:
                row[f"vax_lag{k}"] = float(v[j - k]) if j - k >= 0 else np.nan
            rows.append(row)

    panel = pd.DataFrame(rows)
    out = HERE / args.out
    panel.to_csv(out, sep="\t", index=False, float_format="%.6g")

    # ---- provenance summary -------------------------------------------------
    print(f"\n[panel]   {panel.shape[0]} rows "
          f"({len(PROVINCES)} provinces x {len(weeks)} weeks), "
          f"{panel.shape[1]} columns")
    print(f"[panel]   lags built: {lags}")
    print(f"[panel]   total events in panel: {int(panel['n_events'].sum())}")
    print(f"[panel]   weeks with any vaccination: "
          f"{int((panel.groupby('week')['vax'].sum() > 0).sum())}")
    print(f"[panel]   wrote {out}")


if __name__ == "__main__":
    main()
