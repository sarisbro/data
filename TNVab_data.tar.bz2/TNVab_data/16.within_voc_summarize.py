"""
within_voc_summarize.py  (step 3 of 3 of the within-VOC MEME re-analysis)
========================================================================
Parses the within-VOC MEME JSONs produced by run_within_voc_meme.sh and asks the
question Reviewer 1 posed: once we test for selection *within* a VOC dominance
phase -- so that mutations defining that phase are fixed and cannot register --
which sites remain under episodic selection, and are they the phase-defining
mutations or something else?

For each (province, phase) it reports the codons with MEME p <= threshold and
flags whether each is a defining substitution OF THAT PHASE. A site under
selection within a phase that is NOT defining of that phase is genuine
within-background selection (the signal that is *not* an artifact of the variant
sweeping to fixation).

Run after:
    python3 within_voc_partition.py
    Rscript  within_voc_prepare.R
    (cd within_voc && bash run_within_voc_meme.sh)
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent
VOC_DIR = HERE / "within_voc"

# reuse the curated defining-site table from the exclusion analysis
from lineage_defining_analysis import DEFINING   # noqa: E402

# which VOC tags in DEFINING count as "defining of" each dominance phase
PHASE_TAGS = {
    "B1":      {"all"},                        # only D614G is 'defining' late-B.1
    "Alpha":   {"Alpha"},
    "Delta":   {"Delta"},
    "Omicron": {"Omicron", "OmicronBA2", "BA45"},
}


def phase_defining(phase: str) -> set[int]:
    # 'all' = fixed in every VOC (e.g. D614G), so it is defining of every phase
    tags = PHASE_TAGS.get(phase, set()) | {"all"}
    return {c for c, vocs in DEFINING.items() if tags.intersection(vocs)}


def meme_sites(json_path: Path, pthr: float) -> list[tuple[int, float, int]]:
    """Return [(codon_1based, p_value, n_branches_under_selection), ...]."""
    d = json.load(open(json_path))
    content = d["MLE"]["content"]["0"]        # one row per codon, 13 columns
    hits = []
    for i, row in enumerate(content):
        pval = row[6]                          # 'p-value' column
        nbr = row[7]                           # '# branches under selection'
        if pval is not None and pval <= pthr:
            hits.append((i + 1, float(pval), int(nbr)))
    return hits


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--pvalue", type=float, default=0.1)
    ap.add_argument("--voc-dir", default=str(VOC_DIR))
    args = ap.parse_args()
    vdir = Path(args.voc_dir)

    jsons = sorted(vdir.glob("*_hyphy.MEME.json"))
    if not jsons:
        raise SystemExit(f"no *_hyphy.MEME.json in {vdir}; run the pipeline first "
                         "(within_voc_partition.py -> within_voc_prepare.R -> "
                         "run_within_voc_meme.sh)")

    rows = []
    for jp in jsons:
        tag = jp.name.replace("_hyphy.MEME.json", "")
        prov, phase = tag.split("_", 1)
        defset = phase_defining(phase)
        if jp.stat().st_size == 0:
            print(f"  [skip] {jp.name} is empty (HyPhy run did not complete)")
            continue
        try:
            hits = meme_sites(jp, args.pvalue)
        except (json.JSONDecodeError, KeyError) as e:
            print(f"  [skip] {jp.name} is not valid MEME JSON ({e}); re-run it")
            continue
        for codon, pval, nbr in hits:
            rows.append(dict(province=prov, phase=phase, codon=codon,
                             p_value=pval, n_branches=nbr,
                             defining_of_phase=codon in defset,
                             defining_any_voc=codon in DEFINING))
    df = pd.DataFrame(rows)
    if df.empty:
        print("No sites under selection at the chosen threshold.")
        return

    out = vdir / "within_voc_selected_sites.tsv"
    df.sort_values(["province", "phase", "p_value"]).to_csv(out, sep="\t", index=False)

    # ---- summary ------------------------------------------------------------
    print("[within-VOC MEME] sites with p <= "
          f"{args.pvalue} per (province, phase):\n")
    summ = (df.groupby(["province", "phase"])
              .agg(n_sites=("codon", "nunique"),
                   n_defining_of_phase=("defining_of_phase", "sum"),
                   n_not_defining=("defining_of_phase", lambda s: int((~s).sum())))
              .reset_index())
    print(summ.to_string(index=False))

    tot = df["codon"].nunique()
    ndp = df.loc[df.defining_of_phase, "codon"].nunique()
    print(f"\n[key result] across all within-phase analyses, "
          f"{tot} distinct selected codons; "
          f"{ndp} are defining of their own phase, "
          f"{tot - ndp} are NOT -- the latter are within-background selection "
          f"that is not an artifact of variant emergence.")
    print(f"[recurrent non-phase-defining] "
          + ", ".join(str(c) for c in sorted(
              df.loc[~df.defining_of_phase, "codon"].value_counts()
                .head(12).index)))
    print(f"\n  -> {out}")


if __name__ == "__main__":
    main()
