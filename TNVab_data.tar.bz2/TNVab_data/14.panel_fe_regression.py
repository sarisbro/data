"""
panel_fe_regression.py
======================
Two-way (province + time) FIXED-EFFECTS panel regression of episodic-selection
event counts on vaccine-deployment intensity, replacing the VOC-residualization
+ cross-correlation analysis (Reviewer 2, section 2.1; abstract's promised
"lagged panel regression ... that accounted for province and time effects ...
and sampling heterogeneity").

Model
-----
For province i and time period t (week or month):

    n_events_{it} = alpha_i + gamma_t + beta * vax_{i,t-k} + delta * log1p(seq_{it}) + e_{it}

    alpha_i : province fixed effect  (absorbs level differences in sampling,
              epidemic size, tree size, etc.)
    gamma_t : time fixed effect      (absorbs everything common across provinces
              in that period -- the national variant-emergence wave, national
              booster scheduling, season -- and is STRICTLY FINER than the
              VOC-phase indicator it replaces, which is what the reviewer asked
              for)
    vax     : weekly new dose-1 per 100k, optionally lagged by k weeks
              (positive k = the immune-escape direction: selection FOLLOWS
              vaccine deployment)
    seq     : sequencing effort (log1p tips that week) -- the sampling-effort
              control. Identifies whether vaccine intensity, net of surveillance
              intensity, is associated with selection.

Because province+time FE are absorbed and a national rollout is common across
provinces within a period, beta is identified only from WITHIN-period,
CROSS-province differences in vaccine intensity -- a conservative, interpretable
"within estimator". A positive, significant beta at a plausible lag (8-24 wk)
would support the vaccine-escape hypothesis; the manuscript's claim is that beta
is not distinguishable from zero once variant emergence (now the time FE) is
removed.

Estimation & inference
----------------------
* Balanced two-way WITHIN transform (exact for a balanced panel):
      x~_{it} = x_{it} - xbar_{i.} - xbar_{.t} + xbar_{..}
  then OLS with no intercept (Frisch-Waugh-Lovell).
* Province-CLUSTERED covariance (G = 6 clusters).
* Because 6 clusters is few, the primary p-values come from a wild CLUSTER
  bootstrap with the null imposed (Rademacher weights); with G = 6 all 2^6 = 64
  sign vectors are ENUMERATED, giving an exact restricted-wild-bootstrap p-value
  rather than a Monte-Carlo approximation.
* A linear model is the reviewer's request and is directly interpretable; a
  two-way FE POISSON model (count-appropriate) is also fit as a robustness check
  when statsmodels is available.

Specifications reported
-----------------------
1. Single-lag sweep : one model per lag k (mirrors the CCF lag scan, but as a
   proper FE panel regression). beta_k, clustered SE, wild-bootstrap p.
2. Joint distributed lag : all lags in one model; per-lag betas, the cumulative
   effect sum(beta_k), and a joint test that all vaccine coefficients are zero.

Outputs
-------
    panel_fe_singlelag_{time}.tsv       per-lag beta / SE / p (linear + poisson)
    panel_fe_jointlag_{time}.tsv        joint distributed-lag coefficients
    panel_fe_coefficients_{time}.pdf    beta_k vs lag figure (Fig-2 replacement)
    panel_fe_coefficients_{time}.png

Usage
-----
    python3 panel_fe_regression.py                 # week time FE (finest)
    python3 panel_fe_regression.py --time month    # month time FE (more power)
    python3 panel_fe_regression.py --panel panel_province_week.tsv
"""

from __future__ import annotations

import argparse
import itertools
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent


# ============================ estimator core ==============================

def two_way_within(df: pd.DataFrame, cols, entity: str, time: str) -> np.ndarray:
    """Exact balanced two-way within transform of the given columns.

    Returns an (N x len(cols)) array of demeaned values.
    """
    out = np.empty((len(df), len(cols)), dtype=float)
    ent = df[entity].values
    tim = df[time].values
    for j, c in enumerate(cols):
        x = df[c].astype(float).values
        s = pd.Series(x)
        ent_mean = s.groupby(ent).transform("mean").values
        tim_mean = s.groupby(tim).transform("mean").values
        out[:, j] = x - ent_mean - tim_mean + x.mean()
    return out


def _ols(yw: np.ndarray, Xw: np.ndarray):
    """OLS on already-demeaned data, no intercept. Returns beta, resid, XtX_inv."""
    XtX = Xw.T @ Xw
    XtX_inv = np.linalg.pinv(XtX)
    beta = XtX_inv @ (Xw.T @ yw)
    resid = yw - Xw @ beta
    return beta, resid, XtX_inv


def cluster_vcov(Xw, resid, XtX_inv, clusters, n_absorbed):
    """Cluster-robust (province) covariance with a standard small-sample factor."""
    N, K = Xw.shape
    G = len(np.unique(clusters))
    meat = np.zeros((K, K))
    for g in np.unique(clusters):
        m = clusters == g
        Xg = Xw[m]
        ug = resid[m]
        s = Xg.T @ ug
        meat += np.outer(s, s)
    dof = N - K - n_absorbed
    c = (G / (G - 1.0)) * ((N - 1.0) / max(dof, 1))
    return c * (XtX_inv @ meat @ XtX_inv)


def fit_fe(df, ycol, xcols, entity, time):
    """Fit a linear two-way FE model; return a result dict."""
    dat = df.dropna(subset=[ycol] + list(xcols)).copy()
    demeaned = two_way_within(dat, [ycol] + list(xcols), entity, time)
    yw = demeaned[:, 0]
    Xw = demeaned[:, 1:]
    beta, resid, XtX_inv = _ols(yw, Xw)
    I = dat[entity].nunique()
    T = dat[time].nunique()
    n_absorbed = (I - 1) + (T - 1) + 1               # province + time + grand
    clusters = dat[entity].values
    V = cluster_vcov(Xw, resid, XtX_inv, clusters, n_absorbed)
    se = np.sqrt(np.diag(V))
    return dict(data=dat, yw=yw, Xw=Xw, beta=beta, resid=resid,
                XtX_inv=XtX_inv, V=V, se=se, xcols=list(xcols),
                clusters=clusters, I=I, T=T, N=len(dat))


# ---- restricted wild cluster bootstrap (enumerate all 2^G sign vectors) ----

def wild_bootstrap_p(res, test_idx, joint=False):
    """Restricted (null-imposed) wild cluster bootstrap p-value.

    test_idx : list of column indices (into Xw) whose coefficients are set to
               zero under the null. Single index -> t-test (two-sided);
               multiple -> Wald joint test.
    Enumerates all 2^G Rademacher sign vectors (exact for small G).
    """
    yw, Xw = res["yw"], res["Xw"]
    clusters = res["clusters"]
    uniq = np.unique(clusters)
    G = len(uniq)
    K = Xw.shape[1]
    keep = [j for j in range(K) if j not in test_idx]

    # observed statistic
    def stat_from(beta, V):
        if joint:
            b = beta[test_idx]
            Vsub = V[np.ix_(test_idx, test_idx)]
            return float(b @ np.linalg.pinv(Vsub) @ b)
        j = test_idx[0]
        return float(beta[j] / np.sqrt(V[j, j]))

    obs = stat_from(res["beta"], res["V"])

    # restricted fit (impose null): regress yw on the kept columns only
    if keep:
        Xr = Xw[:, keep]
        br, ur, _ = _ols(yw, Xr)
        fitted_r = Xr @ br
    else:
        ur = yw.copy()
        fitted_r = np.zeros_like(yw)

    n_absorbed_guess = (res["I"] - 1) + (res["T"] - 1) + 1
    count = 0
    total = 0
    for signs in itertools.product((-1.0, 1.0), repeat=G):
        sign_map = {g: s for g, s in zip(uniq, signs)}
        w = np.array([sign_map[c] for c in clusters])
        y_star = fitted_r + w * ur
        beta_s, resid_s, XtX_inv_s = _ols(y_star, Xw)
        V_s = cluster_vcov(Xw, resid_s, XtX_inv_s, clusters, n_absorbed_guess)
        st = stat_from(beta_s, V_s)
        total += 1
        if joint:
            if st >= obs:
                count += 1
        else:
            if abs(st) >= abs(obs):
                count += 1
    return count / total, obs


# ============================ analyses ====================================

def single_lag_sweep(df, lags, time, seqcol="log_seq"):
    rows = []
    for k in lags:
        xcols = [f"vax_lag{k}", seqcol]
        res = fit_fe(df, "n_events", xcols, "province", time)
        p_wb, tstat = wild_bootstrap_p(res, test_idx=[0], joint=False)
        j = 0
        rows.append(dict(
            lag_weeks=k,
            beta=res["beta"][j],
            se_cluster=res["se"][j],
            t=res["beta"][j] / res["se"][j],
            p_wildboot=p_wb,
            beta_seq=res["beta"][1],
            N=res["N"], I=res["I"], T=res["T"],
        ))
    return pd.DataFrame(rows)


def joint_distributed_lag(df, lags, time, seqcol="log_seq"):
    xcols = [f"vax_lag{k}" for k in lags] + [seqcol]
    res = fit_fe(df, "n_events", xcols, "province", time)
    vax_idx = list(range(len(lags)))
    # per-lag rows
    rows = []
    for j, k in enumerate(lags):
        rows.append(dict(term=f"vax_lag{k}", lag_weeks=k,
                         beta=res["beta"][j], se_cluster=res["se"][j],
                         t=res["beta"][j] / res["se"][j]))
    rows.append(dict(term="log_seq", lag_weeks=np.nan,
                     beta=res["beta"][-1], se_cluster=res["se"][-1],
                     t=res["beta"][-1] / res["se"][-1]))
    # cumulative (sustained-deployment) effect and its clustered SE
    L = np.zeros(len(res["beta"])); L[vax_idx] = 1.0
    cum = float(L @ res["beta"])
    cum_se = float(np.sqrt(L @ res["V"] @ L))
    # joint wild-bootstrap test that all vaccine coefficients are zero
    p_joint, wald = wild_bootstrap_p(res, test_idx=vax_idx, joint=True)
    summary = dict(cum_beta=cum, cum_se=cum_se,
                   joint_wald=wald, joint_p_wildboot=p_joint,
                   N=res["N"], I=res["I"], T=res["T"], K_vax=len(lags))
    return pd.DataFrame(rows), summary


def try_poisson(df, lags, time, seqcol="log_seq"):
    """Two-way FE Poisson (province + time dummies) single-lag sweep.
    Robustness for the count nature of the outcome. Requires statsmodels.
    """
    try:
        import statsmodels.api as sm
        import statsmodels.formula.api as smf
    except Exception as e:            # pragma: no cover
        print(f"[poisson] statsmodels unavailable ({e}); skipping Poisson check.")
        return None
    rows = []
    dat_all = df.copy()
    # Restrict to the active event window: Poisson with a full set of time
    # dummies suffers perfect separation on all-zero periods (the long
    # post-2021 tail), so we (i) trim to the span between the first and last
    # period that carries an event and (ii) drop any remaining time level whose
    # total event count is zero. This is the standard fix and is equivalent to
    # what a conditional-likelihood FE Poisson does automatically.
    ev_periods = dat_all.groupby(time)["n_events"].sum()
    active = ev_periods[ev_periods > 0].index
    if len(active):
        dat_all = dat_all[(dat_all[time] >= active.min())
                          & (dat_all[time] <= active.max())].copy()
    keep_lvls = (dat_all.groupby(time)["n_events"].transform("sum") > 0)
    dat_all = dat_all[keep_lvls].copy()
    dat_all["province"] = dat_all["province"].astype("category")
    dat_all[time] = dat_all[time].astype("category")
    print(f"[poisson] active window: {dat_all[time].nunique()} {time} levels, "
          f"{len(dat_all)} rows after dropping all-zero periods")
    for k in lags:
        d = dat_all.dropna(subset=[f"vax_lag{k}", seqcol, "n_events"]).copy()
        d[time] = d[time].cat.remove_unused_categories()
        d["province"] = d["province"].cat.remove_unused_categories()
        # drop time levels with no within-variation to avoid separation
        formula = f"n_events ~ vax_lag{k} + {seqcol} + C(province) + C({time})"
        try:
            m = smf.glm(formula, data=d,
                        family=sm.families.Poisson()).fit(
                        cov_type="cluster",
                        cov_kwds={"groups": d["province"]})
            b = m.params[f"vax_lag{k}"]
            se = m.bse[f"vax_lag{k}"]
            p = m.pvalues[f"vax_lag{k}"]
            rows.append(dict(lag_weeks=k, beta=b, se_cluster=se,
                             irr=np.exp(b), p_cluster=p, converged=True))
        except Exception as e:
            rows.append(dict(lag_weeks=k, beta=np.nan, se_cluster=np.nan,
                             irr=np.nan, p_cluster=np.nan, converged=False))
            print(f"[poisson] lag {k}: {e}")
    return pd.DataFrame(rows)


# ============================ figure ======================================

def make_figure(sweep, joint_summary, time, out_pdf, out_png):
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(8.2, 5.0))
    k = sweep["lag_weeks"].values
    b = sweep["beta"].values
    se = sweep["se_cluster"].values
    # plausible immune-escape window
    ax.axvspan(8, 24, color="#f0e6d2", alpha=0.6, zorder=0,
               label="plausible immune-escape lag (8-24 wk)")
    ax.axhline(0, color="gray", lw=0.8)
    ax.errorbar(k, b, yerr=1.96 * se, fmt="o-", color="#2c6fbb",
                ecolor="#2c6fbb", elinewidth=1.1, capsize=3, ms=5,
                label=r"$\beta_k$ (province+%s FE, 95%% cluster CI)" % time)
    sig = sweep["p_wildboot"].values < 0.05
    if sig.any():
        ax.scatter(k[sig], b[sig], s=90, facecolors="none",
                   edgecolors="#c0392b", linewidths=1.6, zorder=5,
                   label="wild-bootstrap p < 0.05")
    ax.set_xlabel("Vaccine lag $k$ (weeks); positive = selection follows deployment")
    ax.set_ylabel(r"$\beta_k$: events per (dose-1 per 100k), within province+time")
    txt = (f"cumulative (sum of lags) = {joint_summary['cum_beta']:.3g} "
           f"± {joint_summary['cum_se']:.2g}\n"
           f"joint H0 (all vaccine β=0): wild-boot p = "
           f"{joint_summary['joint_p_wildboot']:.3f}")
    ax.text(0.02, 0.02, txt, transform=ax.transAxes, fontsize=8.5,
            va="bottom", ha="left",
            bbox=dict(boxstyle="round", fc="white", ec="0.7"))
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.legend(fontsize=8, frameon=False, loc="upper right")
    fig.tight_layout()
    fig.savefig(out_pdf, format="pdf", bbox_inches="tight")
    fig.savefig(out_png, dpi=180, bbox_inches="tight")
    print(f"[fig]     wrote {out_pdf.name} and {out_png.name}")


# ============================ main ========================================

def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--panel", default="panel_province_week.tsv")
    ap.add_argument("--time", choices=["week", "month"], default="week",
                    help="granularity of the time fixed effect")
    ap.add_argument("--no-poisson", action="store_true",
                    help="skip the Poisson robustness check")
    args = ap.parse_args()

    panel = pd.read_csv(HERE / args.panel, sep="\t")
    panel["log_seq"] = np.log1p(panel["seq"].astype(float))
    lags = sorted(int(c.replace("vax_lag", ""))
                  for c in panel.columns if c.startswith("vax_lag"))
    time = args.time
    print(f"[main]    panel = {args.panel}  time FE = {time}  lags = {lags}")
    print(f"[main]    {panel['province'].nunique()} provinces x "
          f"{panel['week'].nunique()} weeks; "
          f"{int(panel['n_events'].sum())} events\n")

    # 1. single-lag sweep
    sweep = single_lag_sweep(panel, lags, time)
    sweep_out = HERE / f"panel_fe_singlelag_{time}.tsv"
    sweep.to_csv(sweep_out, sep="\t", index=False, float_format="%.5g")
    print("[single-lag sweep]  (linear two-way FE, wild-bootstrap p)")
    print(sweep.to_string(index=False,
          columns=["lag_weeks", "beta", "se_cluster", "t", "p_wildboot"]))
    print(f"  -> {sweep_out.name}\n")

    # 2. joint distributed lag
    joint_df, joint_summary = joint_distributed_lag(panel, lags, time)
    joint_out = HERE / f"panel_fe_jointlag_{time}.tsv"
    joint_df.to_csv(joint_out, sep="\t", index=False, float_format="%.5g")
    print("[joint distributed lag]")
    print(joint_df.to_string(index=False))
    print(f"  cumulative vaccine effect = {joint_summary['cum_beta']:.4g} "
          f"± {joint_summary['cum_se']:.3g} (clustered SE)")
    print(f"  joint H0 all vaccine beta = 0: Wald = {joint_summary['joint_wald']:.3g}, "
          f"wild-bootstrap p = {joint_summary['joint_p_wildboot']:.3f}")
    print(f"  -> {joint_out.name}\n")

    # 3. Poisson robustness
    if not args.no_poisson:
        pois = try_poisson(panel, lags, time)
        if pois is not None:
            pois_out = HERE / f"panel_fe_poisson_{time}.tsv"
            pois.to_csv(pois_out, sep="\t", index=False, float_format="%.5g")
            print("[poisson robustness]  (two-way FE Poisson, IRR = exp(beta))")
            print(pois.to_string(index=False))
            print(f"  -> {pois_out.name}\n")

    # 4. figure
    make_figure(sweep, joint_summary, time,
                HERE / f"panel_fe_coefficients_{time}.pdf",
                HERE / f"panel_fe_coefficients_{time}.png")

    print("\n[done]  Interpretation: a positive beta_k that clears the "
          "wild-bootstrap\n        threshold within the 8-24 wk window would "
          "support vaccine-driven\n        escape. Absence of such a coefficient "
          "is the panel-regression\n        analogue of the manuscript's null.")


if __name__ == "__main__":
    main()
