"""
threshold_robustness.py  (section 2.2)
==================================================
This script recomputes, directly from the MEME JSONs, the empirical Bayes factor
(EBF) for every (site x branch) pair,
        EBF = [post/(1-post)] / [prior/(1-prior)],
where `post` is the branch-level posterior probability of the positive-omega
class at that site and `prior` is the site-level mixture weight on that class
(identical to the definition used to build selection_events.tsv). It then:

  1. plots log10(EBF) against P_MEME for every pair with positive evidence
     (EBF >= 1), shading the strict (P<=0.10, EBF>=100) and suggestive
     (P<=0.20, EBF>=100) acceptance regions;
  2. tabulates how many (site x branch) events, and how many distinct codons,
     are retained across a grid of P_MEME x EBF thresholds.

Outputs (into threshold_robustness/):
    threshold_scatter.pdf / .png       P_MEME vs EBF, regions marked
    threshold_grid.tsv                 event / codon counts over a threshold grid
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
HYPHY = HERE.parent / "province_fastas"
OUT = HERE / "threshold_robustness"
PROVINCES = ["AB", "BC", "MB", "NB", "NL", "NS", "ON", "PE", "QC", "SK"]

P_COL, PPOS_COL = 6, 4          # MLE columns: 6 = p-value, 4 = p+ (prior)
P_MAX_KEEP = 0.5                # only collect pairs at sites with p<=0.5
EBF_MIN_KEEP = 1.0              # ...and positive evidence (EBF>=1), to bound size


def ebf(post: float, prior: float) -> float:
    if prior <= 0.0 or prior >= 1.0:
        return np.nan
    if post <= 0.0:
        return 0.0
    if post >= 1.0:
        post = 1.0 - 1e-12
    return (post / (1.0 - post)) / (prior / (1.0 - prior))


def collect(prov: str) -> pd.DataFrame:
    jp = HYPHY / f"{prov}_hyphy.MEME.json"
    if not jp.exists() or jp.stat().st_size == 0:
        return pd.DataFrame()
    d = json.load(open(jp))
    content = d["MLE"]["content"]["0"]
    ba = d["branch attributes"]["0"]
    # candidate sites: p<=P_MAX_KEEP and a usable prior
    cand = [(i, row[P_COL], row[PPOS_COL]) for i, row in enumerate(content)
            if row[P_COL] is not None and row[P_COL] <= P_MAX_KEEP
            and 0.0 < row[PPOS_COL] < 1.0]
    rows = []
    for br, attrs in ba.items():
        pp = attrs.get("Posterior prob omega class by site")
        if pp is None:
            continue
        pos = pp[1]
        for i, pval, prior in cand:
            e = ebf(float(pos[i]), float(prior))
            if np.isnan(e) or e < EBF_MIN_KEEP:
                continue
            rows.append((prov, i + 1, float(pval), e))
    return pd.DataFrame(rows, columns=["province", "codon", "p", "EBF"])


def main():
    OUT.mkdir(exist_ok=True)
    df = pd.concat([collect(p) for p in PROVINCES], ignore_index=True)
    print(f"[data] {len(df)} (site x branch) pairs with EBF>=1 and p<=0.5 "
          f"across {df['province'].nunique()} provinces")

    # ---- scatterplot --------------------------------------------------------
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(8.4, 5.6))
    y = np.log10(np.clip(df["EBF"], 1, 1e12))
    ax.scatter(df["p"], y, s=6, alpha=0.25, color="#4472a8",
               edgecolor="none", rasterized=True)
    # strict region: p<=0.10 & EBF>=100
    ax.axvspan(0, 0.10, ymin=(2 - (-0)) / (12 - 0), color="#c0392b", alpha=0.0)
    ax.axhline(2, color="#c0392b", lw=1.0, ls="--")
    ax.axvline(0.10, color="#c0392b", lw=1.0, ls="--")
    ax.axvline(0.20, color="#e08e0b", lw=1.0, ls=":")
    ax.add_patch(plt.Rectangle((0, 2), 0.10, 10.5, facecolor="#c0392b",
                               alpha=0.10, edgecolor="none", zorder=0))
    ax.add_patch(plt.Rectangle((0.10, 2), 0.10, 10.5, facecolor="#e08e0b",
                               alpha=0.10, edgecolor="none", zorder=0))
    ax.text(0.05, 11.3, "strict\n$P\\leq0.10$, EBF$\\geq100$", ha="center",
            va="top", fontsize=8, color="#c0392b")
    ax.text(0.15, 11.3, "suggestive\nadds $0.10<P\\leq0.20$", ha="center",
            va="top", fontsize=8, color="#b8760a")
    ax.text(0.30, 2.1, "EBF = 100", fontsize=8, color="#c0392b", va="bottom")
    ax.set_xlim(0, 0.5)
    ax.set_ylim(0, 12)
    ax.set_xlabel("MEME site $p$-value")
    ax.set_ylabel("$\\log_{10}$(empirical Bayes factor) per branch")
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    fig.tight_layout()
    fig.savefig(OUT / "threshold_scatter.pdf", bbox_inches="tight", dpi=200)
    fig.savefig(OUT / "threshold_scatter.png", bbox_inches="tight", dpi=180)
    print(f"[fig] wrote {OUT/'threshold_scatter.pdf'}")

    # ---- threshold grid -----------------------------------------------------
    p_grid = [0.05, 0.10, 0.15, 0.20]
    ebf_grid = [30, 100, 300, 1000]
    recs = []
    for pt in p_grid:
        for et in ebf_grid:
            sub = df[(df["p"] <= pt) & (df["EBF"] >= et)]
            recs.append(dict(p_thr=pt, EBF_thr=et,
                             n_events=len(sub),
                             n_codons=sub["codon"].nunique()))
    grid = pd.DataFrame(recs)
    grid.to_csv(OUT / "threshold_grid.tsv", sep="\t", index=False)
    print("\n[grid] (site x branch) events and distinct codons by threshold:")
    print(grid.pivot(index="p_thr", columns="EBF_thr", values="n_events")
              .to_string())
    print("\n[grid] distinct codons by threshold:")
    print(grid.pivot(index="p_thr", columns="EBF_thr", values="n_codons")
              .to_string())
    print(f"\n[note] the strict cell (p<=0.10, EBF>=100) reproduces the 480 "
          f"events in selection_events.tsv up to branch-matching to BEAST; the "
          f"grid shows counts change smoothly with no qualitative cliff.")
    print(f"  -> {OUT/'threshold_grid.tsv'}")


if __name__ == "__main__":
    main()
