"""
mask_defining_sites.py  (step 1 of 2 of the "exclude defining sites" re-analysis)
================================================================================
Approach
--------
For each province we reuse the exact alignment *and tree* already used in the
manuscript (the province's `*_hyphy.nex`), delete the codon columns of every
VOC-defining position (3 nt each), and rewrite a reduced NEXUS with the same
TREES block. Reusing the fixed input tree means the only thing that changes is
the set of sites available to the test, which is precisely the intended
manipulation; no re-inference (and hence no R) is needed. A coordinate map from
reduced-codon index back to original spike codon is written for interpretation.

Outputs (into masked_sites/)
----------------------------
    {PROV}_masked_hyphy.nex         reduced alignment + original tree
    {PROV}_masked_coordmap.tsv       new_codon <-> original_codon
    {PROV}_masked_meme.bf            HyPhy MEME batch file
    {PROV}_masked_busted.bf          HyPhy BUSTED batch file
    run_masked_meme_busted.sh        master runner (MEME + BUSTED, all provinces)

Then:  bash masked_sites/run_masked_meme_busted.sh
       python3 masked_sites_summarize.py
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path

from lineage_defining_analysis import DEFINING     # curated VOC-defining codons

HERE = Path(__file__).resolve().parent
SRC_DIR_DEFAULT = HERE.parent / "province_fastas"  # where the *_hyphy.nex live
OUT = HERE / "masked_sites"

ALL_PROV = ["AB", "BC", "MB", "NB", "NL", "NS", "ON", "PE", "QC", "SK"]


# ---- NEXUS parsing / writing --------------------------------------------

def parse_nexus(path: Path):
    """Return (labels, seqs, nchar, tree_lines) from a HyPhy DATA+TREES NEXUS."""
    labels, seqs, tree_lines = [], [], []
    nchar = None
    in_matrix = in_trees = False
    with open(path) as fh:
        for line in fh:
            s = line.rstrip("\n")
            u = s.strip()
            if nchar is None and "NCHAR=" in u.upper():
                nchar = int(u.upper().split("NCHAR=")[1].split(";")[0].split()[0])
            if u.upper().startswith("MATRIX"):
                in_matrix = True; continue
            if in_matrix:
                if u == ";":
                    in_matrix = False; continue
                parts = s.split()
                if len(parts) >= 2:
                    labels.append(parts[0]); seqs.append(parts[1])
                continue
            if u.upper().startswith("BEGIN TREES"):
                in_trees = True; continue
            if in_trees:
                if u.upper() == "END;":
                    in_trees = False; continue
                tree_lines.append(s)
    if nchar is None:
        nchar = len(seqs[0]) if seqs else 0
    return labels, seqs, nchar, tree_lines


def write_nexus(path: Path, labels, seqs, tree_lines):
    nchar = len(seqs[0])
    maxw = max(len(l) for l in labels)
    with open(path, "w") as fh:
        fh.write("#NEXUS\n\nBEGIN DATA;\n")
        fh.write(f"  DIMENSIONS NTAX={len(labels)} NCHAR={nchar};\n")
        fh.write("  FORMAT DATATYPE=DNA MISSING=? GAP=- INTERLEAVE=NO;\n")
        fh.write("  MATRIX\n")
        for lab, sq in zip(labels, seqs):
            fh.write(f"    {lab.ljust(maxw)}  {sq.upper()}\n")
        fh.write("  ;\nEND;\n\nBEGIN TREES;\n")
        for t in tree_lines:
            fh.write(t + "\n")
        fh.write("END;\n")


# ---- HyPhy batch-file templates (mirror generate_hyphy_scripts.R) --------

def meme_bf(nex_abs, json_abs, tag):
    return (f'/* HyPhy MEME  -  defining-sites-masked dataset {tag} */\n'
            'ExecuteAFile (\n'
            '    HYPHY_LIB_DIRECTORY + "TemplateBatchFiles" + DIRECTORY_SEPARATOR +\n'
            '    "SelectionAnalyses" + DIRECTORY_SEPARATOR + "MEME.bf",\n'
            f'    {{ "code":"Universal", "alignment":"{nex_abs}", "branches":"All",\n'
            f'      "pvalue":"0.1", "output":"{json_abs}" }}\n);\n')


def busted_bf(nex_abs, json_abs, tag):
    return (f'/* HyPhy BUSTED  -  defining-sites-masked dataset {tag} */\n'
            'ExecuteAFile (\n'
            '    HYPHY_LIB_DIRECTORY + "TemplateBatchFiles" + DIRECTORY_SEPARATOR +\n'
            '    "SelectionAnalyses" + DIRECTORY_SEPARATOR + "BUSTED.bf",\n'
            f'    {{ "code":"Universal", "alignment":"{nex_abs}", "branches":"All",\n'
            f'      "rates":"3", "srv":"Yes", "output":"{json_abs}" }}\n);\n')


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--src-dir", default=str(SRC_DIR_DEFAULT),
                    help="directory holding the {PROV}_hyphy.nex files")
    ap.add_argument("--provinces", nargs="*", default=ALL_PROV,
                    help="provinces to process (default: all with a NEXUS)")
    ap.add_argument("--analyses", default="meme,busted",
                    help="comma list: meme, busted (default both)")
    ap.add_argument("--hyphy", default="hyphy", help="HyPhy executable name")
    args = ap.parse_args()
    src = Path(args.src_dir)
    analyses = [a.strip().lower() for a in args.analyses.split(",") if a.strip()]
    OUT.mkdir(exist_ok=True)

    runner = ["#!/usr/bin/env bash",
              "# run_masked_meme_busted.sh  (auto-generated)",
              "# Re-runs MEME/BUSTED on alignments with VOC-defining codons removed.",
              "set -euo pipefail", 'cd "$(dirname "$0")"',
              f'HYPHY="${{HYPHY:-{args.hyphy}}}"', 'echo "HyPhy: $HYPHY"', ""]

    for prov in args.provinces:
        nex = src / f"{prov}_hyphy.nex"
        if not nex.exists():
            print(f"[skip] {nex.name} not found"); continue
        labels, seqs, nchar, tree_lines = parse_nexus(nex)
        # strip internal node labels (ape can write 'NA', which HyPhy rejects)
        tree_lines = [re.sub(r"\)([^:,();\s]+)", ")", t) for t in tree_lines]
        ncodon = nchar // 3

        # columns (0-based) to delete = every nt of every defining codon in range
        drop_codons = sorted(c for c in DEFINING if 1 <= c <= ncodon)
        drop_cols = set()
        for c in drop_codons:
            drop_cols.update({3 * (c - 1), 3 * (c - 1) + 1, 3 * (c - 1) + 2})
        keep_cols = [i for i in range(nchar) if i not in drop_cols]

        red_seqs = ["".join(sq[i] for i in keep_cols) for sq in seqs]

        # coordinate map: new codon index -> original codon
        kept_codons = [c for c in range(1, ncodon + 1) if c not in set(drop_codons)]
        cmap = OUT / f"{prov}_masked_coordmap.tsv"
        with open(cmap, "w") as fh:
            fh.write("new_codon\toriginal_codon\n")
            for new_i, orig in enumerate(kept_codons, start=1):
                fh.write(f"{new_i}\t{orig}\n")

        out_nex = OUT / f"{prov}_masked_hyphy.nex"
        write_nexus(out_nex, labels, red_seqs, tree_lines)
        print(f"[{prov}] {nchar//3} codons -> {len(red_seqs[0])//3} "
              f"(removed {len(drop_codons)} defining codons); "
              f"{len(labels)} taxa -> {out_nex.name}")

        nex_abs = str(out_nex.resolve())
        for a in analyses:
            json_abs = nex_abs.replace(".nex", f".{a.upper()}.json")
            bf = OUT / f"{prov}_masked_{a}.bf"
            tmpl = meme_bf if a == "meme" else busted_bf
            bf.write_text(tmpl(nex_abs, json_abs, f"{prov}_masked"))
            cli = ("meme --alignment \"%s\" --code Universal --branches All "
                   "--pvalue 0.1 --output \"%s\"" % (nex_abs, json_abs)) if a == "meme" \
                  else ("busted --alignment \"%s\" --code Universal --branches All "
                        "--rates 3 --srv Yes --output \"%s\"" % (nex_abs, json_abs))
            runner += [f'echo "== {prov} : {a.upper()} (masked) =="',
                       f'$HYPHY {cli}', ""]

    sh = OUT / "run_masked_meme_busted.sh"
    sh.write_text("\n".join(runner) + "\n")
    sh.chmod(0o755)
    print(f"\n[runner] {sh.relative_to(HERE)}")
    print("[note] BUSTED on the large provinces (BC, QC, ON) is slow; consider "
          "HYPHY=HYPHYMPI or running a subset first with --provinces.")
    print("[next] bash masked_sites/run_masked_meme_busted.sh "
          "&& python3 masked_sites_summarize.py")


if __name__ == "__main__":
    main()
