"""
compare_clock_models.py  (Reviewer 1: strict- vs relaxed-clock comparison)
=========================================================================
Summarises the strict-clock runs (existing combined logs) against the
relaxed-clock (UCLD) runs produced from make_relaxed_clock_xml.py, and reports
the statistic that answers the reviewer: the posterior coefficient of variation
(CoV) of among-branch rates.

Reading of the result
---------------------
* CoV 95% HPD near 0  -> negligible rate variation; the strict clock is adequate
  and a relaxed clock does not improve the fit.
* CoV bounded well away from 0 -> a relaxed clock fits better; re-interpret the
  strict-clock dates with that caveat.
The strict `clock.rate` and the relaxed `ucld.mean` are also compared to show
whether the rate point estimate moves.

Inputs
------
    combined/<PROV>_combined.log           strict-clock (already burned-in)
    <relaxed-dir>/<PROV>_04_final.relaxed.log   relaxed-clock (run by the user)

Usage
-----
    python3 compare_clock_models.py                      # after the relaxed runs
    python3 compare_clock_models.py --relaxed-dir relaxed_clock_xml --burnin 0.1
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
STRICT_DIR = HERE / "combined"
PROVINCES = ["AB", "BC", "MB", "NB", "NL", "NS", "ON", "PE", "QC", "SK"]


def read_log(path: Path, burnin: float) -> pd.DataFrame:
    rows = []
    header = None
    with open(path) as fh:
        for line in fh:
            if line.startswith("#") or not line.strip():
                continue
            parts = line.rstrip("\n").split("\t")
            if header is None:
                header = parts
                continue
            rows.append(parts)
    df = pd.DataFrame(rows, columns=header)
    for c in df.columns:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    if 0 < burnin < 1:
        df = df.iloc[int(len(df) * burnin):]
    return df


def hpd(x: np.ndarray, cred: float = 0.95) -> tuple[float, float]:
    x = np.sort(np.asarray(x, float))
    n = len(x)
    k = max(1, int(np.floor(cred * n)))
    widths = x[k:] - x[:n - k]
    i = int(np.argmin(widths))
    return float(x[i]), float(x[i + k])


def summ(df: pd.DataFrame, col: str):
    if df is None or col not in df.columns:
        return None
    x = df[col].dropna().values
    if x.size == 0:
        return None
    lo, hi = hpd(x)
    return dict(mean=float(np.mean(x)), lo=lo, hi=hi)


def fmt(s):
    return "-" if s is None else f"{s['mean']:.3g} ({s['lo']:.3g},{s['hi']:.3g})"


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--relaxed-dir", default="relaxed_clock_xml")
    ap.add_argument("--burnin", type=float, default=0.1)
    ap.add_argument("--cov-threshold", type=float, default=0.1,
                    help="CoV HPD-low below this => strict clock deemed adequate")
    args = ap.parse_args()
    rdir = Path(args.relaxed_dir)
    if not rdir.is_absolute():
        rdir = HERE / rdir

    def read_relaxed(prov):
        """Prefer a combined top-level log; else pool run1+run2 (post-burn-in)."""
        combined = rdir / f"{prov}_04_final.relaxed.log"
        if combined.exists():
            return read_log(combined, args.burnin)
        parts = []
        for sub in ("run1", "run2"):
            p = rdir / sub / f"{prov}_04_final.relaxed.log"
            if p.exists():
                parts.append(read_log(p, args.burnin))
        if not parts:
            return None
        return pd.concat(parts, ignore_index=True)

    rows, missing = [], []
    for prov in PROVINCES:
        slog = STRICT_DIR / f"{prov}_combined.log"
        sdf = read_log(slog, args.burnin) if slog.exists() else None
        rdf = read_relaxed(prov)
        if rdf is None:
            missing.append(prov)
        rate_strict = summ(sdf, "clock.rate")
        rate_relax = summ(rdf, "ucld.mean")
        stdev = summ(rdf, "ucld.stdev")
        cov = summ(rdf, "coefficientOfVariation")
        verdict = "-"
        if cov is not None:
            verdict = ("strict adequate" if cov["lo"] < args.cov_threshold
                       else "relaxed better")
        rows.append(dict(province=prov,
                         strict_clock_rate=fmt(rate_strict),
                         relaxed_ucld_mean=fmt(rate_relax),
                         ucld_stdev=fmt(stdev),
                         CoV=fmt(cov),
                         verdict=verdict))
    out = pd.DataFrame(rows)
    print(out.to_string(index=False))
    out.to_csv(HERE / "clock_model_comparison.tsv", sep="\t", index=False)
    print(f"\nwrote {HERE/'clock_model_comparison.tsv'}")
    if missing:
        print(f"\n[pending] relaxed-clock logs not found for: {', '.join(missing)}")
        print(f"          run BEAST on {rdir.name}/<PROV>_04_final.relaxed.xml first")
    else:
        adequate = (out["verdict"] == "strict adequate").sum()
        print(f"\n[summary] strict clock deemed adequate in {adequate}/{len(out)} "
              f"provinces (CoV 95% HPD lower bound < {args.cov_threshold}).")


if __name__ == "__main__":
    main()
