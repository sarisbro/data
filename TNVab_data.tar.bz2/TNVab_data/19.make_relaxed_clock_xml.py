"""
make_relaxed_clock_xml.py  (strict- vs relaxed-clock comparison)
===========================================================================
Transforms the existing strict-clock BEAST 1.10 XMLs into uncorrelated
relaxed-clock (UCLD; lognormal) XMLs, so the two clock models can be compared.

The uncorrelated lognormal relaxed clock estimates a coefficient of variation
(CoV) of branch rates. If the posterior CoV is close to zero (its 95% HPD
abutting/including 0), among-branch rate variation is negligible and the strict
clock is adequate; if CoV is large and bounded away from 0, the relaxed clock
fits better. This is the standard, direct test of "does a relaxed clock provide
a better fit" and requires only one extra BEAST run per province (no marginal-
likelihood/path-sampling machinery). Comparing the relaxed-clock rate
(`ucld.mean`) with the strict-clock rate (`clock.rate`) additionally shows
whether the point estimates move.

What this script changes (BEAUti-equivalent UCLD setup)
-------------------------------------------------------
* `<strictClockBranchRates>`  ->  `<discretizedBranchRates>` with a
  lognormal distribution (`ucld.mean`, `ucld.stdev`) and a `rateCategories`
  parameter of dimension 2N-2 (N = taxa);
* adds a `coefficientOfVariation` rateStatistic;
* swaps the `clock.rate` operator for `ucld.mean`/`ucld.stdev` scale operators
  and adds `swapOperator` + `uniformIntegerOperator` on the rate categories;
* moves the CTMC-scale reference prior onto `ucld.mean` and adds the standard
  Exponential(mean=1/3) prior on `ucld.stdev`;
* logs `ucld.mean`, `ucld.stdev` and `coefficientOfVariation`;
* redirects all output filenames to `*.relaxed.{log,trees,ops}` so the strict
  runs are not overwritten.


Usage
-----
    python3 make_relaxed_clock_xml.py --src-dir <dir with *_04_final.xml>
    # default src-dir: ../260506_MS/Clean.data/xml.beast ; writes *_04_final.relaxed.xml
"""

from __future__ import annotations

import argparse
import copy
import xml.etree.ElementTree as ET
from pathlib import Path

HERE = Path(__file__).resolve().parent
DEFAULT_SRC = HERE.parent / "260506_MS" / "Clean.data" / "xml.beast"

# treeModel auto-generated ids that are valid idref targets without an explicit id=
TREEMODEL_AUTO = {
    "treeModel.rootHeight", "treeModel.allInternalNodeHeights",
    "treeModel.internalNodeHeights", "treeModel.internalNodes",
}


def frag(s: str) -> ET.Element:
    return ET.fromstring(s)


def transform(src: Path, out: Path) -> dict:
    tree = ET.parse(src)
    root = tree.getroot()

    n_taxa = sum(1 for _ in root.iter("sequence"))
    if n_taxa < 3:
        raise ValueError(f"{src.name}: only {n_taxa} taxa")
    ncat = 2 * n_taxa - 2

    # ---- 1. replace the strict-clock definition with UCLD ------------------
    strict = root.find("strictClockBranchRates")
    if strict is None:
        raise ValueError(f"{src.name}: no <strictClockBranchRates> found")
    idx = list(root).index(strict)
    root.remove(strict)
    ucld = frag(
        '<discretizedBranchRates id="branchRates">'
        '<treeModel idref="treeModel"/>'
        '<distribution><logNormalDistributionModel meanInRealSpace="true">'
        '<mean><parameter id="ucld.mean" value="1.0" lower="0.0"/></mean>'
        '<stdev><parameter id="ucld.stdev" value="0.1" lower="0.0"/></stdev>'
        '</logNormalDistributionModel></distribution>'
        f'<rateCategories><parameter id="branchRates.categories" dimension="{ncat}"/>'
        '</rateCategories></discretizedBranchRates>')
    root.insert(idx, ucld)

    # ---- 2. rename every remaining strictClockBranchRates idref ------------
    for el in list(root.iter("strictClockBranchRates")):
        el.tag = "discretizedBranchRates"

    # ---- 3. coefficientOfVariation rateStatistic after meanRate -----------
    meanrate = next(e for e in root.iter("rateStatistic") if e.get("id") == "meanRate")
    cov = frag('<rateStatistic id="coefficientOfVariation" '
               'name="coefficientOfVariation" mode="coefficientOfVariation" '
               'internal="true" external="true">'
               '<treeModel idref="treeModel"/>'
               '<discretizedBranchRates idref="branchRates"/></rateStatistic>')
    j = list(root).index(meanrate)
    root.insert(j + 1, cov)

    # ---- 4. operators ------------------------------------------------------
    ops = root.find("operators")
    for op in list(ops):
        if op.tag == "scaleOperator":
            p = op.find("parameter")
            if p is not None and p.get("idref") == "clock.rate":
                ops.remove(op)
        elif op.tag == "upDownOperator":
            for p in op.iter("parameter"):
                if p.get("idref") == "clock.rate":
                    p.set("idref", "ucld.mean")
    ops.append(frag('<scaleOperator scaleFactor="0.75" weight="3">'
                    '<parameter idref="ucld.mean"/></scaleOperator>'))
    ops.append(frag('<scaleOperator scaleFactor="0.75" weight="3">'
                    '<parameter idref="ucld.stdev"/></scaleOperator>'))
    ops.append(frag('<swapOperator size="1" weight="10" autoOptimize="false">'
                    '<parameter idref="branchRates.categories"/></swapOperator>'))
    ops.append(frag('<uniformIntegerOperator weight="10">'
                    '<parameter idref="branchRates.categories"/>'
                    '</uniformIntegerOperator>'))

    # ---- 5. priors ---------------------------------------------------------
    prior = next(e for e in root.iter("prior") if e.get("id") == "prior")
    for p in prior.iter("parameter"):
        if p.get("idref") == "clock.rate":      # inside <ctmcScale>
            p.set("idref", "ucld.mean")
    prior.append(frag('<exponentialPrior mean="0.3333333333333333" offset="0.0">'
                      '<parameter idref="ucld.stdev"/></exponentialPrior>'))

    # ---- 6. loggers --------------------------------------------------------
    for col in root.iter("column"):
        p = col.find("parameter")
        if p is not None and p.get("idref") == "clock.rate":
            p.set("idref", "ucld.mean")
            col.set("label", "ucld.mean")
    filelog = next(e for e in root.iter("log") if e.get("id") == "fileLog")
    for p in filelog.findall("parameter"):
        if p.get("idref") == "clock.rate":
            p.set("idref", "ucld.mean")
    filelog.append(frag('<parameter idref="ucld.stdev"/>'))
    filelog.append(frag('<rateStatistic idref="coefficientOfVariation"/>'))

    # ---- 7. redirect output filenames --------------------------------------
    for e in root.iter():
        for k, v in list(e.attrib.items()):
            if v.endswith((".log", ".trees", ".ops")):
                base, ext = v.rsplit(".", 1)
                e.set(k, f"{base}.relaxed.{ext}")

    tree.write(out, encoding="UTF-8", xml_declaration=True)
    return {"src": src.name, "out": out.name, "n_taxa": n_taxa, "ncat": ncat}


def validate(out: Path) -> list[str]:
    """Well-formedness + internal reference integrity checks."""
    problems = []
    root = ET.parse(out).getroot()               # raises if not well-formed
    ids = {e.get("id") for e in root.iter() if e.get("id")}
    for e in root.iter():
        ref = e.get("idref")
        if ref and ref not in ids and ref not in TREEMODEL_AUTO:
            problems.append(f"dangling idref: {ref}")
    for need in ("ucld.mean", "ucld.stdev", "branchRates.categories",
                 "coefficientOfVariation"):
        if need not in ids:
            problems.append(f"missing id: {need}")
    txt = out.read_text()
    if "clock.rate" in txt:
        problems.append("residual 'clock.rate' reference")
    if "strictClockBranchRates" in txt:
        problems.append("residual 'strictClockBranchRates'")
    return sorted(set(problems))


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--src-dir", default=str(DEFAULT_SRC))
    ap.add_argument("--out-dir", default=None,
                    help="output dir (default: alongside sources)")
    args = ap.parse_args()
    src_dir = Path(args.src_dir)
    out_dir = Path(args.out_dir) if args.out_dir else src_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    xmls = sorted(p for p in src_dir.glob("*_04_final.xml")
                  if ".relaxed." not in p.name)
    if not xmls:
        raise SystemExit(f"no *_04_final.xml in {src_dir}")

    all_ok = True
    for src in xmls:
        out = out_dir / src.name.replace(".xml", ".relaxed.xml")
        info = transform(src, out)
        probs = validate(out)
        status = "OK" if not probs else "PROBLEM: " + "; ".join(probs)
        all_ok &= not probs
        print(f"[{info['src']:<22}] N={info['n_taxa']:>4}  categories={info['ncat']:>4}"
              f"  -> {info['out']}   {status}")

    print("\nAll relaxed-clock XMLs " + ("passed structural validation."
          if all_ok else "written, BUT some failed validation (see above)."))
    print("Next: run BEAST on each *_04_final.relaxed.xml (validate one with a "
          "short chain first), then\n      python3 compare_clock_models.py")


if __name__ == "__main__":
    main()
