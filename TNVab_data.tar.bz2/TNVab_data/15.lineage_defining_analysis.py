"""
lineage_defining_analysis.py
============================
Reviewer 1: "it is not clear to what extent the identified sites under selection
are actually lineage-defining mutations of the variants of concern ... What
happens if lineage-defining sites are excluded from the selection tests?"

This script answers the *exclusion* half of that question directly on the
existing MEME event set. It:

  1. annotates every strict episodic-selection event with whether its codon is a
     defining spike position of one of the five major VOCs (Alpha, Beta, Gamma,
     Delta, Omicron BA.1/2 and the BA.4/5 update);
  2. quantifies how much of the selection signal is carried by defining vs
     non-defining sites, overall and per province;
  3. recomputes the cross-province recurrence and temporal distribution after
     removing defining sites;
  4. writes selection_events_nondefining.tsv so the panel regression can be
     re-run on non-defining sites only (ties Reviewer 1 to Reviewer 2);
  5. produces a figure and an annotated recurrence table.

The complementary half of Reviewer 1's suggestion -- re-running MEME *within*
each VOC so that defining mutations (fixed within a VOC) cannot register as
substitutions -- is set up by within_voc_partition.py / within_voc_prepare.R /
within_voc_summarize.py.

Defining-site list
------------------
Codon positions of established VOC-defining spike substitutions, compiled from
the PANGO constellation definitions (Rambaut et al. constellations repo),
covariants.org and outbreak.info lineage reports. A position is flagged as
"defining" if any major VOC carries a defining amino-acid change (including
characteristic deletions/insertions) at that codon. This is deliberately
inclusive, which makes the exclusion test conservative (it removes as much
variant-linked signal as possible).
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent

# codon position -> tuple of VOCs with a defining spike change at that position
DEFINING: dict[int, tuple[str, ...]] = {
    18: ("Gamma",), 20: ("Gamma",), 26: ("Gamma", "OmicronBA2"),
    67: ("Omicron",), 69: ("Alpha", "Omicron", "BA45"), 70: ("Alpha", "Omicron", "BA45"),
    80: ("Beta",), 95: ("Omicron", "Delta"),
    138: ("Gamma",), 142: ("Omicron", "Delta"), 143: ("Omicron",),
    144: ("Alpha", "Omicron"), 145: ("Omicron",),
    156: ("Delta",), 157: ("Delta",), 158: ("Delta",),
    190: ("Gamma",), 211: ("Omicron",), 212: ("Omicron",), 214: ("Omicron",),
    215: ("Beta",), 242: ("Beta",), 243: ("Beta",), 244: ("Beta",),
    339: ("Omicron",), 371: ("Omicron",), 373: ("Omicron",), 375: ("Omicron",),
    376: ("OmicronBA2",), 405: ("OmicronBA2",), 408: ("OmicronBA2",),
    417: ("Beta", "Gamma", "Omicron"), 440: ("Omicron",), 446: ("Omicron",),
    452: ("Delta", "BA45"), 477: ("Omicron",), 478: ("Delta", "Omicron"),
    484: ("Beta", "Gamma", "Omicron"), 486: ("BA45",),
    493: ("Omicron",), 496: ("Omicron",), 498: ("Omicron",),
    501: ("Alpha", "Beta", "Gamma", "Omicron"), 505: ("Omicron",),
    547: ("Omicron",), 570: ("Alpha",), 614: ("all",),
    655: ("Gamma", "Omicron"), 679: ("Omicron",),
    681: ("Alpha", "Delta", "Omicron"), 701: ("Beta",), 716: ("Alpha",),
    764: ("Omicron",), 796: ("Omicron",), 856: ("Omicron",), 950: ("Delta",),
    954: ("Omicron",), 969: ("Omicron",), 981: ("Omicron",), 982: ("Alpha",),
    1027: ("Gamma",), 1118: ("Alpha",), 1176: ("Gamma",),
}


def parse_args():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--events", choices=["strict", "suggestive"], default="strict")
    return p.parse_args()


def main():
    args = parse_args()
    fn = HERE / ("selection_events.tsv" if args.events == "strict"
                 else "selection_events_suggestive.tsv")
    ev = pd.read_csv(fn, sep="\t")
    ev["date"] = pd.to_datetime(ev["child_date_iso"], errors="coerce")
    ev["defining"] = ev["codon_site_1based"].isin(DEFINING)
    ev["defining_vocs"] = ev["codon_site_1based"].map(
        lambda s: ",".join(DEFINING.get(int(s), ())) if s in DEFINING else "")

    n = len(ev)
    n_def = int(ev["defining"].sum())
    print(f"[events]  {fn.name}: {n} events")
    print(f"[split]   defining-site events    : {n_def} "
          f"({100*n_def/n:.1f}%)  at {ev.loc[ev.defining,'codon_site_1based'].nunique()} sites")
    print(f"[split]   NON-defining-site events : {n-n_def} "
          f"({100*(n-n_def)/n:.1f}%)  at "
          f"{ev.loc[~ev.defining,'codon_site_1based'].nunique()} sites")

    # ---- per-site recurrence, annotated ------------------------------------
    rec = (ev.groupby("codon_site_1based")
             .agg(n_events=("province", "size"),
                  n_provinces=("province", "nunique"),
                  defining=("defining", "first"),
                  vocs=("defining_vocs", "first"))
             .reset_index()
             .sort_values(["n_provinces", "n_events"], ascending=False))
    rec_out = HERE / f"lineage_defining_recurrence_{args.events}.tsv"
    rec.to_csv(rec_out, sep="\t", index=False)
    print(f"\n[recurrence] top 15 sites (flagged D=defining, .=non-defining):")
    for _, r in rec.head(15).iterrows():
        flag = "D" if r.defining else "."
        print(f"   site {int(r.codon_site_1based):>4}  {flag}  "
              f"{int(r.n_events):>3} events  {int(r.n_provinces)} prov  {r.vocs}")
    print(f"  -> {rec_out.name}")

    # ---- most recurrent NON-defining sites (the residual signal) -----------
    nd = rec[~rec.defining].head(10)
    print(f"\n[non-defining] most recurrent non-defining sites (signal that "
          f"survives exclusion):")
    for _, r in nd.iterrows():
        print(f"   site {int(r.codon_site_1based):>4}     "
              f"{int(r.n_events):>3} events  {int(r.n_provinces)} prov")

    # ---- per-province retention --------------------------------------------
    per_prov = (ev.groupby("province")
                  .agg(total=("defining", "size"),
                       nondef=("defining", lambda s: int((~s).sum())))
                  .assign(pct_nondef=lambda d: 100*d.nondef/d.total)
                  .reset_index())
    print(f"\n[per province] events retained after excluding defining sites:")
    print(per_prov.to_string(index=False))

    # ---- write non-defining event file for the panel -----------------------
    nd_events = ev[~ev.defining].drop(columns=["defining", "defining_vocs", "date"])
    nd_out = HERE / "selection_events_nondefining.tsv"
    nd_events.to_csv(nd_out, sep="\t", index=False)
    print(f"\n[panel]   wrote {nd_out.name} "
          f"({len(nd_events)} non-defining events) for panel_build.py --events-file")

    # ---- figure -------------------------------------------------------------
    make_figure(ev, rec, args.events)


def make_figure(ev, rec, kind):
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.6))

    # (a) monthly event counts, defining vs non-defining
    m = (ev.assign(month=ev["date"].values.astype("datetime64[M]"))
           .groupby(["month", "defining"]).size().unstack(fill_value=0))
    m = m.rename(columns={True: "defining", False: "non-defining"})
    ax = axes[0]
    ax.bar(m.index, m.get("non-defining", 0), width=20, color="#2c6fbb",
           label="non-defining sites")
    ax.bar(m.index, m.get("defining", 0), width=20,
           bottom=m.get("non-defining", 0), color="#c9a227",
           label="VOC-defining sites")
    for d, lab in [("2020-12-14", "Alpha"), ("2021-04-01", "Delta"),
                   ("2021-12-15", "Omicron")]:
        ax.axvline(pd.Timestamp(d), color="grey", ls=":", lw=0.8)
        ax.text(pd.Timestamp(d), ax.get_ylim()[1]*0.95, lab, rotation=90,
                va="top", ha="right", fontsize=7, color="grey")
    ax.set_ylabel("strict episodic-selection events / month")
    ax.set_title("A", fontsize=13, fontweight="bold", loc="left")
    ax.legend(fontsize=8, frameon=False)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)

    # (b) recurrence: events per site, colored by class, top 20
    ax = axes[1]
    top = rec.head(20).iloc[::-1]
    colors = ["#c9a227" if d else "#2c6fbb" for d in top.defining]
    ax.barh([str(int(s)) for s in top.codon_site_1based], top.n_events,
            color=colors)
    ax.set_xlabel("number of strict events")
    ax.set_ylabel("spike codon")
    ax.set_title("B", fontsize=13, fontweight="bold", loc="left")
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)

    fig.tight_layout()
    out_pdf = HERE / f"lineage_defining_{kind}.pdf"
    out_png = HERE / f"lineage_defining_{kind}.png"
    fig.savefig(out_pdf, bbox_inches="tight")
    fig.savefig(out_png, dpi=180, bbox_inches="tight")
    print(f"[fig]     wrote {out_pdf.name} and {out_png.name}")


if __name__ == "__main__":
    main()
