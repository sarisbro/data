# Unsupervised viral fitness prediction

Code and derived data for:

> **A moving target: non-stationary selection governs unsupervised prediction of viral fitness.**
> Stéphane Aris-Brosou and Matthieu Vilain.

A modular, fully label-free (unsupervised) pipeline that scores amino-acid
substitutions in viral proteins for intrinsic fitness and antigenic escape, and the
analysis scripts that reproduce every figure and table of the paper. The central
result is evolutionary: for a fast-evolving virus, prediction accuracy depends on
*which* sequences the alignment is built from and *from which epoch*, tracing to the
non-stationarity of the site-specific substitution process.

## Repository layout

```
evescape_plm/     importable Python package (the scoring pipeline: PLM, PSSM,
                  structure/RSA, fusion, calibration, growth, validation)
scripts/          numbered analysis scripts, in the order they are meant to be run
data/             small derived data and sequence accession lists (see below)
requirements.txt  Python dependencies (tested versions)
```

The heavy raw inputs are **not** stored here (they are multi-gigabyte and either
downloaded from public archives or regenerated). See *Obtaining the large data*.

## Pipeline: scripts in order

Run from inside `scripts/`. Each finds the `evescape_plm` package one directory up.

| # | Script | Purpose | Main output | Paper item |
|---|--------|---------|-------------|------------|
| 01 | `run_proteingym.py` | Score ProteinGym viral assays with ESM-2 and the alignment PSSM | `results_proteingym.csv` | Table 1, Fig 2 |
| 02 | `proteingym_reference_scores.py` | Pull ProteinGym's released MSA Transformer / Tranception / site-independent scores | `proteingym_reference_scores_viral.csv` | Table 2, Fig 1 |
| 03 | `make_supp_table.py` | Build the per-assay benchmark table | `table_S1_proteingym.tex` | Table S2 |
| 04 | `fetch_spike_dated.py` | Download dated SARS-CoV-2 spike sequences from NCBI | `spike_temporal/records.jsonl` | (input) |
| 05 | `fetch_flu_dated.py` | Download dated H3N2 hemagglutinin sequences from NCBI | `flu_temporal/records.jsonl` | (input) |
| 06 | `temporal_sweep.py` | Epoch-resolved PSSM vs. a fixed DMS (cumulative and sliding windows; depth-matched control) | `figure_temporal_both.pdf` | Fig 4 |
| 07 | `nonstationarity.py` | Per-site Jensen–Shannon drift from the earliest epoch | `figure_nonstationarity.pdf` | Fig 5 |
| 08 | `nonstationarity_increment.py` | Cumulative vs. incremental drift | `figure_nonstationarity_increment.pdf` | S2 Fig |
| 09 | `build_codon_data.py` | Codon alignment + IQ-TREE topology for each virus | `{spike,flu}_temporal/codon_alignment.fasta`, `tree.treefile` | (input) |
| 10 | `run_hyphy.py` | HyPhy SLAC/FEL/MEME/FUBAR site-selection tests | `*.json` | Tables S3, S4 |
| 11 | `parse_hyphy.py` | Parse selected sites and build the antigenic prior | `hyphy_*_sites.csv`, `hyphy_antigenic_prior.csv` | Tables S3, S4 |
| 12 | `run_phylobayes.py` | Fit the CAT mutation-selection model (PhyloBayes-MPI, two chains) | `pb_*.chain` | (input) |
| 13 | `parse_phylobayes.py` | Posterior-mean ΔF vs. DMS + matched-alignment PSSM + paired bootstrap | `phylobayes_vs_pssm.csv`, `phylobayes_bootstrap*.csv` | Fig 6 |
| 14 | `phylobayes_convergence.py` | Between-chain convergence diagnostics | `phylobayes_convergence.csv`, `S1_Fig.pdf`, `S2_Fig.pdf` | S3, S4 Figs |
| 15 | `reproduce_synthetic.py` | Implementation-validation checks on synthetic/simulated data | `results_synthetic.csv` | S1 Text, Table S5, S5 Fig |
| 16 | `make_figures.py` | Assemble the main and supporting figures | `figure_*.pdf` | Figs 1–3, S1/S5 Figs |

Scripts 01–03 (benchmark), 04–08 (temporal / non-stationarity), and 09–14
(codon-model) are independent tracks; 15 is standalone; 16 collects the figures and
depends on outputs of 01–02 and 13. Most scripts accept `--help`.

## Data included here (`data/`)

- `data/accessions/` — the sequence identifiers used, so the exact inputs are
  reproducible without shipping the sequences:
  - `spike_dated_accessions.tsv` (2,800 records: accession, collection date, window)
  - `flu_dated_accessions.tsv` (2,730 records)
  - `proteingym_viral_assays.csv` — the 21 viral ProteinGym assays (ID, organism,
    protein, phenotype); these IDs index the ProteinGym release.
- `data/results/` — small derived tables that let the figures/tables be rebuilt
  without rerunning the heavy steps (benchmark scores, non-viral control, HyPhy
  counts and site lists, PhyloBayes ΔF-vs-PSSM and bootstrap CIs, synthetic checks).
- `data/alignments/` — the dated codon alignments for spike and H3N2 HA.
- `data/hyphy/` — per-virus, per-method HyPhy site tables and antigenic priors.

## Obtaining the large data (not in the repo)

- **ProteinGym** DMS assays, MSAs, and released model scores: download from
  <https://proteingym.org>. Scripts 01–02 fetch and cache what they need under
  `scripts/proteingym_data/` on first run.
- **Dated viral sequences**: the exact accessions are in `data/accessions/`. Scripts
  04–05 re-download them from NCBI into `scripts/{spike,flu}_temporal/`.
- **PhyloBayes chains** (`pb_*.chain`, ~1–2 GB each): regenerate with script 12
  (PhyloBayes-MPI). Convergence summaries and the derived ΔF are already in `data/`.

## Requirements

Python 3 with the packages in `requirements.txt` (NumPy, pandas, SciPy, Biopython,
Matplotlib; PyTorch + `transformers` for ESM-2). External programs for the
codon-model track: IQ-TREE 2 (v2.3.6), HyPhy (v2.5), and PhyloBayes-MPI. When the
protein-language-model weights are absent, the scorer falls back to a BLOSUM62
baseline so the pipeline still runs end to end.

## License

Released under the MIT License (see `LICENSE`).
