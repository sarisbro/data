#!/usr/bin/env python3
"""Alignment-conditioned PLMs vs the site-independent baseline on the viral assays.

Rather than re-run MSA Transformer and Tranception ourselves (both need GPUs and
large weights), we read their *official* per-assay Spearman correlations from
ProteinGym's released results, alongside ESM-2 (650M) and the site-independent
alignment baseline, so the four models are compared on one internally consistent
source. This directly answers whether alignment-conditioned / retrieval-augmented
PLMs---which, unlike single-sequence ESM-2, see a family alignment---beat a trivial
alignment model on viral proteins.

Source (downloaded on first use, ~140 KB, no GPU):
  ProteinGym, benchmarks/DMS_zero_shot/substitutions/Spearman/
  DMS_substitutions_Spearman_DMS_level.csv

As a sanity check the script also prints ProteinGym's ESM-2 (650M) mean next to our
own ESM-2 run (results_proteingym.csv); they should agree, confirming the harnesses
are comparable.

Usage:
  python reproduce/proteingym_reference_scores.py
Outputs: reproduce/proteingym_reference_scores_viral.csv
"""
from __future__ import annotations
import argparse, os, sys, urllib.request
import numpy as np
import pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__))
URL = ("https://raw.githubusercontent.com/OATML-Markslab/ProteinGym/main/benchmarks/"
       "DMS_zero_shot/substitutions/Spearman/DMS_substitutions_Spearman_DMS_level.csv")

# our (newer) ProteinGym DMS ids -> the ids used in the released DMS-level table
REMAP = {
    "A0A140D2T1_ZIKV_Sourisseau_growth_2019": "A0A140D2T1_ZIKV_Sourisseau_2019",
    "A4D664_9INFA_Soh_CCL141_2019":           "A4D664_9INFA_Soh_2019",
    "CAPSD_AAV2S_Sinai_substitutions_2021":   "CAPSD_AAV2S_Sinai_2021",
    "NRAM_I33A0_Jiang_standard_2016":         "NRAM_I33A0_Jiang_2016",
    "R1AB_SARS2_Flynn_growth_2022":           "R1AB_SARS2_Flynn_2022",
    "SPIKE_SARS2_Starr_bind_2020":            "SPIKE_SARS2_Starr_2020_binding",
    "SPIKE_SARS2_Starr_expr_2020":            "SPIKE_SARS2_Starr_2020_expression",
}
MODELS = {
    "ESM2 (650M)":               "ESM-2 650M (single-seq)",
    "Site-Independent":          "Site-independent (alignment)",
    "MSA Transformer (ensemble)": "MSA Transformer",
    "Tranception L":             "Tranception L",
}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--url", default=URL)
    ap.add_argument("--results", default=os.path.join(_HERE, "results_proteingym.csv"))
    ap.add_argument("--out", default=os.path.join(_HERE, "proteingym_reference_scores_viral.csv"))
    ap.add_argument("--cache", default=os.path.join(_HERE, "proteingym_data",
                                                    "DMS_substitutions_Spearman_DMS_level.csv"))
    args = ap.parse_args()

    if os.path.exists(args.cache):
        pg = pd.read_csv(args.cache)
    else:
        print(f"[download] {args.url}")
        os.makedirs(os.path.dirname(args.cache), exist_ok=True)
        urllib.request.urlretrieve(args.url, args.cache)
        pg = pd.read_csv(args.cache)
    pg = pg.set_index("DMS ID")

    ours = pd.read_csv(args.results)
    viral = [d for d in ours["dms_id"].unique() if d != "BLAT_ECOLX_Firnberg_2014"]
    pgid = {d: REMAP.get(d, d) for d in viral}
    missing = [d for d, p in pgid.items() if p not in pg.index]
    if missing:
        sys.exit(f"not found in ProteinGym table (check REMAP/version): {missing}")

    T = pd.DataFrame({d: pg.loc[pgid[d], list(MODELS)].astype(float) for d in viral}).T
    T.columns = [MODELS[c] for c in T.columns]
    T.to_csv(args.out, index_label="dms_id")

    print(f"\n{len(T)} viral assays; mean (median) Spearman from ProteinGym's released scores:")
    for c in T.columns:
        print(f"  {c:30s} {T[c].mean():.3f}  ({T[c].median():.3f})")

    base = "Site-independent (alignment)"
    try:
        from scipy.stats import wilcoxon
        print(f"\npaired Wilcoxon vs {base}:")
        for c in T.columns:
            if c == base:
                continue
            p = wilcoxon(T[c], T[base]).pvalue
            print(f"  {c:30s} mean diff {(T[c]-T[base]).mean():+.3f}  p={p:.3f}")
    except Exception as e:
        print(f"  (install scipy for paired tests: {e})")

    # sanity check: our ESM-2 vs ProteinGym's ESM-2 on the same assays
    e = ours[ours["model"].astype(str).str.startswith("esm2")].set_index("dms_id")["spearman"]
    shared = [d for d in viral if d in e.index]
    if shared:
        print(f"\nsanity check on {len(shared)} assays: "
              f"our ESM-2 mean {e.loc[shared].mean():.3f} vs "
              f"ProteinGym ESM-2 (650M) {T.loc[shared, 'ESM-2 650M (single-seq)'].mean():.3f}")
    print(f"\nwrote {os.path.relpath(args.out, _HERE)}")


if __name__ == "__main__":
    main()
