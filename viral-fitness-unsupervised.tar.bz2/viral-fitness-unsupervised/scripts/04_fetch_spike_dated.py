#!/usr/bin/env python3
"""Fetch a dated sample of SARS-CoV-2 spike protein sequences from NCBI (Entrez).

Samples ~per_window sequences from each publication-date window (a proxy to
spread the sample across time), then records each sequence's *real* collection
date parsed from the GenPept source feature. Resumable: appends to a JSONL cache
and skips windows already present.

Output: reproduce/spike_temporal/records.jsonl  (accession, collection_date, seq)
"""
from __future__ import annotations
import json, os, sys, time
from Bio import Entrez, SeqIO

Entrez.email = os.environ.get("ENTREZ_EMAIL", "sarisbro@uottawa.ca")
_HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(_HERE, "spike_temporal")
OUT = os.path.join(OUT_DIR, "records.jsonl")
BASE = "SARS-CoV-2[Organism] AND surface glycoprotein[Protein Name] AND 1250:1275[SLEN]"

# publication-date windows (YYYY/MM/DD) to sample across the pandemic
WINDOWS = [
    ("2020-06", "2020/04/01:2020/09/30"), ("2020-12", "2020/10/01:2020/12/31"),
    ("2021-03", "2021/01/01:2021/03/31"), ("2021-06", "2021/04/01:2021/06/30"),
    ("2021-09", "2021/07/01:2021/09/30"), ("2021-12", "2021/10/01:2021/12/31"),
    ("2022-03", "2022/01/01:2022/03/31"), ("2022-06", "2022/04/01:2022/06/30"),
    ("2022-09", "2022/07/01:2022/09/30"), ("2022-12", "2022/10/01:2022/12/31"),
    ("2023-03", "2023/01/01:2023/03/31"), ("2023-06", "2023/04/01:2023/06/30"),
    ("2023-12", "2023/10/01:2023/12/31"), ("2024-06", "2024/04/01:2024/09/30"),
]


def _collection_date(rec):
    for feat in rec.features:
        if feat.type == "source":
            return feat.qualifiers.get("collection_date", [None])[0]
    return None


def fetch_window(pdat_range, per_window, done_windows, tag):
    if tag in done_windows:
        print(f"[{tag}] cached, skip", file=sys.stderr); return []
    h = Entrez.esearch(db="protein", term=f"{BASE} AND {pdat_range}[PDAT]", retmax=per_window)
    ids = Entrez.read(h)["IdList"]; h.close()
    rows = []
    for s in range(0, len(ids), 150):
        f = Entrez.efetch(db="protein", id=ids[s:s + 150], rettype="gp", retmode="text")
        for r in SeqIO.parse(f, "genbank"):
            cd = _collection_date(r)
            if cd:
                rows.append({"acc": r.id, "date": cd, "seq": str(r.seq), "window": tag})
        f.close(); time.sleep(0.34)
    return rows


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--per-window", type=int, default=200)
    args = ap.parse_args()
    os.makedirs(OUT_DIR, exist_ok=True)
    done = set()
    if os.path.exists(OUT):
        for ln in open(OUT):
            try: done.add(json.loads(ln)["window"])
            except Exception: pass
    with open(OUT, "a") as out:
        for tag, pdat in WINDOWS:
            try:
                rows = fetch_window(pdat, args.per_window, done, tag)
                for r in rows:
                    out.write(json.dumps(r) + "\n")
                out.flush()
                if rows:
                    print(f"[{tag}] +{len(rows)} records")
            except Exception as exc:
                print(f"[{tag}] ERROR {type(exc).__name__}: {exc}", file=sys.stderr)
    print("done")


if __name__ == "__main__":
    main()
