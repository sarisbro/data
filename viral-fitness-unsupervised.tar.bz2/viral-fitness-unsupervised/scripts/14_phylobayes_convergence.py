#!/usr/bin/env python3
"""Visualize PhyloBayes MCMC convergence and choose a burn-in, per dataset.

Reads the `.trace` files of the (two) chains for each virus, overlays their trace
plots for the key summary statistics, and picks a burn-in the way `tracecomp` does:
for a grid of candidate burn-ins it computes, over the monitored statistics,

  * the between-chain discrepancy   d = 2 |mu1 - mu2| / (sigma1 + sigma2)
    (its maximum over statistics is the `maxdiff`), and
  * the effective sample size (ESS) by Geyer's (1992) initial monotone sequence
    estimator (its minimum over statistics/chains is the `min ESS`),

then recommends the smallest burn-in that clears PhyloBayes's guidelines:
  good        : maxdiff < 0.10 and min ESS > 300
  acceptable  : maxdiff < 0.30 and min ESS > 50
Burn-in is reported in SAVED POINTS, i.e. the number to pass to `readpb(_mpi) -x`
(and to `run_phylobayes.py --burnin` / `parse_phylobayes.py --burnin`).

Outputs, per virus:
  <virus>_temporal/phylobayes_convergence.pdf   trace panels + diagnostic curve
  <virus>_temporal/phylobayes_convergence.csv   maxdiff / min-ESS vs burn-in

Example:
  python reproduce/phylobayes_convergence.py                 # spike + flu
  python reproduce/phylobayes_convergence.py --virus flu --name pb
"""
from __future__ import annotations
import argparse, glob, os, sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

_HERE = os.path.dirname(os.path.abspath(__file__))
DATASETS = {"spike": "spike_temporal", "flu": "flu_temporal"}
# columns never worth monitoring (bookkeeping, not model state)
_SKIP = {"iter", "time", "pruning"}
# preferred order for the figure (whichever exist and vary)
_PRIORITY = ["lnL", "length", "Nmode", "statent", "statalpha", "codonent", "omega"]


def ess_geyer(x: np.ndarray) -> float:
    """Effective sample size via Geyer's initial monotone sequence estimator."""
    x = np.asarray(x, float)
    n = len(x)
    if n < 10:
        return float(n)
    mu = x.mean()
    if x.std() <= 1e-8 * (abs(mu) + 1.0):    # effectively constant -> mean is trivially known
        return float(n)
    x = x - mu
    g0 = float(np.dot(x, x) / n)
    if g0 <= 0:
        return float(n)
    def gamma(k):
        return float(np.dot(x[: n - k], x[k:]) / n)
    Gamma, k = [], 0
    while 2 * k + 1 < n:
        g = gamma(2 * k) + gamma(2 * k + 1)   # sum of adjacent lag pairs
        if g <= 0:
            break
        Gamma.append(g)
        k += 1
    if not Gamma:
        return float(n)
    for i in range(1, len(Gamma)):            # enforce monotone non-increasing
        Gamma[i] = min(Gamma[i], Gamma[i - 1])
    tau = max(2.0 * sum(Gamma) / g0 - 1.0, 1.0)   # integrated autocorrelation time
    return float(n / tau)


def discrepancy(a: np.ndarray, b: np.ndarray) -> float:
    """tracecomp discrepancy d = 2|mu1-mu2|/(sigma1+sigma2)."""
    s = a.std() + b.std()
    return float(2.0 * abs(a.mean() - b.mean()) / s) if s > 0 else 0.0


def load_chains(ddir, name):
    traces = sorted(glob.glob(os.path.join(ddir, f"{name}_*.trace")))
    chains = []
    for t in traces:
        try:
            df = pd.read_csv(t, sep="\t")
        except Exception:
            df = pd.read_csv(t, delim_whitespace=True)
        df.columns = [c.lstrip("#").strip() for c in df.columns]
        chains.append((os.path.basename(t)[:-6], df))   # strip ".trace"
    return chains


def pick_columns(chains, max_cols=6):
    """Numeric, non-bookkeeping columns that actually vary in at least one chain."""
    common = set(chains[0][1].columns)
    for _, df in chains[1:]:
        common &= set(df.columns)
    varying = []
    for col in common:
        if col in _SKIP:
            continue
        if not all(np.issubdtype(df[col].dtype, np.number) for _, df in chains):
            continue
        scale = max(abs(df[col].mean()) for _, df in chains) + 1.0
        if max(df[col].std() for _, df in chains) > 1e-8 * scale:   # skip fixed params
            varying.append(col)
    ordered = [c for c in _PRIORITY if c in varying] + \
              [c for c in sorted(varying) if c not in _PRIORITY]
    return ordered[:max_cols]


def sweep(chains, cols, grid):
    """maxdiff and min-ESS as a function of burn-in (in saved points)."""
    nmin = min(len(df) for _, df in chains)
    rows = []
    for b in grid:
        if nmin - b < 20:                     # need enough post-burn-in points
            continue
        dmax, ess_min = 0.0, np.inf
        for col in cols:
            segs = [df[col].to_numpy()[b:nmin] for _, df in chains]
            if len(segs) >= 2:
                dmax = max(dmax, discrepancy(segs[0], segs[1]))
            for s in segs:
                ess_min = min(ess_min, ess_geyer(s))
        rows.append(dict(burnin=b, maxdiff=dmax, min_ess=ess_min))
    return pd.DataFrame(rows)


def transient_end(chains, cols):
    """Point index at which the SLOWEST-equilibrating monitored statistic first
    enters the central band of its post-stationary (last-half) distribution
    (max over statistics and chains). For CAT/MutSel the mixture statistics
    (Nmode, entropy) burn in far more slowly than the log-likelihood, so basing
    the transient on all of them, not just lnL, avoids an over-optimistic burn-in."""
    ends = []
    for _, df in chains:
        n = len(df)
        for col in cols:
            x = df[col].to_numpy()
            lo, hi = np.percentile(x[n // 2:], [2.5, 97.5])
            inside = np.where((x >= lo) & (x <= hi))[0]
            ends.append(int(inside[0]) if len(inside) else n // 2)
    return max(ends) if ends else 0


def choose_burnin(sw, min_burnin=0):
    """Smallest burn-in that (a) clears the transient (>= min_burnin) and (b) meets
    PhyloBayes's cross-chain guidelines."""
    v = sw[sw.burnin >= min_burnin]
    if v.empty:
        v = sw
    good = v[(v.maxdiff < 0.10) & (v.min_ess > 300)]
    acc = v[(v.maxdiff < 0.30) & (v.min_ess > 50)]
    if len(good):
        return int(good.burnin.min()), "good (maxdiff<0.1, ESS>300)"
    if len(acc):
        return int(acc.burnin.min()), "acceptable (maxdiff<0.3, ESS>50)"
    return int(v.loc[v.maxdiff.idxmin(), "burnin"]), "NOT converged (best available)"


def make_figure(virus, chains, cols, sw, burnin, tier, out_pdf):
    n = len(cols) + 1
    ncol = 2
    nrow = int(np.ceil(n / ncol))
    fig, axes = plt.subplots(nrow, ncol, figsize=(11, 2.5 * nrow))
    axes = np.atleast_1d(axes).ravel()
    colors = ["#1f77b4", "#d62728", "#2ca02c", "#9467bd"]
    for ax, col in zip(axes, cols):
        for j, (nm, df) in enumerate(chains):
            x = df["iter"].to_numpy() if "iter" in df else np.arange(len(df))
            ax.plot(x, df[col].to_numpy(), lw=0.7, alpha=0.8,
                    color=colors[j % len(colors)], label=nm)
        # burn-in line: convert point index -> iter value if possible
        xb = chains[0][1]["iter"].to_numpy()
        xbi = xb[burnin] if "iter" in chains[0][1] and burnin < len(xb) else burnin
        ax.axvline(xbi, color="k", ls="--", lw=0.9)
        ax.set_title(col, fontsize=10)
        ax.tick_params(labelsize=8)
    # diagnostic panel
    axd = axes[len(cols)]
    axd.plot(sw.burnin, sw.maxdiff, "-o", ms=3, color="#333", label="maxdiff")
    axd.axhline(0.1, color="green", ls=":", lw=1)
    axd.axhline(0.3, color="orange", ls=":", lw=1)
    axd.axvline(burnin, color="k", ls="--", lw=0.9)
    axd.set_ylabel("maxdiff", fontsize=9)
    axd.set_xlabel("burn-in (points)", fontsize=9)
    axt = axd.twinx()
    axt.plot(sw.burnin, sw.min_ess, "-s", ms=3, color="#1f77b4", alpha=0.7)
    axt.set_ylabel("min ESS", fontsize=9, color="#1f77b4")
    axt.tick_params(labelsize=8, colors="#1f77b4")
    axd.set_title("between-chain discrepancy & ESS", fontsize=10)
    axd.tick_params(labelsize=8)
    for ax in axes[n:]:
        ax.axis("off")
    axes[0].legend(fontsize=8, loc="best")
    fig.suptitle(f"{virus}: PhyloBayes convergence — recommended burn-in = "
                 f"{burnin} points [{tier}]", fontsize=12)
    fig.tight_layout(rect=[0, 0, 1, 0.97])
    fig.savefig(out_pdf)
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--virus", nargs="+", choices=list(DATASETS), default=list(DATASETS))
    ap.add_argument("--name", default="pb", help="Chain basename (<name>_1.trace ...)")
    ap.add_argument("--step", type=float, default=0.05,
                    help="Burn-in grid step as a fraction of chain length")
    args = ap.parse_args()

    recs = {}
    for virus in args.virus:
        ddir = os.path.join(_HERE, DATASETS[virus])
        chains = load_chains(ddir, args.name)
        if len(chains) < 1:
            print(f"[{virus}] no {args.name}_*.trace in {ddir}", file=sys.stderr); continue
        cols = pick_columns(chains)
        nmin = min(len(df) for _, df in chains)
        b_trans = transient_end(chains, cols)
        grid = sorted(set([int(f * nmin) for f in np.arange(0, 0.9 + 1e-9, args.step)] + [b_trans]))
        sw = sweep(chains, cols, grid)
        if sw.empty:
            print(f"[{virus}] chains too short to assess", file=sys.stderr); continue
        burnin, tier = choose_burnin(sw, min_burnin=b_trans)
        sw.to_csv(os.path.join(ddir, "phylobayes_convergence.csv"), index=False)
        out_pdf = os.path.join(ddir, "phylobayes_convergence.pdf")
        make_figure(virus, chains, cols, sw, burnin, tier, out_pdf)
        at = sw.iloc[(sw.burnin - burnin).abs().idxmin()]
        recs[virus] = (burnin, nmin, tier, at.maxdiff, at.min_ess)
        print(f"\n=== {virus} ===  {len(chains)} chain(s), {nmin} points each")
        print(f"  monitored: {', '.join(cols)}")
        print(f"  slowest-statistic transient ends ~point {b_trans}")
        print(f"  recommended burn-in: {burnin} points ({burnin/nmin:.0%})  [{tier}]")
        print(f"    at that burn-in: maxdiff={at.maxdiff:.3f}, min ESS={at.min_ess:.0f}, "
              f"post-burn-in points={nmin-burnin}")
        print(f"  -> phylobayes_convergence.pdf / .csv")

    if recs:
        print("\nUse these burn-ins for extraction, e.g.:")
        for v, (b, n, tier, md, ess) in recs.items():
            print(f"  {v}: python reproduce/parse_phylobayes.py --virus {v} --burnin {b}")


if __name__ == "__main__":
    main()
