#!/usr/bin/env python3
"""Generate the supplementary per-assay benchmark table (LaTeX) from results.

Reads reproduce/results_proteingym.csv (ESM-2 and PSSM rows, with QC columns)
and writes manuscript/table_S1_proteingym.tex: one row per assay with the
ESM-2 and PSSM Spearman correlations, their difference, and the PSSM MSA
QC (alignment identity and coverage). Viral assays are sorted by PSSM-minus-ESM-2;
the non-viral control is listed separately.

Usage: python reproduce/make_supp_table.py
"""

from __future__ import annotations

import os

import pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__))
_PKG = os.path.dirname(_HERE)
_PROJECT = os.path.dirname(_PKG)


def _tex_escape(s: str) -> str:
    return str(s).replace("_", r"\_")


def _fmt(x, nd=2):
    return "---" if pd.isna(x) else f"{x:.{nd}f}"


def build(results_csv=None, reference_csv=None, out_path=None):
    results_csv = results_csv or os.path.join(_HERE, "results_proteingym.csv")
    reference_csv = reference_csv or os.path.join(_HERE, "proteingym_data",
                                                  "ProteinGym_reference_file_substitutions.csv")
    out_path = out_path or os.path.join(_PROJECT, "manuscript", "table_S1_proteingym.tex")

    r = pd.read_csv(results_csv)
    tax = pd.read_csv(reference_csv).set_index("DMS_id")["taxon"]

    esm = r[r["model"].str.contains("esm", case=False)].set_index("dms_id")
    pssm = r[r["model"] == "pssm"].set_index("dms_id")
    ids = [i for i in r["dms_id"].unique()]

    rows = []
    for dms_id in ids:
        e = esm["spearman"].get(dms_id, float("nan"))
        p = pssm["spearman"].get(dms_id, float("nan"))
        rows.append({
            "dms_id": dms_id,
            "taxon": str(tax.get(dms_id, "?")),
            "esm2": e,
            "pssm": p,
            "delta": (p - e) if pd.notna(p) and pd.notna(e) else float("nan"),
            "identity": pssm["map_identity"].get(dms_id, float("nan")),
            "coverage": pssm["msa_coverage"].get(dms_id, float("nan")),
        })
    df = pd.DataFrame(rows)
    viral = df[df["taxon"] == "Virus"].sort_values("delta", ascending=False)
    ctrl = df[df["taxon"] != "Virus"]

    def line(x):
        flag = ""
        if pd.notna(x["identity"]) and pd.notna(x["coverage"]) and \
           (x["identity"] < 0.9 or x["coverage"] < 0.9):
            flag = r"$^{\dagger}$"
        return (f"\\texttt{{{_tex_escape(x['dms_id'])}}}{flag} & {_fmt(x['esm2'])} & "
                f"{_fmt(x['pssm'])} & {_fmt(x['delta'], 2)} & "
                f"{_fmt(x['identity'], 3)} & {_fmt(x['coverage'], 3)} \\\\")

    vmean_e, vmean_p = viral["esm2"].mean(), viral["pssm"].mean()

    tex = []
    tex.append(r"\begin{table}[!ht]")
    tex.append(r"\centering")
    tex.append(r"\caption{{\bf Per-assay ProteinGym benchmark (Supporting Information).} "
               r"Spearman correlation against experimental DMS for the single-sequence "
               r"language model (ESM-2, 650M) and the alignment-based site-independent model "
               r"(PSSM), their difference $\Delta$, and the PSSM MSA quality control "
               r"(focus-to-target alignment identity and per-assay coverage). Viral assays are "
               r"sorted by $\Delta$; the non-viral assay is a positive control. "
               r"$^{\dagger}$: MSA identity or coverage $<0.9$.}")
    tex.append(r"\label{tab:supp}")
    tex.append(r"\begin{tabular}{@{}lccccc@{}}")
    tex.append(r"\toprule")
    tex.append(r"Assay & ESM-2 & PSSM & $\Delta$ & id. & cov. \\")
    tex.append(r"\midrule")
    tex.append(r"\multicolumn{6}{@{}l}{\emph{Viral assays}} \\")
    for _, x in viral.iterrows():
        tex.append(line(x))
    tex.append(r"\midrule")
    tex.append(f"\\emph{{Viral mean}} & {_fmt(vmean_e)} & {_fmt(vmean_p)} & "
               f"{_fmt(vmean_p - vmean_e)} & & \\\\")
    tex.append(r"\midrule")
    tex.append(r"\multicolumn{6}{@{}l}{\emph{Non-viral control}} \\")
    for _, x in ctrl.iterrows():
        tex.append(line(x))
    tex.append(r"\bottomrule")
    tex.append(r"\end{tabular}")
    tex.append(r"\end{table}")

    with open(out_path, "w") as fh:
        fh.write("\n".join(tex) + "\n")
    print(f"wrote {out_path} ({len(viral)} viral + {len(ctrl)} control assays)")
    return out_path


if __name__ == "__main__":
    build()
