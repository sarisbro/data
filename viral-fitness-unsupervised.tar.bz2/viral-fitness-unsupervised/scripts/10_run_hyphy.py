#!/usr/bin/env python3
"""Run all HyPhy site-selection analyses for each dated dataset (spike + flu).

For each virus it runs the requested HyPhy methods on the codon alignment + tree
produced by build_codon_data.py, writing one JSON per (virus, method). Uses all
requested cores (`CPU=<n>`), skips analyses whose output already exists (resumable),
and logs each command.

Prereqs (per dataset):
  reproduce/<virus>_temporal/codon_alignment.fasta
  reproduce/<virus>_temporal/tree.nwk        (from build_codon_data.py)

Example:
  python reproduce/run_hyphy.py --cpu 14
  python reproduce/run_hyphy.py --viruses flu --methods FEL MEME --cpu 14
"""
from __future__ import annotations
import argparse, os, shutil, subprocess, sys, time

_HERE = os.path.dirname(os.path.abspath(__file__))
DATASETS = {"spike": "spike_temporal", "flu": "flu_temporal"}
# site-level dN/dS methods (fast, well-parallelised). FADE (directional) needs a
# rooted tree and is opt-in via --methods.
DEFAULT_METHODS = ["SLAC", "FEL", "MEME", "FUBAR"]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--viruses", nargs="+", choices=list(DATASETS), default=list(DATASETS))
    ap.add_argument("--methods", nargs="+", default=DEFAULT_METHODS,
                    help="HyPhy analyses (e.g. SLAC FEL MEME FUBAR FADE)")
    ap.add_argument("--cpu", type=int, default=14, help="Threads (HyPhy CPU=<n>)")
    ap.add_argument("--hyphy-bin", default="hyphy")
    ap.add_argument("--redo", action="store_true", help="Re-run even if output JSON exists")
    ap.add_argument("--dry-run", action="store_true", help="Print commands without running")
    ap.add_argument("--extra", nargs=argparse.REMAINDER, default=[],
                    help="Extra args passed through to hyphy (after --)")
    args = ap.parse_args()

    hyphy = shutil.which(args.hyphy_bin) if not args.dry_run else args.hyphy_bin
    if not args.dry_run and not hyphy:
        sys.exit(f"HyPhy not found ('{args.hyphy_bin}' not on PATH). Install it "
                 f"(`conda install -c bioconda hyphy` or `brew install hyphy`).")

    jobs, done, failed = [], [], []
    for virus in args.viruses:
        ddir = os.path.join(_HERE, DATASETS[virus])
        aln = os.path.join(ddir, "codon_alignment.fasta"); tree = os.path.join(ddir, "tree.nwk")
        if not (os.path.exists(aln) and os.path.exists(tree)):
            print(f"[{virus}] missing inputs ({aln} / {tree}); run build_codon_data.py first",
                  file=sys.stderr); continue
        for method in args.methods:
            out = os.path.join(ddir, f"{method.lower()}.json")
            if os.path.exists(out) and not args.redo:
                print(f"[{virus}:{method}] cached -> {out}"); continue
            cmd = [hyphy, f"CPU={args.cpu}", method, "--alignment", aln,
                   "--tree", tree, "--output", out] + list(args.extra)
            jobs.append((virus, method, out, cmd))

    for virus, method, out, cmd in jobs:
        print(f"\n[{virus}:{method}] " + " ".join(cmd))
        if args.dry_run:
            continue
        t = time.time()
        try:
            subprocess.run(cmd, check=True)
            done.append((virus, method)); print(f"[{virus}:{method}] done in {time.time()-t:.0f}s -> {out}")
        except subprocess.CalledProcessError as exc:
            failed.append((virus, method)); print(f"[{virus}:{method}] FAILED: {exc}", file=sys.stderr)

    if not args.dry_run:
        print(f"\n=== summary: {len(done)} ok, {len(failed)} failed ===")
        for v, m in failed:
            print(f"  FAILED {v}:{m}")


if __name__ == "__main__":
    main()
