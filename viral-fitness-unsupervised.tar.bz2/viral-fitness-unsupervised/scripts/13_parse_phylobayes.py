#!/usr/bin/env python3
"""Parse PhyloBayes CAT-MutSel site profiles into per-mutation fitness (ΔF).

Reads the posterior-mean site-specific amino-acid fitness profiles produced by
PhyloBayes: MutSel writes them to `<chain>.aap` (via `readpb_mpi`, no -ss), CAT-GTR
to `<chain>.siteprofiles` (via `readpb -ss`), and turns them into a
phylogenetically-informed per-mutation fitness score

    ΔF_i(wt→mut) = log pi_i(mut) − log pi_i(wt)

and validates it against the experimental DMS for the same protein (the headline
question: does the tree-based mutation-selection fitness predict the DMS, and how
does it compare to the plain PSSM?). Codon-alignment sites equal reference-protein
positions, so site i == DMS position i (no offset).

Outputs (per dataset):
  <virus>_temporal/phylobayes_site_fitness.csv   (per-site log-profile / fitness)
  <virus>_temporal/phylobayes_mutation_scores.csv (per-mutant ΔF + DMS_score)

By default this first (re)extracts the posterior site profiles from the finished
chains at an 800-cycle burn-in (`readpb_mpi -x 800 -ss`, no re-sampling) and averages
the chains, then computes ΔF. Use --no-extract to just read existing profiles, or
--profiles to point at a specific file.

Example:
  python reproduce/parse_phylobayes.py                       # extract at burn-in 800, then parse
  python reproduce/parse_phylobayes.py --burnin 500          # different burn-in
  python reproduce/parse_phylobayes.py --no-extract          # read existing pb.siteprofiles
  python reproduce/parse_phylobayes.py --virus flu --profiles reproduce/flu_temporal/pb.siteprofiles
"""
from __future__ import annotations
import argparse, math, os, sys
import numpy as np
import pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.dirname(_HERE))
from evescape_plm.validation import spearman   # noqa: E402

PG = os.path.join(_HERE, "proteingym_data")
AA20 = "ACDEFGHIKLMNPQRSTVWY"
DATASETS = {
    "spike": dict(data="spike_temporal", dms="SPIKE_SARS2_Starr_bind_2020", region=(331, 531)),
    "flu":   dict(data="flu_temporal", dms="C6KNH7_9INFA_Lee_2018", region=(1, 566)),
}


def read_siteprofiles(path):
    """Return (aa_order, profiles) from a readpb_mpi -ss .siteprofiles file.

    Robust to a header line naming the amino acids and to an optional leading
    site-index column; the last 20 numeric fields of each row are the profile.
    Falls back to the standard alphabetical AA order if no header is found.
    """
    aa_order, profiles = None, []
    for line in open(path):
        toks = line.split()
        if not toks:
            continue
        letters = [t.upper() for t in toks if len(t) == 1 and t.upper() in AA20]
        if aa_order is None and len(letters) >= 18:      # header row
            aa_order = letters
            continue
        nums = []
        for t in toks:
            try:
                nums.append(float(t))
            except ValueError:
                pass
        if len(nums) >= 20:
            profiles.append(nums[-20:])
    if not aa_order or len(aa_order) != 20:
        aa_order = list(AA20)
    return aa_order, profiles


def extract_and_combine(ddir, name, burnin, every, mpi, np_, mpirun, readpb_bin):
    """(Re)extract posterior-mean site profiles from the finished chains at a given
    burn-in and average them into <ddir>/<name>.siteprofiles. No re-sampling: this
    just re-runs `readpb_mpi -x <burnin> <every> -ss <chain>` on existing chains.
    Returns (combined_path, n_chains) or (None, 0) if no chains are present.
    """
    import glob, subprocess
    from reproduce.run_phylobayes import combine_siteprofiles
    bases = [c[:-len(".chain")] for c in sorted(glob.glob(os.path.join(ddir, f"{name}_*.chain")))]
    if not bases:
        return None, 0
    # MutSel (MPI): readpb_mpi has no -ss; it writes <chain>.aap by default.
    # CAT-GTR (non-MPI): -ss writes <chain>.siteprofiles.
    ss = [] if mpi else ["-ss"]
    for base in bases:
        prefix = [mpirun, "-np", str(np_)] if mpi else []
        subprocess.run(prefix + [readpb_bin, "-x", str(burnin), str(every), *ss, base], check=True)
    res = combine_siteprofiles(bases, os.path.join(ddir, f"{name}.siteprofiles"))
    return (res[0] if res else None), len(bases)


def matched_pssm_spearman(ddir, dms, L, eps):
    """Site-independent PSSM on the SAME dated alignment MutSel used (codon alignment
    translated to protein; columns = reference positions), scored against the same
    DMS. This isolates the estimator (tree-based MutSel vs plain column counts) from
    the alignment, giving the like-for-like comparison reviewers expect. Returns
    (Spearman, n) or None."""
    from reproduce.run_phylobayes import _read_fasta, _translate_codon
    cf = os.path.join(ddir, "codon_alignment.fasta")
    if not os.path.exists(cf):
        return None
    recs = _read_fasta(cf)
    prot = ["".join(_translate_codon(s[i:i + 3]) for i in range(0, len(s) - len(s) % 3, 3))
            for _, s in recs]
    idx = {a: j for j, a in enumerate(AA20)}
    cnt = np.zeros((L, 20))
    for s in prot:
        for i, ch in enumerate(s):
            if i < L and ch in idx:
                cnt[i, idx[ch]] += 1
    logf = np.log(cnt / np.clip(cnt.sum(1, keepdims=True), 1.0, None) + eps)
    a = []
    for _, r in dms.iterrows():
        wt, pos, mut = r["mutant"][0], int(r["pos"]), r["mutant"][-1]
        if 1 <= pos <= L and wt in idx and mut in idx:
            a.append((logf[pos - 1, idx[mut]] - logf[pos - 1, idx[wt]], r["DMS_score"]))
    a = np.array(a)
    return (spearman(a[:, 0], a[:, 1]), len(a)) if len(a) > 10 else None


def _spear(x, y):
    """Spearman = Pearson of average ranks. Uses average-rank ties so that the
    duplicate pairs created by bootstrap resampling are not spuriously decorrelated."""
    from scipy.stats import rankdata
    return float(np.corrcoef(rankdata(x), rankdata(y))[0, 1])


def bootstrap_matched(ddir, out_df, L, eps, esm2_path, B=2000, seed=0):
    """Paired bootstrap of MutSel, the same-alignment PSSM, and ESM-2 on the shared
    mutation set of one assay. Resampling the same mutant indices for all estimators
    gives per-estimator 95% CIs and a paired test of (matched PSSM vs MutSel).
    Returns (rows, paired) or None."""
    from reproduce.run_phylobayes import _read_fasta, _translate_codon
    cf = os.path.join(ddir, "codon_alignment.fasta")
    if not os.path.exists(cf) or out_df.empty:
        return None
    idx = {a: j for j, a in enumerate(AA20)}
    prot = ["".join(_translate_codon(s[i:i + 3]) for i in range(0, len(s) - len(s) % 3, 3))
            for _, s in _read_fasta(cf)]
    cnt = np.zeros((L, 20))
    for s in prot:
        for i, ch in enumerate(s):
            if i < L and ch in idx:
                cnt[i, idx[ch]] += 1
    logf = np.log(cnt / np.clip(cnt.sum(1, keepdims=True), 1.0, None) + eps)
    esm = {}
    if esm2_path and os.path.exists(esm2_path):
        e = pd.read_csv(esm2_path)
        col = "esm2_score" if "esm2_score" in e.columns else e.columns[1]
        esm = dict(zip(e["mutant"], e[col]))
    rows = []
    for _, r in out_df.iterrows():
        wt, pos, mut = r["mutant"][0], int(r["pos"]), r["mutant"][-1]
        if not (1 <= pos <= L and wt in idx and mut in idx):
            continue
        m = r["mutant"]
        if m not in esm:            # restrict to the shared set (all three defined)
            continue
        rows.append((float(r["delta_F"]), float(logf[pos - 1, idx[mut]] - logf[pos - 1, idx[wt]]),
                     float(esm[m]), float(r["DMS_score"])))
    if len(rows) < 20:
        return None
    a = np.array(rows); mutsel, matched, esm2, dms = a[:, 0], a[:, 1], a[:, 2], a[:, 3]
    n = len(a); rng = np.random.default_rng(seed)
    pt = {"MutSel": _spear(mutsel, dms), "matched_PSSM": _spear(matched, dms),
          "ESM-2": _spear(esm2, dms)}
    bs = {k: np.empty(B) for k in pt}; diff = np.empty(B)
    for b in range(B):
        j = rng.integers(0, n, n)
        d = dms[j]
        bs["MutSel"][b] = _spear(mutsel[j], d)
        bs["matched_PSSM"][b] = _spear(matched[j], d)
        bs["ESM-2"][b] = _spear(esm2[j], d)
        diff[b] = bs["matched_PSSM"][b] - bs["MutSel"][b]
    rowout = []
    for k in ("ESM-2", "matched_PSSM", "MutSel"):
        lo, hi = np.percentile(bs[k], [2.5, 97.5])
        rowout.append(dict(estimator=k, rho=round(pt[k], 4),
                           ci_lo=round(lo, 4), ci_hi=round(hi, 4), n=n))
    p = 2 * min((diff <= 0).mean(), (diff >= 0).mean())    # two-sided bootstrap p
    paired = dict(contrast="matched_PSSM - MutSel", diff=round(pt["matched_PSSM"] - pt["MutSel"], 4),
                  ci_lo=round(np.percentile(diff, 2.5), 4), ci_hi=round(np.percentile(diff, 97.5), 4),
                  p=round(float(p), 4), n=n)
    return rowout, paired


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--virus", nargs="+", choices=list(DATASETS), default=list(DATASETS))
    ap.add_argument("--profiles", default=None, help="Override .siteprofiles path (single virus); skips extraction")
    ap.add_argument("--eps", type=float, default=1e-4, help="Pseudocount added to profile frequencies")
    ap.add_argument("--bootstrap", type=int, default=2000,
                    help="Bootstrap resamples for the MutSel/PSSM/ESM-2 CIs (0 to skip)")
    # --- site-profile extraction (readpb) --------------------------------------
    ap.add_argument("--burnin", type=int, default=800,
                    help="Burn-in cycles discarded when extracting site profiles (readpb -x); default 800")
    ap.add_argument("--every", type=int, default=1, help="Sub-sampling interval for readpb -x")
    ap.add_argument("--name", default="pb", help="Chain basename (<name>_1.chain ...) and combined <name>.siteprofiles")
    ap.add_argument("--no-extract", action="store_true",
                    help="Do not run readpb; just read existing <name>.siteprofiles")
    ap.add_argument("--no-mpi", action="store_true", help="Use non-MPI readpb instead of readpb_mpi")
    ap.add_argument("--np", type=int, default=14, help="MPI ranks for readpb_mpi extraction")
    ap.add_argument("--mpirun", default="mpirun")
    ap.add_argument("--readpb-bin", default=None,
                    help="Override readpb binary (default: local pbmpi/data build if present, else PATH)")
    args = ap.parse_args()

    # resolve the readpb binary (default to the locally compiled MPI build if present)
    mpi = not args.no_mpi
    if args.readpb_bin:
        readpb_bin = args.readpb_bin
    else:
        from reproduce.run_phylobayes import _LOCAL_MPI
        readpb_bin = _LOCAL_MPI.get("readpb_mpi") or ("readpb_mpi" if mpi else "readpb")

    # candidate site-profile files, newest layout first: combined non-MPI CAT-GTR
    # (pb.siteprofiles / phylobayes.siteprofiles) then legacy per-chain names.
    CANDIDATES = ["pb.siteprofiles", "phylobayes.siteprofiles",
                  "pb_1.siteprofiles", "pb_mutsel_1.siteprofiles"]
    summary = []   # (virus, dms_id, mutsel_rho, matched_pssm_rho, n) for the comparison figure
    boot, paired_rows = [], []   # per-estimator bootstrap CIs + paired contrast
    for virus in args.virus:
        cfg = DATASETS[virus]; ddir = os.path.join(_HERE, cfg["data"])
        # Re-extract site profiles from the finished chains at the chosen burn-in,
        # unless the user pinned an explicit --profiles file or passed --no-extract.
        if not args.profiles and not args.no_extract:
            try:
                combined, k = extract_and_combine(ddir, args.name, args.burnin, args.every,
                                                  mpi, args.np, args.mpirun, readpb_bin)
                if combined:
                    print(f"[{virus}] extracted + combined {k} chain(s) at burn-in {args.burnin} "
                          f"-> {os.path.basename(combined)}")
                else:
                    print(f"[{virus}] no {args.name}_*.chain found; using any existing .siteprofiles",
                          file=sys.stderr)
            except FileNotFoundError:
                print(f"[{virus}] '{readpb_bin}' not found; skipping extraction, reading existing profiles. "
                      f"Point --readpb-bin at your build or use --no-extract.", file=sys.stderr)
            except Exception as e:
                print(f"[{virus}] extraction failed ({e}); reading existing profiles.", file=sys.stderr)
        if args.profiles:
            prof_path = args.profiles
        else:
            prof_path = next((os.path.join(ddir, c) for c in CANDIDATES
                              if os.path.exists(os.path.join(ddir, c))),
                             os.path.join(ddir, CANDIDATES[0]))
        if not os.path.exists(prof_path):
            print(f"[{virus}] no site profiles in {ddir} (looked for {', '.join(CANDIDATES)}); "
                  f"run run_phylobayes.py first (sampling), then this script extracts them",
                  file=sys.stderr); continue
        aa_order, profiles = read_siteprofiles(prof_path)
        idx = {a: j for j, a in enumerate(aa_order)}
        L = len(profiles)
        print(f"\n=== {virus} ===  {L} sites, AA order {''.join(aa_order)}")

        # per-site log-fitness table
        logp = np.log(np.array(profiles) + args.eps)
        pd.DataFrame(logp, columns=aa_order, index=range(1, L + 1)).to_csv(
            os.path.join(ddir, "phylobayes_site_fitness.csv"), index_label="site")

        # per-mutation ΔF, joined to DMS
        dms = pd.read_csv(os.path.join(PG, f"{cfg['dms']}.csv")).dropna(subset=["DMS_score"])
        dms = dms[dms["mutant"].str.match(r"^[A-Z]\d+[A-Z]$")].copy()
        dms["pos"] = dms["mutant"].str[1:-1].astype(int)
        rows = []
        for _, r in dms.iterrows():
            wt, pos, mut = r["mutant"][0], int(r["pos"]), r["mutant"][-1]
            if 1 <= pos <= L and wt in idx and mut in idx:
                dF = float(logp[pos - 1, idx[mut]] - logp[pos - 1, idx[wt]])
                rows.append({"mutant": r["mutant"], "pos": pos, "delta_F": dF, "DMS_score": r["DMS_score"]})
        out = pd.DataFrame(rows)
        out.to_csv(os.path.join(ddir, "phylobayes_mutation_scores.csv"), index=False)
        rho = None
        if len(out) > 10:
            rho = spearman(out["delta_F"].to_numpy(), out["DMS_score"].to_numpy())
            print(f"  MutSel ΔF vs DMS: Spearman = {rho:+.3f}  (n={len(out)})  "
                  f"-> phylobayes_mutation_scores.csv")
        # like-for-like control: plain PSSM on the SAME alignment (no tree)
        matched = matched_pssm_spearman(ddir, dms, L, args.eps)
        if matched:
            print(f"  matched-alignment PSSM vs DMS: Spearman = {matched[0]:+.3f}  "
                  f"(n={matched[1]}; same alignment, no tree)")
        summary.append({"virus": virus, "dms_id": cfg["dms"],
                        "mutsel": None if rho is None else round(rho, 4),
                        "matched_pssm": None if not matched else round(matched[0], 4),
                        "n": len(out)})
        # paired bootstrap (MutSel / matched-alignment PSSM / ESM-2) on the shared mutant set
        esm2_path = os.path.join(PG, f"{cfg['dms']}_esm2_scores.csv")
        bt = bootstrap_matched(ddir, out, L, args.eps, esm2_path, B=args.bootstrap, seed=0) \
            if args.bootstrap > 0 else None
        if bt:
            rr, paired = bt
            for row in rr:
                boot.append({"virus": virus, **row})
            paired_rows.append({"virus": virus, **paired})
            print(f"  bootstrap ({paired['n']} shared mutants, B={args.bootstrap}): "
                  f"matched PSSM {dict((r['estimator'], r['rho']) for r in rr)['matched_PSSM']} vs "
                  f"MutSel {dict((r['estimator'], r['rho']) for r in rr)['MutSel']}, "
                  f"diff {paired['diff']:+.3f} [{paired['ci_lo']:+.3f}, {paired['ci_hi']:+.3f}], p={paired['p']:.3f}")

    if summary:
        sp = os.path.join(_HERE, "phylobayes_vs_pssm.csv")
        pd.DataFrame(summary).to_csv(sp, index=False)
        print(f"\nwrote {os.path.relpath(sp, _HERE)} (MutSel vs matched-alignment PSSM)")
    if boot:
        bp = os.path.join(_HERE, "phylobayes_bootstrap.csv")
        pd.DataFrame(boot).to_csv(bp, index=False)
        pd.DataFrame(paired_rows).to_csv(os.path.join(_HERE, "phylobayes_bootstrap_paired.csv"), index=False)
        print(f"wrote {os.path.relpath(bp, _HERE)} (+ _paired.csv): per-estimator 95% CIs")


if __name__ == "__main__":
    main()
