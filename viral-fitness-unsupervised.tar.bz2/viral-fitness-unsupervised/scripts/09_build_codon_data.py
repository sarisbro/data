#!/usr/bin/env python3
"""Build a codon alignment + tree from the dated isolates, for HyPhy and MutSel.

The temporal analyses fetched *protein* sequences; codon models (HyPhy site tests
FEL/MEME/FADE, and mutation-selection models such as swMutSel/phydms) need an
in-frame *codon* alignment and a tree. This script produces both from a dated
subset of the isolates already cached by fetch_{spike,flu}_dated.py:

  1. resolve each protein's coding nucleotides via the GenPept `coded_by`
     qualifier and fetch the CDS from NCBI (cached/resumable);
  2. thread each isolate's codons onto a reference-guided protein alignment,
     giving an in-frame codon alignment (columns = reference codons);
  3. build a neighbour-joining tree (Biopython) as a ready-to-use default.

Outputs (in reproduce/<virus>_temporal/):
  codon_alignment.fasta   -- in-frame; first record is the assay reference
  tree.nwk                -- NJ tree over the same taxa

Then, on your machine:
  hyphy FEL   --alignment codon_alignment.fasta --tree tree.nwk --output fel.json
  hyphy MEME  --alignment codon_alignment.fasta --tree tree.nwk --output meme.json
  # MutSel (site-specific amino-acid fitnesses):
  swmutsel -s codon_alignment.fasta -t tree.nwk ...        # or phydms / phylobayes
For a tree, rebuild with IQ-TREE/FastTree from codon_alignment.fasta.
"""
from __future__ import annotations
import json, os, re, sys, time, datetime as dt
from Bio import Entrez, SeqIO
from Bio.Seq import Seq

Entrez.email = os.environ.get("ENTREZ_EMAIL", "sarisbro@uottawa.ca")
_HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.dirname(_HERE))
PG = os.path.join(_HERE, "proteingym_data")
PRESETS = {
    "spike": dict(dms="SPIKE_SARS2_Starr_bind_2020", data="spike_temporal", region=(331, 531)),
    "flu":   dict(dms="C6KNH7_9INFA_Lee_2018", data="flu_temporal", region=(1, 566)),
}
_CODED = re.compile(r"([A-Z0-9_.]+):(\d+)\.\.(\d+)")

# an API key (env NCBI_API_KEY) raises the NCBI rate limit from 3 to 10 req/s and
# is strongly recommended for --n of a few hundred; otherwise fetches get throttled.
if os.environ.get("NCBI_API_KEY"):
    Entrez.api_key = os.environ["NCBI_API_KEY"]
_THROTTLE = 0.11 if os.environ.get("NCBI_API_KEY") else 0.35


def _efetch(**kw):
    """Entrez.efetch with retries/backoff (NCBI throttling returns transient errors)."""
    last = None
    for attempt in range(5):
        try:
            return Entrez.efetch(**kw)
        except Exception as exc:      # HTTP 429/500 etc.
            last = exc; time.sleep(1.0 * (attempt + 1))
    raise RuntimeError(f"efetch failed after retries: {last}")


def _safe(name):
    """HyPhy/Newick-safe taxon name (alphanumeric + underscore only)."""
    return re.sub(r"[^A-Za-z0-9]", "_", name)


def _target_seq(dms_id):
    import pandas as pd
    ref = pd.read_csv(os.path.join(PG, "ProteinGym_reference_file_substitutions.csv"))
    return str(ref[ref["DMS_id"] == dms_id].iloc[0]["target_seq"])


def _parse_date(s):
    from dateutil import parser as p
    try:
        d = p.parse(str(s), default=dt.datetime(2000, 7, 1)).date()
        return d if 1960 <= d.year <= 2026 else None
    except Exception:
        return None


def subsample(records, n):
    """Evenly spaced by date to span the timeframe."""
    dated = [(r, _parse_date(r["date"])) for r in records]
    dated = sorted([(r, d) for r, d in dated if d], key=lambda x: x[1])
    if len(dated) <= n:
        return [r for r, _ in dated]
    idx = [round(i * (len(dated) - 1) / (n - 1)) for i in range(n)]
    return [dated[i][0] for i in sorted(set(idx))]


def fetch_cds(accs, cache):
    """Fetch CDS nucleotides for protein accessions (via coded_by). Resumable."""
    done = {}
    if os.path.exists(cache):
        for ln in open(cache):
            j = json.loads(ln); done[j["acc"]] = j["cds"]
    todo = [a for a in accs if a not in done]
    n_fetched = 0
    with open(cache, "a") as out:
        for s in range(0, len(todo), 100):
            batch = todo[s:s + 100]
            h = _efetch(db="protein", id=batch, rettype="gp", retmode="text")
            coded = {}
            for g in SeqIO.parse(h, "genbank"):
                for f in g.features:
                    if f.type == "CDS" and "coded_by" in f.qualifiers:
                        coded[g.id] = f.qualifiers["coded_by"][0]
            h.close()
            for acc in batch:
                cb = coded.get(acc); m = _CODED.search(cb or "")
                if not m:
                    print(f"[cds] {acc}: no simple coded_by ({cb})", file=sys.stderr); continue
                nacc, a, b = m.group(1), int(m.group(2)), int(m.group(3))
                try:
                    hh = _efetch(db="nuccore", id=nacc, seq_start=a, seq_stop=b,
                                 rettype="fasta", retmode="text")
                    nt = SeqIO.read(hh, "fasta"); hh.close()
                    seq = nt.seq.reverse_complement() if "complement" in cb else nt.seq
                    if len(seq) < 30:
                        continue
                    done[acc] = str(seq); n_fetched += 1
                    out.write(json.dumps({"acc": acc, "cds": str(seq)}) + "\n"); out.flush()
                except Exception as exc:
                    print(f"[cds] {acc}: {exc}", file=sys.stderr)
                time.sleep(_THROTTLE)
    if todo:
        print(f"[cds] fetched {n_fetched}/{len(todo)} new CDS "
              f"({'API key in use' if os.environ.get('NCBI_API_KEY') else 'no API key -- set NCBI_API_KEY to avoid throttling'})",
              file=sys.stderr)
    return done


def codon_alignment(ref_prot, isolates):
    """Thread isolate codons onto a reference-guided protein alignment.
    isolates: list of (name, date, cds_str). Returns list of (name, codon_row)."""
    from Bio.Align import PairwiseAligner, substitution_matrices
    aligner = PairwiseAligner(); aligner.mode = "global"
    aligner.substitution_matrix = substitution_matrices.load("BLOSUM62")
    aligner.open_gap_score = -11; aligner.extend_gap_score = -1; aligner.end_gap_score = 0.0
    Lp = len(ref_prot)
    out, dropped = [], 0
    for name, date, cds in isolates:
        prot = str(Seq(cds).translate()).rstrip("*")
        if "*" in prot:                       # internal stop -> codon models reject it
            dropped += 1; continue
        aln = aligner.align(ref_prot, prot)[0]
        codon_row = ["---"] * Lp
        rb, pb = aln.aligned
        for (rs, re_), (ps, pe) in zip(rb, pb):
            for o in range(re_ - rs):
                k = ps + o
                cod = cds[3 * k:3 * k + 3]
                if len(cod) == 3 and cod.upper() not in ("TAA", "TAG", "TGA"):
                    codon_row[rs + o] = cod
        if set("".join(codon_row)) - set("-"):     # not all-gap
            out.append((_safe(f"{name}_{date}"), "".join(codon_row)))
    if dropped:
        print(f"[codon] dropped {dropped} sequences with internal stop codons", file=sys.stderr)
    return out


def build_tree_iqtree(aln_path, out_nwk, threads=14, iqtree_bin="iqtree2",
                      model="GTR+G", fast=False, bootstrap=0):
    """Build an ML tree with IQ-TREE from the codon alignment (nucleotide GTR+G by
    default) and copy the result to out_nwk. Requires iqtree2/iqtree on PATH."""
    import shutil, subprocess
    binpath = shutil.which(iqtree_bin) or shutil.which("iqtree2") or shutil.which("iqtree")
    if not binpath:
        raise SystemExit(
            "IQ-TREE not found (looked for iqtree2/iqtree on PATH). Install it, e.g. "
            "`conda install -c bioconda iqtree` or `brew install iqtree`, or pass --tree nj.")
    prefix = out_nwk[:-4] if out_nwk.endswith(".nwk") else out_nwk + "_iqtree"
    cmd = [binpath, "-s", aln_path, "-st", "DNA", "-m", model,
           "-T", str(threads), "-ntmax", str(threads), "--prefix", prefix, "-redo"]
    if fast:
        cmd.append("--fast")
    if bootstrap:
        cmd += ["-B", str(bootstrap)]
    print("[iqtree] " + " ".join(cmd), file=sys.stderr)
    subprocess.run(cmd, check=True)
    tf = prefix + ".treefile"
    if not os.path.exists(tf):
        raise SystemExit(f"IQ-TREE finished but {tf} not found.")
    shutil.copy(tf, out_nwk)
    return out_nwk


def nj_tree(names, seqs):
    import numpy as np
    from Bio.Phylo.TreeConstruction import DistanceMatrix, DistanceTreeConstructor
    arr = np.array([list(s) for s in seqs])
    N = len(seqs)
    mat = [[0.0] * (i + 1) for i in range(N)]
    for i in range(N):
        for j in range(i):
            a, b = arr[i], arr[j]
            valid = (a != "-") & (b != "-")
            nv = valid.sum()
            mat[i][j] = float((a[valid] != b[valid]).sum() / nv) if nv else 1.0
    dm = DistanceMatrix(list(names), mat)
    return DistanceTreeConstructor().nj(dm)


def main():
    import argparse
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--virus", choices=list(PRESETS), required=True)
    ap.add_argument("--n", type=int, default=300, help="Number of isolates (subsampled across dates)")
    ap.add_argument("--tree", choices=["iqtree", "nj", "none"], default="iqtree",
                    help="Tree method: IQ-TREE ML (default), Biopython NJ, or skip")
    ap.add_argument("--iqtree-bin", default="iqtree2", help="IQ-TREE binary name")
    ap.add_argument("--iqtree-model", default="GTR+G", help="IQ-TREE substitution model")
    ap.add_argument("--iqtree-fast", action="store_true", help="IQ-TREE --fast (quicker, rougher)")
    ap.add_argument("--threads", type=int, default=14, help="Threads for IQ-TREE / cores hint")
    args = ap.parse_args()
    cfg = PRESETS[args.virus]; data_dir = os.path.join(_HERE, cfg["data"])
    records = [json.loads(l) for l in open(os.path.join(data_dir, "records.jsonl"))]
    sub = subsample(records, args.n)
    print(f"[codon:{args.virus}] {len(sub)} isolates selected")

    cds = fetch_cds([r["acc"] for r in sub], os.path.join(data_dir, "cds.jsonl"))
    ref_prot = _target_seq(cfg["dms"])
    isolates = [(r["acc"], _parse_date(r["date"]).isoformat(), cds[r["acc"]])
                for r in sub if r["acc"] in cds]
    aln = codon_alignment(ref_prot, isolates)

    # refuse to write an empty/degenerate alignment (the cause of HyPhy's
    # "Empty File Encountered By ReadDataSet"): fail loudly with guidance instead.
    if len(aln) < 4:
        sys.exit(f"[codon:{args.virus}] only {len(aln)} usable sequences after CDS fetch + QC. "
                 f"This is almost always NCBI throttling: set NCBI_API_KEY and rerun "
                 f"(export NCBI_API_KEY=...). Not writing an alignment.")
    lengths = {len(s) for _, s in aln}
    assert len(lengths) == 1, f"unequal codon-alignment lengths: {lengths}"

    out_fa = os.path.join(data_dir, "codon_alignment.fasta")
    with open(out_fa, "w") as f:
        for name, row in aln:
            f.write(f">{name}\n{row}\n")
    print(f"[codon:{args.virus}] wrote {out_fa} "
          f"({len(aln)} seqs x {len(ref_prot)} codons, {os.path.getsize(out_fa)} bytes)")

    out_nwk = os.path.join(data_dir, "tree.nwk")
    if args.tree != "none" and len(aln) >= 3:
        if args.tree == "iqtree":
            build_tree_iqtree(out_fa, out_nwk, threads=args.threads, iqtree_bin=args.iqtree_bin,
                              model=args.iqtree_model, fast=args.iqtree_fast)
        else:
            from Bio import Phylo
            Phylo.write(nj_tree([n for n, _ in aln], [s for _, s in aln]), out_nwk, "newick")
        print(f"[codon:{args.virus}] wrote {out_nwk} (method={args.tree})")

    ncpu = args.threads
    print("\nRun HyPhy on all cores (CPU sets the thread count), e.g.:")
    for method in ("FEL", "MEME", "FADE"):
        print(f"  hyphy CPU={ncpu} {method} --alignment {out_fa} --tree {out_nwk} "
              f"--output {os.path.join(data_dir, method.lower() + '.json')}")
    print(f"MutSel:  swmutsel -s {out_fa} -t {out_nwk} -n {ncpu} ...   # or phydms / phylobayes")


if __name__ == "__main__":
    main()
