#!/usr/bin/env python3
"""Fetch a dated sample of H3N2 influenza hemagglutinin (HA) protein sequences.

Analogous to fetch_spike_dated.py but for the Lee 2018 A/Perth/16/2009 (H3N2) HA
DMS. Collection date is taken from the GenPept /collection_date qualifier when
present, otherwise from the year embedded in the strain name (e.g. A/Perth/16/2009).

Output: reproduce/flu_temporal/records.jsonl  (acc, date, seq)
"""
from __future__ import annotations
import json, os, re, sys, time
from Bio import Entrez, SeqIO

Entrez.email = os.environ.get("ENTREZ_EMAIL", "sarisbro@uottawa.ca")
_HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(_HERE, "flu_temporal")
OUT = os.path.join(OUT_DIR, "records.jsonl")
BASE = ('Influenza A virus[Organism] AND hemagglutinin[Protein Name] '
        'AND H3N2 AND 560:570[SLEN]')
# publication-date windows spanning the modern record, bracketing the 2009 strain
WINDOWS = [("%d" % y, f"{y}/01/01:{y+1}/12/31") for y in range(2004, 2025, 2)]

_STRAIN_YEAR = re.compile(r"/((?:19|20)\d{2})(?:\D|$)")


def _date(rec):
    for feat in rec.features:
        if feat.type == "source":
            q = feat.qualifiers
            if "collection_date" in q:
                return q["collection_date"][0]
            for key in ("strain", "isolate"):
                if key in q:
                    m = _STRAIN_YEAR.search(q[key][0])
                    if m:
                        return m.group(1)
    m = _STRAIN_YEAR.search(rec.description)
    return m.group(1) if m else None


def fetch_window(pdat, per, done, tag):
    if tag in done:
        print(f"[{tag}] cached, skip", file=sys.stderr); return []
    h = Entrez.esearch(db="protein", term=f"{BASE} AND {pdat}[PDAT]", retmax=per)
    ids = Entrez.read(h)["IdList"]; h.close()
    rows = []
    for s in range(0, len(ids), 150):
        f = Entrez.efetch(db="protein", id=ids[s:s + 150], rettype="gp", retmode="text")
        for r in SeqIO.parse(f, "genbank"):
            d = _date(r)
            if d:
                rows.append({"acc": r.id, "date": d, "seq": str(r.seq), "window": tag})
        f.close(); time.sleep(0.34)
    return rows


def main():
    import argparse
    ap = argparse.ArgumentParser(); ap.add_argument("--per-window", type=int, default=250)
    args = ap.parse_args()
    os.makedirs(OUT_DIR, exist_ok=True)
    done = set()
    if os.path.exists(OUT):
        for ln in open(OUT):
            try: done.add(json.loads(ln)["window"])
            except Exception: pass
    with open(OUT, "a") as out:
        for tag, pdat in WINDOWS:
            try:
                rows = fetch_window(pdat, args.per_window, done, tag)
                for r in rows:
                    out.write(json.dumps(r) + "\n")
                out.flush()
                if rows:
                    print(f"[{tag}] +{len(rows)} records")
            except Exception as exc:
                print(f"[{tag}] ERROR {type(exc).__name__}: {exc}", file=sys.stderr)
    print("done")


if __name__ == "__main__":
    main()
