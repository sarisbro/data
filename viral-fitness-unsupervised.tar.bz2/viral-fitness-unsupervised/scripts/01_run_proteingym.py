#!/usr/bin/env python3
"""Empirical benchmark: score ProteinGym substitution assays with real ESM-2.

For each assay this scores every measured mutant with the ESM-2 masked-marginal
likelihood ratio (intrinsic-fitness mode) and reports the Spearman correlation
against the experimental DMS score, then aggregates across assays, the
standard ProteinGym zero-shot evaluation.

Requirements: torch + transformers, ESM-2
weights (downloaded on first use from HuggingFace), and the ProteinGym
substitution assay CSVs. See reproduce/README.md for data acquisition. 

Usage
-----
# a directory of ProteinGym assays + the ProteinGym reference file (DMS_id,target_seq):
python reproduce/run_proteingym.py \
    --assays-dir ProteinGym/DMS_ProteinGym_substitutions \
    --reference  ProteinGym/reference_file.csv \
    --model-name facebook/esm2_t33_650M_UR50D \
    --out reproduce/results_proteingym.csv

# a single assay with an explicit target FASTA:
python reproduce/run_proteingym.py --dms assay.csv --fasta target.fasta

# ONE-COMMAND FIRST RUN: auto-download a viral assay (SARS-CoV-2 spike RBD) and score it:
python reproduce/run_proteingym.py --download --model-name facebook/esm2_t12_35M_UR50D

# ALL viral assays (taxon == Virus): download + score + aggregate, resumable:
python reproduce/run_proteingym.py --viral-subset --save-scores \
    --model-name facebook/esm2_t33_650M_UR50D
"""

from __future__ import annotations

import argparse
import glob
import os
import sys
import tempfile

import numpy as np
import pandas as pd

_REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _REPO)

from evescape_plm.pipeline import run_pipeline   # noqa: E402

# ProteinGym data hosted on HuggingFace (individual assay CSVs + a reference file).
HF_BASE = "https://huggingface.co/datasets/ICML2022/ProteinGym/resolve/main"
REF_FILE = "ProteinGym_reference_file_substitutions.csv"
# small, viral default assay: SARS-CoV-2 spike RBD ACE2-binding DMS (~52 KB)
DEFAULT_ASSAY = "SPIKE_SARS2_Starr_bind_2020"
# ProteinGym MSAs are distributed only as one archive (~5.2 GB) per release.
MSA_ZIP_URL = "https://marks.hms.harvard.edu/proteingym/ProteinGym_{version}/DMS_msa_files.zip"


def _download(url, dest):
    """Fetch a file to dest (skips if present). Uses only the standard library."""
    import urllib.request

    os.makedirs(os.path.dirname(os.path.abspath(dest)), exist_ok=True)
    if os.path.exists(dest) and os.path.getsize(dest) > 0:
        return dest
    print(f"[download] {url}\n        -> {dest}")
    urllib.request.urlretrieve(url, dest)
    return dest


def download_assay(assay, data_dir):
    """Download one ProteinGym substitution assay + the reference file.
    Returns (assay_csv_path, reference_csv_path)."""
    assay = assay[:-4] if assay.endswith(".csv") else assay
    ref = _download(f"{HF_BASE}/{REF_FILE}", os.path.join(data_dir, REF_FILE))
    csv = _download(f"{HF_BASE}/ProteinGym_substitutions/{assay}.csv",
                    os.path.join(data_dir, f"{assay}.csv"))
    return csv, ref


def _target_seq_lookup(reference_csv):
    """Map assay identifiers (DMS_id and/or filename stem) to target sequences.
    Robust to minor column-name variation in the ProteinGym reference file."""
    df = pd.read_csv(reference_csv)
    seq_col = next((c for c in ("target_seq", "target_sequence", "seq") if c in df.columns), None)
    if seq_col is None:
        raise ValueError("reference file must contain a 'target_seq' column")
    lut = {}
    for _, row in df.iterrows():
        keys = set()
        if "DMS_id" in df.columns and pd.notna(row["DMS_id"]):
            keys.add(str(row["DMS_id"]))
        if "DMS_filename" in df.columns and pd.notna(row["DMS_filename"]):
            keys.add(os.path.splitext(str(row["DMS_filename"]))[0])
        for k in keys:
            lut[k] = str(row[seq_col])
    return lut


def score_assay(assay_csv, target_seq, model_name, score_col, mutant_col, limit, tmp,
                scorer="esm2", device=None, msa=None, pssm_kwargs=None):
    """Return (n_matched, spearman, dataframe) for one assay via the pipeline.

    scorer='esm2' (masked-marginal PLM) or 'pssm' (alignment log-odds; needs msa).
    """
    fasta = os.path.join(tmp, "target.fasta")
    with open(fasta, "w") as fh:
        fh.write(f">target\n{target_seq}\n")

    dms = assay_csv
    if limit:  # optional subsample for a quick smoke test
        d = pd.read_csv(assay_csv)
        d.sample(min(limit, len(d)), random_state=0).to_csv(os.path.join(tmp, "sub.csv"), index=False)
        dms = os.path.join(tmp, "sub.csv")

    out = run_pipeline(
        fasta=fasta, scorer=scorer, mode="intrinsic",
        dms_csv=dms, mutant_col=mutant_col, score_col=score_col,
        model_name=model_name, device=device, msa=msa, pssm_kwargs=pssm_kwargs,
        allow_fallback=False, verbose=False,
    )
    m = out.metrics
    qc = {"map_identity": m.get("map_identity"), "msa_coverage": m.get("msa_coverage")}
    return m.get("n_matched", 0.0), m.get("spearman", float("nan")), out.dataframe, qc


RESULT_COLS = ["dms_id", "n_matched", "spearman", "model", "map_identity", "msa_coverage"]


def _row(dms_id, n, sp, modeltag, qc):
    return {"dms_id": dms_id, "n_matched": n, "spearman": sp, "model": modeltag,
            "map_identity": qc.get("map_identity"), "msa_coverage": qc.get("msa_coverage")}


def _msa_map(ref_df):
    """dms_id -> MSA filename, from the ProteinGym reference file."""
    if {"DMS_id", "MSA_filename"}.issubset(ref_df.columns):
        return {str(i): str(f) for i, f in zip(ref_df["DMS_id"], ref_df["MSA_filename"])}
    return {}


# cache the opened MSA archive across assays within a run
_MSA_ZIP = {"path": None, "names": None}


def _ensure_msa_zip(data_dir, version="v1.3"):
    """Return the ProteinGym MSA archive path, downloading it only if absent.

    If ``DMS_msa_files.zip`` is already present in ``data_dir`` (e.g. downloaded
    manually), it is used as-is and the ~5.2 GB download is skipped. A present
    but invalid/partial archive raises a clear error rather than being re-fetched.
    """
    import zipfile

    dest = os.path.join(data_dir, "DMS_msa_files.zip")
    if os.path.exists(dest) and os.path.getsize(dest) > 0:
        if not zipfile.is_zipfile(dest):
            raise SystemExit(
                f"[msa] {dest} exists but is not a valid zip (partial/corrupt download?). "
                f"Delete it and retry, or replace it with a complete DMS_msa_files.zip.")
        print(f"[msa] using existing archive: {dest} "
              f"({os.path.getsize(dest) / 1e6:.0f} MB) -- skipping download", file=sys.stderr)
        return dest
    url = MSA_ZIP_URL.format(version=version)
    print(f"[msa] downloading the ProteinGym MSA archive (~5.2 GB, one time):\n      {url}",
          file=sys.stderr)
    _download(url, dest)
    return dest


def _extract_msa(dms_id, msa_filename, data_dir, version="v1.3"):
    """Extract one assay's MSA from the archive into data_dir/msa/, return its path."""
    import zipfile

    out_dir = os.path.join(data_dir, "msa")
    os.makedirs(out_dir, exist_ok=True)
    want = os.path.basename(str(msa_filename))
    local = os.path.join(out_dir, want)
    if os.path.exists(local) and os.path.getsize(local) > 0:
        return local

    zip_path = _ensure_msa_zip(data_dir, version=version)
    if _MSA_ZIP["path"] != zip_path:
        with zipfile.ZipFile(zip_path) as zf:
            _MSA_ZIP.update(path=zip_path, names=zf.namelist())
    # match by basename (archive may nest files under a folder)
    member = next((n for n in _MSA_ZIP["names"] if os.path.basename(n) == want), None)
    if member is None:  # try matching on the DMS_id stem
        member = next((n for n in _MSA_ZIP["names"]
                       if os.path.basename(n).startswith(dms_id)), None)
    if member is None:
        raise FileNotFoundError(f"no MSA for {dms_id} ({want}) in {os.path.basename(zip_path)}")
    with zipfile.ZipFile(zip_path) as zf, open(local, "wb") as out:
        out.write(zf.read(member))
    return local


def _resolve_msa(dms_id, msa_map, args):
    """Path to the MSA for an assay when scoring with PSSM, else None.

    Priority: explicit --msa; a file in --msa-dir; otherwise auto-download and
    extract from the ProteinGym MSA archive (unless --no-download-msas).
    """
    if not args.scorer.startswith("pssm"):
        return None
    if args.msa:
        return args.msa
    fn = msa_map.get(dms_id)
    if not fn:
        raise SystemExit(f"scorer=pssm: no MSA_filename for {dms_id} in the reference file")
    if args.msa_dir:
        cand = os.path.join(args.msa_dir, os.path.basename(fn))
        if os.path.exists(cand):
            return cand
        if args.no_download_msas:
            raise SystemExit(f"scorer=pssm: {os.path.basename(fn)} not found in --msa-dir")
    if args.no_download_msas:
        raise SystemExit("scorer=pssm needs MSAs; pass --msa-dir or drop --no-download-msas")
    return _extract_msa(dms_id, fn, args.data_dir, version=args.msa_version)


def _save_scores(df, dms_id, data_dir):
    """Persist per-mutant ESM-2 scores so make_figures.py can overlay them."""
    os.makedirs(data_dir, exist_ok=True)
    path = os.path.join(data_dir, f"{dms_id}_esm2_scores.csv")
    (df[["mutant", "fitness_plm", "measured"]]
        .rename(columns={"fitness_plm": "esm2_score", "measured": "DMS_score"})
        .to_csv(path, index=False))
    return path


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--download", action="store_true",
                    help="Auto-download one assay (default: SARS-CoV-2 spike RBD) and score it")
    ap.add_argument("--viral-subset", action="store_true",
                    help="Download and score every viral assay (taxon==Virus); resumable")
    ap.add_argument("--assay", default=DEFAULT_ASSAY,
                    help=f"Assay name to download with --download (default: {DEFAULT_ASSAY})")
    ap.add_argument("--data-dir", default=os.path.join(os.path.dirname(__file__), "proteingym_data"),
                    help="Where downloaded ProteinGym files are cached")
    ap.add_argument("--assays-dir", default=None, help="Directory of ProteinGym substitution CSVs")
    ap.add_argument("--reference", default=None, help="ProteinGym reference_file.csv (DMS_id,target_seq)")
    ap.add_argument("--dms", default=None, help="Single assay CSV")
    ap.add_argument("--fasta", default=None, help="Target FASTA for the single-assay mode")
    ap.add_argument("--model-name", default="facebook/esm2_t33_650M_UR50D")
    ap.add_argument("--scorer", choices=["esm2", "pssm", "pssm_w"], default="esm2",
                    help="'esm2' (masked-marginal PLM), 'pssm' (alignment log-odds), "
                         "or 'pssm_w' (redundancy-reweighted PSSM); pssm* need MSAs")
    ap.add_argument("--msa-dir", default=None, help="Directory of per-assay MSAs (for --scorer pssm)")
    ap.add_argument("--msa", default=None, help="Single MSA file (for --scorer pssm in single-assay mode)")
    ap.add_argument("--select", choices=["topk", "min_identity"], default=None,
                    help="Identity-to-target sequence selection for pssm* (drop divergent homologs)")
    ap.add_argument("--select-k", type=int, default=None, help="Keep the K closest sequences (--select topk)")
    ap.add_argument("--select-min-identity", type=float, default=None,
                    help="Keep sequences with identity to target >= this (--select min_identity)")
    ap.add_argument("--msa-version", default="v1.3", help="ProteinGym release for MSA auto-download")
    ap.add_argument("--no-download-msas", action="store_true",
                    help="Do not auto-download the ~5.2 GB MSA archive; require --msa-dir/--msa")
    ap.add_argument("--device", default=None, help="Force torch device: cuda | mps | cpu (default: auto)")
    ap.add_argument("--score-col", default="DMS_score")
    ap.add_argument("--mutant-col", default="mutant")
    ap.add_argument("--limit", type=int, default=0, help="Subsample N mutants per assay (0 = all)")
    ap.add_argument("--save-scores", action="store_true",
                    help="Also write per-mutant ESM-2 scores (for figure overlays)")
    ap.add_argument("--out", default=os.path.join(os.path.dirname(__file__), "results_proteingym.csv"))
    args = ap.parse_args()

    tmp = tempfile.mkdtemp(prefix="proteingym_")
    pssm_kwargs = {}
    if args.select:
        pssm_kwargs["select"] = args.select
    if args.select_k:
        pssm_kwargs["select_k"] = args.select_k
    if args.select_min_identity is not None:
        pssm_kwargs["select_min_identity"] = args.select_min_identity

    if args.scorer.startswith("pssm"):
        modeltag = args.scorer
        if args.select == "topk" and args.select_k:
            modeltag += f"_top{args.select_k}"
        elif args.select == "min_identity" and args.select_min_identity is not None:
            modeltag += f"_id{args.select_min_identity}"
    else:
        modeltag = os.path.basename(args.model_name)
    rows = []

    if args.viral_subset:
        ref_path = _download(f"{HF_BASE}/{REF_FILE}", os.path.join(args.data_dir, REF_FILE))
        refdf = pd.read_csv(ref_path)
        lut = _target_seq_lookup(ref_path)
        msa_map = _msa_map(refdf)
        viral = sorted(refdf.loc[refdf["taxon"] == "Virus", "DMS_id"].astype(str))
        print(f"[viral-subset] {len(viral)} viral assays; model={modeltag}")

        done = set()
        if os.path.exists(args.out):                      # resume from prior run
            prev = pd.read_csv(args.out)
            if {"dms_id", "model"}.issubset(prev.columns):
                rows.extend(prev.to_dict("records"))
                done = {(str(d), str(m)) for d, m in zip(prev["dms_id"], prev["model"])}

        for i, dms_id in enumerate(viral, 1):
            if (dms_id, modeltag) in done:
                print(f"[{i:>2}/{len(viral)}] {dms_id:<40} cached, skipping")
                continue
            if dms_id not in lut:
                print(f"[{i:>2}/{len(viral)}] {dms_id}: no target_seq, skipping", file=sys.stderr)
                continue
            try:
                csv = _download(f"{HF_BASE}/ProteinGym_substitutions/{dms_id}.csv",
                                os.path.join(args.data_dir, f"{dms_id}.csv"))
                msa = _resolve_msa(dms_id, msa_map, args)
                n, sp, sdf, qc = score_assay(csv, lut[dms_id], args.model_name, args.score_col,
                                             args.mutant_col, args.limit, tmp,
                                             scorer=args.scorer, device=args.device, msa=msa, pssm_kwargs=pssm_kwargs)
                rows.append(_row(dms_id, n, sp, modeltag, qc))
                if args.save_scores:
                    _save_scores(sdf, dms_id, args.data_dir)
                print(f"[{i:>2}/{len(viral)}] {dms_id:<40} n={int(n):>6}  Spearman={sp:.3f}")
            except Exception as exc:
                print(f"[{i:>2}/{len(viral)}] {dms_id}: ERROR {type(exc).__name__}: {exc}", file=sys.stderr)
            # incremental save so a long run is crash-safe / resumable
            pd.DataFrame(rows).reindex(columns=RESULT_COLS).to_csv(args.out, index=False)
    elif args.download:
        dms_path, ref_path = download_assay(args.assay, args.data_dir)
        lut = _target_seq_lookup(ref_path)
        msa_map = _msa_map(pd.read_csv(ref_path))
        dms_id = os.path.splitext(os.path.basename(dms_path))[0]
        if dms_id not in lut:
            raise SystemExit(f"{dms_id}: no target_seq found in {os.path.basename(ref_path)}")
        msa = _resolve_msa(dms_id, msa_map, args)
        n, sp, sdf, qc = score_assay(dms_path, lut[dms_id], args.model_name, args.score_col,
                                     args.mutant_col, args.limit, tmp,
                                     scorer=args.scorer, device=args.device, msa=msa, pssm_kwargs=pssm_kwargs)
        rows.append(_row(dms_id, n, sp, modeltag, qc))
        if args.save_scores:
            print(f"[scores] {_save_scores(sdf, dms_id, args.data_dir)}")
        print(f"{dms_id:<45} n={int(n):>6}  Spearman={sp:.3f}")
    elif args.assays_dir:
        if not args.reference:
            raise SystemExit("--assays-dir requires --reference (for target_seq per assay)")
        lut = _target_seq_lookup(args.reference)
        msa_map = _msa_map(pd.read_csv(args.reference))
        assays = sorted(glob.glob(os.path.join(args.assays_dir, "*.csv")))
        if not assays:
            raise SystemExit(f"No CSVs found in {args.assays_dir}")
        for a in assays:
            dms_id = os.path.splitext(os.path.basename(a))[0]
            if dms_id not in lut:
                print(f"[skip] {dms_id}: no target_seq in reference", file=sys.stderr)
                continue
            try:
                msa = _resolve_msa(dms_id, msa_map, args)
                n, sp, sdf, qc = score_assay(a, lut[dms_id], args.model_name, args.score_col,
                                             args.mutant_col, args.limit, tmp,
                                             scorer=args.scorer, device=args.device, msa=msa, pssm_kwargs=pssm_kwargs)
                rows.append(_row(dms_id, n, sp, modeltag, qc))
                if args.save_scores:
                    _save_scores(sdf, dms_id, args.data_dir)
                print(f"{dms_id:<45} n={int(n):>6}  Spearman={sp:.3f}")
            except Exception as exc:
                print(f"[error] {dms_id}: {type(exc).__name__}: {exc}", file=sys.stderr)
    elif args.dms:
        if not args.fasta:
            raise SystemExit("--dms requires --fasta")
        from evescape_plm.data import read_fasta
        _, seq = read_fasta(args.fasta)
        dms_id = os.path.splitext(os.path.basename(args.dms))[0]
        msa = _resolve_msa(dms_id, {}, args)
        n, sp, sdf, qc = score_assay(args.dms, seq, args.model_name, args.score_col,
                                     args.mutant_col, args.limit, tmp,
                                     scorer=args.scorer, device=args.device, msa=msa, pssm_kwargs=pssm_kwargs)
        rows.append(_row(dms_id, n, sp, modeltag, qc))
        if args.save_scores:
            print(f"[scores] {_save_scores(sdf, dms_id, args.data_dir)}")
        print(f"{dms_id}: n={int(n)}  Spearman={sp:.3f}")
    else:
        raise SystemExit("Provide --assays-dir (+--reference) or --dms (+--fasta)")

    df = pd.DataFrame(rows).reindex(columns=RESULT_COLS)
    df.to_csv(args.out, index=False)
    valid = df["spearman"].dropna()
    print("\n=== ProteinGym summary ===")
    print(f"assays: {len(df)}   mean Spearman: {valid.mean():.3f}   median: {valid.median():.3f}")
    print(f"wrote {args.out}")


if __name__ == "__main__":
    main()
