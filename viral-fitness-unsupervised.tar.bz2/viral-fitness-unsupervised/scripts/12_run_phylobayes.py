#!/usr/bin/env python3
"""Run PhyloBayes site-specific profiles for each dataset (MPI CAT-MutSel by default).

Default mode fits the site-heterogeneous **mutation-selection** model (`-mutsel -dp`,
Rodrigue & Lartillot 2014, Bioinformatics 30:1020) with PhyloBayes-MPI on the codon
alignment. The MPI binaries default to the locally compiled build at
`evescape_plm_pipeline/pbmpi/data/{pb_mpi,readpb_mpi}` if present, else fall back to
PATH; override with --pb-mpi-bin / --readpb-mpi-bin. Under MutSel, `readpb_mpi`
(no -ss; that flag is CAT-only) writes the posterior-mean site-specific amino-acid
fitness profiles pi_i(a) to `<chain>.aap`, from which parse_phylobayes.py computes
the per-mutation fitness

    dF_i(wt->mut) = log pi_i(mut) - log pi_i(wt)

(codon site i == reference position i, no offset).

Using the 14 cores
------------------
pb_mpi parallelizes ONE chain across MPI ranks, so `--np 14` puts all 14 cores on a
single CAT-MutSel chain. Chains therefore run one at a time (`--jobs 1`); the default
`--chains 2` runs two sequential chains for convergence checking (tracecomp / bpcomp),
and their per-chain `.siteprofiles` are averaged into `<virus>_temporal/pb.siteprofiles`.
If mpirun complains about slots, add `--mpi-extra "--oversubscribe"` or lower `--np`.

`--no-mpi` switches to the single-threaded fallback: the amino-acid CAT-GTR model
(non-MPI `pb`) on a translated protein alignment, parallelized as many independent
1-core chains (`--chains 7 --jobs 14`). Same downstream profiles and parser.

Prereqs per dataset (from build_codon_data.py):
  reproduce/<virus>_temporal/codon_alignment.fasta   (in-frame nucleotide/codon)
  reproduce/<virus>_temporal/tree.nwk

Example (MPI CAT-MutSel, 14 cores):
  python reproduce/run_phylobayes.py --np 14 --until 1100 --burnin 100 --extract
Then check convergence:  tracecomp -x 100 <virus>_temporal/pb_1 <virus>_temporal/pb_2
Then parse:              python reproduce/parse_phylobayes.py
"""
from __future__ import annotations
import argparse, os, shutil, subprocess, sys, time

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)                       # evescape_plm_pipeline/
sys.path.insert(0, _ROOT)
DATASETS = {"spike": "spike_temporal", "flu": "flu_temporal"}

# Locally compiled PhyloBayes-MPI build, if present (evescape_plm_pipeline/pbmpi/data/*).
_MPI_DATA = os.path.join(_ROOT, "pbmpi", "data")
_LOCAL_MPI = {b: os.path.join(_MPI_DATA, b)
              for b in ("pb_mpi", "readpb_mpi")
              if os.path.exists(os.path.join(_MPI_DATA, b))}


def _resolve_bin(name):
    """Return an executable path for a binary given as a path or a PATH name, else None."""
    if os.path.sep in name or name.startswith("."):
        p = os.path.abspath(name)
        return p if (os.path.exists(p) and os.access(p, os.X_OK)) else None
    return shutil.which(name)

# Standard genetic code (for translating the in-frame codon alignment to protein).
_CODON_TABLE = {
    "TTT": "F", "TTC": "F", "TTA": "L", "TTG": "L", "CTT": "L", "CTC": "L",
    "CTA": "L", "CTG": "L", "ATT": "I", "ATC": "I", "ATA": "I", "ATG": "M",
    "GTT": "V", "GTC": "V", "GTA": "V", "GTG": "V", "TCT": "S", "TCC": "S",
    "TCA": "S", "TCG": "S", "CCT": "P", "CCC": "P", "CCA": "P", "CCG": "P",
    "ACT": "T", "ACC": "T", "ACA": "T", "ACG": "T", "GCT": "A", "GCC": "A",
    "GCA": "A", "GCG": "A", "TAT": "Y", "TAC": "Y", "TAA": "*", "TAG": "*",
    "CAT": "H", "CAC": "H", "CAA": "Q", "CAG": "Q", "AAT": "N", "AAC": "N",
    "AAA": "K", "AAG": "K", "GAT": "D", "GAC": "D", "GAA": "E", "GAG": "E",
    "TGT": "C", "TGC": "C", "TGA": "*", "TGG": "W", "CGT": "R", "CGC": "R",
    "CGA": "R", "CGG": "R", "AGT": "S", "AGC": "S", "AGA": "R", "AGG": "R",
    "GGT": "G", "GGC": "G", "GGA": "G", "GGG": "G",
}


def _read_fasta(path):
    name, seq, out = None, [], []
    for line in open(path):
        line = line.rstrip("\n")
        if line.startswith(">"):
            if name is not None:
                out.append((name, "".join(seq)))
            name, seq = line[1:].split()[0], []
        elif line:
            seq.append(line.strip())
    if name is not None:
        out.append((name, "".join(seq)))
    return out


def _translate_codon(codon):
    codon = codon.upper()
    if codon == "---":
        return "-"
    if "-" in codon or "N" in codon:
        return "X"          # partial / ambiguous codon -> unknown residue
    return _CODON_TABLE.get(codon, "X")


def translate_alignment(codon_fasta, prot_fasta):
    """Translate an in-frame codon alignment to a protein alignment (columns preserved)."""
    recs = _read_fasta(codon_fasta)
    with open(prot_fasta, "w") as fh:
        for name, seq in recs:
            aa = "".join(_translate_codon(seq[i:i + 3]) for i in range(0, len(seq) - len(seq) % 3, 3))
            fh.write(f">{name}\n{aa}\n")
    return prot_fasta, len(recs)


def fasta_to_phylip(fasta, phy):
    """Write a relaxed sequential PHYLIP file (PhyloBayes input): '<ntaxa> <nsites>' then 'name seq'."""
    recs = _read_fasta(fasta)
    lengths = {len(s) for _, s in recs}
    if len(lengths) != 1:
        raise ValueError(f"{fasta}: sequences are not all the same length ({sorted(lengths)}); not aligned.")
    n, L = len(recs), lengths.pop()
    with open(phy, "w") as fh:
        fh.write(f"{n} {L}\n")
        for name, seq in recs:
            fh.write(f"{name}  {seq}\n")           # two spaces separate name from sequence
    return phy, n, L


def combine_siteprofiles(chain_paths, out_path):
    """Average posterior-mean site profiles across chains into one readpb-style file.

    Reads whichever per-chain profile file exists: ``.aap`` (MutSel posterior-mean
    site-specific amino-acid fitness, from `readpb_mpi`) or ``.siteprofiles``
    (CAT-GTR site profiles, from `readpb -ss`). Both list 20 values per site in
    PhyloBayes's alphabetical amino-acid order.
    """
    from reproduce.parse_phylobayes import read_siteprofiles  # reuse robust reader
    import numpy as np
    stacks, aa_order = [], None
    for ch in chain_paths:
        sp = next((ch + suf for suf in (".aap", ".siteprofiles") if os.path.exists(ch + suf)), None)
        if sp is None:
            continue
        order, prof = read_siteprofiles(sp)
        if prof:
            aa_order = aa_order or order
            stacks.append(np.asarray(prof, dtype=float))
    if not stacks:
        return None
    L = min(a.shape[0] for a in stacks)                 # guard ragged lengths
    mean = np.mean([a[:L] for a in stacks], axis=0)
    mean = mean / mean.sum(axis=1, keepdims=True)       # renormalise
    with open(out_path, "w") as fh:
        fh.write(" ".join(aa_order) + "\n")
        for i, row in enumerate(mean, 1):
            fh.write(f"{i} " + " ".join(f"{x:.6g}" for x in row) + "\n")
    return out_path, len(mean), len(stacks)


def run_pool(jobs, jobs_max, dry):
    """Run (label, cmd, logpath) jobs concurrently, at most `jobs_max` at a time."""
    pending, running, failures = list(jobs), [], []
    while pending or running:
        while pending and len(running) < jobs_max:
            label, cmd, logp = pending.pop(0)
            print(f"[start] {label}\n        {' '.join(cmd)}")
            if dry:
                running.append((label, None, None)); continue
            fh = open(logp, "a")
            fh.write(f"\n# {' '.join(cmd)}\n"); fh.flush()
            running.append((label, subprocess.Popen(cmd, stdout=fh, stderr=subprocess.STDOUT), fh))
        if dry:
            running = []
        else:
            time.sleep(2)
            still = []
            for label, p, fh in running:
                if p.poll() is None:
                    still.append((label, p, fh)); continue
                fh.close()
                if p.returncode != 0:
                    failures.append((label, p.returncode)); print(f"[FAIL ] {label} (exit {p.returncode}) — see log")
                else:
                    print(f"[done ] {label}")
            running = still
    return failures


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--viruses", nargs="+", choices=list(DATASETS), default=list(DATASETS))
    ap.add_argument("--chains", type=int, default=None,
                    help="Independent chains PER dataset (default: MPI 2, non-MPI 7)")
    ap.add_argument("--jobs", type=int, default=None,
                    help="Max chains running at once (default: MPI 1 [each uses --np ranks], non-MPI 14)")
    ap.add_argument("--until", type=int, default=1100, help="MCMC cycles per chain (must be finite so chains exit)")
    ap.add_argument("--every", type=int, default=1, help="Sampling frequency")
    ap.add_argument("--burnin", type=int, default=100, help="Burn-in for readpb -ss extraction")
    ap.add_argument("--name", default="pb", help="Chain basename (chains: <name>_1.. ; combined: <name>.siteprofiles)")
    ap.add_argument("--model", choices=["catgtr", "cat"], default="catgtr",
                    help="Non-MPI site-profile model on the protein alignment (default CAT-GTR)")
    # binaries (non-MPI CAT-GTR fallback)
    ap.add_argument("--pb-bin", default="pb")
    ap.add_argument("--readpb-bin", default="readpb")
    # MPI CAT-MutSel path (DEFAULT). --no-mpi switches to the non-MPI CAT-GTR fallback.
    ap.add_argument("--no-mpi", action="store_true",
                    help="Use single-threaded pb CAT-GTR on the protein alignment instead of MPI CAT-MutSel")
    ap.add_argument("--np", type=int, default=14, help="MPI processes (cores) per chain")
    ap.add_argument("--mpirun", default="mpirun")
    ap.add_argument("--mpi-extra", default="", help="Extra tokens passed to mpirun (e.g. '--oversubscribe')")
    ap.add_argument("--pb-mpi-bin", default=_LOCAL_MPI.get("pb_mpi", "pb_mpi"),
                    help="pb_mpi binary (default: local pbmpi/data build if present, else PATH)")
    ap.add_argument("--readpb-mpi-bin", default=_LOCAL_MPI.get("readpb_mpi", "readpb_mpi"),
                    help="readpb_mpi binary (default: local pbmpi/data build if present, else PATH)")
    ap.add_argument("--extract", action="store_true", help="Run readpb -ss after sampling and combine chains")
    ap.add_argument("--redo", action="store_true", help="Start chains fresh (else resume if present)")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    if args.until <= 0:
        sys.exit("--until must be a finite, positive number of cycles so each chain terminates.")

    args.mpi = not args.no_mpi
    # mode-dependent defaults: MPI runs one chain at a time with --np ranks each
    # (so 14 cores go to one CAT-MutSel chain); non-MPI runs many 1-core chains.
    if args.chains is None:
        args.chains = 2 if args.mpi else 7
    if args.jobs is None:
        args.jobs = 1 if args.mpi else 14
    mpi_extra = args.mpi_extra.split()

    # resolve binaries / model for the chosen mode
    if args.mpi:
        model_flags = ["-mutsel", "-dp"]
        want = {"pb": args.pb_mpi_bin, "readpb": args.readpb_mpi_bin, "mpirun": args.mpirun}
    else:
        model_flags = ["-cat", "-gtr"] if args.model == "catgtr" else ["-cat"]
        want = {"pb": args.pb_bin, "readpb": args.readpb_bin}
    resolved = {}
    if not args.dry_run:
        for key, name in want.items():
            if key == "readpb" and not args.extract:
                continue
            p = _resolve_bin(name)
            if not p:
                hint = ("build/point --pb-mpi-bin at pbmpi/data (or install PhyloBayes-MPI + MPI runtime)"
                        if args.mpi else "install single-threaded PhyloBayes (pb/readpb)")
                sys.exit(f"'{name}' not found. {hint}.")
            resolved[key] = p
    else:
        resolved = {k: (_resolve_bin(v) or v) for k, v in want.items()}
    pb_bin, readpb_bin = resolved.get("pb"), resolved.get("readpb")
    mpirun = resolved.get("mpirun", args.mpirun)
    if args.jobs > 1 and args.mpi:
        print(f"[warn] --jobs {args.jobs} with MPI (--np {args.np}/chain) may oversubscribe your cores.",
              file=sys.stderr)

    def pb_cmd(chain, aln, tree, resume):
        prefix = [mpirun, "-np", str(args.np), *mpi_extra] if args.mpi else []
        if resume:
            return prefix + [pb_bin, chain]
        core = ["-d", aln, "-T", tree, *model_flags, "-x", str(args.every), str(args.until), chain]
        return prefix + [pb_bin, *core]

    # ---- prepare inputs + build the sampling job list ------------------------
    sampling, chains_by_virus = [], {}
    for virus in args.viruses:
        ddir = os.path.join(_HERE, DATASETS[virus])
        codon = os.path.join(ddir, "codon_alignment.fasta"); tree = os.path.join(ddir, "tree.nwk")
        if not (os.path.exists(codon) and os.path.exists(tree)):
            print(f"[{virus}] missing inputs; run build_codon_data.py first", file=sys.stderr); continue
        # PhyloBayes reads PHYLIP, not FASTA -> convert. MPI CAT-MutSel uses the codon
        # alignment; non-MPI CAT-GTR uses a translated protein alignment.
        if args.mpi:
            src, phy = codon, os.path.join(ddir, "codon_alignment.phy")
        else:
            src = os.path.join(ddir, "protein_alignment.fasta")
            if args.redo or not os.path.exists(src):
                _, n = translate_alignment(codon, src)
                print(f"[{virus}] translated {n} sequences -> {os.path.relpath(src, _HERE)}")
            phy = os.path.join(ddir, "protein_alignment.phy")
        _, n, L = fasta_to_phylip(src, phy)
        print(f"[{virus}] PHYLIP -> {os.path.relpath(phy, _HERE)} ({n} taxa x {L} sites)")
        aln = phy
        chains = [os.path.join(ddir, f"{args.name}_{c}") for c in range(1, args.chains + 1)]
        chains_by_virus[virus] = chains
        for c, chain in enumerate(chains, 1):
            resume = os.path.exists(chain + ".chain") and not args.redo
            sampling.append((f"{virus} chain {c}{' [resume]' if resume else ''}",
                             pb_cmd(chain, aln, tree, resume), chain + ".log"))

    if not sampling:
        sys.exit("No datasets ready. Run build_codon_data.py first.")

    mode = "PhyloBayes-MPI CAT-MutSel (codon)" if args.mpi else f"PhyloBayes {args.model.upper()} (protein AA)"
    print(f"\n=== {mode}: {len(sampling)} chains, up to {args.jobs} concurrent "
          f"({'MPI ' + str(args.np) + ' ranks/chain' if args.mpi else '1 core/chain'}) ===")
    print(f"    binary: {pb_bin}")
    fails = run_pool(sampling, args.jobs, args.dry_run)

    # ---- extraction + combine ------------------------------------------------
    if args.extract and not args.dry_run:
        extract = []
        for virus, chains in chains_by_virus.items():
            for c, chain in enumerate(chains, 1):
                if not os.path.exists(chain + ".chain"):
                    continue
                prefix = [mpirun, "-np", str(args.np), *mpi_extra] if args.mpi else []
                # MutSel: readpb_mpi has no -ss (it writes <chain>.aap fitness profiles by
                # default); CAT-GTR needs -ss to write <chain>.siteprofiles.
                ss = [] if args.mpi else ["-ss"]
                cmd = prefix + [readpb_bin, "-x", str(args.burnin), str(args.every), *ss, chain]
                extract.append((f"{virus} readpb chain {c}", cmd, chain + ".log"))
        run_pool(extract, args.jobs, False)
        for virus, chains in chains_by_virus.items():
            ddir = os.path.join(_HERE, DATASETS[virus])
            res = combine_siteprofiles(chains, os.path.join(ddir, f"{args.name}.siteprofiles"))
            if res:
                _, L, k = res
                print(f"[{virus}] combined {k} chain(s) -> {args.name}.siteprofiles ({L} sites)")
    elif args.extract and args.dry_run:
        print("\n[dry-run] would run readpb -ss per chain and average into <name>.siteprofiles")

    print("\nConvergence (fixed tree):  tracecomp -x <burnin> <virus>_temporal/{args.name}_1 <virus>_temporal/{args.name}_2"
          .replace("{args.name}", args.name))
    print("Then parse:               python reproduce/parse_phylobayes.py")
    if fails:
        sys.exit(f"\n{len(fails)} chain(s) failed: " + ", ".join(l for l, _ in fails))


if __name__ == "__main__":
    main()
