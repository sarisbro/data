#!/usr/bin/env python3
"""Generate the two manuscript figures as PDFs.

    figure_simulation.pdf : growth-estimator recovery on simulated data + a
                            summary of the Table 1 validation metrics.
    figure_realdata.pdf   : the pipeline's unsupervised score vs experimental
                            DMS on the real SARS-CoV-2 spike RBD ProteinGym
                            assay, plus the measured mutational landscape.

The simulation panels are computed here with the same fixed seed as
reproduce_synthetic.py. The real-data panels use the cached ProteinGym spike
assay (auto-downloaded if absent) scored with the substitution-matrix baseline;
if reproduce/results_proteingym.csv exists, the ESM-2 mean Spearman is drawn as
an annotation so the figure updates once the benchmark has been run.

Usage:
    python reproduce/make_figures.py [--outdir DIR]
"""

from __future__ import annotations

import argparse
import os
import sys
import tempfile

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__))
_PKG = os.path.dirname(_HERE)                 # evescape_plm_pipeline
sys.path.insert(0, _PKG)

from evescape_plm.data import AA20                                   # noqa: E402
from evescape_plm.pipeline import run_pipeline                       # noqa: E402
from evescape_plm.growth_fit import (fit_variant_growth,             # noqa: E402
                                     fit_mutation_growth, build_genotype_matrix)
from evescape_plm.validation import spearman                         # noqa: E402

plt.rcParams.update({
    "font.family": "sans-serif", "font.size": 9, "axes.titlesize": 10,
    "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 150,
})
BLUE, ORANGE, GREY = "#2c6fbb", "#e08214", "#666666"

SEED_GROWTH = 11
TEST_SEQ = "MFVFLVLLPLVSSQCVNLTTRTQLPPAYTNSFTRGVYYPDKVFRSSVLHSTQDLFLPFFS"


# --------------------------------------------------------------------------- #
def simulate_growth():
    """Reproduce the growth simulation (seed = reproduce_synthetic) -> arrays."""
    rng = np.random.default_rng(SEED_GROWTH)
    positions = [2, 5, 8, 11, 14, 17, 20]
    effects = [0.12, 0.09, -0.05, 0.04, 0.06, 0.03, 0.00]
    muts, true_beta = [], {}
    for pos, eff in zip(positions, effects):
        wt = TEST_SEQ[pos - 1]
        alt = rng.choice([a for a in AA20 if a != wt])
        muts.append(f"{wt}{pos}{alt}"); true_beta[f"{wt}{pos}{alt}"] = eff

    variants, geno = [], {}
    for i in range(12):
        variants.append(f"V{i}")
        geno[f"V{i}"] = set(m for m in muts if rng.random() < 0.5)
    r_true = {v: sum(true_beta[m] for m in geno[v]) for v in variants}

    alpha = dict(zip(variants, rng.normal(0, 1.5, len(variants))))
    times = np.arange(0, 140, 7)
    counts = np.zeros((len(times), len(variants)))
    for ti, t in enumerate(times):
        lg = np.array([alpha[v] + r_true[v] * t for v in variants])
        p = np.exp(lg - lg.max()); p /= p.sum()
        counts[ti] = rng.multinomial(500, p)

    G, kept = build_genotype_matrix(variants, geno)
    fm = fit_mutation_growth(counts, times.astype(float), variants, geno, l2=0.5, verbose=False)
    bhat = dict(zip(fm.table.mutant, fm.table.growth))
    tb = np.array([true_beta[m] for m in kept]); bh = np.array([bhat[m] for m in kept])

    fv = fit_variant_growth(counts, times.astype(float), variants, verbose=False)
    rhat = dict(zip(fv.table.variant, fv.table.growth))
    rt = np.array([r_true[v] for v in variants]); rh = np.array([rhat[v] for v in variants])
    return (tb, bh, kept), (rt, rh)


def figure_simulation(outpath):
    (tb, bh, kept), (rt, rh) = simulate_growth()
    sp_m, pe_m = spearman(tb, bh), float(np.corrcoef(tb, bh)[0, 1])
    sp_v = spearman(rt, rh)

    fig, axes = plt.subplots(3, 1, figsize=(5.0, 8.1))

    # A: per-mutation recovery
    ax = axes[0]
    lo = min(tb.min(), bh.min()) - 0.02; hi = max(tb.max(), bh.max()) + 0.02
    ax.plot([lo, hi], [lo, hi], "--", color=GREY, lw=1)
    ax.scatter(tb, bh, s=45, color=BLUE, zorder=3)
    for x, y, name in zip(tb, bh, kept):
        ax.annotate(name, (x, y), fontsize=6, xytext=(3, 3), textcoords="offset points")
    ax.set_xlabel("True effect (per day)"); ax.set_ylabel("Estimated effect")
    ax.set_title("A  Per-mutation growth", loc="left", fontweight="bold")
    ax.text(0.05, 0.92, f"Spearman {sp_m:.2f}\nPearson {pe_m:.2f}",
            transform=ax.transAxes, va="top", fontsize=8)

    # B: per-variant recovery
    ax = axes[1]
    lo = min(rt.min(), rh.min()) - 0.02; hi = max(rt.max(), rh.max()) + 0.02
    ax.plot([lo, hi], [lo, hi], "--", color=GREY, lw=1)
    ax.scatter(rt, rh, s=40, color=ORANGE, zorder=3)
    ax.set_xlabel("True variant growth"); ax.set_ylabel("Estimated growth")
    ax.set_title("B  Per-variant growth", loc="left", fontweight="bold")
    ax.text(0.05, 0.92, f"Spearman {sp_v:.2f}", transform=ax.transAxes, va="top", fontsize=8)

    # C: validation-metric summary (from Table 1)
    ax = axes[2]
    labels = ["Growth\nPearson", "Per-variant\nSpearman", "MSA\nAUROC", "DMS\nSpearman"]
    vals = [pe_m, sp_v, 0.83, 0.58]
    y = np.arange(len(labels))[::-1]
    ax.barh(y, vals, color=[BLUE, ORANGE, "#5aae61", "#9970ab"], height=0.6)
    for yi, v in zip(y, vals):
        ax.text(v + 0.02, yi, f"{v:.2f}", va="center", fontsize=8)
    ax.set_yticks(y); ax.set_yticklabels(labels, fontsize=8)
    ax.set_xlim(0, 1.05); ax.set_xlabel("Metric value")
    ax.set_title("C  Validation summary", loc="left", fontweight="bold")

    fig.tight_layout()
    fig.savefig(outpath); plt.close(fig)
    return {"spearman_mut": sp_m, "pearson_mut": pe_m, "spearman_var": sp_v}


def _load_spike():
    """Load the cached ProteinGym spike assay (download if missing)."""
    import importlib.util
    spec = importlib.util.spec_from_file_location("rpg", os.path.join(_HERE, "01_run_proteingym.py"))
    rpg = importlib.util.module_from_spec(spec); spec.loader.exec_module(rpg)
    dms, ref = rpg.download_assay(rpg.DEFAULT_ASSAY, os.path.join(_HERE, "proteingym_data"))
    lut = rpg._target_seq_lookup(ref)
    dms_id = os.path.splitext(os.path.basename(dms))[0]
    return dms, lut[dms_id], dms_id


def _z(a):
    a = np.asarray(a, float); s = a.std()
    return (a - a.mean()) / s if s > 0 else a - a.mean()


def figure_realdata(outpath, esm2_scores=None, results_csv=None):
    dms_csv, target_seq, dms_id = _load_spike()
    fasta = os.path.join(tempfile.mkdtemp(), "t.fasta")
    open(fasta, "w").write(f">t\n{target_seq}\n")
    out = run_pipeline(fasta=fasta, scorer="mock", mode="intrinsic",
                       dms_csv=dms_csv, score_col="DMS_score", verbose=False)
    df = out.dataframe.dropna(subset=["measured"]).copy()
    sp_base = out.metrics["spearman"]
    df["pos"] = df["mutant"].str.extract(r"^[A-Z](\d+)[A-Z]$").astype(float)
    per_pos = df.groupby("pos")["measured"].mean()

    # optional: per-mutant ESM-2 scores for this assay (overlay in panel A)
    esm2_scores = esm2_scores or os.path.join(_HERE, "proteingym_data", f"{dms_id}_esm2_scores.csv")
    esm_df, sp_esm = None, None
    if os.path.exists(esm2_scores):
        e = pd.read_csv(esm2_scores)
        m = df[["mutant", "measured"]].merge(e[["mutant", "esm2_score"]], on="mutant").dropna()
        if len(m) > 10:
            esm_df = m
            sp_esm = spearman(m["esm2_score"].to_numpy(), m["measured"].to_numpy())

    npanels = 2
    fig, axes = plt.subplots(1, npanels, figsize=(4.2 * npanels, 3.3))
    axes = np.atleast_1d(axes)

    # Panel A: score vs DMS
    ax = axes[0]
    if esm_df is not None:
        ax.scatter(_z(df["fitness_plm"]), df["measured"], s=6, alpha=0.20, color=GREY,
                   label=f"baseline ($\\rho$={sp_base:.2f})")
        ax.scatter(_z(esm_df["esm2_score"]), esm_df["measured"], s=6, alpha=0.30, color=BLUE,
                   label=f"ESM-2 ($\\rho$={sp_esm:.2f})")
        ax.set_xlabel("Standardized unsupervised score")
        ax.legend(loc="lower right", fontsize=7, framealpha=0.9)
    else:
        hb = ax.hexbin(df["fitness_plm"], df["measured"], gridsize=32, cmap="Blues", mincnt=1)
        ax.set_xlabel("Baseline unsupervised score (substitution matrix)")
        ax.text(0.05, 0.95, f"Spearman {sp_base:.2f}\n(baseline; ESM-2 pending)",
                transform=ax.transAxes, va="top", fontsize=8,
                bbox=dict(boxstyle="round", fc="white", ec=GREY, alpha=0.8))
        fig.colorbar(hb, ax=ax, label="mutants", shrink=0.85)
    ax.set_ylabel("Experimental DMS score")
    ax.set_title("A  Spike RBD: score vs DMS", loc="left", fontweight="bold")

    # Panel B: measured mutational landscape
    ax = axes[1]
    ax.plot(per_pos.index, per_pos.values, color=ORANGE, lw=0.9)
    ax.axhline(0, color=GREY, lw=0.7, ls="--")
    ax.set_xlabel("Spike position"); ax.set_ylabel("Mean DMS score")
    ax.set_title("B  Measured landscape", loc="left", fontweight="bold")
    ax.text(0.05, 0.05, f"{dms_id}\n{len(df):,} variants",
            transform=ax.transAxes, va="bottom", fontsize=7, color=GREY)

    fig.tight_layout()
    fig.savefig(outpath); plt.close(fig)
    return {"spearman_baseline": sp_base, "n": int(len(df)), "esm2_overlay": sp_esm}


def _short_label(dms_id):
    """Compact, human-readable assay label from a ProteinGym DMS_id."""
    parts = dms_id.split("_")
    return "_".join(parts[:2]) + (f" ({parts[2][:4]})" if len(parts) > 2 else "")


def _model_label(m):
    ml = str(m).lower()
    if ml == "pssm":
        return "PSSM (alignment)"
    if "650m" in ml:
        return "ESM-2 (650M)"
    if "esm2" in ml or "esm-2" in ml:
        return "ESM-2"
    return str(m)


_MODEL_COLORS = [BLUE, ORANGE, "#5aae61", "#9970ab"]


def figure_viral(outpath, results_csv=None, reference_csv=None):
    """Per-assay Spearman across the viral benchmark, with control + per-model means.

    One bar per assay if the results contain a single model; grouped bars
    (e.g. ESM-2 vs PSSM) if several models are present.
    """
    results_csv = results_csv or os.path.join(_HERE, "results_proteingym.csv")
    reference_csv = reference_csv or os.path.join(_HERE, "proteingym_data",
                                                  "ProteinGym_reference_file_substitutions.csv")
    if not (os.path.exists(results_csv) and os.path.exists(reference_csv)):
        return None
    r = pd.read_csv(results_csv)
    if not {"model", "spearman", "dms_id"}.issubset(r.columns):
        return None
    r = r.dropna(subset=["spearman"])
    tax = pd.read_csv(reference_csv).set_index("DMS_id")["taxon"]

    # QC flag: PSSM assays with weak MSA-to-target mapping (low identity/coverage)
    flag = set()
    if {"map_identity", "msa_coverage"}.issubset(r.columns):
        pr = r[r["model"] == "pssm"]
        for _, row in pr.iterrows():
            if (pd.notna(row["map_identity"]) and row["map_identity"] < 0.9) or \
               (pd.notna(row["msa_coverage"]) and row["msa_coverage"] < 0.9):
                flag.add(row["dms_id"])

    piv = r.pivot_table(index="dms_id", values="spearman", columns="model", aggfunc="mean")
    models = list(piv.columns)
    primary = next((m for m in models if "esm2" in str(m).lower()), models[0])
    piv["taxon"] = [tax.get(i, "?") for i in piv.index]
    piv["label"] = [_short_label(i) + (" *" if i in flag else "") for i in piv.index]
    viral = piv[piv["taxon"] == "Virus"].sort_values(primary)
    ctrl = piv[piv["taxon"] != "Virus"]
    if len(viral) == 0:
        return None
    order = pd.concat([viral, ctrl])
    y = np.arange(len(order))
    nm = len(models)
    bh = 0.8 / nm
    colors = {m: _MODEL_COLORS[i % len(_MODEL_COLORS)] for i, m in enumerate(models)}

    fig, ax = plt.subplots(figsize=(6.8, 0.36 * len(order) + 1.3))
    for j, m in enumerate(models):
        vals = order[m].to_numpy(dtype=float)
        off = (j - (nm - 1) / 2) * bh
        ax.barh(y + off, np.nan_to_num(vals), height=bh, color=colors[m], label=_model_label(m))
        if nm == 1:
            for yi, v in zip(y, vals):
                if np.isfinite(v):
                    ax.text(v + (0.01 if v >= 0 else -0.01), yi, f"{v:.2f}",
                            va="center", ha="left" if v >= 0 else "right", fontsize=6.5)
    ax.axvline(0, color="black", lw=0.6)
    # per-model viral mean lines
    means = {}
    for m in models:
        vmean = float(viral[m].mean())
        means[m] = vmean
        ax.axvline(vmean, color=colors[m], lw=1.1, ls="--")
    ax.set_yticks(y); ax.set_yticklabels(order["label"], fontsize=7)
    ax.set_xlabel("Spearman correlation vs DMS")
    xmin = min(-0.1, float(np.nanmin(order[models].to_numpy())) - 0.05)
    xmax = max(0.8, float(np.nanmax(order[models].to_numpy())) + 0.05)
    ax.set_xlim(xmin, xmax)
    title = ("ESM-2 zero-shot on ProteinGym viral assays" if nm == 1
             else "ProteinGym viral assays: " + " vs ".join(_model_label(m) for m in models))
    ax.set_title(title, loc="left", fontweight="bold")
    if len(ctrl):
        ci = len(viral)  # control rows start after viral block
        ax.text(0.99, (ci + 0.5) / len(order), "control", transform=ax.transAxes,
                fontsize=6.5, color=GREY, ha="right")
    mean_txt = "  ".join(f"{_model_label(m)} mean={means[m]:.2f}" for m in models)
    ax.legend(loc="lower right", fontsize=7, framealpha=0.9, title=mean_txt, title_fontsize=6.5)
    fig.tight_layout()
    fig.savefig(outpath); plt.close(fig)
    return {"models": [_model_label(m) for m in models],
            "viral_means": {_model_label(m): round(means[m], 3) for m in models},
            "n_viral": int(len(viral))}


def figure_viral_plms(outpath, ref_csv=None):
    """Per-assay Spearman for single-sequence vs alignment-based models on the viral
    assays, from ProteinGym's released scores (companion to Table 3). Draws ESM-2
    (single-sequence), MSA Transformer, Tranception, and the site-independent
    alignment baseline, with per-model viral means."""
    ref_csv = ref_csv or os.path.join(_HERE, "proteingym_reference_scores_viral.csv")
    if not os.path.exists(ref_csv):
        return None
    d = pd.read_csv(ref_csv).set_index("dms_id")
    order = ["ESM-2 650M (single-seq)", "MSA Transformer", "Tranception L",
             "Site-independent (alignment)"]
    cols = [c for c in order if c in d.columns]
    if "Site-independent (alignment)" in d.columns:
        d = d.sort_values("Site-independent (alignment)")
    short = {"ESM-2 650M (single-seq)": "ESM-2 (single-seq)", "MSA Transformer": "MSA Transformer",
             "Tranception L": "Tranception L", "Site-independent (alignment)": "Site-independent"}
    colors = {"ESM-2 650M (single-seq)": ORANGE, "MSA Transformer": "#5aae61",
              "Tranception L": "#9970ab", "Site-independent (alignment)": BLUE}
    y = np.arange(len(d)); nm = len(cols); bh = 0.8 / nm
    fig, ax = plt.subplots(figsize=(7.0, 0.42 * len(d) + 1.4))
    means = {}
    for j, c in enumerate(cols):
        vals = d[c].to_numpy(dtype=float)
        off = (j - (nm - 1) / 2) * bh
        ax.barh(y + off, np.nan_to_num(vals), height=bh, color=colors.get(c, GREY), label=short.get(c, c))
        means[c] = float(np.nanmean(vals))
        ax.axvline(means[c], color=colors.get(c, GREY), lw=1.1, ls="--")
    ax.axvline(0, color="black", lw=0.6)
    ax.set_yticks(y); ax.set_yticklabels([_short_label(i) for i in d.index], fontsize=7)
    ax.set_ylim(-0.6, len(d) - 0.4)          # no extra room needed; legend sits outside
    ax.set_xlabel("Spearman correlation vs DMS")
    # legend as a horizontal strip ABOVE the axes so it never masks the bottom assay row;
    # order matches the plotting order (ESM-2, MSA Transformer, Tranception, site-independent)
    ax.legend(loc="lower left", bbox_to_anchor=(0.0, 1.01), ncol=len(cols),
              fontsize=6.8, frameon=False, handlelength=1.2, columnspacing=1.2)
    fig.tight_layout(); fig.savefig(outpath); plt.close(fig)
    return {"means": {short.get(c, c): round(means[c], 3) for c in cols}, "n": int(len(d))}


def figure_overview(outpath):
    """Conceptual schematic: three fitness terms, each with interchangeable
    unsupervised estimators, fused and calibrated, then validated. Solid boxes are
    estimators evaluated here; hatched boxes are components framed as future work."""
    from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
    import matplotlib as mpl
    mpl.rcParams["hatch.color"] = "#c9ced6"   # light-gray hatch, independent of the box border
    mpl.rcParams["hatch.linewidth"] = 0.5     # thin hatch lines
    fig, ax = plt.subplots(figsize=(7.2, 4.6)); ax.set_xlim(0, 100); ax.set_ylim(0, 100); ax.axis("off")

    def box(x, y, w, h, text, fc, hatch=None, fs=8, tc="black"):
        # dark, crisp border regardless of hatch; the hatch itself is light (rcParams above)
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.6,rounding_size=2",
                     linewidth=1.0, edgecolor="#333", facecolor=fc, hatch=hatch))
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs, color=tc, zorder=5)

    VAL, FUT, HDR = "#dbeafe", "#f3f4f6", "#1f2a44"
    # term headers
    terms = [("Intrinsic fitness", 6), ("Antigenic escape", 38), ("Realized growth", 70)]
    for name, x in terms:
        ax.text(x + 13, 94, name, ha="center", va="center", fontsize=9.5, fontweight="bold", color=HDR)
    # intrinsic estimators (all evaluated)
    box(6, 78, 26, 8, "PLM zero-shot (ESM-2)", VAL)
    box(6, 68, 26, 8, "alignment PSSM", VAL)
    box(6, 58, 26, 8, "phylo. mutation--selection", VAL)
    # antigenic estimators
    box(38, 78, 26, 8, "structural accessibility", VAL)
    box(38, 68, 26, 8, "codon-model selection", FUT, hatch="//")
    box(38, 58, 26, 8, "chemical dissimilarity", VAL)
    # growth
    box(70, 78, 24, 8, "MLR / surveillance\ngrowth advantage", FUT, hatch="//", fs=7.5)
    # fusion + calibration + validation column
    box(30, 40, 40, 9, "Score fusion\n(intrinsic / additive / multiplicative)", "#fde68a", fs=8)
    box(30, 26, 40, 9, "Sign-of-selection calibration\n(self-supervised)", "#fde68a", fs=8)
    box(24, 10, 52, 9, "Validation vs DMS, alignment frequency,\nphylogenetic and surveillance fitness", "#bbf7d0", fs=8)

    def arrow(x1, y1, x2, y2):
        ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=9,
                     lw=0.9, color="#555", shrinkA=1, shrinkB=1))
    for yy in (82, 72, 62):   # intrinsic -> fusion
        arrow(32, yy, 44, 49)
    for yy in (82, 72, 62):
        arrow(64, yy, 52, 49)
    arrow(82, 78, 60, 49)
    arrow(50, 40, 50, 35)
    arrow(50, 26, 50, 19)
    # legend
    box(6, 2, 20, 6, "evaluated here", VAL, fs=7.5)
    box(30, 2, 24, 6, "framed as future work", FUT, hatch="//", fs=7.5)
    fig.tight_layout(); fig.savefig(outpath); plt.close(fig)
    return {"schematic": True}


def _bootstrap_ci(x, B=10000, seed=0):
    x = np.asarray(x, float); x = x[np.isfinite(x)]
    rng = np.random.default_rng(seed)
    bs = rng.choice(x, size=(B, len(x)), replace=True).mean(axis=1)
    return x.mean(), np.percentile(bs, 2.5), np.percentile(bs, 97.5)


def figure_benchmark_ci(outpath, ref_csv=None):
    """Mean Spearman with 95% bootstrap CIs (over the 21 viral assays) for the
    single-sequence PLM, MSA Transformer, Tranception, and site-independent PSSM."""
    ref_csv = ref_csv or os.path.join(_HERE, "proteingym_reference_scores_viral.csv")
    if not os.path.exists(ref_csv):
        return None
    d = pd.read_csv(ref_csv).set_index("dms_id")
    order = ["ESM-2 650M (single-seq)", "MSA Transformer", "Tranception L",
             "Site-independent (alignment)"]
    cols = [c for c in order if c in d.columns]
    short = {"ESM-2 650M (single-seq)": "ESM-2 (single-seq)", "MSA Transformer": "MSA Transformer",
             "Tranception L": "Tranception L", "Site-independent (alignment)": "Site-independent"}
    colors = {"ESM-2 650M (single-seq)": ORANGE, "MSA Transformer": "#5aae61",
              "Tranception L": "#9970ab", "Site-independent (alignment)": BLUE}
    stats = {c: _bootstrap_ci(d[c].to_numpy(float)) for c in cols}
    y = np.arange(len(cols))[::-1]
    fig, ax = plt.subplots(figsize=(6.6, 2.6))
    for yi, c in zip(y, cols):
        m, lo, hi = stats[c]
        ax.barh(yi, m, height=0.6, color=colors[c])
        ax.errorbar(m, yi, xerr=[[m - lo], [hi - m]], fmt="none", ecolor="#222", capsize=3, lw=1.1)
        ax.text(hi + 0.01, yi, f"{m:.2f} [{lo:.2f}, {hi:.2f}]", va="center", fontsize=7.5)
    ax.set_yticks(y); ax.set_yticklabels([short[c] for c in cols], fontsize=8)
    ax.set_xlabel("Mean Spearman vs DMS over 21 viral assays (95% bootstrap CI)")
    ax.set_xlim(0, max(hi for _, _, hi in stats.values()) + 0.14)
    ax.axvline(0, color="black", lw=0.6)
    ax.set_title("Single-sequence vs alignment-based models (viral)", loc="left", fontweight="bold")
    fig.tight_layout(); fig.savefig(outpath); plt.close(fig)
    return {short[c]: tuple(round(v, 3) for v in stats[c]) for c in cols}


def figure_mutsel_matched(outpath, boot_csv=None, paired_csv=None):
    """Per-virus grouped bars with 95% bootstrap CIs for three estimators on the same
    shared mutation set: single-sequence ESM-2, the same-alignment PSSM, and the
    phylogenetic MutSel Delta-F. The paired MutSel-vs-matched-PSSM contrast (bootstrap
    p) is annotated above each virus."""
    boot_csv = boot_csv or os.path.join(_HERE, "phylobayes_bootstrap.csv")
    paired_csv = paired_csv or os.path.join(_HERE, "phylobayes_bootstrap_paired.csv")
    if not os.path.exists(boot_csv):
        return None
    b = pd.read_csv(boot_csv)
    paired = pd.read_csv(paired_csv).set_index("virus") if os.path.exists(paired_csv) else None
    series = ["ESM-2", "matched_PSSM", "MutSel"]
    label = {"ESM-2": "ESM-2 (single-seq)", "matched_PSSM": "PSSM (same alignment)",
             "MutSel": "MutSel (phylo.)"}
    colors = {"ESM-2": ORANGE, "matched_PSSM": BLUE, "MutSel": "#9970ab"}
    names = {"spike": "SARS-CoV-2 spike RBD", "flu": "H3N2 HA"}
    viruses = [v for v in ("spike", "flu") if v in set(b.virus)]
    if not viruses:
        return None
    x = np.arange(len(viruses)); nb = len(series); bw = 0.8 / nb
    fig, ax = plt.subplots(figsize=(6.4, 3.6))
    vtop = {v: float(b[b.virus == v].ci_hi.max()) for v in viruses}
    gtop = max(vtop.values())
    for j, s in enumerate(series):
        xs, ys, err = [], [], [[], []]
        for i, v in enumerate(viruses):
            row = b[(b.virus == v) & (b.estimator == s)]
            if row.empty:
                continue
            rho, lo, hi = float(row.rho.iloc[0]), float(row.ci_lo.iloc[0]), float(row.ci_hi.iloc[0])
            xs.append(i + (j - (nb - 1) / 2) * bw); ys.append(rho)
            err[0].append(rho - lo); err[1].append(hi - rho)
        ax.bar(xs, ys, width=bw, color=colors[s], label=label[s])
        ax.errorbar(xs, ys, yerr=err, fmt="none", ecolor="#222", capsize=3, lw=1.0)
    # annotate the paired matched-PSSM vs MutSel contrast just above each virus's bars
    if paired is not None:
        for i, v in enumerate(viruses):
            if v in paired.index:
                p = float(paired.loc[v, "p"])
                txt = "p < 0.001" if p < 1e-3 else f"p = {p:.3f}"
                ax.text(i, vtop[v] + 0.03, f"PSSM $>$ MutSel, {txt}", ha="center", fontsize=7.2)
    ax.set_xticks(x); ax.set_xticklabels([names.get(v, v) for v in viruses], fontsize=9)
    ax.set_ylabel("Spearman vs DMS")
    ax.axhline(0, color="black", lw=0.6)
    ax.set_title("Phylogenetic MutSel does not beat a matched alignment count",
                 loc="left", fontweight="bold", fontsize=10)
    ax.legend(fontsize=7.5, loc="upper left", framealpha=0.9)
    ax.set_ylim(min(0, float(b.ci_lo.min())) - 0.05, gtop + 0.14)
    fig.tight_layout(); fig.savefig(outpath); plt.close(fig)
    return {v: {s: round(float(b[(b.virus == v) & (b.estimator == s)].rho.iloc[0]), 3)
                for s in series if not b[(b.virus == v) & (b.estimator == s)].empty}
            for v in viruses}


def main():
    default_outdir = os.path.join(os.path.dirname(_PKG), "manuscript")
    if not os.path.isdir(default_outdir):
        default_outdir = _HERE
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default=default_outdir)
    ap.add_argument("--esm2-scores", default=None,
                    help="Per-mutant ESM-2 scores CSV to overlay (default: auto-detect cached)")
    ap.add_argument("--results", default=None,
                    help="results_proteingym.csv for the aggregate panel (default: auto-detect)")
    args = ap.parse_args()
    os.makedirs(args.outdir, exist_ok=True)

    s = figure_simulation(os.path.join(args.outdir, "figure_simulation.pdf"))
    r = figure_realdata(os.path.join(args.outdir, "figure_realdata.pdf"),
                        esm2_scores=args.esm2_scores, results_csv=args.results)
    # 4-model view (ESM-2 vs MSA Transformer vs Tranception vs site-independent) when the
    # ProteinGym reference scores are present; otherwise the ESM-2-vs-PSSM view.
    vpath = os.path.join(args.outdir, "figure_viral_benchmark.pdf")
    v = figure_viral_plms(vpath) or figure_viral(vpath, results_csv=args.results)
    ov = figure_overview(os.path.join(args.outdir, "figure_overview.pdf"))
    ci = figure_benchmark_ci(os.path.join(args.outdir, "figure_benchmark_ci.pdf"))
    ms = figure_mutsel_matched(os.path.join(args.outdir, "figure_mutsel_matched.pdf"))
    print("figure_overview.pdf       :", ov)
    print("figure_simulation.pdf     :", {k: round(x, 3) for k, x in s.items()})
    print("figure_realdata.pdf       :", r)
    print("figure_viral_benchmark.pdf:", v if v else "(skipped: no results file)")
    print("figure_benchmark_ci.pdf   :", ci if ci else "(skipped: no reference scores)")
    print("figure_mutsel_matched.pdf :", ms if ms else "(skipped: no phylobayes_vs_pssm.csv)")
    print("written to:", args.outdir)


if __name__ == "__main__":
    main()
