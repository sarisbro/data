#!/usr/bin/env python3
"""PSSM performance vs. sequence collection date, on real dated viral alignments.

Tests time-inhomogeneous selection directly: build a per-column PSSM from
sequences collected in a given epoch, score it against a fixed deep-mutational-
scanning assay for the same protein, and plot Spearman vs collection date.

Presets (``--virus``):
  spike : SARS-CoV-2 spike RBD (331-531) vs Starr 2020 ACE2-binding DMS.
  flu   : H3N2 hemagglutinin (1-566) vs Lee 2018 A/Perth/2009 replication DMS.

Steps: (1) extract the assayed region from each dated isolate by local alignment
to the reference (cached/resumable); (2) sweep cumulative and sliding
collection-date windows; (3) score the DMS and plot.

Inputs:  reproduce/<virus>_temporal/records.jsonl  (from fetch_*_dated.py)
         reproduce/proteingym_data/<DMS_id>.csv + reference
Output:  manuscript/figure_temporal_<virus>.pdf
"""
from __future__ import annotations
import json, os, sys, datetime as dt
import numpy as np
from dateutil import parser as _dparser

_HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.dirname(_HERE))
PG = os.path.join(_HERE, "proteingym_data")
AA20 = "ACDEFGHIKLMNPQRSTVWY"

PRESETS = {
    "spike": dict(dms="SPIKE_SARS2_Starr_bind_2020", data="spike_temporal", cache="rbd.jsonl",
                  region=(331, 531), label="SARS-CoV-2 spike RBD",
                  assay="2020 ACE2-binding", event=(dt.date(2021, 11, 1), "Omicron\nemerges")),
    "flu":   dict(dms="C6KNH7_9INFA_Lee_2018", data="flu_temporal", cache="ha.jsonl",
                  region=(1, 566), label="H3N2 hemagglutinin",
                  assay="Perth/2009 replication", event=(dt.date(2009, 1, 1), "assay strain\n(2009)")),
}


def _target_seq(dms_id):
    import pandas as pd
    ref = pd.read_csv(os.path.join(PG, "ProteinGym_reference_file_substitutions.csv"))
    return str(ref[ref["DMS_id"] == dms_id].iloc[0]["target_seq"])


def _parse_date(s):
    try:
        d = _dparser.parse(str(s), default=dt.datetime(2000, 7, 1)).date()
        return d if 1960 <= d.year <= 2026 else None
    except Exception:
        return None


def extract_region(cfg):
    """Extract the assayed region (reference-column-aligned) from each isolate."""
    from Bio.Align import PairwiseAligner, substitution_matrices
    rs, re_ = cfg["region"]
    target = _target_seq(cfg["dms"]); reg_ref = target[rs - 1:re_]
    aligner = PairwiseAligner(); aligner.mode = "local"
    aligner.substitution_matrix = substitution_matrices.load("BLOSUM62")
    aligner.open_gap_score = -11; aligner.extend_gap_score = -1

    data_dir = os.path.join(_HERE, cfg["data"]); cache = os.path.join(data_dir, cfg["cache"])
    recs_path = os.path.join(data_dir, "records.jsonl")
    done = set()
    if os.path.exists(cache):
        for ln in open(cache):
            done.add(json.loads(ln)["acc"])
    recs = [json.loads(l) for l in open(recs_path)]
    todo = [r for r in recs if r["acc"] not in done]
    if todo:
        with open(cache, "a") as out:
            for i, r in enumerate(todo):
                d = _parse_date(r["date"])
                if d is None:
                    continue
                iso = r["seq"]; win = iso[max(0, rs - 30):re_ + 30]
                try:
                    aln = aligner.align(win, reg_ref)[0]
                    row = ["-"] * len(reg_ref)
                    wb, rb = aln.aligned
                    for (ws, we), (rsb, reb) in zip(wb, rb):
                        for o in range(reb - rsb):
                            row[rsb + o] = win[ws + o]
                    out.write(json.dumps({"acc": r["acc"], "date": d.isoformat(),
                                          "reg": "".join(row)}) + "\n")
                except Exception:
                    pass
                if (i + 1) % 400 == 0:
                    out.flush(); print(f"  extracted {i+1}/{len(todo)}", file=sys.stderr)
    return [json.loads(l) for l in open(cache)]


_AAIDX = {a: j for j, a in enumerate(AA20)}


def _pssm_scores(sub_arr, parsed_muts, region_start, pc=0.5):
    """Vectorized log-odds for pre-parsed mutants from an (N x L) char array."""
    L = sub_arr.shape[1]
    counts = np.empty((L, 20))
    for j, aa in enumerate(AA20):
        counts[:, j] = (sub_arr == aa).sum(0)
    n = counts.sum(1)
    denom = n + pc * 20
    out = {}
    for tok, wt, col, mut in parsed_muts:      # col already 0-based within region
        pm = (counts[col, mut] + pc) / denom[col]
        pw = (counts[col, wt] + pc) / denom[col]
        out[tok] = float(np.log(pm) - np.log(pw))
    return out


def compute_sweep(cfg, rows, B=400, seed=0, depth_n=100, depth_reps=20):
    """Cumulative and sliding-window Spearman-vs-date series, each with a 95%
    bootstrap CI (resampling the DMS mutations) and the number of sequences in the
    window. Returns tuples (date, rho, lo, hi, n_seq).

    Also returns a depth-matched sliding series (``sldfx``): every window with at
    least ``depth_n`` sequences is subsampled to exactly ``depth_n`` (mean over
    ``depth_reps`` random draws), holding alignment depth constant across epochs so
    that any remaining epoch dependence cannot be an artifact of growing depth."""
    import pandas as pd
    from scipy.stats import rankdata
    rng = np.random.default_rng(seed)
    rs, re_ = cfg["region"]
    dms = pd.read_csv(os.path.join(PG, f"{cfg['dms']}.csv")).dropna(subset=["DMS_score"])
    dms = dms[dms["mutant"].str.match(r"^[A-Z]\d+[A-Z]$")]
    dms = dms[dms["mutant"].str[1:-1].astype(int).between(rs, re_)]
    L = re_ - rs + 1
    parsed = []
    for tok in dms["mutant"]:
        wt, pos, mut = tok[0], int(tok[1:-1]), tok[-1]
        col = pos - rs
        if 0 <= col < L and wt in _AAIDX and mut in _AAIDX:
            parsed.append((tok, _AAIDX[wt], col, _AAIDX[mut]))
    dm = dms.set_index("mutant")["DMS_score"]
    tokens = [p[0] for p in parsed]
    ry = rankdata(np.array([dm[t] for t in tokens], float)); ry = ry - ry.mean()   # fixed DMS ranks
    # vectorized mutant indices (avoid a per-mutant Python loop inside the sweep)
    cols = np.array([p[2] for p in parsed]); wt_i = np.array([p[1] for p in parsed])
    mut_i = np.array([p[3] for p in parsed]); pc = 0.5

    dates = np.array([dt.date.fromisoformat(r["date"]) for r in rows])
    full = np.array([list(r["reg"]) for r in rows], dtype="<U1")
    months = pd.date_range(min(dates), max(dates), freq="MS").date

    def score(mask, min_n=50):
        ns = int(mask.sum())
        if ns < min_n or len(tokens) < 10:
            return (np.nan, np.nan, np.nan, ns)
        sub = full[mask]
        counts = np.stack([(sub == aa).sum(0) for aa in AA20], axis=1).astype(float)  # (L,20)
        denom = counts.sum(1) + pc * 20
        pm = (counts[cols, mut_i] + pc) / denom[cols]
        pw = (counts[cols, wt_i] + pc) / denom[cols]
        rx = rankdata(np.log(pm) - np.log(pw)); rx = rx - rx.mean()
        n = len(rx)
        den = np.sqrt((rx ** 2).sum() * (ry ** 2).sum())
        rho = float((rx * ry).sum() / den) if den > 0 else np.nan
        # fast bootstrap CI: Pearson of the (fixed) ranks over resampled mutations
        idx = rng.integers(0, n, size=(B, n))
        X = rx[idx]; Y = ry[idx]
        X -= X.mean(1, keepdims=True); Y -= Y.mean(1, keepdims=True)
        num = (X * Y).sum(1); dd = np.sqrt((X ** 2).sum(1) * (Y ** 2).sum(1))
        b = num / np.where(dd > 0, dd, np.nan)
        lo, hi = np.nanpercentile(b, [2.5, 97.5])
        return (rho, float(lo), float(hi), ns)

    def rho_of(sub):
        counts = np.stack([(sub == aa).sum(0) for aa in AA20], axis=1).astype(float)
        denom = counts.sum(1) + pc * 20
        rx = rankdata(np.log((counts[cols, mut_i] + pc) / denom[cols])
                      - np.log((counts[cols, wt_i] + pc) / denom[cols])); rx = rx - rx.mean()
        d = np.sqrt((rx ** 2).sum() * (ry ** 2).sum())
        return float((rx * ry).sum() / d) if d > 0 else np.nan

    def score_fixed(mask):
        idxs = np.flatnonzero(mask)
        if len(idxs) < depth_n or len(tokens) < 10:
            return (np.nan, np.nan, np.nan, depth_n)
        rr = np.array([rho_of(full[rng.choice(idxs, depth_n, replace=False)])
                       for _ in range(depth_reps)])
        lo, hi = np.nanpercentile(rr, [2.5, 97.5])
        return (float(np.nanmean(rr)), float(lo), float(hi), depth_n)

    half = dt.timedelta(days=183)
    cum = [(T, *score(dates <= T)) for T in months]
    sld = [(T, *score((dates >= T - half) & (dates <= T + half))) for T in months]
    sldfx = [(T, *score_fixed((dates >= T - half) & (dates <= T + half))) for T in months]
    cov = sum(1 for _, r, *_ in sldfx if not np.isnan(r))
    return {"cfg": cfg, "dates": dates, "cum": cum, "sld": sld, "sldfx": sldfx,
            "depth_n": depth_n, "depth_cov": cov, "n": len(rows)}


def _plot_axis(ax, res, panel=None):
    cfg = res["cfg"]
    # background (right axis): number of sequences in the sliding window, to show depth
    ax2 = ax.twinx()
    xsN = [t for (t, r, lo, hi, ns) in res["sld"]]
    nsN = [ns for (t, r, lo, hi, ns) in res["sld"]]
    ax2.fill_between(xsN, 0, nsN, color="#9aa0a6", alpha=0.16, step="mid", lw=0, zorder=0)
    ax2.set_ylabel("sequences in $\\pm$6-mo window", fontsize=8, color="#777")
    ax2.tick_params(axis="y", labelsize=7, colors="#777")
    ax2.set_ylim(0, max(nsN) * 1.05 if nsN else 1)
    ax.set_zorder(ax2.get_zorder() + 1); ax.patch.set_visible(False)   # correlation on top

    dn = res.get("depth_n")
    for data, color, lab, dashed in [
            (res["cum"], "#2c6fbb", "cumulative ($\\leq$ date)", False),
            (res["sld"], "#e08214", "sliding window ($\\pm$6 mo)", False),
            (res.get("sldfx", []), "#2ca02c", f"sliding, fixed depth ($N={dn}$)", True)]:
        pts = [(t, r, lo, hi) for (t, r, lo, hi, ns) in data if not np.isnan(r)]
        if not pts:
            continue
        xs = [t for t, r, lo, hi in pts]; ys = [r for t, r, lo, hi in pts]
        los = [lo for t, r, lo, hi in pts]; his = [hi for t, r, lo, hi in pts]
        if dashed:
            ax.plot(xs, ys, "--", lw=1.4, color=color, label=lab, zorder=3)
        else:
            ax.fill_between(xs, los, his, color=color, alpha=0.18, lw=0, zorder=2)
            ax.plot(xs, ys, "-o", ms=2.5, color=color, label=lab, zorder=3)
    ev_date, ev_lab = cfg["event"]
    if res["dates"].min() <= ev_date <= res["dates"].max():
        ax.axvline(ev_date, color="#888", ls=":", lw=1)
        ax.text(ev_date, ax.get_ylim()[1], " " + ev_lab, fontsize=7, va="top", color="#555")
    ax.axhline(0, color="k", lw=0.5)
    ax.set_xlabel("Sequence collection date")
    # adaptive, non-overlapping date ticks (yearly-ish for spike, coarser for the 56-yr flu span)
    import matplotlib.dates as mdates
    loc = mdates.AutoDateLocator(minticks=4, maxticks=8)
    ax.xaxis.set_major_locator(loc)
    ax.xaxis.set_major_formatter(mdates.ConciseDateFormatter(loc))
    ax.set_ylabel(f"Spearman vs {cfg['assay']} DMS")
    title = f"{cfg['label']}"
    ax.set_title((f"{panel}  " if panel else "") + title, loc="left", fontweight="bold", fontsize=10)
    ax.legend(loc="lower right", fontsize=7.5, framealpha=0.9)


def _summary(res):
    cum = [r for _, r, lo, hi, ns in res["cum"] if not np.isnan(r)]
    sld = [r for _, r, lo, hi, ns in res["sld"] if not np.isnan(r)]
    return {"n": res["n"], "cum_last": round(cum[-1], 3) if cum else None,
            "sld_range": (round(min(sld), 3), round(max(sld), 3)) if sld else None}


def figure_single(cfg, rows, out_pdf):
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    plt.rcParams.update({"font.family": "sans-serif", "axes.spines.top": False,
                         "axes.spines.right": False})
    res = compute_sweep(cfg, rows)
    fig, ax = plt.subplots(figsize=(7.2, 3.6)); _plot_axis(ax, res)
    fig.tight_layout(); fig.savefig(out_pdf); plt.close(fig)
    return _summary(res)


def figure_combined(out_pdf):
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    plt.rcParams.update({"font.family": "sans-serif", "axes.spines.top": False,
                         "axes.spines.right": False})
    resS = compute_sweep(PRESETS["spike"], extract_region(PRESETS["spike"]))
    resF = compute_sweep(PRESETS["flu"], extract_region(PRESETS["flu"]))
    fig, axes = plt.subplots(1, 2, figsize=(11.0, 3.7))
    _plot_axis(axes[0], resS, "A"); _plot_axis(axes[1], resF, "B")
    fig.suptitle("Prediction of a fixed DMS by PSSMs built from sequences of different collection epochs",
                 fontsize=10, fontweight="bold", x=0.02, ha="left")
    fig.tight_layout(rect=(0, 0, 1, 0.96)); fig.savefig(out_pdf); plt.close(fig)
    return {"spike": _summary(resS), "flu": _summary(resF)}


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--virus", choices=list(PRESETS) + ["both"], default="spike")
    args = ap.parse_args()
    outdir = os.path.join(os.path.dirname(os.path.dirname(_HERE)), "manuscript")
    if not os.path.isdir(outdir):
        outdir = _HERE
    if args.virus == "both":
        info = figure_combined(os.path.join(outdir, "figure_temporal_both.pdf"))
    else:
        cfg = PRESETS[args.virus]
        info = figure_single(cfg, extract_region(cfg),
                             os.path.join(outdir, f"figure_temporal_{args.virus}.pdf"))
    print(f"[temporal:{args.virus}]", info)


if __name__ == "__main__":
    main()
