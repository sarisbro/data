#!/usr/bin/env python3
"""Regenerate every synthetic/simulated result in the manuscript (Table 1).

Self-contained and fully seeded: running this reproduces the numbers reported in
the "Simulation results" subsection. All experiments use synthetic or simulated
data; the fitness term uses the substitution-matrix fallback scorer (no PLM
weights required), except that none of these experiments claims predictive
accuracy on real proteins; they validate implementation correctness and the
growth estimator against known ground truth.

Usage:
    python reproduce/reproduce_synthetic.py            # prints table, writes CSV
    python reproduce/reproduce_synthetic.py --out x.csv

Outputs: reproduce/results_synthetic.csv
"""

from __future__ import annotations

import argparse
import os
import sys
import tempfile

import numpy as np

# make the evescape_plm package importable when run from anywhere
_REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _REPO)

from evescape_plm.data import AA20, enumerate_single_mutants, read_fasta          # noqa: E402
from evescape_plm.scorers import MockScorer                                       # noqa: E402
from evescape_plm.pipeline import run_pipeline                                    # noqa: E402
from evescape_plm.growth_fit import (                                            # noqa: E402
    load_counts, load_genotypes, fit_variant_growth, fit_mutation_growth,
    build_genotype_matrix,
)
from evescape_plm.validation import spearman, auroc                              # noqa: E402
from evescape_plm.natural_validation import column_counts                        # noqa: E402

# Fixed seeds for every experiment (change here to explore variance)
SEED_GROWTH = 11
SEED_MSA = 1
SEED_DMS = 0

TEST_SEQ = "MFVFLVLLPLVSSQCVNLTTRTQLPPAYTNSFTRGVYYPDKVFRSSVLHSTQDLFLPFFS"

# A minimal 3-residue structure (ALA-GLY-VAL) for the RSA/mapping check
MINI_PDB = """\
ATOM      1  N   ALA A   1       0.000   0.000   0.000  1.00  0.00           N
ATOM      2  CA  ALA A   1       1.458   0.000   0.000  1.00  0.00           C
ATOM      3  C   ALA A   1       2.009   1.420   0.000  1.00  0.00           C
ATOM      4  O   ALA A   1       1.251   2.390   0.000  1.00  0.00           O
ATOM      5  CB  ALA A   1       1.988  -0.773   1.199  1.00  0.00           C
ATOM      6  N   GLY A   2       3.332   1.552   0.000  1.00  0.00           N
ATOM      7  CA  GLY A   2       3.999   2.845   0.000  1.00  0.00           C
ATOM      8  C   GLY A   2       5.510   2.700   0.000  1.00  0.00           C
ATOM      9  O   GLY A   2       6.045   1.590   0.000  1.00  0.00           O
ATOM     10  N   VAL A   3       6.207   3.827   0.000  1.00  0.00           N
ATOM     11  CA  VAL A   3       7.665   3.844   0.000  1.00  0.00           C
ATOM     12  C   VAL A   3       8.203   5.269   0.000  1.00  0.00           C
ATOM     13  O   VAL A   3       7.454   6.243   0.000  1.00  0.00           O
ATOM     14  CB  VAL A   3       8.235   3.088  -1.220  1.00  0.00           C
ATOM     15  CG1 VAL A   3       9.762   3.100  -1.200  1.00  0.00           C
ATOM     16  CG2 VAL A   3       7.735   1.650  -1.250  1.00  0.00           C
TER      17      VAL A   3
END
"""


def experiment_growth(tmp):
    """Recover known per-mutation and per-variant growth effects (Table 1)."""
    rng = np.random.default_rng(SEED_GROWTH)
    positions = [2, 5, 8, 11, 14, 17, 20]
    effects = [0.12, 0.09, -0.05, 0.04, 0.06, 0.03, 0.00]
    muts, true_beta = [], {}
    for pos, eff in zip(positions, effects):
        wt = TEST_SEQ[pos - 1]
        alt = rng.choice([a for a in AA20 if a != wt])
        tok = f"{wt}{pos}{alt}"
        muts.append(tok); true_beta[tok] = eff

    variants, geno = [], {}
    for i in range(12):
        variants.append(f"V{i}")
        geno[f"V{i}"] = [m for m in muts if rng.random() < 0.5]
    r_true = {v: sum(true_beta[m] for m in geno[v]) for v in variants}

    alpha = dict(zip(variants, rng.normal(0, 1.5, len(variants))))
    counts_rows = {}
    times = np.arange(0, 140, 7)
    counts = np.zeros((len(times), len(variants)))
    for ti, t in enumerate(times):
        lg = np.array([alpha[v] + r_true[v] * t for v in variants])
        p = np.exp(lg - lg.max()); p /= p.sum()
        counts[ti] = rng.multinomial(500, p)

    # per-mutation recovery
    G, kept = build_genotype_matrix(variants, {v: set(geno[v]) for v in variants})
    fm = fit_mutation_growth(counts, times.astype(float), variants,
                             {v: set(geno[v]) for v in variants}, l2=0.5, verbose=False)
    bhat = dict(zip(fm.table.mutant, fm.table.growth))
    tb = np.array([true_beta[m] for m in kept]); bh = np.array([bhat[m] for m in kept])
    sp_mut = spearman(tb, bh); pe_mut = float(np.corrcoef(tb, bh)[0, 1])

    # per-variant recovery
    fv = fit_variant_growth(counts, times.astype(float), variants, verbose=False)
    rhat = dict(zip(fv.table.variant, fv.table.growth))
    rt = np.array([r_true[v] for v in variants]); rh = np.array([rhat[v] for v in variants])
    sp_var = spearman(rt, rh)

    return [
        ("Growth estimator (per mutation)",
         f"12 variants, {len(kept)} effects, {len(times)} time points",
         f"Spearman {sp_mut:.2f}, Pearson {pe_mut:.2f}", sp_mut),
        ("Growth estimator (per variant)", "same simulation",
         f"Spearman {sp_var:.2f}", sp_var),
    ]


def experiment_rsa(tmp):
    """RSA range and template->query coordinate mapping (Table 1)."""
    from evescape_plm.structure_rsa import (compute_rsa_by_residue, _load_model,
                                            _chain_sequence, map_rsa_to_query)
    pdb = os.path.join(tmp, "mini.pdb")
    open(pdb, "w").write(MINI_PDB)
    rsa_by_res = compute_rsa_by_residue(pdb)
    in_range = all(0.0 <= v <= 1.0 for v in rsa_by_res.values())
    model = _load_model(pdb)
    tseq, tres = _chain_sequence(model["A"])
    m1 = map_rsa_to_query("MAGVK", tseq, tres, rsa_by_res, "A")   # expect 2,3,4
    m2 = map_rsa_to_query("WWWAGV", tseq, tres, rsa_by_res, "A")  # expect 4,5,6
    ok = in_range and sorted(m1) == [2, 3, 4] and sorted(m2) == [4, 5, 6]
    return [("Structure-based RSA", "controlled structure + offset alignment",
             "correct range and position mapping" if ok else "FAILED", float(ok))]


def experiment_msa(tmp):
    """Label-free MSA validation on a synthetic alignment (consistency check)."""
    rng = np.random.default_rng(SEED_MSA)
    fasta = os.path.join(tmp, "seq.fasta")
    open(fasta, "w").write(f">ref\n{TEST_SEQ}\n")
    mock = MockScorer()
    rows = [(">ref", TEST_SEQ)]
    for k in range(40):
        s = list(TEST_SEQ)
        for _ in range(6):
            pos = int(rng.integers(0, len(TEST_SEQ))); wt = TEST_SEQ[pos]
            cands = [a for a in AA20 if a != wt]
            w = np.array([mock.score(TEST_SEQ, [f"{wt}{pos+1}{a}"])[f"{wt}{pos+1}{a}"] for a in cands], float)
            p = np.exp(w - w.max()); p /= p.sum()
            s[pos] = str(rng.choice(cands, p=p))
        rows.append((f">v{k}", "".join(s)))
    msa = os.path.join(tmp, "msa.fasta")
    with open(msa, "w") as fh:
        for n, s in rows:
            fh.write(f"{n}\n{s}\n")
    m = run_pipeline(fasta=fasta, scorer="mock", msa=msa, verbose=False).metrics
    return [("Label-free MSA validation", "synthetic alignment (consistency check)",
             f"AUROC {m['msa_auroc_observed']:.2f}, enrichment@P {m['msa_enrichment_topP']:.2f}",
             m["msa_auroc_observed"])]


def experiment_dms(tmp):
    """Synthetic DMS scoring (baseline score + noise)."""
    import pandas as pd
    rng = np.random.default_rng(SEED_DMS)
    fasta = os.path.join(tmp, "seq.fasta")
    open(fasta, "w").write(f">ref\n{TEST_SEQ}\n")
    toks = enumerate_single_mutants(TEST_SEQ, positions=list(range(1, 21)))
    mock = MockScorer().score(TEST_SEQ, toks)
    dms = os.path.join(tmp, "dms.csv")
    pd.DataFrame({"mutant": toks,
                  "measured": [mock[t] + rng.normal(0, 2.0) for t in toks]}).to_csv(dms, index=False)
    m = run_pipeline(fasta=fasta, scorer="mock", dms_csv=dms, score_col="measured", verbose=False).metrics
    return [("Synthetic DMS scoring", "baseline score + noise",
             f"Spearman {m['spearman']:.2f}", m["spearman"])]


def experiment_units(tmp):
    """Analytic unit checks on the ranking metrics and A3M parsing."""
    sp = spearman(np.arange(10), np.arange(10) ** 2)
    ar = auroc(np.array([.1, .2, .9, .8]), np.array([0, 0, 1, 1]))
    a3m = os.path.join(tmp, "t.a3m")
    open(a3m, "w").write(">q\nMKVaa\n>s1\nMRV..\n>s2\nMKVff\n")
    counts, info = column_counts(a3m, "MKV")
    ok = abs(sp - 1.0) < 1e-9 and abs(ar - 1.0) < 1e-9 and dict(counts[2]) == {"K": 2, "R": 1}
    return [("Ranking-metric unit checks", "monotonic / separable / A3M inputs",
             f"Spearman {sp:.1f}, AUROC {ar:.1f}" if ok else "FAILED", float(ok))]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(os.path.dirname(__file__), "results_synthetic.csv"))
    args = ap.parse_args()

    tmp = tempfile.mkdtemp(prefix="evescape_repro_")
    rows = []
    for fn in (experiment_growth, experiment_rsa, experiment_msa, experiment_dms, experiment_units):
        rows.extend(fn(tmp))

    import pandas as pd
    df = pd.DataFrame([(a, b, c) for a, b, c, _ in rows], columns=["experiment", "setup", "result"])
    df.to_csv(args.out, index=False)

    width = max(len(r[0]) for r in rows)
    print(f"\nSynthetic/simulated validation (seeds: growth={SEED_GROWTH}, msa={SEED_MSA}, dms={SEED_DMS})\n")
    for a, b, c, _ in rows:
        print(f"  {a:<{width}}  |  {c}")
    print(f"\nWrote {args.out}")


if __name__ == "__main__":
    main()
