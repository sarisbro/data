#!/usr/bin/env python3
"""Non-stationarity measured two ways: cumulative vs incremental drift.

Fig 5 (nonstationarity.py) plots the mean per-site Jensen-Shannon divergence (JSD)
of each sliding window's amino-acid profile from the *earliest-epoch* profile. That
is a *cumulative* drift measure: how far the site-specific landscape has moved from
where it started. A reviewer may ask whether the earliest-epoch reference inflates
the apparent effect. Here we add the *incremental* measure: the JSD of each window's
profile from the profile 6 months earlier (one window half-width back). A stationary
process gives a flat, near-zero incremental curve; a punctuated one (spike) should
show a sharp transient at the regime change; a continuously drifting one (HA) should
show a sustained positive baseline. Both references are plotted per virus.

Outputs: manuscript/figure_nonstationarity_increment.pdf ; prints summary stats.
"""
from __future__ import annotations
import os, sys, datetime as dt
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import importlib.util as _ilu
def _load(_name,_file):
    _s=_ilu.spec_from_file_location(_name, os.path.join(_HERE,_file))
    _m=_ilu.module_from_spec(_s); _s.loader.exec_module(_m); return _m
ts = _load('temporal_sweep','06_temporal_sweep.py')
ns = _load('nonstationarity','07_nonstationarity.py')


def compute(cfg, rows, half_days=183, step="MS", min_n=50):
    dates = np.array([dt.date.fromisoformat(r["date"]) for r in rows])
    full = np.array([list(r["reg"]) for r in rows], dtype="<U1")
    order = np.argsort(dates)
    n_base = max(min_n, int(0.1 * len(rows)))
    base = ns.window_profile(full[order[:n_base]])            # earliest-epoch profile
    months = pd.date_range(min(dates), max(dates), freq=step).date
    half = dt.timedelta(days=half_days)
    lag = dt.timedelta(days=half_days)                        # compare to 6 months earlier
    def prof(T):
        m = (dates >= T - half) & (dates <= T + half)
        return (ns.window_profile(full[m]), int(m.sum())) if m.sum() >= min_n else (None, int(m.sum()))
    cum, inc = [], []
    for T in months:
        pT, nT = prof(T)
        if pT is None:
            cum.append((T, np.nan)); inc.append((T, np.nan)); continue
        cum.append((T, ns.mean_site_jsd(pT, base)[0]))
        pPrev, _ = prof(T - lag)
        inc.append((T, ns.mean_site_jsd(pT, pPrev)[0] if pPrev is not None else np.nan))
    return {"cfg": cfg, "dates": dates, "cum": cum, "inc": inc}


def _axis(ax, res, panel):
    cfg = res["cfg"]
    for series, lab, col, sty in [("cum", "from earliest epoch (cumulative)", "#762a83", "-o"),
                                  ("inc", "from 6 months earlier (incremental)", "#1b7837", "-s")]:
        pts = [(t, d) for t, d in res[series] if not np.isnan(d)]
        ax.plot([t for t, _ in pts], [d for _, d in pts], sty, ms=2.5, lw=1.3, color=col, label=lab)
    ev_date, ev_lab = cfg["event"]
    if res["dates"].min() <= ev_date <= res["dates"].max():
        ax.axvline(ev_date, color="#888", ls=":", lw=1)
        ax.text(ev_date, ax.get_ylim()[1], " " + ev_lab, fontsize=7, va="top", color="#555")
    loc = mdates.AutoDateLocator(minticks=4, maxticks=8)
    ax.xaxis.set_major_locator(loc); ax.xaxis.set_major_formatter(mdates.ConciseDateFormatter(loc))
    ax.set_xlabel("Sequence collection date")
    ax.set_ylabel("mean per-site JSD (bits)")
    ax.set_title(f"{panel}  {cfg['label']}", loc="left", fontweight="bold", fontsize=10)
    ax.legend(fontsize=7, frameon=False, loc="upper left")


def main():
    outdir = os.path.join(os.path.dirname(_HERE), "..", "manuscript")
    outdir = outdir if os.path.isdir(outdir) else _HERE
    order = [v for v in ("spike", "flu") if v in ts.PRESETS]
    res = {v: compute(ts.PRESETS[v], ts.extract_region(ts.PRESETS[v])) for v in order}
    for v in order:
        inc = [d for _, d in res[v]["inc"] if not np.isnan(d)]
        cum = [d for _, d in res[v]["cum"] if not np.isnan(d)]
        print(f"{v}: incremental JSD median {np.median(inc):.3f}, max {np.max(inc):.3f} bits; "
              f"cumulative final {cum[-1]:.3f} bits")
    fig, axes = plt.subplots(len(order), 1, figsize=(6.4, 3.4 * len(order)), squeeze=False)
    for ax, v, pan in zip(axes[:, 0], order, "ABCD"):
        _axis(ax, res[v], pan)
    fig.tight_layout()
    out = os.path.join(outdir, "figure_nonstationarity_increment.pdf")
    fig.savefig(out); plt.close(fig)
    print("wrote", out)


if __name__ == "__main__":
    main()
