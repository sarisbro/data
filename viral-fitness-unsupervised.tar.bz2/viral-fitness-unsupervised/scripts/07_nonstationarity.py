#!/usr/bin/env python3
"""Direct measurement of non-stationarity in the site-specific substitution process.

Figure 6 shows that *prediction* of a fixed DMS depends on the collection epoch of
the alignment. That is an indirect signature of a non-time-homogeneous process. Here
we measure the non-homogeneity directly, from the dated sequences alone (no DMS):
we build the site-specific amino-acid frequency profile in each sliding collection-
date window and ask how far it has drifted from the earliest-epoch profile, by the
mean per-site Jensen-Shannon divergence (JSD, in bits). A stationary process would
give a flat, near-zero curve; a punctuated one (SARS-CoV-2 spike RBD) should jump
when a new antigenic variant sweeps; a continuously drifting one (H3N2 HA) should
rise gradually.

Reuses the dated, region-extracted sequences from temporal_sweep.py.

Outputs: manuscript/figure_nonstationarity.pdf  and prints summary statistics.
"""
from __future__ import annotations
import os, sys, datetime as dt
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import importlib.util as _ilu
def _load(_name,_file):
    _s=_ilu.spec_from_file_location(_name, os.path.join(_HERE,_file))
    _m=_ilu.module_from_spec(_s); _s.loader.exec_module(_m); return _m
ts = _load('temporal_sweep','06_temporal_sweep.py')   # PRESETS, extract_region, AA20


def window_profile(sub, pc=0.5):
    """Per-site amino-acid frequency profile (L x 20) with a pseudocount, gaps/X ignored."""
    counts = np.stack([(sub == aa).sum(0) for aa in ts.AA20], axis=1).astype(float)
    counts += pc
    return counts / counts.sum(1, keepdims=True)


def mean_site_jsd(P, Q):
    """Mean over sites of the Jensen-Shannon divergence (bits) between two profiles."""
    M = 0.5 * (P + Q)
    def kl(a, b):
        return np.sum(np.where(a > 0, a * (np.log2(a) - np.log2(b)), 0.0), axis=1)
    jsd = 0.5 * kl(P, M) + 0.5 * kl(Q, M)
    return float(np.mean(jsd)), jsd   # scalar mean, per-site array


def compute(cfg, rows, base_frac=0.1, min_n=50):
    dates = np.array([dt.date.fromisoformat(r["date"]) for r in rows])
    full = np.array([list(r["reg"]) for r in rows], dtype="<U1")
    order = np.argsort(dates)
    n_base = max(min_n, int(base_frac * len(rows)))
    base = window_profile(full[order[:n_base]])           # earliest-epoch profile
    last = window_profile(full[order[-n_base:]])          # latest-epoch profile
    import pandas as pd
    months = pd.date_range(min(dates), max(dates), freq="MS").date
    half = dt.timedelta(days=183)
    drift = []
    for T in months:
        m = (dates >= T - half) & (dates <= T + half)
        if m.sum() < min_n:
            drift.append((T, np.nan, int(m.sum())))
            continue
        d, _ = mean_site_jsd(window_profile(full[m]), base)
        drift.append((T, d, int(m.sum())))
    end_jsd, per_site = mean_site_jsd(last, base)
    # fraction of sites whose profile shifted substantially (JSD > 0.1 bits)
    frac_shift = float(np.mean(per_site > 0.1))
    return {"cfg": cfg, "dates": dates, "drift": drift,
            "end_jsd": end_jsd, "frac_shift": frac_shift, "n_base": n_base}


def _axis(ax, res, panel):
    cfg = res["cfg"]
    pts = [(t, d) for t, d, n in res["drift"] if not np.isnan(d)]
    xs = [t for t, d in pts]; ys = [d for t, d in pts]
    ax.plot(xs, ys, "-o", ms=2.5, color="#762a83")
    ax.fill_between(xs, 0, ys, color="#762a83", alpha=0.12, lw=0)
    ev_date, ev_lab = cfg["event"]
    if res["dates"].min() <= ev_date <= res["dates"].max():
        ax.axvline(ev_date, color="#888", ls=":", lw=1)
        ax.text(ev_date, ax.get_ylim()[1], " " + ev_lab, fontsize=7, va="top", color="#555")
    import matplotlib.dates as mdates
    loc = mdates.AutoDateLocator(minticks=4, maxticks=8)
    ax.xaxis.set_major_locator(loc); ax.xaxis.set_major_formatter(mdates.ConciseDateFormatter(loc))
    ax.set_xlabel("Sequence collection date")
    ax.set_ylabel("mean per-site JSD from earliest epoch (bits)")
    ax.set_title(f"{panel}  {cfg['label']}", loc="left", fontweight="bold", fontsize=10)


def main():
    import argparse
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--virus", nargs="+", choices=list(ts.PRESETS), default=list(ts.PRESETS))
    args = ap.parse_args()
    outdir = os.path.join(os.path.dirname(os.path.dirname(_HERE)), "manuscript")
    if not os.path.isdir(outdir):
        outdir = _HERE
    res = {}
    for v in args.virus:
        cfg = ts.PRESETS[v]
        res[v] = compute(cfg, ts.extract_region(cfg))
        r = res[v]
        print(f"{v}: earliest-vs-latest mean per-site JSD = {r['end_jsd']:.3f} bits; "
              f"{100*r['frac_shift']:.0f}% of sites shifted (JSD>0.1); baseline N={r['n_base']}")
    order = [v for v in ("spike", "flu") if v in res]
    fig, axes = plt.subplots(1, len(order), figsize=(6.2 * len(order), 3.6), squeeze=False)
    for ax, v, pan in zip(axes[0], order, "ABCD"):
        _axis(ax, res[v], pan)
    fig.suptitle("Non-stationarity of the site-specific substitution process",
                 fontsize=12, fontweight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    out = os.path.join(outdir, "figure_nonstationarity.pdf")
    fig.savefig(out); plt.close(fig)
    print("wrote", out)


if __name__ == "__main__":
    main()
