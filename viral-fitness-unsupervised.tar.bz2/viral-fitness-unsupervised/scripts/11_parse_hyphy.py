#!/usr/bin/env python3
"""Parse HyPhy result JSONs into tidy tables + an antigenic prior over DMS positions.

For each dataset (spike, flu) and each method JSON produced by run_hyphy.py this:
  - writes a per-site table   <virus>_temporal/hyphy_<method>_sites.csv
  - computes the per-site antigenic prior (positive-selection score in [0,1])
  - combines the priors across methods and joins them to the DMS-assayed
    positions, writing <virus>_temporal/hyphy_antigenic_prior.csv
  - prints a summary (positively-selected sites per method; overlap with, and
    rank correlation against, the experimental mutational tolerance).

Codon-alignment columns equal reference-protein positions (build_codon_data.py
threads onto the full target), so HyPhy site i == protein position i == DMS
position i; no offset is needed.

Example:
  python reproduce/parse_hyphy.py                 # both viruses, all methods found
  python reproduce/parse_hyphy.py --virus flu --methods FEL MEME
"""
from __future__ import annotations
import argparse, os, sys
import numpy as np
import pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.dirname(_HERE))
from evescape_plm.phylo_selection import parse_selection_json, antigenic_prior   # noqa: E402

PG = os.path.join(_HERE, "proteingym_data")
DATASETS = {
    "spike": dict(data="spike_temporal", dms="SPIKE_SARS2_Starr_bind_2020", region=(331, 531)),
    "flu":   dict(data="flu_temporal", dms="C6KNH7_9INFA_Lee_2018", region=(1, 566)),
}
KNOWN_METHODS = ["SLAC", "FEL", "MEME", "FUBAR", "FADE"]


def dms_per_position(dms_id, region):
    """Per-position experimental summary: mean and min DMS over the assayed region."""
    d = pd.read_csv(os.path.join(PG, f"{dms_id}.csv")).dropna(subset=["DMS_score"])
    d = d[d["mutant"].str.match(r"^[A-Z]\d+[A-Z]$")].copy()
    d["pos"] = d["mutant"].str[1:-1].astype(int)
    d = d[d["pos"].between(*region)]
    g = d.groupby("pos")["DMS_score"]
    return pd.DataFrame({"mean_dms": g.mean(), "min_dms": g.min(), "n_dms": g.size()})


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--virus", nargs="+", choices=list(DATASETS), default=list(DATASETS))
    ap.add_argument("--methods", nargs="+", default=None, help="Default: whichever JSONs exist")
    ap.add_argument("--p-threshold", type=float, default=0.1)
    args = ap.parse_args()

    from evescape_plm.validation import spearman

    for virus in args.virus:
        cfg = DATASETS[virus]; ddir = os.path.join(_HERE, cfg["data"])
        methods = args.methods or [m for m in KNOWN_METHODS
                                   if os.path.exists(os.path.join(ddir, f"{m.lower()}.json"))]
        if not methods:
            print(f"[{virus}] no HyPhy JSONs found in {ddir}; run run_hyphy.py first", file=sys.stderr)
            continue
        dms = dms_per_position(cfg["dms"], cfg["region"])
        priors = {}
        print(f"\n=== {virus} ===")
        for m in methods:
            jp = os.path.join(ddir, f"{m.lower()}.json")
            if not os.path.exists(jp):
                print(f"  [{m}] missing {jp}", file=sys.stderr); continue
            sel = parse_selection_json(jp, method=m)
            df = sel.to_dataframe()
            df.to_csv(os.path.join(ddir, f"hyphy_{m.lower()}_sites.csv"), index=False)
            pr = antigenic_prior(sel, p_threshold=args.p_threshold)
            priors[m] = pr
            n_pos = sum(1 for x in pr.values() if x > 0)
            print(f"  [{m}] {len(sel.sites)} sites; {n_pos} positively selected "
                  f"(p<{args.p_threshold}) -> hyphy_{m.lower()}_sites.csv")

        # combined per-site prior table joined to the DMS-assayed positions
        all_sites = sorted({s for pr in priors.values() for s in pr})
        comb = pd.DataFrame({"site": all_sites}).set_index("site")
        for m, pr in priors.items():
            comb[f"{m.lower()}_prior"] = [pr.get(s, np.nan) for s in all_sites]
        comb = comb.join(dms, how="left")
        comb["dms_assayed"] = comb["mean_dms"].notna()
        out = os.path.join(ddir, "hyphy_antigenic_prior.csv")
        comb.reset_index().to_csv(out, index=False)
        print(f"  -> {out} ({comb['dms_assayed'].sum()} of {len(comb)} sites are DMS-assayed)")

        # does positive selection fall on binding/replication-tolerant sites?
        sub = comb[comb["dms_assayed"]]
        for m in priors:
            col = f"{m.lower()}_prior"
            v = sub[[col, "mean_dms"]].dropna()
            if len(v) > 10 and v[col].std() > 0:
                rho = spearman(v[col].to_numpy(), v["mean_dms"].to_numpy())
                print(f"  [{m}] Spearman(antigenic prior, mean DMS over assayed sites) = {rho:+.3f}")


if __name__ == "__main__":
    main()
