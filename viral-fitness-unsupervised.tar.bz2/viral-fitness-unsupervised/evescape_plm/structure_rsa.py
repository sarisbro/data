"""Estimate relative solvent accessibility (RSA) for a query sequence with no
experimental RSA of its own, by borrowing a homologous PDB structure.

Pipeline:

    query sequence
      -> (1) find a template  : RCSB MMseqs2 sequence-search API (the modern
                                replacement for "PDB BLAST"); or supply a PDB id
      -> (2) download mmCIF    : files.rcsb.org
      -> (3) SASA -> RSA       : Biopython Shrake-Rupley (no DSSP binary needed),
                                 normalised by Tien et al. (2013) theoretical maxASA
      -> (4) map to query      : pairwise-align template chain to the query and
                                 transfer per-residue RSA onto query positions

Output is a dict {query_pos(1-based): rsa in [0,1]}, or a CSV (position,rsa)
directly consumable by ``EscapeTerms.from_rsa_csv`` / ``run.py --rsa``.

Network note: steps (1) and (2) require internet and are meant to run on your
machine. Steps (3) and (4) are offline given a local structure file.

Accessibility caveat: antibody accessibility depends on quaternary structure, so
prefer a template of the *biological assembly* (e.g. the spike trimer, not one
protomer). Pass ``assembly=True`` to score SASA in the full multi-chain context.
"""

from __future__ import annotations

import os
import urllib.request

# Tien et al. 2013 theoretical maximum accessible surface area (A^2)
MAX_ASA = {
    "A": 129.0, "R": 274.0, "N": 195.0, "D": 193.0, "C": 167.0, "E": 223.0,
    "Q": 225.0, "G": 104.0, "H": 224.0, "I": 197.0, "L": 201.0, "K": 236.0,
    "M": 224.0, "F": 240.0, "P": 159.0, "S": 155.0, "T": 172.0, "W": 285.0,
    "Y": 263.0, "V": 174.0,
}

RCSB_SEARCH_URL = "https://search.rcsb.org/rcsbsearch/v2/query"
RCSB_CIF_URL = "https://files.rcsb.org/download/{pdb_id}.cif"


# --------------------------------------------------------------------------- #
# (1) template search
# --------------------------------------------------------------------------- #
def search_pdb_template(
    sequence: str,
    identity_cutoff: float = 0.3,
    evalue_cutoff: float = 1.0,
    max_hits: int = 5,
    timeout: int = 30,
) -> list[dict]:
    """Query the RCSB sequence-search API. Returns hits sorted best-first.

    Each hit: {'pdb_id', 'entity_id', 'identity', 'evalue', 'score'}.
    Requires network access.
    """
    import json

    payload = {
        "query": {
            "type": "terminal",
            "service": "sequence",
            "parameters": {
                "evalue_cutoff": evalue_cutoff,
                "identity_cutoff": identity_cutoff,
                "sequence_type": "protein",
                "value": sequence,
            },
        },
        "request_options": {
            "scoring_strategy": "sequence",
            "paginate": {"start": 0, "rows": max_hits},
        },
        "return_type": "polymer_entity",
    }
    data = json.dumps(payload).encode()
    req = urllib.request.Request(
        RCSB_SEARCH_URL, data=data, headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        result = json.loads(resp.read().decode())

    hits = []
    for item in result.get("result_set", []):
        ident = item["identifier"]           # e.g. "6VXX_1"
        pdb_id, _, entity_id = ident.partition("_")
        identity = evalue = None
        for svc in item.get("services", []):
            for node in svc.get("nodes", []):
                for mc in node.get("match_context", []):
                    identity = mc.get("sequence_identity", identity)
                    evalue = mc.get("evalue", evalue)
        hits.append({
            "pdb_id": pdb_id,
            "entity_id": entity_id,
            "identity": identity,
            "evalue": evalue,
            "score": item.get("score"),
        })
    return hits


def fetch_structure(pdb_id: str, out_dir: str = ".", timeout: int = 60) -> str:
    """Download an mmCIF file from RCSB. Requires network access."""
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{pdb_id.upper()}.cif")
    if not os.path.exists(path):
        urllib.request.urlretrieve(RCSB_CIF_URL.format(pdb_id=pdb_id.upper()), path)
    return path


# --------------------------------------------------------------------------- #
# (3) structure parsing + SASA -> RSA
# --------------------------------------------------------------------------- #
def _one_letter(resname: str) -> str:
    from Bio.SeqUtils import seq1

    return seq1(resname, undef_code="X")


def _load_model(structure_path: str, model_index: int = 0):
    from Bio.PDB import MMCIFParser, PDBParser

    parser = MMCIFParser(QUIET=True) if structure_path.lower().endswith(".cif") else PDBParser(QUIET=True)
    structure = parser.get_structure("s", structure_path)
    return list(structure.get_models())[model_index]


def _chain_sequence(chain):
    """Ordered (one-letter seq, [residue objects]) of standard amino acids."""
    from Bio.PDB.Polypeptide import is_aa

    seq, residues = [], []
    for res in chain:
        if res.id[0] != " ":            # skip hetero / water
            continue
        if not is_aa(res, standard=True):
            continue
        if "CA" not in res:
            continue
        seq.append(_one_letter(res.resname))
        residues.append(res)
    return "".join(seq), residues


def compute_rsa_by_residue(
    structure_path: str,
    assembly: bool = True,
    model_index: int = 0,
) -> dict:
    """Compute RSA per residue. Returns {(chain_id, res_id_tuple): rsa}.

    ``assembly=True`` computes SASA in the full multi-chain context of the model
    (appropriate for antibody accessibility); False would require pre-splitting
    chains yourself for monomer accessibility.
    """
    from Bio.PDB.SASA import ShrakeRupley

    model = _load_model(structure_path, model_index)
    ShrakeRupley().compute(model, level="R")   # sets residue.sasa

    rsa = {}
    for chain in model:
        _, residues = _chain_sequence(chain)
        for res in residues:
            aa = _one_letter(res.resname)
            maxasa = MAX_ASA.get(aa)
            if maxasa and getattr(res, "sasa", None) is not None:
                rsa[(chain.id, res.id)] = min(1.0, max(0.0, res.sasa / maxasa))
    return rsa


# --------------------------------------------------------------------------- #
# (4) map template RSA onto the query sequence
# --------------------------------------------------------------------------- #
def _best_chain(query: str, model):
    """Pick the model chain whose sequence best aligns to the query."""
    from Bio.Align import PairwiseAligner

    aligner = PairwiseAligner()
    aligner.mode = "local"
    aligner.open_gap_score = -11
    aligner.extend_gap_score = -1
    try:
        from Bio.Align import substitution_matrices

        aligner.substitution_matrix = substitution_matrices.load("BLOSUM62")
    except Exception:
        aligner.match_score, aligner.mismatch_score = 2, -1

    best = None
    for chain in model:
        seq, residues = _chain_sequence(chain)
        if len(seq) < 5:
            continue
        score = aligner.score(query, seq)
        if best is None or score > best[0]:
            best = (score, chain.id, seq, residues)
    return best  # (score, chain_id, seq, residues) or None


def map_rsa_to_query(
    query: str,
    template_seq: str,
    template_residues: list,
    rsa_by_res: dict,
    chain_id: str,
) -> dict:
    """Transfer per-residue RSA onto 1-based query positions via alignment."""
    from Bio.Align import PairwiseAligner

    aligner = PairwiseAligner()
    aligner.mode = "local"
    aligner.open_gap_score = -11
    aligner.extend_gap_score = -1
    try:
        from Bio.Align import substitution_matrices

        aligner.substitution_matrix = substitution_matrices.load("BLOSUM62")
    except Exception:
        aligner.match_score, aligner.mismatch_score = 2, -1

    aln = aligner.align(query, template_seq)[0]
    q_blocks, t_blocks = aln.aligned    # aligned index blocks (0-based, half-open)

    out = {}
    for (qs, qe), (ts, te) in zip(q_blocks, t_blocks):
        for off in range(qe - qs):
            q0, t0 = qs + off, ts + off
            res = template_residues[t0]
            val = rsa_by_res.get((chain_id, res.id))
            if val is not None:
                out[q0 + 1] = val       # 1-based query position
    return out


def estimate_rsa(
    query: str,
    pdb_id: str | None = None,
    structure_path: str | None = None,
    chain: str | None = None,
    assembly: bool = True,
    out_dir: str = ".",
    identity_cutoff: float = 0.3,
    verbose: bool = True,
) -> tuple[dict, dict]:
    """High-level driver. Returns ({query_pos: rsa}, provenance dict).

    Provide a local ``structure_path``, an explicit ``pdb_id``, or neither (then
    the RCSB sequence search picks the best template automatically).
    """
    provenance: dict = {}

    if structure_path is None:
        if pdb_id is None:
            hits = search_pdb_template(query, identity_cutoff=identity_cutoff)
            if not hits:
                raise RuntimeError("No PDB template found above the identity cutoff.")
            pdb_id = hits[0]["pdb_id"]
            provenance["hits"] = hits
            if verbose:
                print(f"[structure_rsa] top template {pdb_id} "
                      f"(identity={hits[0]['identity']}, evalue={hits[0]['evalue']})")
        structure_path = fetch_structure(pdb_id, out_dir=out_dir)
    provenance["structure_path"] = structure_path
    provenance["pdb_id"] = pdb_id

    rsa_by_res = compute_rsa_by_residue(structure_path, assembly=assembly)
    model = _load_model(structure_path)

    if chain is not None:
        seq, residues = _chain_sequence(model[chain])
        chosen = (None, chain, seq, residues)
    else:
        chosen = _best_chain(query, model)
        if chosen is None:
            raise RuntimeError("No suitable protein chain in the structure.")
    _, chain_id, tseq, tres = chosen
    provenance["chain"] = chain_id
    provenance["coverage_template_len"] = len(tseq)

    rsa_query = map_rsa_to_query(query, tseq, tres, rsa_by_res, chain_id)
    provenance["n_positions_covered"] = len(rsa_query)
    if verbose:
        print(f"[structure_rsa] chain {chain_id}: mapped RSA onto "
              f"{len(rsa_query)}/{len(query)} query positions")
    return rsa_query, provenance


def write_rsa_csv(rsa_query: dict, path: str, seq_len: int | None = None) -> None:
    """Write a (position,rsa) CSV compatible with EscapeTerms.from_rsa_csv."""
    import pandas as pd

    positions = range(1, seq_len + 1) if seq_len else sorted(rsa_query)
    rows = [(p, rsa_query[p]) for p in positions if p in rsa_query]
    pd.DataFrame(rows, columns=["position", "rsa"]).to_csv(path, index=False)
