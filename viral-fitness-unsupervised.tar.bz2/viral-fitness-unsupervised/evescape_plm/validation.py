"""Validation against ground truth: rank correlation and escape AUROC.

Dependency-free implementations (numpy only) so the pipeline runs without scipy.

Tiers of ground truth to compare against (see README):
  1. DMS fitness      -> Spearman on the 'measured' column (intrinsic term).
  2. Phylogenetic fit -> Spearman vs observed/expected mutation maps.
  3. Realized growth  -> Spearman vs MLR / PyR0 growth advantages, or AUROC on
                         binary escape/success labels.
"""

from __future__ import annotations

import numpy as np


def _rankdata(a: np.ndarray) -> np.ndarray:
    """Average ranks, ties shared (like scipy.stats.rankdata)."""
    a = np.asarray(a, float)
    order = np.argsort(a, kind="mergesort")
    ranks = np.empty(len(a), float)
    ranks[order] = np.arange(1, len(a) + 1)
    sa = a[order]
    i = 0
    while i < len(a):
        j = i
        while j + 1 < len(a) and sa[j + 1] == sa[i]:
            j += 1
        if j > i:
            ranks[order[i : j + 1]] = (i + 1 + j + 1) / 2.0
        i = j + 1
    return ranks


def _pearson(x: np.ndarray, y: np.ndarray) -> float:
    x, y = np.asarray(x, float), np.asarray(y, float)
    xc, yc = x - x.mean(), y - y.mean()
    denom = np.sqrt((xc ** 2).sum() * (yc ** 2).sum())
    return float((xc * yc).sum() / denom) if denom > 0 else float("nan")


def spearman(pred: np.ndarray, target: np.ndarray) -> float:
    """Spearman rank correlation over paired, finite values."""
    pred, target = np.asarray(pred, float), np.asarray(target, float)
    keep = np.isfinite(pred) & np.isfinite(target)
    if keep.sum() < 3:
        return float("nan")
    return _pearson(_rankdata(pred[keep]), _rankdata(target[keep]))


def auroc(scores: np.ndarray, labels: np.ndarray) -> float:
    """Area under ROC via the Mann-Whitney U statistic. labels in {0,1}."""
    scores, labels = np.asarray(scores, float), np.asarray(labels, float)
    keep = np.isfinite(scores) & np.isfinite(labels)
    scores, labels = scores[keep], labels[keep]
    P, N = labels.sum(), (labels == 0).sum()
    if P == 0 or N == 0:
        return float("nan")
    ranks = _rankdata(scores)
    return float((ranks[labels == 1].sum() - P * (P + 1) / 2) / (P * N))


def evaluate(
    tokens: list[str],
    pred: np.ndarray,
    df=None,
) -> dict[str, float]:
    """Compare predictions to a DMS DataFrame (columns 'mutant', 'measured', 'label')."""
    metrics: dict[str, float] = {"n_scored": float(len(tokens))}
    if df is None:
        return metrics

    lut = dict(zip(tokens, pred))
    sub = df[df["mutant"].isin(lut)].copy()
    sub["pred"] = sub["mutant"].map(lut)
    metrics["n_matched"] = float(len(sub))

    if "measured" in sub.columns:
        metrics["spearman"] = spearman(sub["pred"].to_numpy(), sub["measured"].to_numpy())
    if "label" in sub.columns:
        metrics["auroc"] = auroc(sub["pred"].to_numpy(), sub["label"].to_numpy())
    return metrics
