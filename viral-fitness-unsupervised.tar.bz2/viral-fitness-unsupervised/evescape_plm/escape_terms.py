"""EVEscape-style escape terms: antibody accessibility and biochemical dissimilarity.

These two terms model *antigenic* escape and are only meaningful when the target
is realized/antigenic fitness (not intrinsic replicative fitness). They are kept
deliberately simple and transparent:

- accessibility: per-residue relative solvent accessibility (RSA) in [0,1],
  loaded from an optional CSV (columns: position, rsa). Antibodies mostly bind
  exposed residues, so surface mutations are more escape-relevant.
- dissimilarity: how biochemically different the substitution is, combining the
  change in charge and Kyte-Doolittle hydropathy. Large physicochemical jumps
  are more likely to disrupt antibody binding.

Both are returned as raw per-mutation values; standardisation and probability
mapping happen in ``fusion.py``.
"""

from __future__ import annotations

from .data import parse_mutation

# Kyte-Doolittle hydropathy
_KD = {
    "A": 1.8, "R": -4.5, "N": -3.5, "D": -3.5, "C": 2.5, "Q": -3.5, "E": -3.5,
    "G": -0.4, "H": -3.2, "I": 4.5, "L": 3.8, "K": -3.9, "M": 1.9, "F": 2.8,
    "P": -1.6, "S": -0.8, "T": -0.7, "W": -0.9, "Y": -1.3, "V": 4.2,
}
# formal charge at physiological pH
_CHARGE = {"D": -1.0, "E": -1.0, "K": 1.0, "R": 1.0, "H": 0.5}


def _charge(aa: str) -> float:
    return _CHARGE.get(aa, 0.0)


class EscapeTerms:
    def __init__(
        self,
        rsa: dict[int, float] | None = None,
        default_rsa: float = 1.0,
        w_charge: float = 1.0,
        w_hydropathy: float = 1.0,
    ):
        self.rsa = rsa or {}
        self.default_rsa = default_rsa
        self.w_charge = w_charge
        self.w_hydropathy = w_hydropathy

    @classmethod
    def from_rsa_csv(cls, path: str | None, **kwargs) -> "EscapeTerms":
        rsa = {}
        if path:
            import pandas as pd

            df = pd.read_csv(path)
            pos_col = "position" if "position" in df.columns else df.columns[0]
            rsa_col = "rsa" if "rsa" in df.columns else df.columns[1]
            rsa = {int(p): float(v) for p, v in zip(df[pos_col], df[rsa_col])}
        return cls(rsa=rsa, **kwargs)

    def accessibility(self, mutations) -> dict[str, float]:
        """Mean RSA over the mutated position(s). Defaults to ``default_rsa``."""
        out = {}
        for tok in mutations:
            muts = parse_mutation(tok)
            vals = [self.rsa.get(m.pos, self.default_rsa) for m in muts]
            out[tok] = sum(vals) / len(vals)
        return out

    def dissimilarity(self, mutations) -> dict[str, float]:
        """Weighted physicochemical distance of the substitution(s)."""
        out = {}
        for tok in mutations:
            muts = parse_mutation(tok)
            s = 0.0
            for m in muts:
                d_charge = abs(_charge(m.mut) - _charge(m.wt))
                d_kd = abs(_KD.get(m.mut, 0.0) - _KD.get(m.wt, 0.0))
                s += self.w_charge * d_charge + self.w_hydropathy * (d_kd / 9.0)
            out[tok] = s / len(muts)
        return out
