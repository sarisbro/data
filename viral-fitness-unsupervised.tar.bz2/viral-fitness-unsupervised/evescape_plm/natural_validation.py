"""Label-free validation from natural sequence variation (an MSA).

When there is no DMS, we can still ask an unsupervised question of the model:
*does it rank substitutions that actually occur in nature above those that never
do, and does its score track how common each observed substitution is?*

Given an MSA of the target family (aligned FASTA or A3M), this module:

  - maps alignment columns onto query positions,
  - tallies per-position amino-acid counts / frequencies,
  - scores predictions with two label-free metrics:
        * AUROC of observed (1) vs unobserved (0) substitutions,
        * Spearman of model score vs log natural frequency (observed only),
        * top-P enrichment (precision among the top-P ranked predictions),
  - and can emit per-mutation log-frequency "labels" so the fusion step can be
    sign-calibrated against natural frequency when nothing better is available.

A3M insert states (lowercase letters and '.') are stripped so only match columns
aligned to the reference/query are counted.
"""

from __future__ import annotations

import math
from collections import Counter

import numpy as np

from .data import AA20, parse_mutation
from .validation import auroc, spearman


# --------------------------------------------------------------------------- #
# MSA parsing
# --------------------------------------------------------------------------- #
def read_msa(path: str) -> list[tuple[str, str]]:
    """Read a FASTA/A3M alignment; preserves case (needed for A3M insert states)."""
    records, name, buf = [], None, []
    with open(path) as fh:
        for line in fh:
            line = line.rstrip("\n")
            if line.startswith(">"):
                if name is not None:
                    records.append((name, "".join(buf)))
                name, buf = line[1:].strip(), []
            elif line:
                buf.append(line.strip())
    if name is not None:
        records.append((name, "".join(buf)))
    if not records:
        raise ValueError(f"No sequences in MSA {path}")
    return records


def _strip_inserts(seq: str) -> str:
    """Remove A3M insert states (lowercase letters and '.')."""
    return "".join(c for c in seq if not (c.islower() or c == "."))


def _pick_reference(records: list[tuple[str, str]], query: str, ref_index: int) -> int:
    """Prefer the row whose ungapped sequence equals the query; else ref_index."""
    q = query.upper()
    for i, (_, seq) in enumerate(records):
        if seq.replace("-", "").upper() == q:
            return i
    return ref_index


def _sequence_weights(arr, theta: float = 0.8, block: int = 512):
    """EVcouplings-style redundancy weights: w_i = 1 / #{j : identity(i,j) >= theta}.

    Downweights over-represented (phylogenetically redundant) sequences, which is
    important for densely-sampled viral alignments. Identity is the fraction of
    columns at which two sequences carry the *same amino acid*; gaps and non-standard
    characters never count as matches (otherwise fragmentary sequences that share
    gap columns would look spuriously identical). Computed as a sparse one-hot Gram
    matrix in row blocks to stay within memory.
    """
    from scipy import sparse

    N, L = arr.shape
    code = {a: i for i, a in enumerate(AA20)}
    codes = np.full((N, L), -1, dtype=np.int64)
    for a, i in code.items():
        codes[arr == a] = i
    keep = codes.ravel() >= 0                       # non-gap, standard AA cells only
    rows = np.repeat(np.arange(N), L)[keep]
    cols = ((np.arange(L) * 20)[None, :] + codes).ravel()[keep]
    X = sparse.csr_matrix((np.ones(keep.sum(), dtype=np.float32), (rows, cols)),
                          shape=(N, L * 20))
    Xt = X.T.tocsr()
    w = np.empty(N, dtype=np.float64)
    for s in range(0, N, block):
        ident = np.asarray((X[s:s + block] @ Xt).todense(), dtype=np.float32) / L
        w[s:s + block] = 1.0 / np.maximum(1.0, (ident >= theta).sum(axis=1))
    return w


def _focus_to_query_map(focus: str, query: str):
    """Map MSA-focus residue indices (0-based) to 1-based query positions via a
    semi-global pairwise alignment (free end gaps). Returns (mapping, identity)."""
    from Bio.Align import PairwiseAligner

    aligner = PairwiseAligner()
    aligner.mode = "global"
    aligner.match_score = 2.0
    aligner.mismatch_score = -1.0
    aligner.open_gap_score = -6.0
    aligner.extend_gap_score = -0.5
    aligner.end_gap_score = 0.0          # free end gaps -> focus embeds within query
    aln = aligner.align(query, focus)[0]
    q_blocks, f_blocks = aln.aligned     # (target=query, query=focus) coordinate blocks
    mapping, match = {}, 0
    for (qs, qe), (fs, fe) in zip(q_blocks, f_blocks):
        for o in range(qe - qs):
            qi, fi = qs + o, fs + o
            mapping[fi] = qi + 1
            if query[qi] == focus[fi]:
                match += 1
    return mapping, match / max(1, len(mapping))


def column_counts(
    path: str,
    query: str,
    ref_index: int = 0,
    max_sequences: int = 20000,
    reweight: bool = False,
    reweight_theta: float = 0.99,
    select: str | None = None,
    select_k: int | None = None,
    select_min_identity: float | None = None,
) -> tuple[dict[int, Counter], dict]:
    """Return ({query_pos(1-based): Counter(aa->count)}, info).

    Columns are defined by the reference row's non-gap positions, which are
    assumed to correspond to query positions 1..len(query).
    """
    records = read_msa(path)
    is_a3m = any(c.islower() or c == "." for _, s in records for c in s)
    if is_a3m:
        records = [(n, _strip_inserts(s)) for n, s in records]

    ridx = _pick_reference(records, query, ref_index)
    ref = records[ridx][1]

    # Map each reference match column to a 1-based query position. The reference
    # (MSA focus) may cover only a sub-region of the query and may differ slightly
    # from it (e.g. MSAs and assays from different ProteinGym releases). We take
    # the fast path when the focus is an exact substring of the query, and fall
    # back to a semi-global pairwise alignment otherwise.
    L = len(ref)
    match_cols = [c for c in range(L) if ref[c] != "-"]
    focus = "".join(ref[c] for c in match_cols).upper()
    q = query.upper()
    off = q.find(focus)
    if off >= 0:
        f2q = {k: off + k + 1 for k in range(len(focus))}
        map_identity, map_mode = 1.0, "substring"
    else:
        f2q, map_identity = _focus_to_query_map(focus, q)
        map_mode = "aligned"

    seqs = [s for _, s in records]
    # bound cost on very deep alignments; frequency estimates are stable well
    # below this, and small alignments (e.g. the label-free validator) are untouched
    n_total = len(seqs)
    if n_total > max_sequences:
        seqs = seqs[:max_sequences]
    # (N, L) uppercase character matrix; ragged rows padded/truncated to L
    arr = np.char.upper(np.array([list(s[:L].ljust(L, "-")) for s in seqs], dtype="<U1"))
    aa_set = set(AA20)

    # identity-to-target selection: keep sequences closest to the focus/target,
    # dropping divergent (off-regime) homologs before estimating frequencies.
    sel_info = {}
    if select:
        # operate on distinct sequences so oversampled near-duplicates (common for
        # heavily-sequenced pathogens) cannot collapse the alignment's diversity
        arr = np.unique(arr, axis=0)
        focus_cols = np.array([c for c in match_cols if ref[c] in aa_set])
        if len(focus_cols):
            ref_chars = np.array([ref[c] for c in focus_cols])
            ident = (arr[:, focus_cols] == ref_chars).sum(axis=1) / len(focus_cols)
            if select == "topk":
                keep = np.argsort(-ident)[: (select_k or len(ident))]
            elif select == "min_identity":
                keep = np.where(ident >= (select_min_identity or 0.0))[0]
            else:
                raise ValueError(f"unknown select mode '{select}'")
            keep = np.sort(keep)
            arr = arr[keep]
            sel_info = {"select": select, "n_selected": int(len(keep)),
                        "select_min_identity": float(ident[keep].min()) if len(keep) else None}

    w = _sequence_weights(arr, theta=reweight_theta) if reweight else None

    counts: dict[int, Counter] = {}
    for k, col in enumerate(match_cols):
        qpos = f2q.get(k)
        if qpos is None:
            continue
        colv = arr[:, col]
        if w is None:
            vals, cnts = np.unique(colv, return_counts=True)
            counts[qpos] = Counter({v: int(n) for v, n in zip(vals, cnts) if v in aa_set})
        else:
            c: Counter = Counter()
            for v in np.unique(colv):
                if v in aa_set:
                    c[v] = float(w[colv == v].sum())
            counts[qpos] = c

    info = {
        "n_sequences": n_total,
        "n_sequences_used": int(arr.shape[0]),
        "n_eff": round(float(w.sum()), 1) if w is not None else float(arr.shape[0]),
        **sel_info,
        "is_a3m": is_a3m,
        "reference_index": ridx,
        "map_mode": map_mode,
        "map_identity": round(float(map_identity), 3),
        "n_query_positions": len(counts),
        "covers_full_query": len(counts) == len(query),
    }
    return counts, info


# --------------------------------------------------------------------------- #
# Metrics
# --------------------------------------------------------------------------- #
def _freq(counter: Counter, aa: str, pseudocount: float = 0.0) -> float:
    total = sum(counter.values())
    if total == 0 and pseudocount == 0.0:
        return 0.0
    return (counter.get(aa, 0) + pseudocount) / (total + pseudocount * len(AA20))


def evaluate_against_msa(
    scores: dict[str, float],
    counts: dict[int, Counter],
    min_count: int = 1,
    min_freq: float = 0.0,
) -> dict[str, float]:
    """Label-free metrics for single-mutant scores against natural variation.

    A substitution is 'observed' if it appears at its column with count >=
    ``min_count`` and frequency >= ``min_freq``.
    """
    lab_scores, lab_y = [], []
    freq_scores, freq_logf = [], []

    for tok, sc in scores.items():
        muts = parse_mutation(tok)
        if len(muts) != 1:
            continue
        m = muts[0]
        c = counts.get(m.pos)
        if c is None or sum(c.values()) == 0:
            continue
        cnt = c.get(m.mut, 0)
        f = cnt / sum(c.values())
        observed = cnt >= min_count and f >= min_freq
        lab_scores.append(sc)
        lab_y.append(1 if observed else 0)
        if observed and f > 0:
            freq_scores.append(sc)
            freq_logf.append(math.log(f))

    import numpy as np

    n_pos = int(sum(lab_y))
    metrics = {
        "msa_n_covered": float(len(lab_y)),
        "msa_n_observed": float(n_pos),
        "msa_auroc_observed": auroc(np.array(lab_scores), np.array(lab_y)),
        "msa_spearman_logfreq": spearman(np.array(freq_scores), np.array(freq_logf)),
    }
    # top-P enrichment: precision among the P highest-scored, P = #observed
    if n_pos > 0 and len(lab_scores) >= n_pos:
        order = np.argsort(-np.array(lab_scores))
        top = np.array(lab_y)[order][:n_pos]
        metrics["msa_enrichment_topP"] = float(top.sum() / n_pos)
    return metrics


def msa_logfreq_labels(
    scores: dict[str, float],
    counts: dict[int, Counter],
    pseudocount: float = 0.5,
) -> dict[str, float]:
    """Per-mutation log natural-frequency labels for sign calibration.

    Uses a pseudocount so unobserved-but-covered substitutions get a small,
    finite frequency rather than -inf. Only positions present in the MSA are
    assigned labels.
    """
    labels = {}
    for tok in scores:
        muts = parse_mutation(tok)
        if len(muts) != 1:
            continue
        m = muts[0]
        c = counts.get(m.pos)
        if c is None or sum(c.values()) == 0:
            continue
        labels[tok] = math.log(_freq(c, m.mut, pseudocount=pseudocount))
    return labels
