"""Codon-model selection signals (HyPhy) as a data-driven antigenic prior.

This module is the *antigenic-side* counterpart to the intrinsic fitness term.
Where the PLM/PSSM captures purifying selection (what is tolerated), codon-model
site tests capture *positive/diversifying* selection (where a viral protein is
actively changing to escape immunity) -- exactly the signal on which a
likelihood term has the wrong sign. Sites under episodic diversifying or
directional selection are escape-prone, so a per-site selection score is a
principled, phylogenetically-informed replacement/augmentation for the
structure-based accessibility term of the escape module.

Pipeline (run on nucleotide/codon data, not the ProteinGym amino-acid MSAs):

    nucleotide sequences
      -> codon-aware alignment (e.g. MACSE / translatorX)
      -> tree (IQ-TREE / RAxML)
      -> HyPhy site tests:
            FEL   : per-site dN/dS (alpha=dS, beta=dN), purifying vs positive
            MEME  : episodic diversifying selection per site (beta+ > alpha, p)
            FADE  : directional selection toward specific residues (Bayes factor)
            PRIME : selection on specific biochemical properties
      -> per-site antigenic prior in [0, 1]
      -> fuse with the intrinsic and dissimilarity terms (see fusion.py)

Only the HyPhy *execution* requires the external `hyphy` binary and a codon
alignment + tree; the JSON parsing and prior construction below are pure Python
and are unit-testable on saved HyPhy output. This is a scaffold: the
``run_hyphy`` wrapper is intentionally thin and the scientific choices (which
test, significance threshold, prior shape) are exposed as parameters.
"""

from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass


# --------------------------------------------------------------------------- #
# 1. Run HyPhy (requires the external binary + a codon alignment and tree)
# --------------------------------------------------------------------------- #
def run_hyphy(method: str, alignment: str, tree: str, out_json: str,
              hyphy_bin: str = "hyphy", extra: list[str] | None = None) -> str:
    """Run a HyPhy site-selection method and return the path to its JSON output.

    method: 'FEL' | 'MEME' | 'FADE' | 'PRIME' (case-insensitive).
    alignment: in-frame codon alignment (FASTA/NEXUS); tree: Newick.
    Requires HyPhy (https://github.com/veg/hyphy) on PATH.
    """
    cmd = [hyphy_bin, method.upper(), "--alignment", alignment, "--tree", tree,
           "--output", out_json] + (extra or [])
    subprocess.run(cmd, check=True)
    return out_json


# --------------------------------------------------------------------------- #
# 2. Parse HyPhy JSON -> per-site table  (pure Python; testable offline)
# --------------------------------------------------------------------------- #
@dataclass
class SiteSelection:
    method: str
    # 1-based codon site -> dict of the method's per-site statistics
    sites: dict[int, dict]

    def to_dataframe(self):
        import pandas as pd
        return pd.DataFrame([{"site": s, **v} for s, v in sorted(self.sites.items())])


def _clean_header(h) -> str:
    """Normalise a HyPhy column header: unescape HTML, strip tags, lowercase.
    e.g. '&beta;<sup>+</sup>' -> 'beta+', 'p-value' -> 'p-value'."""
    import html
    import re
    s = h[0] if isinstance(h, (list, tuple)) and h else h
    s = html.unescape(str(s))              # &beta; -> unicode greek beta
    s = re.sub(r"<[^>]+>", "", s)          # strip <sup>+</sup> etc.
    # HyPhy headers use Greek dN/dS symbols; normalise to latin names
    for g, name in (("α", "alpha"), ("β", "beta"), ("ω", "omega"),
                    ("Α", "alpha"), ("Β", "beta")):
        s = s.replace(g, name)
    return s.strip().lower()


def _rows_from_block(block):
    """Return the list of per-site rows from an MLE content block.

    FEL/MEME/FUBAR store a plain list of rows at ``content["0"]``. SLAC instead
    nests them under ``content["0"]["by-site"]["RESOLVED"]`` (a dict, not a list),
    which naive iteration would walk as if the keys were data. Handle both.
    """
    if isinstance(block, list):
        return block
    if isinstance(block, dict):
        if "by-site" in block:                       # SLAC
            bs = block["by-site"]
            if isinstance(bs, dict):
                for key in ("RESOLVED", "AVERAGED"):
                    if isinstance(bs.get(key), list):
                        return bs[key]
                for v in bs.values():
                    if isinstance(v, list):
                        return v
            elif isinstance(bs, list):
                return bs
        for v in block.values():                     # generic: first list descendant
            r = _rows_from_block(v)
            if r:
                return r
    return []


def parse_selection_json(path: str, method: str | None = None) -> SiteSelection:
    """Parse a HyPhy site-method JSON (FEL/MEME/SLAC/FUBAR/...) into a per-site table.

    Column names are read from the JSON's own ``["MLE"]["headers"]`` block, so the
    parser is method-agnostic and robust to schema differences; the per-site rows
    come from ``["MLE"]["content"]["0"]`` (or, for SLAC, from its nested
    ``by-site`` block -- see ``_rows_from_block``).
    """
    with open(path) as fh:
        js = json.load(fh)
    mle = js.get("MLE", {})
    headers = [_clean_header(h) for h in mle.get("headers", [])]
    content = mle.get("content", {})
    block = content.get("0") if isinstance(content, dict) else content
    if block is None and isinstance(content, dict):
        block = next(iter(content.values()), [])
    rows = _rows_from_block(block)
    if method is None:
        method = js.get("analysis", {}).get("name", "unknown")
    sites = {}
    for i, row in enumerate(rows or [], start=1):
        sites[i] = {(headers[j] if j < len(headers) else f"col{j}"): row[j]
                    for j in range(len(row))}
    return SiteSelection(method=str(method), sites=sites)


# --------------------------------------------------------------------------- #
# 3. Per-site selection -> antigenic prior in [0, 1]
# --------------------------------------------------------------------------- #
def _pick(keys, *cands):
    """Find the first column key matching a candidate (exact, then substring)."""
    for c in cands:
        if c in keys:
            return c
    for c in cands:
        for k in keys:
            if c in k:
                return k
    return None


def _num(x, default: float = 0.0) -> float:
    """Coerce a HyPhy cell to float; None / non-numeric -> default."""
    try:
        return float(x)
    except (TypeError, ValueError):
        return default


def antigenic_prior(sel: SiteSelection, p_threshold: float = 0.1,
                    dnds_cap: float = 5.0) -> dict[int, float]:
    """Map per-site selection statistics to an escape-prone prior in [0, 1].

    Detects the relevant columns from each method's (cleaned) header names, so it
    works across FEL, MEME, SLAC and FUBAR:

      * dS  = ``alpha``  (FEL/MEME/FUBAR) or ``ds`` (SLAC)
      * dN  = ``beta+``  (MEME episodic) else ``beta`` (FEL/FUBAR) or ``dn`` (SLAC)
      * significance = a frequentist ``p-value`` (FEL/MEME) or ``p[dN/dS>1]``
        (SLAC), significant when ``< p_threshold``; or, for the Bayesian FUBAR,
        the posterior ``Prob[alpha<beta]``, significant when ``> 1 - p_threshold``.

    The prior grows with dN/dS at sites called positively selected and is 0 where
    dN <= dS or the site is not significant. It is a per-*site* weight that
    replaces or augments the structural accessibility term of the escape module.
    """
    out: dict[int, float] = {}
    for site, v in sel.sites.items():
        keys = list(v.keys())
        ka = _pick(keys, "alpha", "ds")
        kb = _pick(keys, "beta+", "beta +", "beta", "dn")
        kpval = _pick(keys, "p-value", "p value", "p [dn/ds > 1]", "p[dn/ds>1]", "p [dn/ds>1]")
        kpost = _pick(keys, "prob[alpha<beta]", "prob [alpha<beta]")
        a = _num(v.get(ka))
        b = _num(v.get(kb))
        if kpval is not None:
            significant = _num(v.get(kpval), 1.0) < p_threshold
        elif kpost is not None:
            significant = _num(v.get(kpost), 0.0) > (1.0 - p_threshold)
        else:
            significant = False
        omega = (b / a) if a > 0 else (dnds_cap if b > 0 else 0.0)
        out[site] = (min(omega, dnds_cap) / dnds_cap) if (significant and b > a) else 0.0
    return out


def prior_to_mutations(prior: dict[int, float], mutations, offset: int = 0) -> dict[str, float]:
    """Broadcast a per-site prior onto per-mutation tokens (wt<pos>mut).

    ``offset`` aligns codon-site numbering to the target protein numbering when
    they differ (as with the sub-region MSAs handled in natural_validation).
    """
    from .data import parse_mutation

    out = {}
    for tok in mutations:
        muts = parse_mutation(tok)
        out[tok] = max((prior.get(m.pos - offset, 0.0) for m in muts), default=0.0)
    return out
