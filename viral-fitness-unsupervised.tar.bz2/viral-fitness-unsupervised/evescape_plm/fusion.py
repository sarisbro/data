"""Term fusion: combine the intrinsic fitness term with the escape terms.

Two modes, mirroring the design discussion:

- ``intrinsic``      : fitness term only (weights 1,0,...). Predicts replicative fitness.
- ``multiplicative`` : EVEscape scaffold -- P(fit) * P(access) * P(antigenic) *
                       P(dissim), each present term squashed to a probability via a
                       temperature sigmoid.
- ``additive``       : w_fit*z_fit + w_access*z_access + ... in standardized
                       (z-score) space, Lassig-style decomposition.

Interchangeable estimators of each term
---------------------------------------
The fused score is built from a small set of terms, each of which can be supplied
by any unsupervised estimator -- the fusion is agnostic to how a term was produced:

- ``fitness``       (intrinsic): PLM zero-shot LLR, alignment PSSM log-odds, or the
                    phylogenetic mutation-selection ΔF = log pi_i(mut) - log pi_i(wt)
                    from PhyloBayes (`reproduce/parse_phylobayes.py`). Just pass the
                    per-mutation dict; higher = more tolerated.
- ``accessibility`` (antigenic, structural): solvent accessibility (RSA) term.
- ``antigenic``     (antigenic, phylogenetic): a per-site positive-selection prior
                    from a codon model (HyPhy FEL/MEME/FUBAR/SLAC), broadcast to
                    mutations by `phylo_selection.prior_to_mutations`. This is the
                    sequence-only counterpart of the structural accessibility term;
                    supply it instead of, or alongside, ``accessibility``.
- ``dissimilarity`` (antigenic): chemical dissimilarity of the substitution.

Sign-of-selection note
-----------------------
A raw likelihood/fitness term has the *wrong sign* on antigenic novelty: escape
mutations are rare (low likelihood) yet positively selected. If you pass labels
(e.g. surveillance growth advantages or escape labels), ``calibrate=True`` fits
the term weights by least squares so the fused score is oriented to agree with
the real selection signal; this is the light, semi-supervised sign fix.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

# escape terms, in EVEscape product order; ``fitness`` is always the intrinsic term
_ESCAPE_TERMS = ("accessibility", "antigenic", "dissimilarity")


def _z(x: np.ndarray) -> np.ndarray:
    sd = x.std()
    return (x - x.mean()) / sd if sd > 0 else x - x.mean()


def _sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-x))


@dataclass
class FusionResult:
    tokens: list[str]
    fused: np.ndarray                       # final score, higher = fitter/more escape
    components: dict[str, np.ndarray]        # z-scored terms actually used
    mode: str
    weights: dict[str, float] = field(default_factory=dict)
    calibrated: bool = False

    def as_dict(self) -> dict[str, float]:
        return {t: float(v) for t, v in zip(self.tokens, self.fused)}


def fuse_terms(
    fitness: dict[str, float],
    accessibility: dict[str, float] | None = None,
    dissimilarity: dict[str, float] | None = None,
    antigenic: dict[str, float] | None = None,
    mode: str = "intrinsic",
    temperature: float = 1.0,
    weights: dict[str, float] | None = None,
    labels: dict[str, float] | None = None,
    calibrate: bool = False,
) -> FusionResult:
    """Fuse per-mutation terms into a single score.

    ``fitness`` is the intrinsic term (from any estimator: PLM, PSSM, or MutSel ΔF).
    ``accessibility``, ``antigenic`` and ``dissimilarity`` are optional escape terms;
    ``antigenic`` is the codon-model positive-selection prior (the phylogenetic
    counterpart of ``accessibility``). All term dicts must be keyed by the same
    mutation tokens as ``fitness``. In the escape modes, every escape term that is
    provided is included, so the method runs with structural accessibility, the
    phylogenetic antigenic prior, either, or both.
    """
    tokens = list(fitness.keys())
    comps = {"fitness": _z(np.array([fitness[t] for t in tokens], float))}

    supplied = {"accessibility": accessibility, "antigenic": antigenic,
                "dissimilarity": dissimilarity}
    use_escape = mode in ("multiplicative", "additive") and any(
        supplied[k] is not None for k in _ESCAPE_TERMS
    )
    if use_escape:
        for k in _ESCAPE_TERMS:                      # keep EVEscape product order
            if supplied[k] is not None:
                comps[k] = _z(np.array([supplied[k][t] for t in tokens], float))

    # ---- calibration: orient/weight terms against a labelled signal ---------
    calibrated = False
    if calibrate and labels is not None:
        y = np.array([labels.get(t, np.nan) for t in tokens], float)
        keep = ~np.isnan(y)
        if keep.sum() >= 3:
            X = np.column_stack([comps[k] for k in comps])
            beta, *_ = np.linalg.lstsq(
                np.column_stack([X[keep], np.ones(keep.sum())]), y[keep], rcond=None
            )
            w = beta[:-1]
            weights = {k: float(wi) for k, wi in zip(comps, w)}
            calibrated = True

    if weights is None:
        weights = {k: 1.0 for k in comps}

    # ---- combine ------------------------------------------------------------
    if mode == "multiplicative" and use_escape:
        fused = np.zeros(len(tokens))
        for k, zk in comps.items():                  # log of the EVEscape product
            fused = fused + np.log(_sigmoid(weights.get(k, 1.0) * zk / temperature))
    else:
        # intrinsic (fitness only) or additive decomposition
        fused = np.zeros(len(tokens))
        for k, zk in comps.items():
            fused = fused + weights.get(k, 0.0) * zk

    return FusionResult(
        tokens=tokens,
        fused=fused,
        components=comps,
        mode=mode,
        weights=weights,
        calibrated=calibrated,
    )
