"""Data layer: sequences, mutations, and DMS ground-truth tables.

Mutation strings use the standard 1-based convention ``<wt><pos><mut>`` e.g.
``N501Y``. Multi-mutants are joined with ``:`` e.g. ``N501Y:E484K``.
Positions are 1-based indices into the wildtype sequence supplied as FASTA.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterable, Sequence

AA20 = "ACDEFGHIKLMNPQRSTVWY"
_MUT_RE = re.compile(r"^([A-Z])(\d+)([A-Z\*])$")


@dataclass(frozen=True)
class Mutation:
    """A single amino-acid substitution (1-based position)."""

    wt: str
    pos: int
    mut: str

    def __str__(self) -> str:  # canonical form, e.g. "N501Y"
        return f"{self.wt}{self.pos}{self.mut}"

    @property
    def idx0(self) -> int:
        """0-based index into the wildtype sequence."""
        return self.pos - 1


def read_fasta(path: str) -> tuple[str, str]:
    """Return (header, sequence) of the first record in a FASTA file."""
    header, seq = "", []
    with open(path) as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            if line.startswith(">"):
                if seq:  # stop at second record
                    break
                header = line[1:].strip()
            else:
                seq.append(line)
    sequence = "".join(seq).upper().replace(" ", "")
    if not sequence:
        raise ValueError(f"No sequence found in {path}")
    return header, sequence


def parse_mutation(token: str) -> list[Mutation]:
    """Parse a (possibly multi-) mutation token into a list of Mutation."""
    muts = []
    for part in token.strip().split(":"):
        m = _MUT_RE.match(part.strip())
        if not m:
            raise ValueError(f"Cannot parse mutation '{part}' (expected e.g. N501Y)")
        wt, pos, mut = m.group(1), int(m.group(2)), m.group(3)
        muts.append(Mutation(wt=wt, pos=pos, mut=mut))
    return muts


def validate_against_sequence(muts: Iterable[Mutation], sequence: str) -> None:
    """Raise if any wildtype letter disagrees with the reference sequence."""
    for mt in muts:
        if not (1 <= mt.pos <= len(sequence)):
            raise ValueError(f"{mt}: position out of range 1..{len(sequence)}")
        ref = sequence[mt.idx0]
        if ref != mt.wt:
            raise ValueError(
                f"{mt}: wildtype '{mt.wt}' disagrees with sequence '{ref}' at pos {mt.pos}"
            )


def enumerate_single_mutants(
    sequence: str,
    positions: Sequence[int] | None = None,
    alphabet: str = AA20,
) -> list[str]:
    """Deep-scan: every single substitution over the given positions (1-based).

    If ``positions`` is None, scans the whole sequence. The wildtype "mutation"
    is skipped.
    """
    positions = positions or range(1, len(sequence) + 1)
    tokens = []
    for pos in positions:
        wt = sequence[pos - 1]
        for mut in alphabet:
            if mut != wt:
                tokens.append(f"{wt}{pos}{mut}")
    return tokens


def load_dms_csv(
    path: str,
    mutant_col: str = "mutant",
    score_col: str | None = None,
    label_col: str | None = None,
):
    """Load a DMS / ground-truth table.

    Returns a pandas DataFrame with at least a ``mutant`` column. ``score_col``
    (continuous fitness, higher = fitter) and ``label_col`` (binary escape 0/1)
    are optional and used only for validation.
    """
    import pandas as pd

    df = pd.read_csv(path)
    if mutant_col not in df.columns:
        raise ValueError(f"Column '{mutant_col}' not found in {path}; got {list(df.columns)}")
    df = df.rename(columns={mutant_col: "mutant"})
    if score_col and score_col in df.columns:
        df = df.rename(columns={score_col: "measured"})
    if label_col and label_col in df.columns:
        df = df.rename(columns={label_col: "label"})
    return df


def load_growth_csv(
    path: str,
    mutant_col: str = "mutant",
    growth_col: str = "growth",
) -> dict[str, float]:
    """Load per-mutation growth advantages (e.g. from an MLR/PyR0 fit).

    Returns {mutant: growth}. This is a *self-supervised* target derived from
    genomic-surveillance frequency dynamics -- no experimental assay required.
    """
    import pandas as pd

    df = pd.read_csv(path)
    for col in (mutant_col, growth_col):
        if col not in df.columns:
            raise ValueError(f"Column '{col}' not found in {path}; got {list(df.columns)}")
    return {str(m): float(g) for m, g in zip(df[mutant_col], df[growth_col])}
