"""Date-aware (temporal) filtering of an alignment for time-inhomogeneous selection.

Selection is not time-homogeneous: a contemporaneous deep-mutational-scanning
assay measures the constraint operating in *one* epoch, so for dated viral
surveillance data the relevant sequences are those near the assay's time, not the
full evolutionary history. Given a MSA of *dated* isolates this module restricts
or reweights sequences by collection date, producing an epoch-specific alignment
that can be fed to the PSSM / codon-model scorers.

Note: this is the principled counterpart to identity-to-target selection. On the
ProteinGym homolog MSAs (undated UniRef sequences) "distance to target" conflates
off-regime divergence with oversampling redundancy; with real collection dates,
time is an axis orthogonal to redundancy, so temporal windowing selects the
relevant regime without destroying diversity.

Dates come from either sequence headers (regex) or a metadata table. All the
logic below is runnable/testable on any dated FASTA; it does not depend on the
ProteinGym benchmark.
"""

from __future__ import annotations

import datetime as _dt
import re

# permissive date patterns: full YYYY-MM-DD (any of -/_. or none) then year-only
_DATE_FULL = re.compile(r"(\d{4})[-/_. ]?(\d{2})[-/_. ]?(\d{2})")
_DATE_YM = re.compile(r"(\d{4})[-/_. ](\d{2})(?![-/_. ]?\d)")
_DATE_YEAR = re.compile(r"(?<!\d)(19|20)\d{2}(?!\d)")


def parse_date(text: str) -> _dt.date | None:
    """Best-effort collection date from a string (header token). Returns a date
    (day/month default to 1 when only year/month are present), or None."""
    m = _DATE_FULL.search(text)
    if m:
        y, mo, d = map(int, m.groups())
        if 1 <= mo <= 12 and 1 <= d <= 31:
            try:
                return _dt.date(y, mo, d)
            except ValueError:
                pass
    m = _DATE_YM.search(text)
    if m:
        y, mo = int(m.group(1)), int(m.group(2))
        if 1 <= mo <= 12:
            return _dt.date(y, mo, 1)
    m = _DATE_YEAR.search(text)
    if m:
        return _dt.date(int(m.group(0)), 1, 1)
    return None


def load_dates_from_headers(records, regex: str | None = None) -> dict[str, _dt.date]:
    """Map sequence id -> date parsed from its header. ``regex`` (with one group)
    overrides the built-in patterns when headers have a known layout."""
    pat = re.compile(regex) if regex else None
    out = {}
    for name, _ in records:
        d = None
        if pat:
            m = pat.search(name)
            if m:
                d = parse_date(m.group(1) if m.groups() else m.group(0))
        if d is None:
            d = parse_date(name)
        if d is not None:
            out[name] = d
    return out


def load_dates_from_metadata(path: str, id_col: str = "strain",
                             date_col: str = "date") -> dict[str, _dt.date]:
    """Map id -> date from a metadata CSV/TSV (e.g. a Nextstrain metadata file)."""
    import pandas as pd

    sep = "\t" if path.endswith((".tsv", ".txt")) else ","
    df = pd.read_csv(path, sep=sep)
    out = {}
    for i, d in zip(df[id_col].astype(str), df[date_col].astype(str)):
        pd_ = parse_date(d)
        if pd_ is not None:
            out[i] = pd_
    return out


def filter_by_window(records, dates: dict, t_ref, days_before: int | None = None,
                     days_after: int | None = 0, keep_undated: bool = False):
    """Keep records whose date lies within [t_ref - days_before, t_ref + days_after].

    ``days_before=None`` means no lower bound (all past sequences). ``days_after=0``
    excludes anything after the reference epoch (the usual causal setting).
    ``t_ref`` may be a date or an ISO string.
    """
    if isinstance(t_ref, str):
        t_ref = parse_date(t_ref)
    lo = t_ref - _dt.timedelta(days=days_before) if days_before is not None else _dt.date.min
    hi = t_ref + _dt.timedelta(days=days_after) if days_after is not None else _dt.date.max
    out = []
    for name, seq in records:
        d = dates.get(name)
        if d is None:
            if keep_undated:
                out.append((name, seq))
            continue
        if lo <= d <= hi:
            out.append((name, seq))
    return out


def time_decay_weights(records, dates: dict, t_ref, tau_days: float,
                       undated_weight: float = 0.0):
    """Exponential time-decay weights w_i = exp(-|t_ref - t_i| / tau_days).

    Returns a numpy array aligned to ``records``. Recent sequences (near t_ref)
    get weight ~1; older ones decay with scale ``tau_days``. Pairs with the PSSM
    weighted-count path (a temporal analog of redundancy reweighting).
    """
    import numpy as np

    if isinstance(t_ref, str):
        t_ref = parse_date(t_ref)
    w = np.empty(len(records))
    for i, (name, _) in enumerate(records):
        d = dates.get(name)
        w[i] = undated_weight if d is None else float(
            __import__("math").exp(-abs((t_ref - d).days) / tau_days))
    return w


def write_msa(records, path: str) -> str:
    with open(path, "w") as fh:
        for name, seq in records:
            fh.write(f">{name}\n{seq}\n")
    return path


def temporal_filter_msa(msa_in: str, msa_out: str, t_ref, days_before: int | None = None,
                        days_after: int | None = 0, header_regex: str | None = None,
                        metadata: str | None = None, id_col: str = "strain",
                        date_col: str = "date", keep_undated: bool = False) -> dict:
    """High-level: read a dated MSA, keep the temporal window, write the subset.

    The output MSA is a drop-in for ``--msa`` / the PSSM scorer. Returns a small
    provenance dict (counts, date range kept).
    """
    from .natural_validation import read_msa

    records = read_msa(msa_in)
    dates = (load_dates_from_metadata(metadata, id_col, date_col) if metadata
             else load_dates_from_headers(records, regex=header_regex))
    kept = filter_by_window(records, dates, t_ref, days_before=days_before,
                            days_after=days_after, keep_undated=keep_undated)
    write_msa(kept, msa_out)
    kept_dates = [dates[n] for n, _ in kept if n in dates]
    return {"n_in": len(records), "n_dated": len(dates), "n_kept": len(kept),
            "date_min": min(kept_dates).isoformat() if kept_dates else None,
            "date_max": max(kept_dates).isoformat() if kept_dates else None,
            "output": msa_out}
