"""Estimate per-mutation growth advantages from a variant-count time series.

A minimal multinomial-logistic (MLR) model, the workhorse of genomic-surveillance
fitness estimation (Nextstrain/evofr; Figgins & Bedford 2024) and, in its
per-mutation form, PyR0 (Obermeyer et al. 2022).

Model
-----
Variant i has frequency at time t

    p_i(t) = softmax_i( alpha_i + r_i * t )

so ``r_i`` is variant i's log-growth advantage (per unit time) relative to the
others; ``alpha_i`` is a nuisance intercept (arbitrary initial frequency).

Two estimands:

- ``fit_variant_growth``  : r_i per variant (one variant fixed as reference).
- ``fit_mutation_growth`` : PyR0-style additive decomposition r_i = sum_m G_im * b_m,
  giving a per-mutation growth effect ``b_m`` (ridge-regularised). This is what
  feeds ``run.py --growth`` (columns: mutant,growth).

The likelihood is convex; we fit by Adam on the exact multinomial gradient
(counts as multinomial totals per time point). numpy/pandas only.

Caveats: this is a phenomenological growth model -- r/b mix intrinsic
transmissibility, immune escape, and epidemiological context, and assume a
roughly constant advantage over the fitting window. Only *relative* values are
identifiable (softmax invariance); mutation effects are pinned by the ridge.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

import numpy as np


# --------------------------------------------------------------------------- #
# IO
# --------------------------------------------------------------------------- #
def load_counts(
    path: str,
    time_col: str = "date",
    variant_col: str = "variant",
    count_col: str = "count",
):
    """Load long-format counts -> (counts[T,K], times[T], variants[K]).

    ``time_col`` may be dates (parsed to days since the first) or numbers.
    """
    import pandas as pd

    df = pd.read_csv(path)
    for c in (time_col, variant_col, count_col):
        if c not in df.columns:
            raise ValueError(f"Column '{c}' not in {path}; got {list(df.columns)}")

    t = df[time_col]
    if pd.api.types.is_numeric_dtype(t):
        tnum = t.astype(float)                     # already a number (days/weeks/...)
    else:
        try:
            dt = pd.to_datetime(t)
            tnum = (dt - dt.min()).dt.days.astype(float)
        except (ValueError, TypeError):
            tnum = t.astype(float)
    tnum = tnum - tnum.min()
    df = df.assign(_t=tnum)

    piv = (
        df.pivot_table(index="_t", columns=variant_col, values=count_col,
                       aggfunc="sum", fill_value=0)
        .sort_index()
    )
    return piv.to_numpy(float), piv.index.to_numpy(float), list(piv.columns)


def load_genotypes(
    path: str,
    variant_col: str = "variant",
    mutations_col: str = "mutations",
) -> dict[str, set]:
    """Load a variant->mutations map. ``mutations`` is a delimited token list
    (whitespace/comma/semicolon), e.g. "N501Y S477N T478K"."""
    import pandas as pd

    df = pd.read_csv(path)
    geno = {}
    for v, muts in zip(df[variant_col], df[mutations_col]):
        toks = [x for x in re.split(r"[;,\s]+", str(muts).strip()) if x]
        geno[str(v)] = set(toks)
    return geno


def build_genotype_matrix(variants, geno, drop_invariant=True):
    """Return (G[K,M], mutation_list). Optionally drop mutations shared by all
    or absent from all variants (unidentifiable / zero-variance columns)."""
    all_muts = sorted({m for v in variants for m in geno.get(v, set())})
    K = len(variants)
    cols, kept = [], []
    for m in all_muts:
        col = np.array([1.0 if m in geno.get(v, set()) else 0.0 for v in variants])
        s = col.sum()
        if drop_invariant and (s == 0 or s == K):
            continue
        cols.append(col)
        kept.append(m)
    G = np.column_stack(cols) if cols else np.zeros((K, 0))
    return G, kept


# --------------------------------------------------------------------------- #
# Core fit (Adam on the exact multinomial gradient)
# --------------------------------------------------------------------------- #
def _softmax_rows(z):
    z = z - z.max(axis=1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis=1, keepdims=True)


def _fit_core(counts, tstd, D, l2, ref, iters=6000, lr=0.05, tol=1e-7, verbose=False):
    """Fit alpha[K], theta[P] for logits = alpha + (D@theta)*tstd.

    ref: index of variant whose alpha is fixed to 0 (identifiability). If D has
    a column per non-ref variant this also pins r_ref=0; otherwise ridge (l2)
    pins theta.
    """
    T, K = counts.shape
    P = D.shape[1]
    N = counts.sum(axis=1)                       # totals per time point

    alpha = np.zeros(K)
    theta = np.zeros(P)
    m_a = v_a = np.zeros(K)
    m_t = v_t = np.zeros(P)
    b1, b2, eps = 0.9, 0.999, 1e-8

    prev = np.inf
    for it in range(1, iters + 1):
        r = D @ theta                            # K
        logits = alpha[None, :] + np.outer(tstd, r)     # T x K
        p = _softmax_rows(logits)
        g_logit = N[:, None] * p - counts        # T x K

        g_alpha = g_logit.sum(axis=0)
        g_alpha[ref] = 0.0
        g_r = (g_logit * tstd[:, None]).sum(axis=0)     # K
        g_theta = D.T @ g_r + l2 * theta

        # Adam
        m_a = b1 * m_a + (1 - b1) * g_alpha
        v_a = b2 * v_a + (1 - b2) * g_alpha ** 2
        m_t = b1 * m_t + (1 - b1) * g_theta
        v_t = b2 * v_t + (1 - b2) * g_theta ** 2
        alpha -= lr * (m_a / (1 - b1 ** it)) / (np.sqrt(v_a / (1 - b2 ** it)) + eps)
        theta -= lr * (m_t / (1 - b1 ** it)) / (np.sqrt(v_t / (1 - b2 ** it)) + eps)
        alpha[ref] = 0.0

        if it % 200 == 0:
            nll = -(counts * np.log(np.clip(p, 1e-12, 1))).sum() + 0.5 * l2 * (theta ** 2).sum()
            if verbose:
                print(f"  iter {it}: nll={nll:.3f}")
            if abs(prev - nll) < tol * (abs(prev) + 1):
                break
            prev = nll
    return alpha, theta, p


def _standardize_time(times):
    sd = times.std()
    if sd == 0:
        raise ValueError("Need at least two distinct time points to estimate growth.")
    return (times - times.mean()) / sd, sd


# --------------------------------------------------------------------------- #
# Public estimators
# --------------------------------------------------------------------------- #
@dataclass
class GrowthFit:
    table: "object"        # pandas.DataFrame
    kind: str              # 'variant' | 'mutation'
    reference: str | None


def fit_variant_growth(counts, times, variants, l2=0.0, verbose=False) -> GrowthFit:
    """Per-variant relative log-growth rate r_i (per unit of the input time)."""
    import pandas as pd

    tstd, sd = _standardize_time(times)
    ref = int(np.argmax(counts.sum(axis=0)))          # most abundant = reference

    # design: one column per non-reference variant -> r_ref pinned to 0
    K = len(variants)
    nonref = [j for j in range(K) if j != ref]
    D = np.zeros((K, len(nonref)))
    for c, j in enumerate(nonref):
        D[j, c] = 1.0

    _, theta, _ = _fit_core(counts, tstd, D, l2=l2, ref=ref, verbose=verbose)
    r = (D @ theta) / sd                               # back to per-original-time
    table = pd.DataFrame({"variant": variants, "growth": r}).sort_values(
        "growth", ascending=False).reset_index(drop=True)
    return GrowthFit(table=table, kind="variant", reference=variants[ref])


def fit_mutation_growth(
    counts, times, variants, geno, l2=1.0, drop_invariant=True, verbose=False
) -> GrowthFit:
    """PyR0-style additive per-mutation growth effects b_m (ridge-regularised)."""
    import pandas as pd

    tstd, sd = _standardize_time(times)
    ref = int(np.argmax(counts.sum(axis=0)))
    G, muts = build_genotype_matrix(variants, geno, drop_invariant=drop_invariant)
    if G.shape[1] == 0:
        raise ValueError("No identifiable mutations (all shared or absent).")

    _, beta, _ = _fit_core(counts, tstd, G, l2=l2, ref=ref, verbose=verbose)
    beta = beta / sd
    table = pd.DataFrame({"mutant": muts, "growth": beta}).sort_values(
        "growth", ascending=False).reset_index(drop=True)
    return GrowthFit(table=table, kind="mutation", reference=variants[ref])


def write_growth_csv(fit: GrowthFit, path: str) -> None:
    fit.table.to_csv(path, index=False)
