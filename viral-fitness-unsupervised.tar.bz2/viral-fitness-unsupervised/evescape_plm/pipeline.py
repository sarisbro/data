"""End-to-end orchestration: data -> PLM scoring -> fusion -> validation.

Ground truth is optional. In decreasing order of preference the pipeline will
use, when available:

  - DMS assay          (--dms)     : Spearman / AUROC; can calibrate.
  - surveillance growth (--growth) : Spearman vs realized growth; can calibrate.
  - natural MSA         (--msa)    : label-free AUROC / freq-Spearman; can
                                     calibrate against log natural frequency.

With none of these, scoring still runs fully unsupervised and returns the ranked
per-mutation table.

Calibration-label priority (for --calibrate): growth > DMS measured > MSA log-freq.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .data import (
    enumerate_single_mutants,
    load_dms_csv,
    load_growth_csv,
    read_fasta,
)
from .escape_terms import EscapeTerms
from .fusion import fuse_terms
from .natural_validation import (
    column_counts,
    evaluate_against_msa,
    msa_logfreq_labels,
)
from .scorers import get_scorer
from .validation import evaluate, spearman


@dataclass
class PipelineOutput:
    dataframe: "object"        # pandas.DataFrame
    metrics: dict
    scorer_name: str
    mode: str
    label_source: str | None = None


def run_pipeline(
    fasta: str,
    scorer: str = "esm2",
    mode: str = "intrinsic",
    dms_csv: str | None = None,
    mutant_col: str = "mutant",
    score_col: str | None = "measured",
    label_col: str | None = None,
    growth_csv: str | None = None,
    growth_col: str = "growth",
    msa: str | None = None,
    ref_index: int = 0,
    min_count: int = 1,
    min_freq: float = 0.0,
    rsa_csv: str | None = None,
    positions: list[int] | None = None,
    temperature: float = 1.0,
    calibrate: bool = False,
    allow_fallback: bool = True,
    model_name: str | None = None,
    device: str | None = None,
    pssm_kwargs: dict | None = None,
    verbose: bool = True,
) -> PipelineOutput:
    import pandas as pd

    header, sequence = read_fasta(fasta)
    if verbose:
        print(f"[pipeline] target: {header}  (length {len(sequence)})")

    # ---- 1. which mutations to score ---------------------------------------
    dms = None
    if dms_csv:
        dms = load_dms_csv(dms_csv, mutant_col=mutant_col, score_col=score_col, label_col=label_col)
        tokens = dms["mutant"].astype(str).tolist()
        if verbose:
            print(f"[pipeline] scoring {len(tokens)} mutants from {dms_csv}")
    else:
        tokens = enumerate_single_mutants(sequence, positions=positions)
        if verbose:
            print(f"[pipeline] deep scan: {len(tokens)} single mutants")

    # ---- 2. per-mutation fitness -------------------------------------------
    if scorer.lower().startswith("pssm") or scorer.lower() == "mutsel":
        if not msa:
            raise ValueError(f"scorer='{scorer}' requires an MSA (pass msa=...).")
        sc = get_scorer(scorer.lower(), msa_path=msa, **(pssm_kwargs or {}))
    else:
        kw = {}
        if model_name:
            kw["model_name"] = model_name
        if device:
            kw["device"] = device
        sc = get_scorer(scorer, allow_fallback=allow_fallback, **kw)
    if verbose:
        print(f"[pipeline] scorer: {sc.name}"
              + (f" (device={getattr(sc, 'device', '?')})" if scorer.lower() == "esm2" and hasattr(sc, "device") else ""))
    fitness = sc.score(sequence, tokens)

    # PSSM QC: alignment identity of the MSA focus to the target, and the
    # fraction of the scored mutations' positions actually covered by the MSA.
    pssm_qc = {}
    if scorer.lower() == "pssm" and getattr(sc, "map_info", None) is not None:
        from .data import parse_mutation
        assay_pos = {mm.pos for t in tokens for mm in parse_mutation(t)}
        cov = len(assay_pos & sc.covered_positions) / max(1, len(assay_pos))
        pssm_qc = {"map_identity": sc.map_info.get("map_identity"),
                   "msa_coverage": round(cov, 3)}

    # ---- 3. escape terms (used by non-intrinsic modes) ---------------------
    et = EscapeTerms.from_rsa_csv(rsa_csv)
    accessibility = et.accessibility(tokens)
    dissimilarity = et.dissimilarity(tokens)

    # ---- 4. ground-truth sources -------------------------------------------
    growth = load_growth_csv(growth_csv, growth_col=growth_col) if growth_csv else None
    counts = info = None
    if msa:
        counts, info = column_counts(msa, sequence, ref_index=ref_index)
        if verbose:
            print(f"[pipeline] MSA: {info['n_sequences']} seqs, covered "
                  f"{info['n_query_positions']}/{len(sequence)} positions "
                  f"(a3m={info['is_a3m']})")

    # calibration labels by priority: growth > DMS measured > MSA log-freq
    labels, label_source = None, None
    if calibrate:
        if growth is not None:
            labels, label_source = growth, "growth"
        elif dms is not None and "measured" in dms.columns:
            labels = dict(zip(dms["mutant"].astype(str), dms["measured"].astype(float)))
            label_source = "dms"
        elif counts is not None:
            labels = msa_logfreq_labels({t: 0.0 for t in tokens}, counts)
            label_source = "msa_logfreq"
        if verbose and label_source:
            print(f"[pipeline] calibrating against: {label_source}")

    # ---- 5. fuse -----------------------------------------------------------
    fr = fuse_terms(
        fitness,
        accessibility=accessibility,
        dissimilarity=dissimilarity,
        mode=mode,
        temperature=temperature,
        labels=labels,
        calibrate=calibrate,
    )
    if verbose and fr.calibrated:
        print(f"[pipeline] calibrated weights ({label_source}): "
              f"{ {k: round(v,3) for k,v in fr.weights.items()} }")

    scores = fr.as_dict()

    # ---- 6. assemble output table ------------------------------------------
    out = pd.DataFrame({
        "mutant": fr.tokens,
        "fitness_plm": [fitness[t] for t in fr.tokens],
        "accessibility": [accessibility[t] for t in fr.tokens],
        "dissimilarity": [dissimilarity[t] for t in fr.tokens],
        "score": fr.fused,
    }).sort_values("score", ascending=False).reset_index(drop=True)

    # ---- 7. validate against whatever ground truth exists ------------------
    metrics = evaluate(fr.tokens, fr.fused, dms)          # DMS Spearman/AUROC
    if growth is not None:
        common = [t for t in fr.tokens if t in growth]
        metrics["growth_n_matched"] = float(len(common))
        metrics["spearman_growth"] = spearman(
            np.array([scores[t] for t in common]),
            np.array([growth[t] for t in common]),
        )
    if counts is not None:
        metrics.update(evaluate_against_msa(scores, counts, min_count=min_count, min_freq=min_freq))
    metrics.update(pssm_qc)

    # ---- 8. attach available ground-truth columns to the table ------------
    if dms is not None:
        merge_cols = ["mutant"] + [c for c in ("measured", "label") if c in dms.columns]
        out = out.merge(dms[merge_cols], on="mutant", how="left")
    if growth is not None:
        out["growth"] = out["mutant"].map(growth)

    if verbose:
        print(f"[pipeline] metrics: { {k: (round(v,4) if isinstance(v,float) else v) for k,v in metrics.items()} }")

    return PipelineOutput(
        dataframe=out, metrics=metrics, scorer_name=sc.name, mode=mode, label_source=label_source
    )
