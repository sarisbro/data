"""Per-mutation fitness scorers.

Every scorer implements ``score(sequence, mutations) -> {mut_str: float}`` where
higher = fitter (i.e. the log-likelihood ratio log P(mut) - log P(wt), summed
over positions for multi-mutants).

- ``ESM2Scorer``   : masked-marginal scoring with HuggingFace ESM-2 (torch).
- ``MockScorer``   : BLOSUM62-based fallback so the pipeline runs anywhere.
- ``EnsembleScorer``: mean of z-scored member scores (ProteinGym-style ensembling).
- ``TranceptionScorer`` / ``MSATransformerScorer``: documented hooks to fill in.

``get_scorer(name, allow_fallback=True)`` returns ESM-2 if torch+transformers+
weights are available, otherwise transparently falls back to the mock scorer.
"""

from __future__ import annotations

import math
import sys
from typing import Iterable

from .data import parse_mutation, validate_against_sequence


# --------------------------------------------------------------------------- #
# Base class
# --------------------------------------------------------------------------- #
class BaseScorer:
    name = "base"

    def score(self, sequence: str, mutations: Iterable[str]) -> dict[str, float]:
        raise NotImplementedError

    def _parsed(self, sequence: str, mutations: Iterable[str]):
        parsed = {tok: parse_mutation(tok) for tok in mutations}
        for muts in parsed.values():
            validate_against_sequence(muts, sequence)
        return parsed


# --------------------------------------------------------------------------- #
# ESM-2 (masked-marginal)
# --------------------------------------------------------------------------- #
class ESM2Scorer(BaseScorer):
    """ESM-2 zero-shot fitness via masked-marginal log-likelihood ratios.

    For each mutated position we mask that token, run one forward pass, and read
    log P(mut) - log P(wt) from the softmax over the amino-acid vocabulary. This
    is the Meier et al. (2021) "masked marginal" scheme, the strongest of the
    ESM zero-shot variants. Multi-mutants sum the per-position contributions.
    """

    def __init__(
        self,
        model_name: str = "facebook/esm2_t6_8M_UR50D",
        device: str | None = None,
        batch_size: int = 16,
    ):
        import torch  # noqa: F401  (raises ImportError -> triggers fallback)
        from transformers import AutoModelForMaskedLM, AutoTokenizer

        import torch

        self.torch = torch
        self.name = f"esm2:{model_name.split('/')[-1]}"
        self.model_name = model_name
        self.batch_size = batch_size
        if device:
            self.device = device
        elif torch.cuda.is_available():
            self.device = "cuda"
        elif getattr(torch.backends, "mps", None) is not None and torch.backends.mps.is_available():
            self.device = "mps"            # Apple Silicon GPU (M1/M2/M3/M4)
        else:
            self.device = "cpu"

        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForMaskedLM.from_pretrained(model_name).to(self.device).eval()
        self.mask_id = self.tokenizer.mask_token_id

    def _aa_id(self, aa: str) -> int:
        return self.tokenizer.convert_tokens_to_ids(aa)

    def score(self, sequence: str, mutations: Iterable[str]) -> dict[str, float]:
        torch = self.torch
        parsed = self._parsed(sequence, mutations)

        # Unique 0-based positions we actually need masked log-probs for.
        need = sorted({m.idx0 for muts in parsed.values() for m in muts})

        enc = self.tokenizer(sequence, return_tensors="pt")
        input_ids = enc["input_ids"].to(self.device)          # (1, L+2): <cls> ... <eos>
        attn = enc["attention_mask"].to(self.device)

        # token index of residue idx0 == idx0 + 1 (offset for the <cls> token)
        logp_at: dict[int, "torch.Tensor"] = {}
        with torch.no_grad():
            for start in range(0, len(need), self.batch_size):
                chunk = need[start : start + self.batch_size]
                batch_ids = input_ids.repeat(len(chunk), 1).clone()
                batch_attn = attn.repeat(len(chunk), 1)
                for row, p in enumerate(chunk):
                    batch_ids[row, p + 1] = self.mask_id
                logits = self.model(input_ids=batch_ids, attention_mask=batch_attn).logits
                for row, p in enumerate(chunk):
                    logp_at[p] = torch.log_softmax(logits[row, p + 1], dim=-1).cpu()

        out = {}
        for tok, muts in parsed.items():
            s = 0.0
            for m in muts:
                lp = logp_at[m.idx0]
                s += float(lp[self._aa_id(m.mut)] - lp[self._aa_id(m.wt)])
            out[tok] = s
        return out


# --------------------------------------------------------------------------- #
# Mock fallback (BLOSUM62)
# --------------------------------------------------------------------------- #
_AA = "A R N D C Q E G H I L K M F P S T W Y V".split()
_BLOSUM62_ROWS = """
 4 -1 -2 -2  0 -1 -1  0 -2 -1 -1 -1 -1 -2 -1  1  0 -3 -2  0
-1  5  0 -2 -3  1  0 -2  0 -3 -2  2 -1 -3 -2 -1 -1 -3 -2 -3
-2  0  6  1 -3  0  0  0  1 -3 -3  0 -2 -3 -2  1  0 -4 -2 -3
-2 -2  1  6 -3  0  2 -1 -1 -3 -4 -1 -3 -3 -1  0 -1 -4 -3 -3
 0 -3 -3 -3  9 -3 -4 -3 -3 -1 -1 -3 -1 -2 -3 -1 -1 -2 -2 -1
-1  1  0  0 -3  5  2 -2  0 -3 -2  1  0 -3 -1  0 -1 -2 -1 -2
-1  0  0  2 -4  2  5 -2  0 -3 -3  1 -2 -3 -1  0 -1 -3 -2 -2
 0 -2  0 -1 -3 -2 -2  6 -2 -4 -4 -2 -3 -3 -2  0 -2 -2 -3 -3
-2  0  1 -1 -3  0  0 -2  8 -3 -3 -1 -2 -1 -2 -1 -2 -2  2 -3
-1 -3 -3 -3 -1 -3 -3 -4 -3  4  2 -3  1  0 -3 -2 -1 -3 -1  3
-1 -2 -3 -4 -1 -2 -3 -4 -3  2  4 -2  2  0 -3 -2 -1 -2 -1  1
-1  2  0 -1 -3  1  1 -2 -1 -3 -2  5 -1 -3 -1  0 -1 -3 -2 -2
-1 -1 -2 -3 -1  0 -2 -3 -2  1  2 -1  5  0 -2 -1 -1 -1 -1  1
-2 -3 -3 -3 -2 -3 -3 -3 -1  0  0 -3  0  6 -4 -2 -2  1  3 -1
-1 -2 -2 -1 -3 -1 -1 -2 -2 -3 -3 -1 -2 -4  7 -1 -1 -4 -3 -2
 1 -1  1  0 -1  0  0  0 -1 -2 -2  0 -1 -2 -1  4  1 -3 -2 -2
 0 -1  0 -1 -1 -1 -1 -2 -2 -1 -1 -1 -1 -2 -1  1  5 -2 -2  0
-3 -3 -4 -4 -2 -2 -3 -2 -2 -3 -2 -3 -1  1 -4 -3 -2 11  2 -3
-2 -2 -2 -3 -2 -1 -2 -3  2 -1 -1 -2 -1  3 -3 -2 -2  2  7 -1
 0 -3 -3 -3 -1 -2 -2 -3 -3  3  1 -2  1 -1 -2 -2  0 -3 -1  4
"""


def _build_blosum():
    rows = [r for r in _BLOSUM62_ROWS.strip().splitlines()]
    mat = {}
    for a, row in zip(_AA, rows):
        vals = [int(x) for x in row.split()]
        mat[a] = {b: v for b, v in zip(_AA, vals)}
    return mat


_BLOSUM62 = _build_blosum()


class MockScorer(BaseScorer):
    """Deterministic, dependency-free fitness proxy from BLOSUM62.

    Uses log-odds of the wt->mut substitution as a stand-in for a PLM score.
    Not a real fitness model -- its only job is to let you exercise and test the
    fusion + validation plumbing before wiring up ESM-2/Tranception.
    """

    name = "mock:blosum62"

    def score(self, sequence: str, mutations: Iterable[str]) -> dict[str, float]:
        parsed = self._parsed(sequence, mutations)
        out = {}
        for tok, muts in parsed.items():
            s = 0.0
            for m in muts:
                s += float(_BLOSUM62.get(m.wt, {}).get(m.mut, -4))
            out[tok] = s
        return out


# --------------------------------------------------------------------------- #
# PSSM (site-independent alignment model)
# --------------------------------------------------------------------------- #
class PSSMScorer(BaseScorer):
    """Alignment-based, GPU-free fitness scorer: site-independent log-odds.

    For a substitution wt->mut at position i, the score is

        log[ (c_i(mut) + kappa) / (N_i + 20 kappa) ]
      - log[ (c_i(wt)  + kappa) / (N_i + 20 kappa) ]

    where c_i are amino-acid counts in the MSA column aligned to position i and
    kappa is a pseudocount. Despite its simplicity this baseline is known to
    match or beat single-sequence protein language models on viral proteins,
    whose families are poorly represented in PLM training data. Requires an MSA
    of the target family (aligned FASTA or A3M).
    """

    name = "pssm"

    def __init__(self, msa_path: str, pseudocount: float = 0.5, ref_index: int = 0,
                 reweight: bool = False, reweight_theta: float = 0.99,
                 select: str | None = None, select_k: int | None = None,
                 select_min_identity: float | None = None):
        self.msa_path = msa_path
        self.pseudocount = pseudocount
        self.ref_index = ref_index
        self.reweight = reweight
        self.reweight_theta = reweight_theta
        self.select = select
        self.select_k = select_k
        self.select_min_identity = select_min_identity
        # redundancy weighting is O(N^2); cap the alignment depth used for it
        self.max_sequences = 4000 if reweight else 20000
        if reweight:
            self.name = "pssm_w"
        if select == "topk":
            self.name += f"_top{select_k}"
        elif select == "min_identity":
            self.name += f"_id{select_min_identity}"

    def score(self, sequence: str, mutations: Iterable[str]) -> dict[str, float]:
        from .natural_validation import column_counts

        counts, info = column_counts(self.msa_path, sequence, ref_index=self.ref_index,
                                     max_sequences=self.max_sequences,
                                     reweight=self.reweight, reweight_theta=self.reweight_theta,
                                     select=self.select, select_k=self.select_k,
                                     select_min_identity=self.select_min_identity)
        self.map_info = info                       # QC: map_identity, coverage, mode
        self.covered_positions = set(counts.keys())
        parsed = self._parsed(sequence, mutations)
        pc, K = self.pseudocount, 20
        out = {}
        for tok, muts in parsed.items():
            s = 0.0
            for m in muts:
                c = counts.get(m.pos)
                if c is None:
                    continue                       # position not covered -> neutral
                tot = sum(c.values())
                p_mut = (c.get(m.mut, 0) + pc) / (tot + pc * K)
                p_wt = (c.get(m.wt, 0) + pc) / (tot + pc * K)
                s += math.log(p_mut) - math.log(p_wt)
            out[tok] = s
        return out


# --------------------------------------------------------------------------- #
# Mutation-selection (MutSel) -- independent-sites, tree-free
# --------------------------------------------------------------------------- #
# number of sense codons per amino acid (standard genetic code)
_CODON_COUNT = {"A": 4, "R": 6, "N": 2, "D": 2, "C": 2, "Q": 2, "E": 2, "G": 4,
                "H": 2, "I": 3, "L": 6, "K": 2, "M": 1, "F": 2, "P": 4, "S": 6,
                "T": 4, "W": 1, "Y": 2, "V": 4}
_CODONS = {  # for the nucleotide-composition-aware supply model
    "A": ["GCT", "GCC", "GCA", "GCG"], "R": ["CGT", "CGC", "CGA", "CGG", "AGA", "AGG"],
    "N": ["AAT", "AAC"], "D": ["GAT", "GAC"], "C": ["TGT", "TGC"], "Q": ["CAA", "CAG"],
    "E": ["GAA", "GAG"], "G": ["GGT", "GGC", "GGA", "GGG"], "H": ["CAT", "CAC"],
    "I": ["ATT", "ATC", "ATA"], "L": ["TTA", "TTG", "CTT", "CTC", "CTA", "CTG"],
    "K": ["AAA", "AAG"], "M": ["ATG"], "F": ["TTT", "TTC"],
    "P": ["CCT", "CCC", "CCA", "CCG"], "S": ["TCT", "TCC", "TCA", "TCG", "AGT", "AGC"],
    "T": ["ACT", "ACC", "ACA", "ACG"], "W": ["TGG"], "Y": ["TAT", "TAC"],
    "V": ["GTT", "GTC", "GTA", "GTG"]}


def _mutational_supply(nuc_freqs=None):
    """M(a): neutral equilibrium supply of each amino acid under the mutation
    process. Uniform nucleotides -> proportional to codon count; otherwise the
    sum of codon probabilities under the supplied base composition."""
    if nuc_freqs is None:
        tot = sum(_CODON_COUNT.values())
        return {a: c / tot for a, c in _CODON_COUNT.items()}
    M = {a: sum(nuc_freqs[c[0]] * nuc_freqs[c[1]] * nuc_freqs[c[2]] for c in cods)
         for a, cods in _CODONS.items()}
    z = sum(M.values())
    return {a: v / z for a, v in M.items()}


class MutSelScorer(PSSMScorer):
    """Independent-sites mutation-selection scorer (Halpern-Bruno at equilibrium).

    Under a MutSel model the stationary site frequency factors as
    ``pi_i(a) ~ M(a) * exp(F_i(a))`` with M(a) the neutral mutational supply of
    amino acid a; the scaled selection coefficient is ``F_i(a) = log pi_i(a) -
    log M(a)``. The per-mutation score is therefore the PSSM log-odds minus a
    codon-supply correction that divides out the fact that some residues are
    reachable by more codons and so appear more often from mutation alone. A tree
    would additionally correct for phylogenetic non-independence (see docs).
    """

    name = "mutsel"

    def __init__(self, msa_path: str, nucleotide_freqs=None, **kwargs):
        super().__init__(msa_path, **kwargs)
        self.name = "mutsel"
        M = _mutational_supply(nucleotide_freqs)
        self.logM = {a: math.log(M[a]) for a in M}

    def score(self, sequence: str, mutations):
        base = super().score(sequence, mutations)          # PSSM log-odds
        out = {}
        for tok in mutations:
            corr = 0.0
            for m in parse_mutation(tok):
                corr += self.logM.get(m.mut, 0.0) - self.logM.get(m.wt, 0.0)
            out[tok] = base[tok] - corr
        return out


# --------------------------------------------------------------------------- #
# Ensemble
# --------------------------------------------------------------------------- #
class EnsembleScorer(BaseScorer):
    """Mean of per-member z-scored fitness scores (equal weight by default)."""

    def __init__(self, members: list[BaseScorer], weights: list[float] | None = None):
        self.members = members
        self.weights = weights or [1.0] * len(members)
        self.name = "ensemble(" + ",".join(m.name for m in members) + ")"

    def score(self, sequence: str, mutations: Iterable[str]) -> dict[str, float]:
        import numpy as np

        toks = list(mutations)
        stacked = []
        for m in self.members:
            d = m.score(sequence, toks)
            v = np.array([d[t] for t in toks], float)
            sd = v.std()
            stacked.append((v - v.mean()) / sd if sd > 0 else v - v.mean())
        w = np.array(self.weights, float)
        w = w / w.sum()
        combined = np.tensordot(w, np.array(stacked), axes=(0, 0))
        return {t: float(x) for t, x in zip(toks, combined)}


# --------------------------------------------------------------------------- #
# Hooks: fill these in to add more PLMs to the ensemble
# --------------------------------------------------------------------------- #
class TranceptionScorer(BaseScorer):
    """Hook for Tranception (autoregressive + MSA retrieval).

    Recommended: use the official Tranception repo's scoring entry point to get
    per-mutant log-likelihood ratios (with retrieval enabled), then return them
    in the same {mut_str: score} contract. Tranception tends to win on viral
    ProteinGym assays and handles indels better than ESM-2.
    """

    name = "tranception"

    def score(self, sequence, mutations):
        raise NotImplementedError(
            "Wire up Tranception here and return {mut_str: log-likelihood-ratio}."
        )


class MSATransformerScorer(BaseScorer):
    """Hook for MSA Transformer (needs a subsampled MSA of the target family).

    For fast-evolving viruses, subsample the alignment for *diversity* rather
    than depth (e.g. hhfilter / diversity-maximizing subsampling), then score
    with masked-marginal over the query row.
    """

    name = "msa_transformer"

    def score(self, sequence, mutations):
        raise NotImplementedError(
            "Wire up MSA Transformer here (supply a subsampled MSA) and return "
            "{mut_str: log-likelihood-ratio}."
        )


# --------------------------------------------------------------------------- #
# Factory
# --------------------------------------------------------------------------- #
def get_scorer(
    name: str = "esm2",
    allow_fallback: bool = True,
    **kwargs,
) -> BaseScorer:
    """Return a scorer by name, transparently falling back to the mock scorer.

    name: 'esm2' | 'mock' | 'tranception' | 'msa_transformer'
    """
    name = name.lower()
    if name in ("mock", "blosum", "blosum62"):
        return MockScorer()
    if name == "pssm":
        return PSSMScorer(**kwargs)          # requires msa_path=...
    if name in ("pssm_w", "pssm-weighted"):
        return PSSMScorer(reweight=True, **kwargs)
    if name == "mutsel":
        return MutSelScorer(**kwargs)        # requires msa_path=...
    if name == "esm2":
        try:
            return ESM2Scorer(**kwargs)
        except Exception as exc:  # ImportError, missing weights, no network...
            if not allow_fallback:
                raise
            print(
                f"[scorers] ESM-2 unavailable ({type(exc).__name__}: {exc}); "
                f"falling back to MockScorer(BLOSUM62). Install torch+transformers "
                f"and provide model weights for real scoring.",
                file=sys.stderr,
            )
            return MockScorer()
    if name == "tranception":
        return TranceptionScorer()
    if name == "msa_transformer":
        return MSATransformerScorer()
    raise ValueError(f"Unknown scorer '{name}'")
