"""EVEscape-style fitness scoring with protein language models.

A modular, unsupervised pipeline for per-mutation fitness / escape scoring:

    data  ->  per-mutation PLM scoring  ->  term fusion  ->  validation

The EVEscape scaffold is a product of independent unsupervised terms:

    score = P(fitness-viable) * P(antibody-accessible) * P(biochemically dissimilar)

Here the fitness term is supplied by a protein language model (ESM-2 by default,
with hooks for Tranception / MSA Transformer) instead of a VAE, and the two
escape terms are retained only when the target is *realized / antigenic* fitness.
"""

from .data import (
    Mutation,
    read_fasta,
    parse_mutation,
    enumerate_single_mutants,
    load_dms_csv,
    load_growth_csv,
)
from .scorers import (get_scorer, BaseScorer, ESM2Scorer, MockScorer, PSSMScorer,
                      MutSelScorer, EnsembleScorer)
from .escape_terms import EscapeTerms
from .fusion import fuse_terms, FusionResult
from .validation import spearman, auroc, evaluate
from .natural_validation import (
    read_msa,
    column_counts,
    evaluate_against_msa,
    msa_logfreq_labels,
)
from .growth_fit import (
    load_counts,
    load_genotypes,
    fit_variant_growth,
    fit_mutation_growth,
    write_growth_csv,
)
from .pipeline import run_pipeline

__all__ = [
    "Mutation",
    "read_fasta",
    "parse_mutation",
    "enumerate_single_mutants",
    "load_dms_csv",
    "load_growth_csv",
    "read_msa",
    "column_counts",
    "evaluate_against_msa",
    "msa_logfreq_labels",
    "load_counts",
    "load_genotypes",
    "fit_variant_growth",
    "fit_mutation_growth",
    "write_growth_csv",
    "get_scorer",
    "BaseScorer",
    "ESM2Scorer",
    "MockScorer",
    "PSSMScorer",
    "EnsembleScorer",
    "EscapeTerms",
    "fuse_terms",
    "FusionResult",
    "spearman",
    "auroc",
    "evaluate",
    "run_pipeline",
]
