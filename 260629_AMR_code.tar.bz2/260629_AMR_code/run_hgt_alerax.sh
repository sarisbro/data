#!/usr/bin/env bash
# run_hgt_alerax.sh --------------------------------------------------------
# HGT view (View 3) via AleRax -- the manuscript's more robust reconciliation
# alternative to GeneRax. Reconciles the per-family gene trees (as single-tree
# distributions) against the species tree under the UndatedDTL model.
#   prep_alerax.py -> alerax -> parse_alerax.py -> hgt.tsv
#
# Usage:
#   bash run_hgt_alerax.sh <label> <out_base>
#
# Knobs:
#   NPROCS        MPI ranks (default 1; AleRax requires mpiexec for parallelism)
#   REC_MODEL     UndatedDTL (default) | UndatedDL
#   SAMPLES       reconciled-tree samples per family (default 100)
#   NO_TL         1 = pass --no-tl (~4x faster; transfers still counted, TL not)
#   MAX_FAMILIES  trial cap (0 = all)
# Requires: alerax (+ mpiexec if NPROCS>1), python3+dendropy (amr-labelfree).
# -------------------------------------------------------------------------
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LABEL="${1:?need a species label}"
OUTB="${2:?need the species out base}"; OUTB="$(cd "$OUTB" && pwd)"
FAMS="$OUTB/families"; AL="$OUTB/hgt_alerax"; PREFIX="$AL/alerax_out"
REC_MODEL="${REC_MODEL:-UndatedDTL}"; NPROCS="${NPROCS:-1}"
SAMPLES="${SAMPLES:-100}"; MAX_FAMILIES="${MAX_FAMILIES:-0}"
say(){ printf '\033[1;35m[%s]\033[0m %s\n' "$LABEL" "$*"; }

[[ -d "$FAMS/genetrees" && -s "$OUTB/core/core.treefile" ]] || { echo "need families/genetrees and core/core.treefile"; exit 1; }
mkdir -p "$AL"

# PARSE_ONLY=1: skip prep + AleRax, just (re)parse an existing run into hgt.tsv.
if [[ "${PARSE_ONLY:-0}" == 1 ]]; then
  say "PARSE_ONLY: parsing existing AleRax output -> hgt.tsv ..."
  python3 "$HERE/parse_alerax.py" --summary-dir "$PREFIX/reconciliations" \
      --out "$OUTB/hgt.tsv" --family-index "$FAMS/family_index.tsv"
  exit 0
fi

command -v alerax >/dev/null || { echo "alerax not found -- install: conda install -c bioconda alerax (or build from source)"; exit 1; }
say "preparing AleRax families file + mappings + rooted species tree..."
python3 "$HERE/prep_alerax.py" --families-dir "$FAMS" --species-tree "$OUTB/core/core.treefile" \
    --out-dir "$AL" --max-families "$MAX_FAMILIES"

run=(alerax); [[ "$NPROCS" -gt 1 ]] && run=(mpiexec -np "$NPROCS" alerax)
notl=(); [[ "${NO_TL:-0}" == 1 ]] && notl=(--no-tl)
say "running AleRax (model=$REC_MODEL, ranks=$NPROCS, samples=$SAMPLES)... [re-run to resume from checkpoint]"
"${run[@]}" -f "$AL/families.txt" -s "$AL/species_rooted.nwk" -p "$PREFIX" \
    -r "$REC_MODEL" --species-tree-search SKIP --gene-tree-samples "$SAMPLES" \
    ${notl[@]+"${notl[@]}"} >"$AL/alerax.log" 2>&1 \
  || { echo "AleRax exited non-zero (see $AL/alerax.log); attempting to parse any summaries"; }

say "parsing transfers -> hgt.tsv ..."
python3 "$HERE/parse_alerax.py" --summary-dir "$PREFIX/reconciliations" \
    --out "$OUTB/hgt.tsv" --family-index "$FAMS/family_index.tsv"
say "DONE -> $OUTB/hgt.tsv"
