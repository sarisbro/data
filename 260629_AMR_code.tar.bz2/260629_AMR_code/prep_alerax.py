#!/usr/bin/env python3
"""prep_alerax.py -- build AleRax inputs from the per-family gene trees.

AleRax takes, per family, a gene-tree distribution (a file with one newick per
line; our single ML gene tree is a distribution of one) and a gene->species
mapping, plus a ROOTED species tree.

Writes, under --out-dir:
  species_rooted.nwk   midpoint-rooted species tree
  map/<fam>.link       gene->species mapping (species:gene1;gene2;...)
  families.txt         AleRax families file (gene_tree = ...; mapping = ...)
"""
import argparse, os, glob
import dendropy


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--families-dir", required=True, help="dir with genetrees/")
    ap.add_argument("--species-tree", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--max-families", type=int, default=0)
    args = ap.parse_args()

    os.makedirs(os.path.join(args.out_dir, "map"), exist_ok=True)
    t = dendropy.Tree.get(path=args.species_tree, schema="newick", preserve_underscores=True)
    t.reroot_at_midpoint(update_bipartitions=False)
    sp_path = os.path.join(args.out_dir, "species_rooted.nwk")
    t.write(path=sp_path, schema="newick", unquoted_underscores=True, suppress_rooting=True)

    tre_dir = os.path.join(args.families_dir, "genetrees")
    trees = sorted(glob.glob(os.path.join(tre_dir, "*.treefile")))
    if args.max_families:
        trees = trees[:args.max_families]

    fpath = os.path.join(args.out_dir, "families.txt")
    n = 0
    with open(fpath, "w") as fh:
        fh.write("[FAMILIES]\n")
        for tr in trees:
            fam = os.path.basename(tr)[:-len(".treefile")]
            gt = dendropy.Tree.get(path=tr, schema="newick", preserve_underscores=True)
            sp2 = {}
            for lf in gt.leaf_node_iter():
                if lf.taxon is None:
                    continue
                g = lf.taxon.label
                sp2.setdefault(g.split("__", 1)[0], []).append(g)
            if len(sp2) < 2:
                continue
            mp = os.path.join(args.out_dir, "map", fam + ".link")
            with open(mp, "w") as m:
                for sp, genes in sp2.items():
                    m.write(f"{sp}:{';'.join(genes)}\n")
            fh.write(f"- {fam}\ngene_tree = {tr}\nmapping = {mp}\n")
            n += 1
    print(f"[prep-alerax] {n} families -> {fpath}; rooted species tree -> {sp_path}")


if __name__ == "__main__":
    main()
