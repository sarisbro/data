#!/usr/bin/env python3
"""parse_alerax.py -- HGT view from AleRax reconciliation summaries.

AleRax writes, per family, under <prefix>/reconciliations/summary/:
  <fam>_meanSpeciesEventCounts.txt   per-species averaged event counts (one file
                                     per family -> used to enumerate families)
  <fam>_meanTransfers.txt            averaged transfer pairs "<from> <to> <count>"
                                     (summing the count column = total transfers)

Per family:
  transfers      sum of the averaged transfer counts (0 if no transfers)
  transfer_rate  transfers / family size
  hgt_score      mean of rank-z(transfers) and rank-z(transfer_rate)

Output (--out): family  transfers  transfer_rate  hgt_score
Defensive about column layout (sums the last numeric token per line).
"""
import argparse, glob, os, re, sys
import numpy as np

NUM = re.compile(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?")


def rank_z(x):
    x = np.asarray(x, float); out = np.zeros_like(x)
    if len(x) > 1 and x.std() > 0:
        r = x.argsort().argsort().astype(float)
        out = (r - r.mean()) / r.std()
    return out


def sum_transfers(path):
    if not os.path.isfile(path):
        return 0.0
    tot = 0.0
    for line in open(path):
        nums = NUM.findall(line)
        if nums:
            tot += float(nums[-1])     # trailing count column
    return tot


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--summary-dir", required=True, help="<prefix>/reconciliations/summary")
    ap.add_argument("--out", required=True)
    ap.add_argument("--family-index", default=None)
    args = ap.parse_args()

    sizes = {}
    if args.family_index and os.path.isfile(args.family_index):
        with open(args.family_index) as fh:
            hdr = fh.readline().rstrip("\n").split("\t")
            ci = hdr.index("n_members") if "n_members" in hdr else -1
            for line in fh:
                p = line.rstrip("\n").split("\t")
                if ci >= 0 and len(p) > ci:
                    try:
                        sizes[p[0]] = int(p[ci])
                    except ValueError:
                        pass

    # AleRax filenames differ by version: >=1.3.0 uses *_meanTransfers.txt /
    # *_meanSpeciesEventCounts.txt; <1.3.0 uses *_transfers.txt /
    # *_perspecies_eventcount.txt. Accept both.
    EVENT_SUFFIXES = ["_meanSpeciesEventCounts.txt", "_perspecies_eventcount.txt",
                      "_speciesEventCounts.txt"]
    XFER_SUFFIXES = ["_meanTransfers.txt", "_transfers.txt"]

    # The summary files may live in <dir>, <dir>/summary, or the parent. Search all.
    base = args.summary_dir.rstrip("/")
    SEARCH_DIRS = [d for d in [base, os.path.join(base, "summaries"),
                               os.path.join(base, "summary"),
                               os.path.dirname(base)] if os.path.isdir(d)]

    def enumerate_families():
        for d in SEARCH_DIRS:
            for suf in EVENT_SUFFIXES + XFER_SUFFIXES:
                hits = glob.glob(os.path.join(d, "*" + suf))
                if hits:
                    return d, sorted(os.path.basename(f)[:-len(suf)] for f in hits), suf
        return None, [], None

    summ_dir, fams, used = enumerate_families()
    if not fams:
        listing = []
        for d in SEARCH_DIRS:
            listing += [os.path.basename(p) for p in glob.glob(os.path.join(d, "*"))[:6]]
        raise SystemExit(f"[parse-alerax] no recognized summary files under {SEARCH_DIRS}\n"
                         f"  found e.g.: {listing[:8]}\n"
                         f"  -> tell me these filenames and I'll add the suffix")
    sys.stderr.write(f"[parse-alerax] {len(fams)} families in {summ_dir} (via '{used}')\n")

    def transfer_file(fam):
        for suf in XFER_SUFFIXES:
            p = os.path.join(summ_dir, fam + suf)
            if os.path.isfile(p):
                return p
        return None

    recs = []
    for fam in fams:
        tf = transfer_file(fam)
        t = sum_transfers(tf) if tf else 0.0
        sz = sizes.get(fam, 0) or 1
        recs.append([fam, t, t / sz])

    transfers = np.array([r[1] for r in recs]); rate = np.array([r[2] for r in recs])
    score = (rank_z(transfers) + rank_z(rate)) / 2.0
    with open(args.out, "w") as o:
        o.write("family\ttransfers\ttransfer_rate\thgt_score\n")
        for i, r in enumerate(recs):
            o.write(f"{r[0]}\t{r[1]:.3f}\t{r[2]:.5f}\t{score[i]:.5f}\n")
    print(f"[parse-alerax] {len(recs)} families -> {args.out} (max transfers={transfers.max():.2f})")


if __name__ == "__main__":
    main()
