#!/usr/bin/env bash
# build_amr_annotation.sh --------------------------------------------------
# Annotate the MMseqs2 pangenome with known resistance determinants: run
# AMRFinderPlus on the family representative proteins, then map hits onto the
# pangenome (prevalence + core/shell/cloud partition) and plot.
#
# Usage:
#   bash build_amr_annotation.sh <label> <out_base> [organism]
# Example:
#   bash build_amr_annotation.sh "Escherichia coli" out/ecoli Escherichia
#
# One-time DB setup (if not done): amrfinder -u
# Knobs: THREADS (14), FORCE=1.
# Requires: amrfinder (ncbi-amrfinderplus, in amr-labelfree), python3.
# -------------------------------------------------------------------------
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
THREADS="${THREADS:-14}"
LABEL="${1:?need a species label}"
OUTB="${2:?need the species out base}"
ORGANISM="${3:-}"
OUTB="$(cd "$OUTB" && pwd)"
MM="$OUTB/mmseqs"; AMR="$OUTB/amr"
mkdir -p "$AMR"
say(){ printf '\033[1;31m[%s]\033[0m %s\n' "$LABEL" "$*"; }

command -v amrfinder >/dev/null || { echo "amrfinder not found -- activate amr-labelfree"; exit 1; }
REPS="$MM/clust_rep_seq.fasta"
CLUST="$MM/clust_cluster.tsv"
[[ -s "$REPS"  ]] || { echo "missing $REPS -- run the MMseqs2 step first"; exit 1; }
[[ -s "$CLUST" ]] || { echo "missing $CLUST -- run the MMseqs2 step first"; exit 1; }

# ---- 1. AMRFinderPlus on the family representatives (protein mode) ----------
AF="$AMR/amrfinder.tsv"
if [[ ! -s "$AF" || "${FORCE:-0}" == 1 ]]; then
  org_arg=(); [[ -n "$ORGANISM" ]] && org_arg=(--organism "$ORGANISM")
  say "running AMRFinderPlus on $(grep -c '^>' "$REPS") family representatives..."
  amrfinder -p "$REPS" --plus --threads "$THREADS" ${org_arg[@]+"${org_arg[@]}"} -o "$AF" \
      > "$AMR/amrfinder.log" 2>&1 || {
        echo "AMRFinderPlus failed (see $AMR/amrfinder.log)."
        echo "If it reports a missing database, run once:  amrfinder -u"
        tail -15 "$AMR/amrfinder.log"; exit 1; }
else
  say "AMRFinderPlus output present -> reusing (FORCE=1 to rerun)"
fi

# ---- 2. map onto the pangenome + plot --------------------------------------
say "mapping AMR hits onto the pangenome..."
python3 "$HERE/annotate_amr.py" \
    --clusters "$CLUST" --amrfinder "$AF" \
    --out-prefix "$AMR/amr_pangenome" --label "$LABEL"

say "DONE -> $AMR/  (amr_families.tsv, amr_summary.tsv, amr_pangenome.{png,pdf})"
