#!/usr/bin/env python3
"""plot_realdata_summary.py -- single consolidated real-data figure for the main
text, comparing both species across all label-free analyses.

2x3 panels (both species overlaid/grouped):
  A pan/core-genome accumulation        D recovery ROC (vs AMRFinderPlus labels)
  B pangenome partition composition     E early enrichment (top 1% / 5%)
  C AMR families per partition          F view ablation (AUPRC by view subset)

Usage:
  plot_realdata_summary.py --out realdata_summary \
     "Escherichia coli=out/ecoli/gene_presence_absence_mmseqs.Rtab=out/ecoli/candidate_scores.tsv=out/ecoli/amr/amr_pangenome_amr_families.tsv" \
     "Klebsiella pneumoniae=out/kpneumoniae/...=...=..."
"""
import argparse, re
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import average_precision_score, roc_auc_score, roc_curve

SP_COLORS = ["#1b9e77", "#7570b3", "#d95f02"]
PART_ORDER = ["core", "soft-core", "shell", "cloud"]
PART_COLORS = {"core": "#2166ac", "soft-core": "#67a9cf", "shell": "#fdb863", "cloud": "#d6604d"}
WEIGHTS = {"selection": 1.25, "pa_convergence": 1.25, "hgt": 1.25, "mobility": 1.0, "novelty": 1.0}


def fam_id(rep):
    return "fam_" + re.sub(r"[^A-Za-z0-9]+", "_", rep).strip("_")


def load_rtab(p):
    df = pd.read_csv(p, sep="\t", index_col=0)
    return (df.astype(float) > 0).astype(int)


def accumulation(mat, n_perm=30, seed=0):
    rng = np.random.default_rng(seed); A = mat.values; G = A.shape[1]
    pan = np.zeros((n_perm, G)); core = np.zeros((n_perm, G))
    for p in range(n_perm):
        cum = np.zeros(A.shape[0], int)
        for i, g in enumerate(rng.permutation(G)):
            cum += A[:, g]; pan[p, i] = np.count_nonzero(cum); core[p, i] = np.count_nonzero(cum == i + 1)
    return pan.mean(0), core.mean(0)


def partitions(mat):
    n = mat.shape[1]; fr = mat.sum(1) / n
    return {"core": int((fr >= .99).sum()), "soft-core": int(((fr >= .95) & (fr < .99)).sum()),
            "shell": int(((fr >= .15) & (fr < .95)).sum()), "cloud": int((fr < .15).sum())}


def fuse(U, cols):
    w = np.array([WEIGHTS.get(c[2:], 1.0) for c in cols]); M = U[cols].to_numpy(float)
    pres = ~np.isnan(M); cov = pres.sum(1) / len(cols)
    logM = np.where(pres, np.log(np.clip(M, 1e-12, 1)), 0.0); den = (pres * w).sum(1)
    return np.exp(np.divide((logM * w).sum(1), den, out=np.zeros_like(den), where=den > 0)) * cov


def ef(y, s, phi):
    k = max(1, int(phi * len(y))); return y[np.argsort(-s)[:k]].mean() / y.mean() if y.mean() else 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("specs", nargs="+", help='"Label=rtab=scores=amr"')
    args = ap.parse_args()
    S = []
    for spec in args.specs:
        label, rtab, scores, amr = spec.split("=", 3)
        mat = load_rtab(rtab); df = pd.read_csv(scores, sep="\t")
        aset = {fam_id(x) for x in pd.read_csv(amr, sep="\t")["family_rep"]}
        y = df["family"].isin(aset).to_numpy().astype(int)
        S.append(dict(label=label, mat=mat, df=df, y=y, score=df["S_conj"].to_numpy(float),
                      amr=pd.read_csv(amr, sep="\t")))

    fig, ax = plt.subplots(2, 3, figsize=(17, 10))
    # A accumulation
    for i, s in enumerate(S):
        pan, core = accumulation(s["mat"]); x = np.arange(1, s["mat"].shape[1] + 1)
        ax[0, 0].plot(x, pan, color=SP_COLORS[i], lw=2, label=f"{s['label']} pan")
        ax[0, 0].plot(x, core, color=SP_COLORS[i], lw=2, ls="--")
    ax[0, 0].set_xlabel("genomes sampled"); ax[0, 0].set_ylabel("gene families")
    ax[0, 0].set_title("A  Pan/core accumulation", loc="left", fontsize=11)
    ax[0, 0].legend(frameon=False, fontsize=8)
    # B partitions (proportions, grouped)
    counts = [partitions(s["mat"]) for s in S]; tot = [sum(c.values()) for c in counts]
    x = np.arange(len(S)); bottom = np.zeros(len(S))
    for part in PART_ORDER:
        v = np.array([counts[i][part] / tot[i] for i in range(len(S))])
        ax[0, 1].bar(x, v, 0.6, bottom=bottom, color=PART_COLORS[part], label=part); bottom += v
    ax[0, 1].set_xticks(x); ax[0, 1].set_xticklabels([s["label"].split()[0] for s in S], fontsize=9)
    ax[0, 1].set_ylabel("fraction of families"); ax[0, 1].set_ylim(0, 1)
    ax[0, 1].set_title("B  Pangenome partitions", loc="left", fontsize=11); ax[0, 1].legend(frameon=False, fontsize=7)
    # C AMR per partition (grouped)
    w = 0.8 / len(S)
    for i, s in enumerate(S):
        by = s["amr"]["partition"].value_counts().reindex(PART_ORDER).fillna(0).astype(int)
        ax[0, 2].bar(np.arange(4) + i * w, by.values, w, color=SP_COLORS[i], label=s["label"].split()[0])
    ax[0, 2].set_xticks(np.arange(4) + w * (len(S) - 1) / 2); ax[0, 2].set_xticklabels(PART_ORDER, fontsize=8)
    ax[0, 2].set_ylabel("AMR families"); ax[0, 2].set_title("C  AMR by partition", loc="left", fontsize=11)
    ax[0, 2].legend(frameon=False, fontsize=8)
    # D ROC
    for i, s in enumerate(S):
        fpr, tpr, _ = roc_curve(s["y"], s["score"])
        ax[1, 0].plot(fpr, tpr, color=SP_COLORS[i], lw=2, label=f"{s['label'].split()[0]} (AUROC={roc_auc_score(s['y'],s['score']):.2f})")
    ax[1, 0].plot([0, 1], [0, 1], "k--", lw=1); ax[1, 0].set_xlabel("FPR"); ax[1, 0].set_ylabel("TPR")
    ax[1, 0].set_title("D  Recovery ROC", loc="left", fontsize=11); ax[1, 0].legend(frameon=False, fontsize=8)
    # E enrichment
    phis = [0.01, 0.05]; xx = np.arange(2)
    for i, s in enumerate(S):
        vals = [ef(s["y"], s["score"], p) for p in phis]
        b = ax[1, 1].bar(xx + i * w, vals, w, color=SP_COLORS[i], label=s["label"].split()[0])
        for bb, v in zip(b, vals):
            ax[1, 1].text(bb.get_x() + bb.get_width() / 2, v, f"{v:.1f}×", ha="center", va="bottom", fontsize=8)
    ax[1, 1].axhline(1, color="grey", ls="--", lw=1)
    ax[1, 1].set_xticks(xx + w * (len(S) - 1) / 2); ax[1, 1].set_xticklabels(["top 1%", "top 5%"])
    ax[1, 1].set_ylabel("enrichment (fold)"); ax[1, 1].set_title("E  Early enrichment", loc="left", fontsize=11)
    ax[1, 1].legend(frameon=False, fontsize=8)
    # F ablation (single views + ALL + drop selection)
    for i, s in enumerate(S):
        uc = [c for c in s["df"].columns if c.startswith("u_")]
        views = [c[2:] for c in uc]
        aupr = [average_precision_score(s["y"], fuse(s["df"], [c])) for c in uc]
        aupr.append(average_precision_score(s["y"], fuse(s["df"], uc)))
        aupr.append(average_precision_score(s["y"], fuse(s["df"], [c for c in uc if c != "u_selection"])))
        labels = views + ["ALL", "drop sel."]
        xb = np.arange(len(labels))
        ax[1, 2].plot(xb, aupr, "o-", color=SP_COLORS[i], lw=1.5, ms=4, label=s["label"].split()[0])
    ax[1, 2].set_xticks(np.arange(len(labels))); ax[1, 2].set_xticklabels(labels, fontsize=7, rotation=45, ha="right")
    ax[1, 2].set_ylabel("AUPRC"); ax[1, 2].set_title("F  View ablation", loc="left", fontsize=11)
    ax[1, 2].legend(frameon=False, fontsize=8)

    fig.suptitle("Label-free analysis of the E. coli and K. pneumoniae pangenomes",
                 fontsize=14, y=1.01)
    fig.tight_layout()
    fig.savefig(args.out + ".png", dpi=160, bbox_inches="tight")
    fig.savefig(args.out + ".pdf", bbox_inches="tight")
    print(f"[realdata-summary] wrote {args.out}.png/.pdf")


if __name__ == "__main__":
    main()
