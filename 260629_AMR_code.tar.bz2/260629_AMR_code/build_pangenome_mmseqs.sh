#!/usr/bin/env bash
# build_pangenome_mmseqs.sh ------------------------------------------------
# Build a per-species pangenome by clustering the Prokka proteomes with MMseqs2.
# This avoids both the Panaroo collapse_families bug and Roary's broken Perl
# dependencies -- and needs NO new install: mmseqs2 is already in amr-labelfree.
#
# Each protein header is prefixed with its genome id so cluster membership maps
# back to genomes; clusters become gene families and the genome presence/absence
# matrix is written in .Rtab form for viz_pangenome.py.
#
# Usage:
#   bash build_pangenome_mmseqs.sh <label> <faa_search_dir> <out_base>
# Example:
#   bash build_pangenome_mmseqs.sh "Escherichia coli" out/ecoli/prokka out/ecoli
#
# Knobs: THREADS (14), MIN_ID (0.90, mmseqs --min-seq-id), COV (0.80, -c), FORCE=1.
# Requires: mmseqs, python3 (amr-labelfree env).
# -------------------------------------------------------------------------
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
THREADS="${THREADS:-14}"
MIN_ID="${MIN_ID:-0.90}"
COV="${COV:-0.80}"

LABEL="${1:?need a species label}"
FAA_DIR="${2:?need a dir to search for *.faa}"
OUTB="${3:?need an output base dir}"
FAA_DIR="$(cd "$FAA_DIR" && pwd)"
mkdir -p "$OUTB"; OUTB="$(cd "$OUTB" && pwd)"
MM="$OUTB/mmseqs"; FIG="$OUTB/figures_mmseqs"
mkdir -p "$MM"
say(){ printf '\033[1;32m[%s]\033[0m %s\n' "$LABEL" "$*"; }

command -v mmseqs >/dev/null || { echo "mmseqs not found -- activate amr-labelfree"; exit 1; }

# ---- 1. concatenate proteomes with genome-prefixed headers (>GENOME__locus) -
COMBINED="$MM/combined.faa"
if [[ ! -s "$COMBINED" || "${FORCE:-0}" == 1 ]]; then
  : > "$COMBINED"
  n=0
  while IFS= read -r f; do
    acc="$(basename "$f" .faa)"
    # keep only the locus id (first token), prefix with genome id and "__"
    awk -v g="$acc" '/^>/{sub(/^>/,">"g"__"); print $1; next} {print}' "$f" >> "$COMBINED"
    n=$((n+1))
  done < <(find "$FAA_DIR" -name '*.faa' | sort)
  say "concatenated $n proteomes ($(grep -c '^>' "$COMBINED") proteins)"
else
  say "combined proteome present -> reusing (FORCE=1 to rebuild)"
fi
ngen=$(grep '^>' "$COMBINED" | sed 's/^>//; s/__.*//' | sort -u | wc -l | tr -d ' ')
[[ "${ngen:-0}" -ge 3 ]] || { echo "need >=3 genomes, found ${ngen:-0}"; exit 1; }

# ---- 2. MMseqs2 clustering -------------------------------------------------
CLUST_TSV="$MM/clust_cluster.tsv"
if [[ ! -s "$CLUST_TSV" || "${FORCE:-0}" == 1 ]]; then
  say "clustering with MMseqs2 (min-seq-id=$MIN_ID, cov=$COV, threads=$THREADS)..."
  rm -f "$MM"/clust_* 2>/dev/null
  mmseqs easy-cluster "$COMBINED" "$MM/clust" "$MM/tmp" \
      --min-seq-id "$MIN_ID" -c "$COV" --threads "$THREADS" >"$MM/mmseqs.log" 2>&1 \
    || { echo "mmseqs easy-cluster failed (see $MM/mmseqs.log)"; tail -15 "$MM/mmseqs.log"; exit 1; }
else
  say "MMseqs2 clusters present -> reusing (FORCE=1 to recompute)"
fi
[[ -s "$CLUST_TSV" ]] || { echo "no cluster TSV produced"; exit 1; }

# ---- 3. presence/absence matrix (.Rtab) -----------------------------------
RTAB="$OUTB/gene_presence_absence_mmseqs.Rtab"
say "building presence/absence matrix..."
python3 - "$CLUST_TSV" "$RTAB" <<'PY'
import sys, collections
tsv, out = sys.argv[1], sys.argv[2]
fam = collections.defaultdict(set)   # representative -> set(genomes)
genomes = set()
with open(tsv) as fh:
    for line in fh:
        parts = line.rstrip("\n").split("\t")
        if len(parts) != 2:
            continue
        rep, mem = parts
        g = mem.split("__", 1)[0]
        genomes.add(g); fam[rep].add(g)
genomes = sorted(genomes)
with open(out, "w") as o:
    o.write("Gene\t" + "\t".join(genomes) + "\n")
    for k, (rep, gs) in enumerate(fam.items()):
        o.write(f"group_{k}\t" + "\t".join("1" if g in gs else "0" for g in genomes) + "\n")
print(f"{len(fam)} families x {len(genomes)} genomes")
PY

# ---- 4. figures -----------------------------------------------------------
say "rendering figures..."
python3 "$HERE/viz_pangenome.py" \
    --rtab "$RTAB" --outdir "$FIG" \
    --label "$LABEL (n=$ngen, MMseqs2)" \
    --core-thr 0.99 --softcore-thr 0.95 --shell-thr 0.15

say "DONE -> figures in $FIG ; matrix: $RTAB"
