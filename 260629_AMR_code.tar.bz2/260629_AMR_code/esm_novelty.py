#!/usr/bin/env python3
"""esm_novelty.py -- protein-language-model novelty view (View 1).

Embeds each gene-family representative with ESM-2 (mean-pooled final-layer
per-residue representations), reduces with PCA, and scores novelty as the
rank-normalized mean of three unsupervised estimators:
  * mean distance to the k nearest neighbours (k=15),
  * Isolation Forest anomaly score,
  * squared distance to the centroid in the whitened embedding space.
High score = unusual relative to the analysed pangenome.

Embeddings are cached to <out_prefix>.emb.npy / .ids.txt so re-runs skip the
(slow) ESM step. On CPU/Rosetta use the smaller model (default
esm2_t30_150M_UR50D); esm2_t33_650M_UR50D is better if a GPU is available.

Output (--out): family  novelty_score

Requires: fair-esm, torch (embedding step); numpy, scikit-learn (scoring).
"""
import argparse, os, re, sys
# Cap threads BEFORE torch/numpy import -- multi-threaded BLAS under Rosetta is a
# common segfault trigger; harmless natively.
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("VECLIB_MAXIMUM_THREADS", "1")
import numpy as np


def fam_id(rep):
    return "fam_" + re.sub(r"[^A-Za-z0-9]+", "_", rep).strip("_")


def read_fasta(path, max_len):
    ids, seqs = [], []
    name, buf = None, []
    with open(path) as fh:
        for line in fh:
            if line.startswith(">"):
                if name is not None:
                    ids.append(name); seqs.append("".join(buf)[:max_len])
                name = line[1:].split()[0]; buf = []
            else:
                buf.append(line.strip())
    if name is not None:
        ids.append(name); seqs.append("".join(buf)[:max_len])
    return ids, seqs


def embed(ids, seqs, model_name, device, batch_tokens, max_len):
    import torch, esm
    torch.set_num_threads(1)
    model, alphabet = getattr(esm.pretrained, model_name)()
    layer = int(re.search(r"_t(\d+)_", model_name).group(1))
    model = model.to(device).eval()
    bc = alphabet.get_batch_converter()
    order = np.argsort([len(s) for s in seqs])          # batch similar lengths
    emb = np.zeros((len(seqs), model.embed_dim), dtype=np.float32)
    i = 0
    while i < len(order):
        batch, tok = [], 0
        while i < len(order):
            j = order[i]; L = len(seqs[j]) + 2
            if batch and tok + L > batch_tokens:
                break
            batch.append((j, seqs[j])); tok += L; i += 1
        data = [(str(j), s) for j, s in batch]
        _, _, toks = bc(data)
        toks = toks.to(device)
        with torch.no_grad():
            out = model(toks, repr_layers=[layer])["representations"][layer]
        for bi, (j, s) in enumerate(batch):
            v = out[bi, 1:len(s) + 1].mean(0)            # mean-pool, drop BOS/EOS
            emb[j] = v.cpu().numpy()
        sys.stderr.write(f"\r[esm] embedded {i}/{len(order)}"); sys.stderr.flush()
    sys.stderr.write("\n")
    return emb


def novelty_scores(emb, k=15, pca=50, seed=0):
    from sklearn.preprocessing import StandardScaler
    from sklearn.decomposition import PCA
    from sklearn.neighbors import NearestNeighbors
    from sklearn.ensemble import IsolationForest
    X = StandardScaler().fit_transform(emb)
    nc = min(pca, X.shape[1], max(2, X.shape[0] - 1))
    Z = PCA(n_components=nc, whiten=True, random_state=seed).fit_transform(X)
    # 1) mean distance to k nearest neighbours
    kk = min(k + 1, len(Z))
    nn = NearestNeighbors(n_neighbors=kk).fit(Z)
    d, _ = nn.kneighbors(Z)
    knn_d = d[:, 1:].mean(1)
    # 2) Isolation Forest anomaly (higher = more anomalous)
    iso = IsolationForest(n_estimators=200, random_state=seed).fit(Z)
    iso_s = -iso.score_samples(Z)
    # 3) squared distance to centroid in whitened space
    cen = ((Z - Z.mean(0)) ** 2).sum(1)

    def rz(x):
        r = np.asarray(x, float).argsort().argsort().astype(float)
        return (r - r.mean()) / (r.std() if r.std() > 0 else 1.0)

    fused = (rz(knn_d) + rz(iso_s) + rz(cen)) / 3.0
    return fused


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--reps", required=True, help="clust_rep_seq.fasta (>GENOME__locus)")
    ap.add_argument("--out", required=True)
    ap.add_argument("--model", default="esm2_t30_150M_UR50D")
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--batch-tokens", type=int, default=8000)
    ap.add_argument("--max-len", type=int, default=1022)
    ap.add_argument("--k", type=int, default=15)
    ap.add_argument("--emb-cache", default=None,
                    help="prefix for embedding cache (default: <out without .tsv>)")
    args = ap.parse_args()

    cache = args.emb_cache or re.sub(r"\.tsv$", "", args.out)
    ids, seqs = read_fasta(args.reps, args.max_len)
    npy, idf = cache + ".emb.npy", cache + ".ids.txt"

    if os.path.exists(npy) and os.path.exists(idf):
        emb = np.load(npy)
        cached_ids = open(idf).read().split()
        if cached_ids == ids and emb.shape[0] == len(ids):
            sys.stderr.write(f"[esm] using cached embeddings {npy}\n")
        else:
            emb = None
    else:
        emb = None
    if emb is None:
        sys.stderr.write(f"[esm] embedding {len(ids)} representatives with {args.model} on {args.device} ...\n")
        emb = embed(ids, seqs, args.model, args.device, args.batch_tokens, args.max_len)
        np.save(npy, emb)
        open(idf, "w").write("\n".join(ids))

    sys.stderr.write("[esm] scoring novelty ...\n")
    score = novelty_scores(emb, k=args.k)
    with open(args.out, "w") as o:
        o.write("family\tnovelty_score\n")
        for rep, s in zip(ids, score):
            o.write(f"{fam_id(rep)}\t{s:.5f}\n")
    print(f"[esm] wrote novelty for {len(ids)} families -> {args.out}")


if __name__ == "__main__":
    main()
