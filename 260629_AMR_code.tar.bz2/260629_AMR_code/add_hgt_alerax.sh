#!/usr/bin/env bash
# add_hgt_alerax.sh --------------------------------------------------------
# HGT view via AleRax for BOTH species (GeneRax alternative). Writes the same
# out/<sp>/hgt.tsv the fusion engine reads, so add_fusion.sh picks it up.
#
# One-time install (if needed): conda install -c bioconda alerax
# Run:
#   conda activate amr-labelfree
#   NPROCS=14 bash add_hgt_alerax.sh
#   bash add_fusion.sh          # folds HGT into the conjunction
#
# Knobs: NPROCS, SAMPLES, NO_TL, MAX_FAMILIES (see run_hgt_alerax.sh).
# -------------------------------------------------------------------------
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
say(){ printf '\033[1;36m[add-hgt-alerax]\033[0m %s\n' "$*"; }
command -v alerax >/dev/null || { say "alerax not found -- conda install -c bioconda alerax"; exit 1; }

for sp in ecoli kpneumoniae; do
  label=$([ "$sp" = ecoli ] && echo "Escherichia coli" || echo "Klebsiella pneumoniae")
  [[ -d "$HERE/out/$sp/families/genetrees" ]] || { say "$sp: no gene trees -- run add_family_trees.sh; skipping"; continue; }
  say "=== $sp ==="
  bash "$HERE/run_hgt_alerax.sh" "$label" "$HERE/out/$sp"
done
echo
for sp in ecoli kpneumoniae; do
  [[ -s "$HERE/out/$sp/hgt.tsv" ]] && say "$sp: HGT -> out/$sp/hgt.tsv ($(($(wc -l < "$HERE/out/$sp/hgt.tsv")-1)) families)"
done
say "next: bash add_fusion.sh"
