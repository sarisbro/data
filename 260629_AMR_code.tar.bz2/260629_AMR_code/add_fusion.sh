#!/usr/bin/env bash
# add_fusion.sh ------------------------------------------------------------
# Compute the remaining light-weight views, fuse all available views
# conjunctively, and run the retrospective evaluation, for BOTH species.
#
#   conda activate amr-labelfree
#   bash add_fusion.sh
#
# Steps per species (writes into out/<sp>/):
#   mobility.tsv        compositional mobility (GC + codon-usage deviation)
#   pa_convergence.tsv  presence/absence homoplasy on the species tree
#   candidate_scores.tsv  conjunctive fusion of ALL view tables present
#                         (selection.tsv now; novelty.tsv / hgt.tsv auto-included
#                          once those heavy views are run)
#   evaluation/         metrics.tsv, ablation.tsv, lofo.tsv (AMRFinderPlus labels)
#
# Re-run any time; fuse_scores.py picks up whatever views exist.
# Requires: python3 (numpy, pandas, scikit-learn, dendropy) in amr-labelfree.
# -------------------------------------------------------------------------
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
say(){ printf '\033[1;36m[add-fusion]\033[0m %s\n' "$*"; }

for sp in ecoli kpneumoniae; do
  o="$HERE/out/$sp"
  [[ -s "$o/mmseqs/clust_cluster.tsv" ]] || { say "$sp: no clusters; run rerun_mmseqs.sh first; skipping"; continue; }
  say "=== $sp: mobility view ==="
  python3 "$HERE/mobility_features.py" --clusters "$o/mmseqs/clust_cluster.tsv" \
      --nuc "$o/mmseqs/combined.ffn" --out "$o/mobility.tsv"
  say "=== $sp: presence/absence convergence view ==="
  python3 "$HERE/pa_convergence.py" --clusters "$o/mmseqs/clust_cluster.tsv" \
      --tree "$o/core/core.treefile" --out "$o/pa_convergence.tsv"
  say "=== $sp: conjunctive fusion ==="
  python3 "$HERE/fuse_scores.py" --dir "$o" --out "$o/candidate_scores.tsv"
  if [[ -s "$o/amr/amr_pangenome_amr_families.tsv" ]]; then
    say "=== $sp: retrospective evaluation ==="
    python3 "$HERE/evaluate.py" --scores "$o/candidate_scores.tsv" \
        --amr "$o/amr/amr_pangenome_amr_families.tsv" --out-dir "$o/evaluation"
  else
    say "$sp: no AMR labels yet (run add_amr.sh) -> skipping evaluation"
  fi
done

echo
for sp in ecoli kpneumoniae; do
  [[ -s "$HERE/out/$sp/evaluation/metrics.tsv" ]] && \
    say "$sp: $(grep -E '^AUPRC|^AUROC|^BEDROC' "$HERE/out/$sp/evaluation/metrics.tsv" | tr '\n' ' ')"
done
