#!/usr/bin/env python3
"""plot_tree_matrix.py -- the signature pangenome figure: the core-genome tree
drawn on the left, aligned row-for-row with the gene presence/absence matrix on
the right (genomes ordered by the tree, gene families ordered by frequency).

Usage:
  plot_tree_matrix.py --rtab gene_presence_absence_mmseqs.Rtab \
                      --tree core/core.treefile --out tree_matrix --label "E. coli (n=150)"
Writes <out>.png and <out>.pdf.
Depends on numpy, pandas, matplotlib, dendropy.
"""
import argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import dendropy


def load_matrix(path):
    df = pd.read_csv(path, sep="\t", index_col=0)
    mat = (df.astype(float) > 0).astype(int)
    return mat.loc[mat.sum(axis=1) > 0]


def layout_tree(tree_path, ladderize=True):
    """Return (segments, leaf_order, max_x). segments: list of ((x0,y0),(x1,y1))."""
    t = dendropy.Tree.get(path=tree_path, schema="newick", preserve_underscores=True)
    if ladderize:
        t.ladderize(ascending=False)
    leaves = [lf for lf in t.leaf_node_iter()]
    for i, lf in enumerate(leaves):
        lf._y = float(i)
    # x = root-to-node distance
    for node in t.preorder_node_iter():
        el = node.edge.length or 0.0
        node._x = (node.parent_node._x + el) if node.parent_node else 0.0
    for node in t.postorder_node_iter():
        if not node.is_leaf():
            ys = [c._y for c in node.child_nodes()]
            node._y = sum(ys) / len(ys)
    segs = []
    for node in t.preorder_node_iter():
        p = node.parent_node
        if p is not None:
            segs.append(((p._x, node._y), (node._x, node._y)))      # horizontal branch
    for node in t.preorder_node_iter():
        ch = node.child_nodes()
        if ch:
            ys = [c._y for c in ch]
            segs.append(((node._x, min(ys)), (node._x, max(ys))))   # vertical connector
    max_x = max(n._x for n in t.leaf_node_iter())
    return segs, [lf.taxon.label for lf in leaves], max_x


def draw_tree_matrix(fig, mat, tree_path, label, core_thr=0.99, tip_labels=False):
    """Draw the core tree + presence/absence matrix onto an existing figure."""
    n = mat.shape[1]
    segs, leaf_order, max_x = layout_tree(tree_path)
    cols = set(mat.columns)
    order = [g for g in leaf_order if g in cols] + [g for g in mat.columns if g not in set(leaf_order)]
    fam_order = mat.sum(axis=1).sort_values(ascending=False).index
    M = mat.loc[fam_order, order].values.T  # genomes x families

    gs = fig.add_gridspec(1, 2, width_ratios=[1, 4.5], wspace=0.02)
    axt = fig.add_subplot(gs[0]); axm = fig.add_subplot(gs[1], sharey=axt)

    for (x0, y0), (x1, y1) in segs:
        axt.plot([x0, x1], [y0, y1], color="#222222", lw=0.5)
    axt.set_xlim(-0.02 * max_x, max_x * 1.05)
    axt.set_ylim(n - 0.5, -0.5)
    axt.set_title(f"{label}\ncore-genome tree", fontsize=10, loc="left")
    axt.spines[["top", "right", "left"]].set_visible(False)
    axt.set_yticks([])
    axt.set_xlabel("subs/site", fontsize=8)
    axt.tick_params(axis="x", labelsize=7)

    axm.imshow(M, aspect="auto", interpolation="nearest",
               cmap=matplotlib.colors.ListedColormap(["#f7f7f7", "#2166ac"]),
               extent=(0, M.shape[1], n - 0.5, -0.5))
    axm.set_xlabel(f"Gene families (n={M.shape[1]}, ordered by frequency)")
    axm.set_title("presence / absence", fontsize=10, loc="left")
    ncore = int((mat.sum(axis=1) >= core_thr * n).sum())
    axm.text(0.99, 1.01, f"{n} genomes · {mat.shape[0]} families · {ncore} core",
             transform=axm.transAxes, ha="right", va="bottom", fontsize=8)
    if tip_labels:
        fs = max(2.0, min(6.0, 600.0 / n))
        axm.set_yticks(np.arange(n))
        axm.set_yticklabels(order, fontsize=fs)
        axm.yaxis.set_tick_params(left=False, right=True, labelleft=False, labelright=True, length=1)
        for lab in axm.get_yticklabels():
            lab.set_va("center")
    else:
        axm.set_yticks([]); plt.setp(axm.get_yticklabels(), visible=False)
    return n, mat.shape[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rtab", required=True)
    ap.add_argument("--tree", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--label", default="pangenome")
    ap.add_argument("--core-thr", type=float, default=0.99)
    ap.add_argument("--tip-labels", action="store_true",
                    help="draw genome names on the right (readable when zoomed)")
    args = ap.parse_args()

    mat = load_matrix(args.rtab)
    n = mat.shape[1]
    height = max(9, n * 0.09) if args.tip_labels else 9
    fig = plt.figure(figsize=(15, height))
    draw_tree_matrix(fig, mat, args.tree, args.label, args.core_thr, args.tip_labels)
    fig.savefig(args.out + ".png", dpi=160, bbox_inches="tight")
    fig.savefig(args.out + ".pdf", bbox_inches="tight")
    print(f"[tree-matrix] wrote {args.out}.png/.pdf  ({n} genomes, {mat.shape[0]} families)")


if __name__ == "__main__":
    main()
