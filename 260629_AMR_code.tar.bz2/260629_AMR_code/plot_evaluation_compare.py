#!/usr/bin/env python3
"""plot_evaluation_compare.py -- combined two-species retrospective-recovery figure.

Overlays the precision-recall and ROC curves for several species and shows their
early-enrichment factors side by side.

Usage:
  plot_evaluation_compare.py --out cross_eval \
      "Escherichia coli=out/ecoli/candidate_scores.tsv=out/ecoli/amr/amr_pangenome_amr_families.tsv" \
      "Klebsiella pneumoniae=out/kpneumoniae/candidate_scores.tsv=out/kpneumoniae/amr/amr_pangenome_amr_families.tsv"
"""
import argparse, re
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import (average_precision_score, roc_auc_score,
                             precision_recall_curve, roc_curve)

COLORS = ["#1b9e77", "#7570b3", "#d95f02", "#e7298a"]


def fam_id(rep):
    return "fam_" + re.sub(r"[^A-Za-z0-9]+", "_", rep).strip("_")


def ef(y, s, phi):
    k = max(1, int(phi * len(y)))
    idx = np.argsort(-s)[:k]
    return (y[idx].mean()) / (y.mean()) if y.mean() > 0 else 0.0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("specs", nargs="+", help='"Label=scores.tsv=amr.tsv"')
    args = ap.parse_args()

    data = []
    for s in args.specs:
        label, scores, amr = s.split("=", 2)
        df = pd.read_csv(scores, sep="\t")
        aset = {fam_id(x) for x in pd.read_csv(amr, sep="\t")["family_rep"]}
        y = df["family"].isin(aset).to_numpy().astype(int)
        S = df["S_conj"].to_numpy(float)
        data.append((label, y, S))

    fig, ax = plt.subplots(1, 3, figsize=(16, 5))
    # A: ROC
    for i, (label, y, S) in enumerate(data):
        fpr, tpr, _ = roc_curve(y, S)
        ax[0].plot(fpr, tpr, color=COLORS[i], lw=2,
                   label=f"{label} (AUROC={roc_auc_score(y,S):.2f})")
    ax[0].plot([0, 1], [0, 1], "k--", lw=1)
    ax[0].set_xlabel("false positive rate"); ax[0].set_ylabel("true positive rate")
    ax[0].set_title("A  ROC", loc="left", fontsize=11); ax[0].legend(frameon=False, fontsize=9)
    # B: PR (log y to show enrichment over tiny baselines)
    for i, (label, y, S) in enumerate(data):
        pr, rc, _ = precision_recall_curve(y, S)
        ax[1].plot(rc, pr, color=COLORS[i], lw=2,
                   label=f"{label} (AUPRC={average_precision_score(y,S):.4f})")
        ax[1].axhline(y.mean(), color=COLORS[i], ls=":", lw=1)
    ax[1].set_yscale("log"); ax[1].set_xlabel("recall"); ax[1].set_ylabel("precision (log)")
    ax[1].set_title("B  Precision-recall (dotted = baseline)", loc="left", fontsize=11)
    ax[1].legend(frameon=False, fontsize=9)
    # C: enrichment factors
    phis = [0.01, 0.05]; x = np.arange(len(phis)); w = 0.8 / len(data)
    for i, (label, y, S) in enumerate(data):
        vals = [ef(y, S, p) for p in phis]
        bars = ax[2].bar(x + i * w, vals, w, color=COLORS[i], label=label)
        for b, v in zip(bars, vals):
            ax[2].text(b.get_x() + b.get_width() / 2, v, f"{v:.1f}×", ha="center", va="bottom", fontsize=8)
    ax[2].axhline(1.0, color="grey", ls="--", lw=1)
    ax[2].set_xticks(x + w * (len(data) - 1) / 2); ax[2].set_xticklabels(["top 1%", "top 5%"])
    ax[2].set_ylabel("enrichment factor (fold over background)")
    ax[2].set_title("C  Early enrichment", loc="left", fontsize=11); ax[2].legend(frameon=False, fontsize=9)

    fig.suptitle("Retrospective recovery of AMR determinants: two-species comparison",
                 fontsize=13, y=1.02)
    fig.tight_layout()
    fig.savefig(args.out + ".png", dpi=160, bbox_inches="tight")
    fig.savefig(args.out + ".pdf", bbox_inches="tight")
    print(f"[eval-compare] wrote {args.out}.png/.pdf for {len(data)} species")


if __name__ == "__main__":
    main()
