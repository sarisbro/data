#!/usr/bin/env bash
# build_core_tree.sh -------------------------------------------------------
# From an existing MMseqs2 pangenome, build a core-genome tree and re-render the
# presence/absence heatmap ordered by that tree.
#   single-copy core (from clusters) -> MAFFT per family -> concatenated core
#   alignment -> IQ-TREE -> viz_pangenome.py --tree
#
# Reuses out/<sp>/mmseqs/clust_cluster.tsv and the Prokka nucleotide CDS (.ffn).
#
# Usage:
#   bash build_core_tree.sh <label> <prokka_dir> <out_base>
# Example:
#   bash build_core_tree.sh "Escherichia coli" out/ecoli/prokka out/ecoli
#
# Knobs: THREADS (14), CORE_FRAC (0.99), MAX_GENES (0 = all core), FORCE=1.
# Requires: mafft, iqtree2, python3 (amr-labelfree env).
# -------------------------------------------------------------------------
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
THREADS="${THREADS:-14}"
CORE_FRAC="${CORE_FRAC:-0.99}"
MAX_GENES="${MAX_GENES:-0}"

LABEL="${1:?need a species label}"
PROKKA_DIR="${2:?need the prokka dir (with per-genome .ffn)}"
OUTB="${3:?need the species out base (containing mmseqs/ and the .Rtab)}"
PROKKA_DIR="$(cd "$PROKKA_DIR" && pwd)"
mkdir -p "$OUTB"; OUTB="$(cd "$OUTB" && pwd)"
MM="$OUTB/mmseqs"; CORE="$OUTB/core"; FIG="$OUTB/figures_mmseqs"
mkdir -p "$CORE"
say(){ printf '\033[1;34m[%s]\033[0m %s\n' "$LABEL" "$*"; }

command -v mafft   >/dev/null || { echo "mafft not found -- activate amr-labelfree"; exit 1; }
CLUST="$MM/clust_cluster.tsv"
RTAB="$OUTB/gene_presence_absence_mmseqs.Rtab"
[[ -s "$CLUST" ]] || { echo "missing $CLUST -- run the MMseqs2 step first"; exit 1; }
[[ -s "$RTAB"  ]] || { echo "missing $RTAB -- run the MMseqs2 step first"; exit 1; }

# ---- 1. combined nucleotide CDS with genome-prefixed headers (>GENOME__locus) -
FFN="$MM/combined.ffn"
nffn=$(find "$PROKKA_DIR" -name '*.ffn' 2>/dev/null | wc -l | tr -d ' ')
[[ "${nffn:-0}" -ge 3 ]] || { echo "need >=3 .ffn under $PROKKA_DIR (found ${nffn:-0})"; exit 1; }
if [[ ! -s "$FFN" || "${FORCE:-0}" == 1 ]]; then
  say "building combined nucleotide CDS from $nffn genomes..."
  : > "$FFN"
  while IFS= read -r f; do
    acc="$(basename "$f" .ffn)"
    awk -v g="$acc" '/^>/{sub(/^>/,">"g"__"); print $1; next} {print}' "$f" >> "$FFN"
  done < <(find "$PROKKA_DIR" -name '*.ffn' | sort)
else
  say "combined.ffn present -> reusing (FORCE=1 to rebuild)"
fi

# ---- 2. single-copy core alignment ----------------------------------------
CORE_ALN="$CORE/core_gene_alignment.aln"
if [[ ! -s "$CORE_ALN" || "${FORCE:-0}" == 1 ]]; then
  say "selecting single-copy core (>= ${CORE_FRAC}) and aligning with MAFFT..."
  python3 "$HERE/core_alignment_from_clusters.py" \
      --clusters "$CLUST" --seqs "$FFN" --out "$CORE_ALN" \
      --core-frac "$CORE_FRAC" --threads "$THREADS" --max-genes "$MAX_GENES" \
      --mafft mafft || { echo "core alignment failed"; exit 1; }
else
  say "core alignment present -> reusing (FORCE=1 to rebuild)"
fi
[[ -s "$CORE_ALN" ]] || { echo "no core alignment produced"; exit 1; }

# ---- 3. core-genome tree (IQ-TREE) ----------------------------------------
TREEFILE=""
if command -v iqtree2 >/dev/null; then
  if [[ ! -s "$CORE/core.treefile" || "${FORCE:-0}" == 1 ]]; then
    say "building core-genome tree with IQ-TREE (GTR+G, -fast)..."
    iqtree2 -s "$CORE_ALN" -m GTR+G -T "$THREADS" -fast --prefix "$CORE/core" -redo \
        >"$CORE/iqtree.log" 2>&1 || say "IQ-TREE failed (see $CORE/iqtree.log)"
  fi
  [[ -s "$CORE/core.treefile" ]] && TREEFILE="$CORE/core.treefile"
else
  echo "iqtree2 not found -- cannot build tree"; exit 1
fi
[[ -n "$TREEFILE" ]] || { echo "no tree produced; see $CORE/iqtree.log"; exit 1; }

# ---- 4. re-render figures, heatmap ordered by the tree ---------------------
ngen=$(head -1 "$RTAB" | tr '\t' '\n' | tail -n +2 | grep -c .)
say "rendering tree-ordered figures..."
python3 "$HERE/viz_pangenome.py" \
    --rtab "$RTAB" --tree "$TREEFILE" --outdir "$FIG" \
    --label "$LABEL (n=$ngen, MMseqs2, tree-ordered)" \
    --core-thr 0.99 --softcore-thr 0.95 --shell-thr 0.15

say "DONE -> tree: $TREEFILE ; figures (tree-ordered): $FIG"
