#!/usr/bin/env python3
"""viz_pangenome.py -- standard pangenome visualizations from a Panaroo/Roary
gene presence/absence matrix.

Produces, for one species:
  1. Gene frequency spectrum (the U-shaped plot), colored by partition.
  2. Pan- and core-genome accumulation (rarefaction) curves over random genome
     orderings, with a Heaps'-law alpha estimate for the pan-genome.
  3. Core / soft-core / shell / cloud partition bar chart.
  4. Presence/absence heatmap: genomes ordered by the core-genome tree (if given),
     gene families ordered by frequency -> the classic block structure.
  5. summary_statistics.tsv with partition counts and openness metrics.

All panels are written as individual PNGs and combined into a single PDF.

Inputs:
  --rtab    Panaroo gene_presence_absence.Rtab (families x genomes, 0/1; tab-sep,
            first column 'Gene').  Roary-style .csv is also accepted.
  --tree    (optional) core-genome tree in Newick (e.g. IQ-TREE .treefile) used to
            order genomes in the heatmap.
  --outdir  output directory.
  --label   plot title prefix, e.g. "Escherichia coli (n=150)".

Depends only on numpy, pandas, matplotlib (+ dendropy if --tree is used) -- all
present in the amr-labelfree environment.
"""
import argparse
import os
import sys

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

# partition palette (color-blind friendly)
PART_COLORS = {
    "core": "#2166ac",       # present in >= core_thr
    "soft-core": "#67a9cf",  # softcore_thr .. core_thr
    "shell": "#fdb863",      # shell_thr .. softcore_thr
    "cloud": "#d6604d",      # < shell_thr
}
PART_ORDER = ["core", "soft-core", "shell", "cloud"]


def load_matrix(path):
    """Return a binary DataFrame (families x genomes) from an Rtab or roary csv."""
    if path.lower().endswith((".csv",)):
        df = pd.read_csv(path, dtype=str).fillna("")
        gene_col = "Gene" if "Gene" in df.columns else df.columns[0]
        meta = {"gene", "non-unique gene name", "annotation", "no. isolates",
                "no. sequences", "avg sequences per isolate", "genome fragment",
                "order within fragment", "accessory fragment",
                "accessory order with fragment", "qc", "min group size nuc",
                "max group size nuc", "avg group size nuc"}
        genome_cols = [c for c in df.columns if c.lower() not in meta and c != gene_col]
        mat = (df[genome_cols] != "").astype(int)
        mat.index = df[gene_col].values
    else:  # Rtab: tab-separated, first column Gene, rest 0/1
        df = pd.read_csv(path, sep="\t", index_col=0)
        mat = (df.astype(float) > 0).astype(int)
    mat = mat.loc[mat.sum(axis=1) > 0]  # drop empty families
    return mat


def partition(freq_frac, core_thr, softcore_thr, shell_thr):
    if freq_frac >= core_thr:
        return "core"
    if freq_frac >= softcore_thr:
        return "soft-core"
    if freq_frac >= shell_thr:
        return "shell"
    return "cloud"


def tree_leaf_order(tree_path, genome_names):
    try:
        import dendropy
    except Exception:
        sys.stderr.write("[viz] dendropy not available; skipping tree ordering.\n")
        return None
    try:
        t = dendropy.Tree.get(path=tree_path, schema="newick",
                              preserve_underscores=True)
    except Exception as e:
        sys.stderr.write(f"[viz] could not read tree ({e}); skipping tree order.\n")
        return None
    order = [lf.taxon.label for lf in t.leaf_node_iter() if lf.taxon]
    name_set = set(genome_names)
    # match leaves to matrix columns (tolerate minor suffix/prefix differences)
    matched, used = [], set()
    for lab in order:
        if lab in name_set:
            matched.append(lab); used.add(lab)
        else:
            cands = [g for g in genome_names if g.startswith(lab) or lab.startswith(g)]
            if len(cands) == 1 and cands[0] not in used:
                matched.append(cands[0]); used.add(cands[0])
    matched += [g for g in genome_names if g not in used]  # append unmatched
    return matched


# ---------------------------------------------------------------- plots
def plot_frequency_spectrum(mat, parts, n, label, ax):
    counts = mat.sum(axis=1).values  # genomes per family
    hist = np.bincount(counts, minlength=n + 1)[1:]  # k=1..n
    x = np.arange(1, n + 1)
    # color each bar by the partition that k/n falls into
    fracs = x / n
    colors = [PART_COLORS[partition(f, *parts)] for f in fracs]
    ax.bar(x, hist, color=colors, width=1.0, edgecolor="none")
    ax.set_xlabel("Number of genomes a gene family is present in")
    ax.set_ylabel("Number of gene families")
    ax.set_title(f"{label}\nGene frequency spectrum")
    handles = [plt.Rectangle((0, 0), 1, 1, color=PART_COLORS[p]) for p in PART_ORDER]
    ax.legend(handles, PART_ORDER, frameon=False, fontsize=8)


def plot_accumulation(mat, label, ax, n_perm=50, seed=0):
    rng = np.random.default_rng(seed)
    A = mat.values  # families x genomes (0/1)
    G = A.shape[1]
    pan = np.zeros((n_perm, G))
    core = np.zeros((n_perm, G))
    for p in range(n_perm):
        order = rng.permutation(G)
        cum_pres = np.zeros(A.shape[0], dtype=int)
        cum_all = np.zeros(A.shape[0], dtype=int)
        for i, g in enumerate(order):
            col = A[:, g]
            cum_pres += col
            cum_all += col
            pan[p, i] = np.count_nonzero(cum_pres)      # union
            core[p, i] = np.count_nonzero(cum_all == (i + 1))  # in all so far
    xs = np.arange(1, G + 1)
    for arr, c, name in [(pan, "#2166ac", "Pan-genome"),
                         (core, "#d6604d", "Core genome")]:
        m, sd = arr.mean(0), arr.std(0)
        ax.plot(xs, m, color=c, label=name)
        ax.fill_between(xs, m - sd, m + sd, color=c, alpha=0.2)
    # Heaps' law fit on number of *new* genes: n_new ~ k * N^-alpha
    pan_mean = pan.mean(0)
    new_genes = np.diff(pan_mean)
    alpha = np.nan
    if np.all(new_genes > 0) and len(new_genes) > 3:
        xfit = np.log(xs[1:]); yfit = np.log(new_genes)
        alpha = -np.polyfit(xfit, yfit, 1)[0]
        openness = "open" if alpha < 1 else "closed"
        ax.text(0.97, 0.5, f"Heaps' $\\alpha$ = {alpha:.2f} ({openness})",
                transform=ax.transAxes, ha="right", fontsize=9)
    ax.set_xlabel("Number of genomes sampled")
    ax.set_ylabel("Number of gene families")
    ax.set_title(f"{label}\nPan/core accumulation ({n_perm} permutations)")
    ax.legend(frameon=False, fontsize=8)
    return alpha


def plot_partition_bar(parts_series, label, ax):
    counts = parts_series.value_counts().reindex(PART_ORDER).fillna(0).astype(int)
    bars = ax.bar(PART_ORDER, counts.values,
                  color=[PART_COLORS[p] for p in PART_ORDER])
    for b, v in zip(bars, counts.values):
        ax.text(b.get_x() + b.get_width() / 2, v, str(v),
                ha="center", va="bottom", fontsize=9)
    ax.set_ylabel("Number of gene families")
    ax.set_title(f"{label}\nPangenome partitions")
    return counts


def plot_heatmap(mat, genome_order, label, ax):
    m = mat[genome_order] if genome_order else mat
    # order families by frequency descending (block structure)
    fam_order = m.sum(axis=1).sort_values(ascending=False).index
    M = m.loc[fam_order].values.T  # genomes x families
    ax.imshow(M, aspect="auto", interpolation="nearest",
              cmap=matplotlib.colors.ListedColormap(["#f7f7f7", "#2166ac"]))
    ax.set_xlabel(f"Gene families (n={M.shape[1]}, ordered by frequency)")
    ax.set_ylabel(f"Genomes (n={M.shape[0]})")
    ttl = "ordered by core-genome tree" if genome_order else "tree not provided"
    ax.set_title(f"{label}\nPresence/absence matrix ({ttl})")
    ax.set_yticks([])


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--rtab", required=True)
    ap.add_argument("--tree", default=None)
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--label", default="pangenome")
    ap.add_argument("--core-thr", type=float, default=0.99)
    ap.add_argument("--softcore-thr", type=float, default=0.95)
    ap.add_argument("--shell-thr", type=float, default=0.15)
    ap.add_argument("--perms", type=int, default=50)
    args = ap.parse_args()

    os.makedirs(args.outdir, exist_ok=True)
    mat = load_matrix(args.rtab)
    n = mat.shape[1]
    parts = (args.core_thr, args.softcore_thr, args.shell_thr)
    fracs = mat.sum(axis=1) / n
    parts_series = fracs.apply(lambda f: partition(f, *parts))

    genome_order = tree_leaf_order(args.tree, list(mat.columns)) if args.tree else None

    # individual panels
    panels = {
        "frequency_spectrum": lambda ax: plot_frequency_spectrum(mat, parts, n, args.label, ax),
        "accumulation_curves": lambda ax: plot_accumulation(mat, args.label, ax, args.perms),
        "partition_bar": lambda ax: plot_partition_bar(parts_series, args.label, ax),
        "presence_absence_heatmap": lambda ax: plot_heatmap(mat, genome_order, args.label, ax),
    }
    alpha = np.nan
    counts = None
    for name, fn in panels.items():
        fig, ax = plt.subplots(figsize=(8, 6))
        ret = fn(ax)
        if name == "accumulation_curves":
            alpha = ret
        if name == "partition_bar":
            counts = ret
        fig.tight_layout()
        fig.savefig(os.path.join(args.outdir, f"{name}.png"), dpi=150)
        plt.close(fig)

    # combined multi-panel figure + PDF
    pdf_path = os.path.join(args.outdir, "pangenome_figures.pdf")
    with PdfPages(pdf_path) as pdf:
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        plot_frequency_spectrum(mat, parts, n, args.label, axes[0, 0])
        plot_accumulation(mat, args.label, axes[0, 1], args.perms)
        plot_partition_bar(parts_series, args.label, axes[1, 0])
        plot_heatmap(mat, genome_order, args.label, axes[1, 1])
        fig.tight_layout()
        pdf.savefig(fig)
        plt.close(fig)

    # summary stats
    if counts is None:
        counts = parts_series.value_counts().reindex(PART_ORDER).fillna(0).astype(int)
    total = int(mat.shape[0])
    with open(os.path.join(args.outdir, "summary_statistics.tsv"), "w") as fh:
        fh.write("metric\tvalue\n")
        fh.write(f"genomes\t{n}\n")
        fh.write(f"total_gene_families\t{total}\n")
        for p in PART_ORDER:
            fh.write(f"{p.replace('-', '_')}_families\t{int(counts.get(p, 0))}\n")
        fh.write(f"heaps_alpha\t{alpha:.4f}\n")
        fh.write(f"pangenome_openness\t{'open' if (alpha == alpha and alpha < 1) else 'closed/NA'}\n")

    print(f"[viz] {args.label}: {total} families across {n} genomes")
    print(f"[viz] partitions: " +
          ", ".join(f"{p}={int(counts.get(p,0))}" for p in PART_ORDER))
    print(f"[viz] Heaps alpha = {alpha:.3f}" if alpha == alpha else "[viz] Heaps alpha = NA")
    print(f"[viz] wrote PNGs + {pdf_path} + summary_statistics.tsv to {args.outdir}")


if __name__ == "__main__":
    main()
