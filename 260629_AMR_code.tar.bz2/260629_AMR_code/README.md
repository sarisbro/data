# Label-free AMR determinant detection — analysis scripts

Scripts used to produce the results in *"Label-free detection of antimicrobial-resistance
determinants by coupling protein-language-model novelty to evolutionary-convergence
signatures."* Each gene family of a per-species pangenome is scored on five label-free
views (protein-language-model novelty, compositional mobility, episodic selection,
presence/absence homoplasy, reconciliation-inferred HGT) and combined conjunctively;
AMRFinderPlus labels enter only at evaluation.

The `add_*.sh` scripts are the **drivers** (they loop over both species, `ecoli` and
`kpneumoniae`); the `build_*.sh` / `run_*.sh` scripts do the per-species work; the
`*.py` scripts are the underlying tools.

## Pipeline order

```
# 0. one-time: download genomes (NCBI datasets) and annotate each with Prokka
#    -> out/<sp>/prokka/<accession>.{faa,ffn}   (inputs to everything below)

bash rerun_mmseqs.sh        # MMseqs2 pangenome: clusters + gene_presence_absence.Rtab + figures
bash add_core_tree.sh       # single-copy core alignment -> IQ-TREE core tree -> tree-ordered heatmap
bash add_amr.sh             # AMRFinderPlus on family reps -> AMR annotation (labels; used only at eval)
bash add_family_trees.sh    # per-family MAFFT+PAL2NAL codon alignments + IQ-TREE gene trees
bash add_hyphy.sh           # HyPhy episodic selection (BUSTED gate -> MEME/FEL/FUBAR/aBSREL) -> selection.tsv
bash add_novelty.sh         # ESM-2 novelty view -> novelty.tsv   (run in a native arm64 env)
bash add_hgt_alerax.sh      # AleRax DTL reconciliation -> hgt.tsv
bash add_fusion.sh          # mobility + P/A convergence views, conjunctive fusion, evaluation
bash make_selection_figures.sh   # selection figures

# main-text / SI figures
python3 plot_realdata_summary.py --out realdata_summary "E...=...=...=..." "K...=...=...=..."
python3 plot_evaluation_compare.py --out cross_eval "E...=...=..." "K...=...=..."
python3 plot_tree_matrix.py --rtab ... --tree ... --out ...
python3 make_report_pdf.py --rtab ... --tree ... --out ...
```

`add_fusion.sh` is re-entrant and `fuse_scores.py` auto-detects whichever view tables
(`selection.tsv`, `novelty.tsv`, `hgt.tsv`, `mobility.tsv`, `pa_convergence.tsv`) exist,
so it can be re-run after each heavy view is added.

## Files

**Drivers (both species):** `rerun_mmseqs.sh`, `add_core_tree.sh`, `add_amr.sh`,
`add_family_trees.sh`, `add_hyphy.sh`, `add_novelty.sh`, `add_hgt_alerax.sh`,
`add_fusion.sh`, `make_selection_figures.sh`

**Per-species stages:** `build_pangenome_mmseqs.sh`, `build_core_tree.sh`,
`build_amr_annotation.sh`, `build_family_trees.sh`, `run_hyphy.sh`, `run_hgt_alerax.sh`

**Views & scoring:** `esm_novelty.py` (novelty), `mobility_features.py` (mobility),
`pa_convergence.py` (P/A homoplasy, Fitch parsimony), `parse_hyphy_families.py`
(selection), `prep_alerax.py` + `parse_alerax.py` (HGT), `fuse_scores.py` (conjunction),
`evaluate.py` (AUPRC/AUROC/BEDROC/enrichment + ablation + leave-family-out)

**Pangenome / trees:** `core_alignment_from_clusters.py`, `build_family_trees.py`

**Figures:** `viz_pangenome.py`, `plot_tree_matrix.py`, `make_report_pdf.py`,
`plot_selection.py`, `plot_evaluation.py`, `plot_evaluation_compare.py`,
`plot_realdata_summary.py`

## Dependencies

Most tools live in one conda environment (`amr-labelfree`):
`ncbi-datasets-cli`, `prokka`, `mmseqs2`, `mafft`, `pal2nal`, `iqtree2`, `hyphy`,
`ncbi-amrfinderplus`, `alerax`; Python `numpy`, `pandas`, `scikit-learn`, `dendropy`,
`matplotlib`.

ESM-2 (`esm_novelty.py`) needs `torch` + `fair-esm`. On Apple Silicon, PyTorch under
Rosetta (osx-64) can segfault, so `add_novelty.sh` prefers a **native arm64** env
named `esm-env`:

```
CONDA_SUBDIR=osx-arm64 conda create -n esm-env -c conda-forge python=3.10 numpy scikit-learn pip
conda run -n esm-env pip install torch fair-esm
```

One-time database fetch for AMRFinderPlus: `amrfinder -u`.

## Notes

* Family ids are derived deterministically from the MMseqs2 cluster representative
  (`fam_<sanitized-rep>`), so every per-view table joins to the fused score by `family`.
* Earlier exploratory pangenome/HGT approaches (Panaroo, Roary, GeneRax) were
  superseded by MMseqs2 + AleRax and are not included here.
* The simulated benchmark generator (`test/00_simulate.py`) lives with the main
  pipeline repository; the quantities reported under the benchmark are reproducible
  from it with a fixed seed.
