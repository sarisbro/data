#!/usr/bin/env python3
"""annotate_amr.py -- map AMRFinderPlus hits onto the MMseqs2 pangenome.

Each gene family is represented by its MMseqs2 cluster representative; AMRFinderPlus
is run on those representatives (see build_amr_annotation.sh). This script joins the
AMRFinderPlus calls back to the families, computes each AMR family's prevalence and
pangenome partition (core / soft-core / shell / cloud), and writes tables + a figure.

Outputs (with --out-prefix P):
  P_amr_families.tsv   one row per AMR family: rep, gene, class, subclass, n_genomes,
                       prevalence, partition
  P_amr_summary.tsv    AMR family counts by partition and by resistance class
  P.png / P.pdf        (left) AMR families per partition; (right) most prevalent AMR genes
"""
import argparse
import collections
import csv
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

PART_ORDER = ["core", "soft-core", "shell", "cloud"]
PART_COLORS = {"core": "#2166ac", "soft-core": "#67a9cf", "shell": "#fdb863", "cloud": "#d6604d"}


def partition(frac, core=0.99, soft=0.95, shell=0.15):
    if frac >= core: return "core"
    if frac >= soft: return "soft-core"
    if frac >= shell: return "shell"
    return "cloud"


def parse_clusters(path):
    rep_genomes = collections.defaultdict(set)
    genomes = set()
    with open(path) as fh:
        for line in fh:
            p = line.rstrip("\n").split("\t")
            if len(p) != 2:
                continue
            rep, mem = p
            g = mem.split("__", 1)[0]
            genomes.add(g); rep_genomes[rep].add(g)
    return rep_genomes, sorted(genomes)


def parse_amrfinder(path, amr_only=True):
    """rep id -> (gene_symbol, class, subclass). Keeps the first AMR hit per rep."""
    hits = {}
    with open(path) as fh:
        reader = csv.DictReader(fh, delimiter="\t")
        # tolerate minor header variations
        def col(row, *names):
            for n in names:
                if n in row and row[n] not in (None, ""):
                    return row[n]
            return ""
        for row in reader:
            pid = col(row, "Protein identifier", "Protein id", "Protein")
            etype = col(row, "Element type", "Type")
            if amr_only and etype and etype.upper() != "AMR":
                continue
            if not pid or pid in hits:
                continue
            # AMRFinderPlus v3 used "Gene symbol"/"Element type"; v4 uses
            # "Element symbol"/"Type". Accept both.
            hits[pid] = (col(row, "Gene symbol", "Element symbol", "Gene") or "?",
                         col(row, "Class") or "UNKNOWN",
                         col(row, "Subclass"))
    return hits


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--clusters", required=True)
    ap.add_argument("--amrfinder", required=True)
    ap.add_argument("--out-prefix", required=True)
    ap.add_argument("--label", default="pangenome")
    ap.add_argument("--top", type=int, default=15)
    ap.add_argument("--keep-all-types", action="store_true",
                    help="include STRESS/VIRULENCE elements too (default: AMR only)")
    args = ap.parse_args()

    import os
    d = os.path.dirname(args.out_prefix)
    if d:
        os.makedirs(d, exist_ok=True)
    rep_genomes, genomes = parse_clusters(args.clusters)
    N = len(genomes)
    hits = parse_amrfinder(args.amrfinder, amr_only=not args.keep_all_types)

    rows = []
    for rep, (gene, cls, sub) in hits.items():
        gs = rep_genomes.get(rep)
        if not gs:
            continue
        n = len(gs); frac = n / N
        rows.append((rep, gene, cls, sub, n, frac, partition(frac)))
    rows.sort(key=lambda r: r[4], reverse=True)

    with open(args.out_prefix + "_amr_families.tsv", "w") as o:
        o.write("family_rep\tgene_symbol\tclass\tsubclass\tn_genomes\tprevalence\tpartition\n")
        for rep, gene, cls, sub, n, frac, part in rows:
            o.write(f"{rep}\t{gene}\t{cls}\t{sub}\t{n}\t{frac:.4f}\t{part}\n")

    by_part = collections.Counter(r[6] for r in rows)
    by_class = collections.Counter(r[2] for r in rows)
    with open(args.out_prefix + "_amr_summary.tsv", "w") as o:
        o.write("metric\tvalue\n")
        o.write(f"genomes\t{N}\n")
        o.write(f"amr_families_total\t{len(rows)}\n")
        for p in PART_ORDER:
            o.write(f"amr_families_{p.replace('-', '_')}\t{by_part.get(p, 0)}\n")
        for cls, c in by_class.most_common():
            o.write(f"class::{cls}\t{c}\n")

    # ---- figure ----
    fig, (axA, axB) = plt.subplots(1, 2, figsize=(14, 6),
                                   gridspec_kw={"width_ratios": [1, 1.4]})
    # A: AMR families per partition
    vals = [by_part.get(p, 0) for p in PART_ORDER]
    bars = axA.bar(PART_ORDER, vals, color=[PART_COLORS[p] for p in PART_ORDER])
    for b, v in zip(bars, vals):
        axA.text(b.get_x() + b.get_width() / 2, v, str(v), ha="center", va="bottom", fontsize=9)
    axA.set_ylabel("Distinct AMR gene families")
    axA.set_title(f"{args.label}\nAMR families by pangenome partition", fontsize=10)

    # B: most prevalent AMR genes, colored by class
    top = rows[:args.top][::-1]
    if top:
        classes = sorted({r[2] for r in top})
        cmap = plt.get_cmap("tab20")
        ccol = {c: cmap(i % 20) for i, c in enumerate(classes)}
        y = np.arange(len(top))
        axB.barh(y, [r[5] * 100 for r in top], color=[ccol[r[2]] for r in top])
        axB.set_yticks(y); axB.set_yticklabels([r[1] for r in top], fontsize=8)
        axB.set_xlabel("Prevalence (% of genomes)")
        axB.set_title(f"Most prevalent AMR determinants (top {len(top)})", fontsize=10)
        handles = [plt.Rectangle((0, 0), 1, 1, color=ccol[c]) for c in classes]
        axB.legend(handles, classes, fontsize=7, title="class", title_fontsize=7,
                   loc="lower right", frameon=False)
    else:
        axB.text(0.5, 0.5, "no AMR determinants found", ha="center", va="center")
        axB.axis("off")

    fig.tight_layout()
    fig.savefig(args.out_prefix + ".png", dpi=160, bbox_inches="tight")
    fig.savefig(args.out_prefix + ".pdf", bbox_inches="tight")

    npos = len(rows)
    acc = sum(1 for r in rows if r[6] in ("shell", "cloud"))
    print(f"[amr] {args.label}: {npos} AMR families across {N} genomes "
          f"({acc} in shell/cloud, {npos-acc} in core/soft-core)")
    print(f"[amr] by partition: " + ", ".join(f"{p}={by_part.get(p,0)}" for p in PART_ORDER))
    print(f"[amr] wrote {args.out_prefix}_amr_families.tsv, _amr_summary.tsv, .png/.pdf")


if __name__ == "__main__":
    main()
