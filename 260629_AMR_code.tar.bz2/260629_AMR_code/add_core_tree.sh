#!/usr/bin/env bash
# add_core_tree.sh ---------------------------------------------------------
# For BOTH species: build a core-genome tree from the MMseqs2 pangenome and
# re-render the presence/absence heatmap ordered by the tree. Run this AFTER
# rerun_mmseqs.sh (it reuses out/<sp>/mmseqs/clust_cluster.tsv, the .Rtab, and
# the Prokka .ffn files).
#
# Run:
#   conda activate amr-labelfree
#   bash add_core_tree.sh
#
# Knobs: THREADS (14), CORE_FRAC (0.99), MAX_GENES (0 = all single-copy core;
#        set e.g. 500 for a faster tree).
# -------------------------------------------------------------------------
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export THREADS="${THREADS:-14}"
export CORE_FRAC="${CORE_FRAC:-0.99}"
export MAX_GENES="${MAX_GENES:-0}"
say(){ printf '\033[1;36m[add-core-tree]\033[0m %s\n' "$*"; }

for t in mafft iqtree2; do
  command -v "$t" >/dev/null || { say "$t not found -- run: conda activate amr-labelfree"; exit 1; }
done

for sp in ecoli kpneumoniae; do
  label=$([ "$sp" = ecoli ] && echo "Escherichia coli" || echo "Klebsiella pneumoniae")
  if [[ ! -s "$HERE/out/$sp/mmseqs/clust_cluster.tsv" ]]; then
    say "$sp: no MMseqs2 clusters yet -- run rerun_mmseqs.sh first; skipping"; continue
  fi
  say "=== $sp ==="
  bash "$HERE/build_core_tree.sh" "$label" "$HERE/out/$sp/prokka" "$HERE/out/$sp"
done

echo
for sp in ecoli kpneumoniae; do
  if [[ -s "$HERE/out/$sp/core/core.treefile" ]]; then
    say "$sp: core tree + tree-ordered figures -> out/$sp/figures_mmseqs/  (tree: out/$sp/core/core.treefile)"
  else
    say "$sp: core tree NOT produced -- see out/$sp/core/iqtree.log"
  fi
done
