#!/usr/bin/env bash
# run_hyphy.sh -------------------------------------------------------------
# Episodic-selection analyses (HyPhy) over the per-family codon alignments and
# gene trees produced by build_family_trees.sh.
#
# BUSTED runs first and acts as a GATE: the more expensive site/branch methods
# (MEME, FEL, FUBAR, aBSREL) run only on families with BUSTED p < FDR, to bound
# compute. aBSREL's selected-branch fraction is the key convergence signal.
# RELAX is omitted here (it needs a tagged {Test} branch partition, which the
# unlabelled gene-family trees do not carry).
#
# Usage:
#   bash run_hyphy.sh <label> <out_base>
# Example:
#   bash run_hyphy.sh "Escherichia coli" out/ecoli
#
# Knobs: HYPHY_PARALLEL (default THREADS=14) families in parallel; HYPHY_CPU
#        (default 1) threads per HyPhy process; GATE (1); FDR (0.05);
#        GENETIC_CODE (Universal); MAX_FAMILIES (0=all); FORCE (0/1).
# Requires: hyphy, python3 (amr-labelfree env).
# -------------------------------------------------------------------------
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LABEL="${1:?need a species label}"
OUTB="${2:?need the species out base}"
OUTB="$(cd "$OUTB" && pwd)"
FAMS="$OUTB/families"; ALN_DIR="$FAMS/align"; TRE_DIR="$FAMS/genetrees"; HD="$FAMS/hyphy"
mkdir -p "$HD"
say(){ printf '\033[1;35m[%s]\033[0m %s\n' "$LABEL" "$*"; }

command -v hyphy >/dev/null || { echo "hyphy not found -- activate amr-labelfree"; exit 1; }
[[ -d "$ALN_DIR" && -d "$TRE_DIR" ]] || { echo "need $ALN_DIR and $TRE_DIR -- run build_family_trees.sh first"; exit 1; }

export HYPHY_PARALLEL="${HYPHY_PARALLEL:-${THREADS:-14}}"
export HYPHY_CPU="${HYPHY_CPU:-1}"
export GATE="${GATE:-1}"; export FDR="${FDR:-0.05}"
export GENETIC_CODE="${GENETIC_CODE:-Universal}"
export FORCE="${FORCE:-0}"
export HD ALN_DIR TRE_DIR

# ---- list families that have BOTH an alignment and a gene tree -------------
FAMLIST="$HD/_family_list.txt"; : > "$FAMLIST"
for a in "$ALN_DIR"/*.codon.fasta; do
  [[ -e "$a" ]] || continue
  f="$(basename "$a" .codon.fasta)"
  [[ -s "$TRE_DIR/$f.treefile" ]] && echo "$f" >> "$FAMLIST"
done
[[ "${MAX_FAMILIES:-0}" -gt 0 ]] && { head -n "$MAX_FAMILIES" "$FAMLIST" > "$FAMLIST.tmp" && mv "$FAMLIST.tmp" "$FAMLIST"; }
n=$(grep -c . "$FAMLIST" 2>/dev/null || echo 0)
say "families with alignment+tree: $n (parallel=$HYPHY_PARALLEL, cpu/proc=$HYPHY_CPU, gate=$GATE, FDR=$FDR)"
[[ "$n" -gt 0 ]] || { echo "no families to process"; exit 1; }

# ---- per-family worker ----------------------------------------------------
run_one() {
  local fam="$1"
  local aln="$ALN_DIR/$fam.codon.fasta" tree="$TRE_DIR/$fam.treefile"
  local method out
  hy() {  # hy <METHOD-keyword> <OUT.json> [extra args...]
    local meth="$1" out="$2"; shift 2
    [[ -s "$out" && "$FORCE" != 1 ]] && return 0
    hyphy CPU="$HYPHY_CPU" "$meth" --alignment "$aln" --tree "$tree" \
          --code "$GENETIC_CODE" --output "$out" "$@" \
          >>"$HD/_hyphy.$meth.log" 2>&1 || echo "  $meth failed: $fam" >&2
  }
  # 1) BUSTED (gate)
  hy busted "$HD/$fam.BUSTED.json" --branches All --srv Yes
  if [[ "$GATE" == 1 ]]; then
    local p
    p=$(python3 - "$HD/$fam.BUSTED.json" <<'PY'
import json,sys
try: print(json.load(open(sys.argv[1])).get("test results",{}).get("p-value",1.0))
except Exception: print(1.0)
PY
)
    awk "BEGIN{exit !($p < $FDR)}" || return 0   # gate: skip downstream if not significant
  fi
  # 2) downstream methods
  hy meme   "$HD/$fam.MEME.json"   --branches All --pvalue 0.1
  hy fel    "$HD/$fam.FEL.json"    --branches All --srv Yes
  hy fubar  "$HD/$fam.FUBAR.json"
  hy absrel "$HD/$fam.ABSREL.json" --branches All
}
export -f run_one
export HYPHY_CPU GENETIC_CODE FDR GATE FORCE HD ALN_DIR TRE_DIR

xargs -P "$HYPHY_PARALLEL" -I{} bash -c 'run_one "$@"' _ {} < "$FAMLIST"

# ---- collect into a selection feature table -------------------------------
say "parsing HyPhy JSON -> selection.tsv ..."
python3 "$HERE/parse_hyphy_families.py" --hyphy-dir "$HD" --out "$OUTB/selection.tsv"
say "DONE -> per-family JSON in $HD/ ; features: $OUTB/selection.tsv"
