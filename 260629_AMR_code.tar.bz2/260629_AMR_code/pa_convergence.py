#!/usr/bin/env python3
"""pa_convergence.py -- presence/absence convergence view (View B2, pure Python).

Repeated independent acquisition of a gene produces a phylogenetically
overdispersed (polyphyletic) presence/absence pattern. For each accessory family
we score the homoplasy of its presence/absence character on the species tree by
Fitch parsimony: the parsimony step count equals the minimum number of
independent gains/losses, so a vertically inherited family needs ~1 change while a
horizontally spread one needs many.

Outputs (--out): family  prevalence  pa_steps  consistency_index  pa_conv_score
  pa_steps          Fitch parsimony changes for the P/A character on S
  consistency_index 1 / pa_steps (low = homoplastic / convergent)
  pa_conv_score     rank-z of excess steps (pa_steps - 1); higher = more convergent

Inputs: clust_cluster.tsv (family memberships) and the species tree (Newick).
Restricted to accessory families (prevalence in [min-prev, max-prev]).
Depends on numpy + dendropy.
"""
import argparse, collections, re
import numpy as np
import dendropy


def fam_id(rep):
    return "fam_" + re.sub(r"[^A-Za-z0-9]+", "_", rep).strip("_")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--clusters", required=True)
    ap.add_argument("--tree", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--min-prev", type=float, default=0.02)
    ap.add_argument("--max-prev", type=float, default=0.98)
    args = ap.parse_args()

    # family -> set(genomes)
    rep_g = collections.defaultdict(set); genomes = set()
    with open(args.clusters) as fh:
        for line in fh:
            p = line.rstrip("\n").split("\t")
            if len(p) == 2:
                g = p[1].split("__", 1)[0]
                genomes.add(g); rep_g[p[0]].add(g)
    N = len(genomes)

    # tree -> postorder structure (children index lists; leaf -> label)
    t = dendropy.Tree.get(path=args.tree, schema="newick", preserve_underscores=True)
    order = list(t.postorder_node_iter())
    idx = {id(nd): i for i, nd in enumerate(order)}
    children = [[idx[id(c)] for c in nd.child_nodes()] for nd in order]
    leaf_label = [nd.taxon.label if nd.is_leaf() else None for nd in order]
    leaf_pos = {lab: i for i, lab in enumerate(leaf_label) if lab is not None}
    nnodes = len(order)

    def fitch_steps(present):
        # state bitmask per node: {0}=1, {1}=2, {0,1}=3
        state = [0] * nnodes
        changes = 0
        for i in range(nnodes):
            ch = children[i]
            if not ch:                                   # leaf
                lab = leaf_label[i]
                state[i] = 2 if lab in present else 1
            else:
                inter = state[ch[0]]
                uni = state[ch[0]]
                for c in ch[1:]:
                    inter &= state[c]; uni |= state[c]
                if inter:
                    state[i] = inter
                else:
                    state[i] = uni; changes += 1
        return changes

    recs = []
    lo, hi = args.min_prev * N, args.max_prev * N
    for rep, gs in rep_g.items():
        k = len(gs & set(leaf_pos))       # present among tree taxa
        if k < max(2, lo) or k > hi:
            continue
        steps = fitch_steps(gs)
        steps = max(steps, 1)
        recs.append([fam_id(rep), k / N, steps, 1.0 / steps])

    excess = np.array([r[2] - 1 for r in recs], float)
    m = excess.std() if excess.std() > 0 else 1.0
    score = (excess - excess.mean()) / m
    # rank-z for robustness
    r = excess.argsort().argsort().astype(float)
    score = (r - r.mean()) / (r.std() if r.std() > 0 else 1.0)

    with open(args.out, "w") as o:
        o.write("family\tprevalence\tpa_steps\tconsistency_index\tpa_conv_score\n")
        for i, rec in enumerate(recs):
            o.write(f"{rec[0]}\t{rec[1]:.4f}\t{rec[2]}\t{rec[3]:.4f}\t{score[i]:.5f}\n")
    import sys
    sys.stderr.write(f"[pa-conv] {len(recs)} accessory families scored "
                     f"(of which max steps={int(max((r[2] for r in recs), default=0))}) -> {args.out}\n")
    print(f"pa_convergence: {len(recs)} families -> {args.out}")


if __name__ == "__main__":
    main()
