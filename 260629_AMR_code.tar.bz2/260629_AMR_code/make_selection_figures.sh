#!/usr/bin/env bash
# make_selection_figures.sh ------------------------------------------------
# Visualize the HyPhy episodic-selection results for both species. Run after
# add_hyphy.sh (needs out/<sp>/selection.tsv).
#   conda activate amr-labelfree
#   bash make_selection_figures.sh
# Outputs: out/<sp>/figures_selection/selection_overview.{png,pdf} and _top.{png,pdf}
# -------------------------------------------------------------------------
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for sp in ecoli kpneumoniae; do
  label=$([ "$sp" = ecoli ] && echo "Escherichia coli" || echo "Klebsiella pneumoniae")
  [[ -s "$HERE/out/$sp/selection.tsv" ]] || { echo "$sp: no selection.tsv -- run add_hyphy.sh first; skipping"; continue; }
  mkdir -p "$HERE/out/$sp/figures_selection"
  python3 "$HERE/plot_selection.py" \
    --selection "$HERE/out/$sp/selection.tsv" \
    --clusters  "$HERE/out/$sp/mmseqs/clust_cluster.tsv" \
    --amr       "$HERE/out/$sp/amr/amr_pangenome_amr_families.tsv" \
    --label "$label" --out-prefix "$HERE/out/$sp/figures_selection/selection"
done
echo "figures: out/<sp>/figures_selection/selection_overview.pdf , selection_top.pdf"
