#!/usr/bin/env bash
# rerun_mmseqs.sh ----------------------------------------------------------
# Build BOTH species' pangenomes by clustering the cached Prokka proteomes with
# MMseqs2 (already in amr-labelfree -- NO new install, no Panaroo bug, no Roary
# Perl mess). Writes figures to out/<sp>/figures_mmseqs/, leaving the earlier
# CD-HIT salvage figures untouched.
#
# Run:
#   conda activate amr-labelfree
#   bash rerun_mmseqs.sh
#
# Knobs: THREADS (14), MIN_ID (0.90), COV (0.80).
# -------------------------------------------------------------------------
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export THREADS="${THREADS:-14}"
say(){ printf '\033[1;36m[rerun-mmseqs]\033[0m %s\n' "$*"; }

command -v mmseqs >/dev/null || { say "mmseqs not found -- run: conda activate amr-labelfree"; exit 1; }

for sp in ecoli kpneumoniae; do
  label=$([ "$sp" = ecoli ] && echo "Escherichia coli" || echo "Klebsiella pneumoniae")
  faadir="$HERE/out/$sp/prokka"
  # NB: count with wc, not `find | grep -q` -- under pipefail, grep -q closes the
  # pipe early, find dies with SIGPIPE, and the check would wrongly report "none".
  nfaa=$(find "$faadir" -name '*.faa' 2>/dev/null | wc -l | tr -d ' ')
  if [[ "${nfaa:-0}" -eq 0 ]]; then
    say "$sp: no Prokka proteomes under $faadir -- skipping"; continue
  fi
  say "=== $sp ($nfaa proteomes) ==="
  bash "$HERE/build_pangenome_mmseqs.sh" "$label" "$faadir" "$HERE/out/$sp"
done

echo
ok=1
for sp in ecoli kpneumoniae; do
  if [[ -s "$HERE/out/$sp/gene_presence_absence_mmseqs.Rtab" ]]; then
    say "$sp: matrix produced  ->  out/$sp/figures_mmseqs/pangenome_figures.pdf"
  else
    say "$sp: did NOT complete  ->  see out/$sp/mmseqs/mmseqs.log"; ok=0
  fi
done
echo
[[ $ok -eq 1 ]] && say "DONE: MMseqs2 pangenome matrices + figures ready." \
                || say "At least one species failed; send me out/<sp>/mmseqs/mmseqs.log."
exit 0
