#!/usr/bin/env python3
"""core_alignment_from_clusters.py -- build a concatenated single-copy core-gene
alignment from MMseqs2 clusters, for building a core-genome tree.

Given the MMseqs2 cluster table (rep<TAB>member, members named GENOME__locus) and
a FASTA of the same sequences (combined.ffn, headers >GENOME__locus), this:
  1. selects single-copy core families -- present in >= core_frac of genomes with
     exactly one copy per present genome (families with any multi-copy genome are
     skipped to avoid paralog ambiguity);
  2. MAFFT-aligns each family (in parallel);
  3. concatenates the per-family alignments into one supermatrix (one sequence per
     genome; genomes missing a family get gaps), written as FASTA.

Output feeds IQ-TREE to produce the core-genome tree used to order the
presence/absence heatmap.

Depends only on the standard library + MAFFT on PATH (override with --mafft).
"""
import argparse
import collections
import concurrent.futures as cf
import math
import os
import subprocess
import sys
import tempfile


def read_fasta(path):
    seqs, name, buf = {}, None, []
    with open(path) as fh:
        for line in fh:
            if line.startswith(">"):
                if name is not None:
                    seqs[name] = "".join(buf)
                name = line[1:].split()[0]
                buf = []
            else:
                buf.append(line.strip())
        if name is not None:
            seqs[name] = "".join(buf)
    return seqs


def parse_clusters(path):
    """rep -> {genome: [member_ids]}"""
    fam = collections.defaultdict(lambda: collections.defaultdict(list))
    genomes = set()
    with open(path) as fh:
        for line in fh:
            p = line.rstrip("\n").split("\t")
            if len(p) != 2:
                continue
            rep, mem = p
            g = mem.split("__", 1)[0]
            genomes.add(g)
            fam[rep][g].append(mem)
    return fam, sorted(genomes)


def align_family(args):
    rep, members, seqs, mafft = args  # members: {genome: member_id}
    recs = []
    for g, mid in members.items():
        s = seqs.get(mid)
        if s:
            recs.append((g, s))
    if len(recs) < 2:
        return rep, None
    with tempfile.NamedTemporaryFile("w", suffix=".fa", delete=False) as tf:
        for g, s in recs:
            tf.write(f">{g}\n{s}\n")
        fa = tf.name
    try:
        out = subprocess.run([mafft, "--auto", "--thread", "1", "--quiet", fa],
                             capture_output=True, text=True, check=True).stdout
    except Exception as e:
        sys.stderr.write(f"[core-aln] MAFFT failed on {rep}: {e}\n")
        return rep, None
    finally:
        os.unlink(fa)
    aln = read_fasta_str(out)
    return rep, aln


def read_fasta_str(text):
    seqs, name, buf = {}, None, []
    for line in text.splitlines():
        if line.startswith(">"):
            if name is not None:
                seqs[name] = "".join(buf)
            name = line[1:].split()[0]
            buf = []
        else:
            buf.append(line.strip())
    if name is not None:
        seqs[name] = "".join(buf)
    return seqs


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--clusters", required=True)
    ap.add_argument("--seqs", required=True, help="combined.ffn (>GENOME__locus)")
    ap.add_argument("--out", required=True, help="output concatenated alignment FASTA")
    ap.add_argument("--core-frac", type=float, default=0.99)
    ap.add_argument("--threads", type=int, default=8)
    ap.add_argument("--max-genes", type=int, default=0, help="0 = use all single-copy core")
    ap.add_argument("--mafft", default="mafft")
    args = ap.parse_args()

    sys.stderr.write("[core-aln] loading sequences ...\n")
    seqs = read_fasta(args.seqs)
    fam, genomes = parse_clusters(args.clusters)
    N = len(genomes)
    min_present = max(2, math.ceil(args.core_frac * N))
    sys.stderr.write(f"[core-aln] {N} genomes; single-copy core needs >= {min_present} genomes\n")

    # select single-copy core families
    core = {}
    for rep, gmap in fam.items():
        if any(len(v) != 1 for v in gmap.values()):
            continue  # a genome has paralogs -> skip
        if len(gmap) < min_present:
            continue
        core[rep] = {g: v[0] for g, v in gmap.items()}
    reps = sorted(core)
    if args.max_genes and len(reps) > args.max_genes:
        # evenly subsample for speed while spanning the set
        step = len(reps) / args.max_genes
        reps = [reps[int(i * step)] for i in range(args.max_genes)]
    sys.stderr.write(f"[core-aln] {len(reps)} single-copy core families to align\n")
    if not reps:
        sys.exit("[core-aln] no single-copy core families found; lower --core-frac")

    # align in parallel
    tasks = [(rep, core[rep], seqs, args.mafft) for rep in reps]
    alns = {}
    done = 0
    with cf.ThreadPoolExecutor(max_workers=args.threads) as ex:
        for rep, aln in ex.map(align_family, tasks):
            done += 1
            if aln:
                alns[rep] = aln
            if done % 200 == 0:
                sys.stderr.write(f"[core-aln]   aligned {done}/{len(reps)}\n")

    # concatenate (preserve a fixed family order)
    ordered = [r for r in reps if r in alns]
    lengths = {r: len(next(iter(alns[r].values()))) for r in ordered}
    cat = {g: [] for g in genomes}
    for r in ordered:
        L = lengths[r]
        a = alns[r]
        for g in genomes:
            cat[g].append(a.get(g, "-" * L))
    total_len = sum(lengths[r] for r in ordered)

    with open(args.out, "w") as o:
        for g in genomes:
            o.write(f">{g}\n{''.join(cat[g])}\n")
    sys.stderr.write(f"[core-aln] wrote {args.out}: {N} taxa x {total_len} bp "
                     f"from {len(ordered)} core families\n")
    print(f"core_families={len(ordered)} alignment_length={total_len} taxa={N}")


if __name__ == "__main__":
    main()
