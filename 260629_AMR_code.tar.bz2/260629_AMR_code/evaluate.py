#!/usr/bin/env python3
"""evaluate.py -- retrospective evaluation of the fused label-free score against
AMRFinderPlus labels (labels enter ONLY here).

Reads candidate_scores.tsv (with per-view u_* columns and S_conj) and the AMR
family table; computes:
  metrics.tsv   AUPRC, AUROC, BEDROC(alpha=20), top-k precision/recall, enrichment
  ablation.tsv  AUPRC for each view subset (single / full / leave-one-out) under
                the conjunctive rule, plus the additive full-set variant
  lofo.tsv      leave-family-out recovery by resistance class (rank-percentile,
                recall@k) -- because the score never uses labels, this measures
                whether each class would be surfaced de novo

Depends on numpy, pandas, scikit-learn.
"""
import argparse, os, re, itertools
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score

WEIGHTS = {"selection": 1.25, "pa_convergence": 1.25, "hgt": 1.25,
           "mobility": 1.0, "novelty": 1.0}


def fam_id(rep):
    return "fam_" + re.sub(r"[^A-Za-z0-9]+", "_", rep).strip("_")


def bedroc(y, score, alpha=20.0):
    order = np.argsort(-np.asarray(score, float))
    y = np.asarray(y)[order]
    N = len(y); n = int(y.sum())
    if n == 0 or n == N:
        return float("nan")
    ranks = np.nonzero(y)[0] + 1
    ra = n / N
    s = np.sum(np.exp(-alpha * ranks / N))
    rie = s * (np.exp(alpha / N) - 1.0) / (ra * (1.0 - np.exp(-alpha)))
    fac = ra * np.sinh(alpha / 2.0) / (np.cosh(alpha / 2.0) - np.cosh(alpha / 2.0 - alpha * ra))
    return rie * fac + 1.0 / (1.0 - np.exp(alpha * (1.0 - ra)))


def fuse(U, cols, additive=False):
    """Recompute the fused score over a subset of u_<view> columns."""
    w = np.array([WEIGHTS.get(c[2:], 1.0) for c in cols])
    M = U[cols].to_numpy(float)
    present = ~np.isnan(M)
    cov = present.sum(1) / len(cols)
    if additive:
        num = np.nansum(M * w, 1); den = (present * w).sum(1)
        base = np.divide(num, den, out=np.zeros_like(num), where=den > 0)
    else:
        logM = np.where(present, np.log(np.clip(M, 1e-12, 1)), 0.0)
        wsum = (present * w).sum(1)
        base = np.exp(np.divide((logM * w).sum(1), wsum, out=np.zeros_like(wsum), where=wsum > 0))
    return base * cov


def topk(y, score, k):
    idx = np.argsort(-score)[:k]
    hit = int(y[idx].sum())
    return hit / k, hit / max(int(y.sum()), 1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scores", required=True)
    ap.add_argument("--amr", required=True)
    ap.add_argument("--out-dir", required=True)
    args = ap.parse_args()
    os.makedirs(args.out_dir, exist_ok=True)

    df = pd.read_csv(args.scores, sep="\t")
    ucols = [c for c in df.columns if c.startswith("u_")]
    amr = pd.read_csv(args.amr, sep="\t")
    amr_class = {fam_id(fr): cl for fr, cl in zip(amr["family_rep"], amr["class"])}
    amr_set = set(amr_class)
    df["y"] = df["family"].isin(amr_set).astype(int)
    y = df["y"].to_numpy()
    S = df["S_conj"].to_numpy(float)
    npos = int(y.sum()); N = len(y)

    # ---- primary metrics on the full conjunction ----
    rows = [("genomes_families", N), ("positives", npos),
            ("AUPRC", round(average_precision_score(y, S), 4)),
            ("AUROC", round(roc_auc_score(y, S), 4)),
            ("BEDROC_a20", round(bedroc(y, S), 4)),
            ("baseline_prevalence", round(npos / N, 5))]
    for k in (50, 100, 300):
        p, r = topk(y, S, k); rows += [(f"precision@{k}", round(p, 4)), (f"recall@{k}", round(r, 4))]
    for phi in (0.01, 0.05):
        kk = max(1, int(phi * N)); p, _ = topk(y, S, kk)
        rows.append((f"EF_{int(phi*100)}pct", round(p / (npos / N), 2)))
    pd.DataFrame(rows, columns=["metric", "value"]).to_csv(
        os.path.join(args.out_dir, "metrics.tsv"), sep="\t", index=False)

    # ---- ablation over view subsets ----
    abl = []
    for c in ucols:
        abl.append((c[2:], "conjunctive", round(average_precision_score(y, fuse(df, [c])), 4)))
    if len(ucols) > 1:
        abl.append(("ALL", "conjunctive", round(average_precision_score(y, fuse(df, ucols)), 4)))
        abl.append(("ALL", "additive", round(average_precision_score(y, fuse(df, ucols, additive=True)), 4)))
        for c in ucols:
            sub = [x for x in ucols if x != c]
            abl.append((f"drop_{c[2:]}", "conjunctive", round(average_precision_score(y, fuse(df, sub)), 4)))
    pd.DataFrame(abl, columns=["views", "rule", "AUPRC"]).to_csv(
        os.path.join(args.out_dir, "ablation.tsv"), sep="\t", index=False)

    # ---- leave-family-out recovery by resistance class ----
    df["pct"] = df["S_conj"].rank(pct=True)          # 1 = top
    lofo = []
    by_class = {}
    for fam, cls in amr_class.items():
        by_class.setdefault(cls, []).append(fam)
    sub = df.set_index("family")
    for cls, fams in sorted(by_class.items(), key=lambda x: -len(x[1])):
        present = [f for f in fams if f in sub.index]
        if not present:
            continue
        pcts = sub.loc[present, "pct"].to_numpy()
        ranks = sub.loc[present, "S_conj"]
        r100 = float(np.mean([sub.loc[f, "pct"] >= 1 - 100 / N for f in present]))
        r300 = float(np.mean([sub.loc[f, "pct"] >= 1 - 300 / N for f in present]))
        lofo.append((cls, len(present), round(float(np.median(pcts)), 4),
                     round(float(np.max(pcts)), 4), round(r100, 3), round(r300, 3)))
    pd.DataFrame(lofo, columns=["class", "n_families", "median_percentile",
                                "best_percentile", "recall@100", "recall@300"]).to_csv(
        os.path.join(args.out_dir, "lofo.tsv"), sep="\t", index=False)

    m = dict(rows)
    print(f"[eval] N={N} positives={npos} | AUPRC={m['AUPRC']} AUROC={m['AUROC']} "
          f"BEDROC={m['BEDROC_a20']} EF_1pct={m.get('EF_1pct')}")
    print(f"[eval] wrote metrics.tsv, ablation.tsv, lofo.tsv -> {args.out_dir}")


if __name__ == "__main__":
    main()
