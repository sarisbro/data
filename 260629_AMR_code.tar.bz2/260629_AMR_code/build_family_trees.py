#!/usr/bin/env python3
"""build_family_trees.py -- per-family codon alignments and ML gene trees.

For every MMseqs2 gene family with at least --min-members member sequences:
  1. align the member proteins with MAFFT;
  2. back-translate to an in-frame codon alignment with PAL2NAL (using the
     nucleotide CDS);
  3. (optionally) infer a maximum-likelihood gene tree with IQ-TREE.

These per-family codon alignments and gene trees are the shared inputs for the
episodic-selection (HyPhy) and gene/species-tree reconciliation (HGT) analyses.

Outputs under --outdir:
  align/<fam>.codon.fasta      codon (nucleotide) alignment
  genetrees/<fam>.treefile     ML gene tree (unless --no-trees)
  family_index.tsv             fam id, representative, n members
Re-entrant: families whose outputs already exist are skipped (unless --force).

Inputs: combined.faa (>GENOME__locus proteins), combined.ffn (matching CDS),
clust_cluster.tsv. Tools: mafft, pal2nal.pl, iqtree2 (override via flags).
"""
import argparse
import collections
import concurrent.futures as cf
import os
import re
import subprocess
import sys


def read_fasta(path):
    seqs, name, buf = {}, None, []
    with open(path) as fh:
        for line in fh:
            if line.startswith(">"):
                if name is not None:
                    seqs[name] = "".join(buf)
                name = line[1:].split()[0]; buf = []
            else:
                buf.append(line.strip())
        if name is not None:
            seqs[name] = "".join(buf)
    return seqs


def parse_clusters(path):
    fam = collections.defaultdict(list)
    with open(path) as fh:
        for line in fh:
            p = line.rstrip("\n").split("\t")
            if len(p) == 2:
                fam[p[0]].append(p[1])
    return fam


def fam_id(rep):
    return "fam_" + re.sub(r"[^A-Za-z0-9]+", "_", rep).strip("_")


def process(task):
    rep, members, prot, nuc, outdir, mafft, pal2nal, iqtree, do_trees, force = task
    fid = fam_id(rep)
    aln_dir = os.path.join(outdir, "align"); tre_dir = os.path.join(outdir, "genetrees")
    codon = os.path.join(aln_dir, fid + ".codon.fasta")
    treef = os.path.join(tre_dir, fid + ".treefile")
    done = os.path.exists(codon) and (os.path.exists(treef) or not do_trees)
    if done and not force:
        return rep, fid, len(members), "skipped"

    recs = [(m, prot.get(m), nuc.get(m)) for m in members]
    recs = [(m, p, c) for m, p, c in recs if p and c]
    if len(recs) < 2:
        return rep, fid, len(members), "too_few_seqs"

    wd = os.path.join(outdir, "_tmp", fid); os.makedirs(wd, exist_ok=True)
    pep, cds, pepaln = (os.path.join(wd, x) for x in ("pep.fa", "cds.fa", "pep.aln"))
    with open(pep, "w") as fp, open(cds, "w") as fc:
        for m, p, c in recs:
            fp.write(f">{m}\n{p}\n"); fc.write(f">{m}\n{c}\n")
    try:
        with open(pepaln, "w") as out:
            subprocess.run([mafft, "--auto", "--thread", "1", "--quiet", pep],
                           stdout=out, check=True)
        os.makedirs(aln_dir, exist_ok=True)
        with open(codon, "w") as out:
            r = subprocess.run([pal2nal, pepaln, cds, "-output", "fasta"],
                               stdout=out, stderr=subprocess.DEVNULL)
        if r.returncode != 0 or os.path.getsize(codon) == 0:
            if os.path.exists(codon):
                os.remove(codon)
            return rep, fid, len(members), "pal2nal_failed"
        if do_trees:
            os.makedirs(tre_dir, exist_ok=True)
            pref = os.path.join(wd, "gt")
            subprocess.run([iqtree, "-s", codon, "-m", "GTR+G", "-T", "1",
                            "-fast", "--prefix", pref, "-redo"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
            if os.path.exists(pref + ".treefile"):
                os.replace(pref + ".treefile", treef)
            else:
                return rep, fid, len(members), "iqtree_failed"
    except Exception as e:
        return rep, fid, len(members), f"error:{type(e).__name__}"
    finally:
        for f in (pep, cds, pepaln):
            try: os.remove(f)
            except OSError: pass
    return rep, fid, len(members), "ok"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--clusters", required=True)
    ap.add_argument("--prot", required=True, help="combined.faa (>GENOME__locus)")
    ap.add_argument("--nuc", required=True, help="combined.ffn (matching CDS)")
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--min-members", type=int, default=4)
    ap.add_argument("--threads", type=int, default=8)
    ap.add_argument("--max-families", type=int, default=0, help="0 = all")
    ap.add_argument("--no-trees", action="store_true")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--mafft", default="mafft")
    ap.add_argument("--pal2nal", default="pal2nal.pl")
    ap.add_argument("--iqtree", default="iqtree2")
    args = ap.parse_args()

    os.makedirs(args.outdir, exist_ok=True)
    sys.stderr.write("[fam] loading sequences ...\n")
    prot = read_fasta(args.prot); nuc = read_fasta(args.nuc)
    fam = parse_clusters(args.clusters)
    reps = sorted([r for r, m in fam.items() if len(m) >= args.min_members])
    if args.max_families and len(reps) > args.max_families:
        reps = reps[:args.max_families]
    sys.stderr.write(f"[fam] {len(reps)} families with >= {args.min_members} members\n")

    with open(os.path.join(args.outdir, "family_index.tsv"), "w") as idx:
        idx.write("family\trepresentative\tn_members\n")
        for r in reps:
            idx.write(f"{fam_id(r)}\t{r}\t{len(fam[r])}\n")

    tasks = [(r, fam[r], prot, nuc, args.outdir, args.mafft, args.pal2nal,
              args.iqtree, not args.no_trees, args.force) for r in reps]
    stats = collections.Counter(); done = 0
    with cf.ThreadPoolExecutor(max_workers=args.threads) as ex:
        for rep, fid, nm, status in ex.map(process, tasks):
            stats[status] += 1; done += 1
            if done % 200 == 0:
                sys.stderr.write(f"[fam]   {done}/{len(reps)} ({dict(stats)})\n")
    # clean tmp
    import shutil
    shutil.rmtree(os.path.join(args.outdir, "_tmp"), ignore_errors=True)
    sys.stderr.write(f"[fam] done: {dict(stats)}\n")
    print(f"families={len(reps)} " + " ".join(f"{k}={v}" for k, v in stats.items()))


if __name__ == "__main__":
    main()
