#!/usr/bin/env python3
"""plot_evaluation.py -- visualize the retrospective evaluation of the fused
label-free score against AMRFinderPlus labels.

Panels (PNG + PDF):
  A  precision-recall curve for the fused score (vs background prevalence)
  B  ROC curve
  C  AUPRC by view subset (single views, full conjunction, leave-one-out, additive)
  D  fused score distribution, AMR vs non-AMR families

Inputs: candidate_scores.tsv (u_* columns + S_conj) and the AMR family table.
"""
import argparse, re
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import (average_precision_score, roc_auc_score,
                             precision_recall_curve, roc_curve)

WEIGHTS = {"selection": 1.25, "pa_convergence": 1.25, "hgt": 1.25,
           "mobility": 1.0, "novelty": 1.0}


def fam_id(rep):
    return "fam_" + re.sub(r"[^A-Za-z0-9]+", "_", rep).strip("_")


def fuse(U, cols, additive=False):
    w = np.array([WEIGHTS.get(c[2:], 1.0) for c in cols])
    M = U[cols].to_numpy(float)
    present = ~np.isnan(M)
    cov = present.sum(1) / len(cols)
    if additive:
        num = np.nansum(M * w, 1); den = (present * w).sum(1)
        base = np.divide(num, den, out=np.zeros_like(num), where=den > 0)
    else:
        logM = np.where(present, np.log(np.clip(M, 1e-12, 1)), 0.0)
        den = (present * w).sum(1)
        base = np.exp(np.divide((logM * w).sum(1), den, out=np.zeros_like(den), where=den > 0))
    return base * cov


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scores", required=True)
    ap.add_argument("--amr", required=True)
    ap.add_argument("--label", default="")
    ap.add_argument("--out-prefix", required=True)
    args = ap.parse_args()

    df = pd.read_csv(args.scores, sep="\t")
    ucols = [c for c in df.columns if c.startswith("u_")]
    amr = pd.read_csv(args.amr, sep="\t")
    amr_set = {fam_id(x) for x in amr["family_rep"]}
    y = df["family"].isin(amr_set).to_numpy().astype(int)
    S = df["S_conj"].to_numpy(float)
    base = y.mean()
    auprc = average_precision_score(y, S); auroc = roc_auc_score(y, S)
    nviews = len(ucols)

    fig, ax = plt.subplots(2, 2, figsize=(13, 10))
    # A: PR
    pr, rc, _ = precision_recall_curve(y, S)
    ax[0, 0].plot(rc, pr, color="#2166ac")
    ax[0, 0].axhline(base, color="grey", ls="--", lw=1, label=f"baseline {base:.4f}")
    ax[0, 0].set_xlabel("recall"); ax[0, 0].set_ylabel("precision")
    ax[0, 0].set_title(f"A  Precision-recall (AUPRC={auprc:.4f})", fontsize=10, loc="left")
    ax[0, 0].legend(frameon=False, fontsize=8)
    # B: ROC
    fpr, tpr, _ = roc_curve(y, S)
    ax[0, 1].plot(fpr, tpr, color="#b2182b"); ax[0, 1].plot([0, 1], [0, 1], "k--", lw=1)
    ax[0, 1].set_xlabel("false positive rate"); ax[0, 1].set_ylabel("true positive rate")
    ax[0, 1].set_title(f"B  ROC (AUROC={auroc:.3f})", fontsize=10, loc="left")
    # C: ablation
    labels, vals, cols = [], [], []
    for c in ucols:
        labels.append(c[2:]); vals.append(average_precision_score(y, fuse(df, [c]))); cols.append("#9ecae1")
    labels.append("ALL"); vals.append(average_precision_score(y, fuse(df, ucols))); cols.append("#2166ac")
    labels.append("ALL\n(additive)"); vals.append(average_precision_score(y, fuse(df, ucols, additive=True))); cols.append("#6baed6")
    for c in ucols:
        sub = [x for x in ucols if x != c]
        labels.append("drop\n" + c[2:]); vals.append(average_precision_score(y, fuse(df, sub))); cols.append("#fdae6b")
    ax[1, 0].bar(range(len(vals)), vals, color=cols)
    ax[1, 0].axhline(base, color="grey", ls="--", lw=1)
    ax[1, 0].set_xticks(range(len(labels))); ax[1, 0].set_xticklabels(labels, fontsize=7, rotation=45, ha="right")
    ax[1, 0].set_ylabel("AUPRC"); ax[1, 0].set_title("C  Ablation by view subset", fontsize=10, loc="left")
    # D: score distribution AMR vs non
    g = [S[y == 0], S[y == 1]]
    bp = ax[1, 1].boxplot(g, labels=[f"non-AMR\n(n={int((y==0).sum())})", f"AMR\n(n={int(y.sum())})"],
                          patch_artist=True, showfliers=False, medianprops=dict(color="black"))
    bp["boxes"][0].set_facecolor("#bbbbbb"); bp["boxes"][1].set_facecolor("#b2182b")
    ax[1, 1].scatter(np.full(int(y.sum()), 2) + np.random.uniform(-0.12, 0.12, int(y.sum())),
                     S[y == 1], s=10, color="#67001f", alpha=0.6, zorder=3)
    ax[1, 1].set_ylabel("fused score $S_{conj}$")
    ax[1, 1].set_title("D  Score: AMR vs non-AMR", fontsize=10, loc="left")

    fig.suptitle(f"{args.label}: retrospective recovery of AMR determinants "
                 f"({nviews} views, {len(df)} families)", fontsize=12, y=1.01)
    fig.tight_layout()
    fig.savefig(args.out_prefix + ".png", dpi=160, bbox_inches="tight")
    fig.savefig(args.out_prefix + ".pdf", bbox_inches="tight")
    print(f"[eval-fig] {args.label}: views={nviews} AUPRC={auprc:.4f} AUROC={auroc:.3f} -> {args.out_prefix}.pdf")


if __name__ == "__main__":
    main()
