#!/usr/bin/env bash
# add_hyphy.sh -------------------------------------------------------------
# Run the HyPhy episodic-selection analyses for BOTH species over the per-family
# codon alignments + gene trees, then build the per-family selection feature
# table. Run after add_family_trees.sh.
#
# Run:
#   conda activate amr-labelfree
#   bash add_hyphy.sh
#
# This is a heavy step (BUSTED on every family, then 4 more methods on the
# selection-positive ones). It is re-entrant (cached JSON are skipped), so it
# resumes if interrupted. Useful knobs:
#   GATE=1            BUSTED gate (default; set 0 to run all methods on all families)
#   FDR=0.05          gate threshold
#   HYPHY_PARALLEL=14 families in parallel
#   MAX_FAMILIES=50   quick trial
# -------------------------------------------------------------------------
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export THREADS="${THREADS:-14}"
say(){ printf '\033[1;36m[add-hyphy]\033[0m %s\n' "$*"; }

command -v hyphy >/dev/null || { say "hyphy not found -- run: conda activate amr-labelfree"; exit 1; }

for sp in ecoli kpneumoniae; do
  label=$([ "$sp" = ecoli ] && echo "Escherichia coli" || echo "Klebsiella pneumoniae")
  # NB: use compgen, not `ls glob` -- with ~11k families the expanded glob
  # exceeds ARG_MAX and `ls` fails, which would misreport "no alignments".
  if ! compgen -G "$HERE/out/$sp/families/align/*.codon.fasta" >/dev/null; then
    say "$sp: no per-family alignments -- run add_family_trees.sh first; skipping"; continue
  fi
  say "=== $sp ==="
  bash "$HERE/run_hyphy.sh" "$label" "$HERE/out/$sp"
done

echo
for sp in ecoli kpneumoniae; do
  f="$HERE/out/$sp/selection.tsv"
  if [[ -s "$f" ]]; then
    say "$sp: selection features for $(($(wc -l < "$f")-1)) families -> out/$sp/selection.tsv"
  else
    say "$sp: HyPhy did NOT complete -> see out/$sp/families/hyphy/_hyphy.*.log"
  fi
done
