#!/usr/bin/env python3
"""mobility_features.py -- compositional mobility view (View 3').

Horizontally acquired genes tend to differ in nucleotide composition from their
host genome. For every gene family we measure, per member, how far the gene's
codon usage and GC content deviate from its OWN host genome's average, and
aggregate (mean) over members. Families whose members look compositionally
foreign score high.

Outputs (--out): family  n_members  gc_dev  codon_dist  mobility_score
  gc_dev        mean |GC(gene) - GC(host genome)|
  codon_dist    mean Euclidean distance between gene and host codon frequencies
  mobility_score rank-z(gc_dev) + rank-z(codon_dist), averaged (higher = more foreign)

Inputs: clust_cluster.tsv and combined.ffn (>GENOME__locus nucleotide CDS).
Pure Python (numpy only).
"""
import argparse, collections
import numpy as np

BASES = "ACGT"
SENSE = [a + b + c for a in BASES for b in BASES for c in BASES
         if a + b + c not in ("TAA", "TAG", "TGA")]
CIDX = {c: i for i, c in enumerate(SENSE)}


def iter_fasta(path):
    name, buf = None, []
    with open(path) as fh:
        for line in fh:
            if line.startswith(">"):
                if name is not None:
                    yield name, "".join(buf)
                name = line[1:].split()[0]; buf = []
            else:
                buf.append(line.strip().upper())
    if name is not None:
        yield name, "".join(buf)


def codon_vec(seq):
    v = np.zeros(len(SENSE))
    gc = 0; tot = 0
    n = len(seq) - (len(seq) % 3)
    for i in range(0, n, 3):
        c = seq[i:i + 3]
        j = CIDX.get(c)
        if j is not None:
            v[j] += 1
    for ch in seq:
        if ch in "GC": gc += 1
        if ch in BASES: tot += 1
    s = v.sum()
    return (v / s if s > 0 else v), (gc / tot if tot > 0 else 0.0)


def rank_z(x):
    x = np.asarray(x, float); out = np.zeros_like(x)
    m = ~np.isnan(x)
    if m.sum() > 1:
        r = x[m].argsort().argsort().astype(float)
        out[m] = (r - r.mean()) / (r.std() if r.std() > 0 else 1.0)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--clusters", required=True)
    ap.add_argument("--nuc", required=True, help="combined.ffn (>GENOME__locus)")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    # per-gene vectors + per-genome aggregate
    gene_vec, gene_gc = {}, {}
    genome_cnt = collections.defaultdict(lambda: np.zeros(len(SENSE)))
    genome_gc = collections.defaultdict(lambda: [0, 0])  # [gc, total]
    import sys
    sys.stderr.write("[mobility] scanning CDS ...\n")
    nseq = 0
    for sid, seq in iter_fasta(args.nuc):
        g = sid.split("__", 1)[0]
        v = np.zeros(len(SENSE)); gc = 0; tot = 0
        n = len(seq) - (len(seq) % 3)
        for i in range(0, n, 3):
            j = CIDX.get(seq[i:i + 3])
            if j is not None:
                v[j] += 1
        for ch in seq:
            if ch in "GC": gc += 1
            if ch in BASES: tot += 1
        s = v.sum()
        gene_vec[sid] = v / s if s > 0 else v
        gene_gc[sid] = gc / tot if tot > 0 else 0.0
        genome_cnt[g] += v
        genome_gc[g][0] += gc; genome_gc[g][1] += tot
        nseq += 1
    sys.stderr.write(f"[mobility] {nseq} CDS across {len(genome_cnt)} genomes\n")

    gvec = {g: (c / c.sum() if c.sum() > 0 else c) for g, c in genome_cnt.items()}
    ggc = {g: (v[0] / v[1] if v[1] > 0 else 0.0) for g, v in genome_gc.items()}

    fam = collections.defaultdict(list)
    with open(args.clusters) as fh:
        for line in fh:
            p = line.rstrip("\n").split("\t")
            if len(p) == 2:
                fam[p[0]].append(p[1])

    import re
    def fam_id(rep): return "fam_" + re.sub(r"[^A-Za-z0-9]+", "_", rep).strip("_")

    recs = []
    for rep, members in fam.items():
        gcs, cds = [], []
        for m in members:
            if m not in gene_vec:
                continue
            g = m.split("__", 1)[0]
            gcs.append(abs(gene_gc[m] - ggc.get(g, gene_gc[m])))
            cds.append(float(np.linalg.norm(gene_vec[m] - gvec.get(g, gene_vec[m]))))
        if not gcs:
            continue
        recs.append([fam_id(rep), len(members), float(np.mean(gcs)), float(np.mean(cds))])

    gc_dev = rank_z([r[2] for r in recs])
    cd = rank_z([r[3] for r in recs])
    score = (gc_dev + cd) / 2.0
    with open(args.out, "w") as o:
        o.write("family\tn_members\tgc_dev\tcodon_dist\tmobility_score\n")
        for i, r in enumerate(recs):
            o.write(f"{r[0]}\t{r[1]}\t{r[2]:.5f}\t{r[3]:.5f}\t{score[i]:.5f}\n")
    sys.stderr.write(f"[mobility] wrote {len(recs)} families -> {args.out}\n")
    print(f"mobility: {len(recs)} families -> {args.out}")


if __name__ == "__main__":
    main()
