#!/usr/bin/env python3
"""plot_selection.py -- visualize the HyPhy episodic-selection results
(selection.tsv) for one species.

Produces two figures (PNG + PDF):
  <out_prefix>_overview.{png,pdf}
     A  BUSTED gene-wide significance (-log10 p) with the gate at p=0.05
     B  selected-branch fraction (aBSREL) among families with any selected branch
     C  fused selection score by pangenome partition (core/soft-core/shell/cloud)
     D  fused selection score in AMR vs non-AMR families
  <out_prefix>_top.{png,pdf}
     top-N families by fused selection score, coloured by partition; AMR-positive
     families marked.

Joins selection.tsv to the pangenome partition (from clust_cluster.tsv) and the
AMR annotation (amr_pangenome_amr_families.tsv) by family id.
"""
import argparse, csv, re, collections
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

PART_ORDER = ["core", "soft-core", "shell", "cloud"]
PART_COLORS = {"core": "#2166ac", "soft-core": "#67a9cf", "shell": "#fdb863", "cloud": "#d6604d"}


def fam_id(rep):
    return "fam_" + re.sub(r"[^A-Za-z0-9]+", "_", rep).strip("_")


def fnum(x):
    try:
        return float(x)
    except Exception:
        return np.nan


def load_selection(path):
    rows = []
    with open(path) as fh:
        for r in csv.DictReader(fh, delimiter="\t"):
            rows.append(r)
    return rows


def partition_map(clusters):
    rep_g = collections.defaultdict(set); genomes = set()
    with open(clusters) as fh:
        for line in fh:
            p = line.rstrip("\n").split("\t")
            if len(p) != 2:
                continue
            g = p[1].split("__", 1)[0]
            genomes.add(g); rep_g[p[0]].add(g)
    N = len(genomes)
    fp = {}
    for rep, gs in rep_g.items():
        fr = len(gs) / N
        fp[fam_id(rep)] = ("core" if fr >= 0.99 else "soft-core" if fr >= 0.95
                           else "shell" if fr >= 0.15 else "cloud")
    return fp, N


def amr_map(path):
    amr = {}
    try:
        with open(path) as fh:
            for r in csv.DictReader(fh, delimiter="\t"):
                amr[fam_id(r["family_rep"])] = r.get("gene_symbol", "") or r.get("class", "")
    except FileNotFoundError:
        pass
    return amr


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--selection", required=True)
    ap.add_argument("--clusters", required=True)
    ap.add_argument("--amr", default=None)
    ap.add_argument("--label", default="selection")
    ap.add_argument("--out-prefix", required=True)
    ap.add_argument("--top", type=int, default=25)
    args = ap.parse_args()

    rows = load_selection(args.selection)
    fp, N = partition_map(args.clusters)
    amr = amr_map(args.amr) if args.amr else {}

    fam = [r["family"] for r in rows]
    busted = np.array([fnum(r["busted_p"]) for r in rows])
    neglog = -np.log10(np.clip(busted, 1e-16, 1.0))
    bfrac = np.array([fnum(r["branch_frac"]) for r in rows])
    sel = np.array([fnum(r["sel_score"]) for r in rows])
    part = np.array([fp.get(f, "cloud") for f in fam])
    is_amr = np.array([f in amr for f in fam])
    n = len(rows)
    n_gate = int(np.sum(busted < 0.05))

    # ---------- overview figure ----------
    fig, ax = plt.subplots(2, 2, figsize=(14, 10))

    # A: BUSTED -log10 p
    a = ax[0, 0]
    a.hist(neglog, bins=60, color="#4393c3", edgecolor="none")
    a.axvline(-np.log10(0.05), color="k", ls="--", lw=1)
    a.text(-np.log10(0.05), a.get_ylim()[1]*0.9, "  p=0.05 gate", fontsize=8, va="top")
    a.set_xlabel(r"BUSTED $-\log_{10}p$ (episodic diversifying selection)")
    a.set_ylabel("gene families")
    a.set_title(f"A  Gene-wide selection: {n_gate}/{n} families pass the gate "
                f"({100*n_gate/n:.0f}%)", fontsize=10, loc="left")

    # B: selected-branch fraction among families with any selected branch
    b = ax[0, 1]
    pos = bfrac[bfrac > 0]
    b.hist(pos, bins=40, color="#d6604d", edgecolor="none")
    b.set_xlabel(r"selected-branch fraction $\beta_f$ (aBSREL)")
    b.set_ylabel("gene families")
    b.set_title(f"B  Branch-level convergence: {len(pos)} families with "
                r"$\beta_f>0$", fontsize=10, loc="left")

    # C: sel_score by partition
    c = ax[1, 0]
    data = [sel[part == p] for p in PART_ORDER]
    bp = c.boxplot(data, labels=PART_ORDER, patch_artist=True, showfliers=False,
                   medianprops=dict(color="black"))
    for patch, p in zip(bp["boxes"], PART_ORDER):
        patch.set_facecolor(PART_COLORS[p])
    c.set_ylabel("fused selection score")
    c.set_title("C  Selection score by pangenome partition", fontsize=10, loc="left")

    # D: AMR vs non-AMR
    d = ax[1, 1]
    grp = [sel[~is_amr], sel[is_amr]]
    bp2 = d.boxplot(grp, labels=[f"non-AMR\n(n={int((~is_amr).sum())})",
                                 f"AMR\n(n={int(is_amr.sum())})"],
                    patch_artist=True, showfliers=False, medianprops=dict(color="black"))
    bp2["boxes"][0].set_facecolor("#bbbbbb"); bp2["boxes"][1].set_facecolor("#b2182b")
    if is_amr.sum():
        d.scatter(np.full(int(is_amr.sum()), 2) + np.random.uniform(-0.12, 0.12, int(is_amr.sum())),
                  sel[is_amr], s=12, color="#67001f", zorder=3, alpha=0.7)
    amr_gate = int(np.sum(busted[is_amr] < 0.05))
    d.set_ylabel("fused selection score")
    d.set_title(f"D  Selection in AMR families "
                f"({amr_gate}/{int(is_amr.sum())} pass BUSTED gate)", fontsize=10, loc="left")

    fig.suptitle(f"{args.label}: episodic-selection landscape (HyPhy, {n} gene families)",
                 fontsize=13, y=1.01)
    fig.tight_layout()
    fig.savefig(args.out_prefix + "_overview.png", dpi=160, bbox_inches="tight")
    fig.savefig(args.out_prefix + "_overview.pdf", bbox_inches="tight")
    plt.close(fig)

    # ---------- top candidates ----------
    order = np.argsort(sel)[::-1][:args.top][::-1]
    fig2, ax2 = plt.subplots(figsize=(10, max(5, 0.32 * args.top)))
    y = np.arange(len(order))
    ax2.barh(y, sel[order], color=[PART_COLORS[part[i]] for i in order])
    labels = []
    for i in order:
        lab = fam[i].replace("fam_", "")
        if fam[i] in amr:
            lab = "★ " + lab + f"  [{amr[fam[i]]}]"
        labels.append(lab)
    ax2.set_yticks(y); ax2.set_yticklabels(labels, fontsize=7)
    ax2.set_xlabel("fused selection score")
    ax2.set_title(f"{args.label}: top {args.top} families by selection score "
                  r"($\bigstar$ = known AMR determinant)", fontsize=10)
    handles = [plt.Rectangle((0, 0), 1, 1, color=PART_COLORS[p]) for p in PART_ORDER]
    ax2.legend(handles, PART_ORDER, fontsize=8, title="partition", loc="lower right", frameon=False)
    fig2.tight_layout()
    fig2.savefig(args.out_prefix + "_top.png", dpi=160, bbox_inches="tight")
    fig2.savefig(args.out_prefix + "_top.pdf", bbox_inches="tight")
    plt.close(fig2)

    print(f"[selection-fig] {args.label}: {n} families, gate {n_gate} ({100*n_gate/n:.0f}%), "
          f"AMR {int(is_amr.sum())} -> {args.out_prefix}_overview/_top .png/.pdf")


if __name__ == "__main__":
    main()
