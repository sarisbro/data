#!/usr/bin/env bash
# add_family_trees.sh ------------------------------------------------------
# Per-family codon alignments + ML gene trees for BOTH species, from the MMseqs2
# pangenome. Run after rerun_mmseqs.sh (and ideally add_core_tree.sh, which builds
# combined.ffn -- otherwise it is built here from the Prokka CDS).
#
# Run:
#   conda activate amr-labelfree
#   bash add_family_trees.sh
#
# This is the heavy step: thousands of families x (MAFFT + PAL2NAL + IQ-TREE).
# It is re-entrant, so it resumes if interrupted. Tips:
#   - alignments only first (fast):   NO_TREES=1 bash add_family_trees.sh
#   - then add trees:                 bash add_family_trees.sh
#   - quick trial:                    MAX_FAMILIES=50 bash add_family_trees.sh
# Knobs: THREADS (14), MIN_MEMBERS (4), MAX_FAMILIES (0=all), NO_TREES, FORCE.
# -------------------------------------------------------------------------
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export THREADS="${THREADS:-14}"
say(){ printf '\033[1;36m[add-family-trees]\033[0m %s\n' "$*"; }

for t in mafft pal2nal.pl iqtree2; do
  command -v "$t" >/dev/null || { say "$t not found -- run: conda activate amr-labelfree"; exit 1; }
done

for sp in ecoli kpneumoniae; do
  label=$([ "$sp" = ecoli ] && echo "Escherichia coli" || echo "Klebsiella pneumoniae")
  if [[ ! -s "$HERE/out/$sp/mmseqs/clust_cluster.tsv" ]]; then
    say "$sp: no MMseqs2 clusters -- run rerun_mmseqs.sh first; skipping"; continue
  fi
  say "=== $sp ==="
  bash "$HERE/build_family_trees.sh" "$label" "$HERE/out/$sp" "$HERE/out/$sp/prokka"
done

echo
for sp in ecoli kpneumoniae; do
  na=$(find "$HERE/out/$sp/families/align" -name '*.codon.fasta' 2>/dev/null | wc -l | tr -d ' ')
  nt=$(find "$HERE/out/$sp/families/genetrees" -name '*.treefile' 2>/dev/null | wc -l | tr -d ' ')
  say "$sp: $na codon alignments, $nt gene trees -> out/$sp/families/"
done
