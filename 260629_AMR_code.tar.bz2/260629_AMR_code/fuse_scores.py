#!/usr/bin/env python3
"""fuse_scores.py -- conjunctive fusion of the label-free views.

Reads whatever per-view score tables are present in a directory, rank-normalizes
each view to a unit-interval score u in (0,1), and combines them per family by a
weighted geometric mean scaled by a coverage factor (the conjunctive rule of the
manuscript):

    S_i = ( prod_{v in V_i} u_{i,v}^{w_v} )^{1/sum w_v}  *  |V_i| / |V|

where V_i is the set of views with a non-missing score for family i and |V| the
total number of views available. The geometric mean rewards agreement across
independent views and penalizes families supported by only one.

Known views (auto-detected) and weights (evolutionary views up-weighted):
    selection.tsv       sel_score        1.25
    pa_convergence.tsv  pa_conv_score    1.25
    hgt.tsv             hgt_score        1.25
    mobility.tsv        mobility_score   1.00
    novelty.tsv         novelty_score    1.00

Output (--out): family, u_<view> per view, n_views, coverage, S_conj
The per-view u columns let the evaluation recompute fusion over view subsets
(ablation) and an additive variant without re-reading the raw tables.
"""
import argparse, os
import numpy as np
import pandas as pd

REGISTRY = [
    ("selection.tsv",      "sel_score",      1.25),
    ("pa_convergence.tsv", "pa_conv_score",  1.25),
    ("hgt.tsv",            "hgt_score",      1.25),
    ("mobility.tsv",       "mobility_score", 1.00),
    ("novelty.tsv",        "novelty_score",  1.00),
]


def unit_rank(s):
    """Rank-normalize a series to u in (0,1); higher raw -> higher u."""
    r = s.rank(method="average")
    return (r) / (len(s) + 1.0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", required=True, help="directory holding the per-view tables")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    views = []          # (name, weight, Series indexed by family -> u)
    for fname, col, w in REGISTRY:
        p = os.path.join(args.dir, fname)
        if not os.path.isfile(p):
            continue
        df = pd.read_csv(p, sep="\t")
        if "family" not in df.columns or col not in df.columns:
            continue
        s = pd.to_numeric(df.set_index("family")[col], errors="coerce").dropna()
        if s.empty:
            continue
        name = fname.replace(".tsv", "")
        views.append((name, w, unit_rank(s)))
        print(f"[fuse] view {name}: {len(s)} families (w={w})")
    if not views:
        raise SystemExit(f"[fuse] no view tables found in {args.dir}")

    fams = sorted(set().union(*[set(v[2].index) for v in views]))
    U = pd.DataFrame(index=fams)
    for name, w, s in views:
        U["u_" + name] = s.reindex(fams)

    nV = len(views)
    weights = {("u_" + n): w for n, w, _ in views}
    ucols = list(weights)

    logsum = pd.Series(0.0, index=fams)
    wsum = pd.Series(0.0, index=fams)
    ncov = pd.Series(0, index=fams)
    for c in ucols:
        u = U[c]; w = weights[c]
        present = u.notna()
        logsum[present] += w * np.log(u[present])
        wsum[present] += w
        ncov[present] += 1
    gmean = np.exp(logsum / wsum.replace(0, np.nan))
    coverage = ncov / nV
    S = gmean * coverage

    out = U.copy()
    out.insert(0, "family", out.index)
    out["n_views"] = ncov.values
    out["coverage"] = coverage.round(4).values
    out["S_conj"] = S.round(6).values
    out = out.sort_values("S_conj", ascending=False)
    out.to_csv(args.out, sep="\t", index=False, float_format="%.5f")
    print(f"[fuse] {len(fams)} families, {nV} views -> {args.out}")
    print(f"[fuse] top family S_conj={out['S_conj'].iloc[0]:.4f}; "
          f"median={out['S_conj'].median():.4f}")


if __name__ == "__main__":
    main()
