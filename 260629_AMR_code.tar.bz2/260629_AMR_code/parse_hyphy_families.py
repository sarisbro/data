#!/usr/bin/env python3
"""parse_hyphy_families.py -- collect per-family HyPhy JSON outputs into one
selection feature table (self-contained; no pipeline config needed).

Per family it extracts (defensive against HyPhy version key differences):
  busted_p      BUSTED gene-wide p-value (small = episodic diversifying selection)
  n_meme        # sites with MEME episodic selection (p <= 0.05)
  n_fel_pos     # sites with FEL pervasive positive selection (p <= 0.05, beta>alpha)
  n_fubar_pos   # sites with FUBAR posterior(positive) > 0.9
  n_branch_sel  # branches with aBSREL episodic selection (corrected p <= 0.05)
  branch_frac   n_branch_sel / tested branches   <- key convergence proxy
  relax_k       RELAX intensity parameter (NaN if RELAX not run)
  sel_score     rank-z fusion: z(-log10 busted_p) + 1.5 z(branch_frac)
                + z(n_meme) + z(n_fubar)
Output: --out (default selection.tsv).
"""
import argparse, glob, json, os, sys
import numpy as np


def _get(d, *path, default=None):
    for k in path:
        if isinstance(d, dict) and k in d:
            d = d[k]
        else:
            return default
    return d


def rank_z(x):
    x = np.asarray(x, float)
    out = np.full(x.shape, np.nan)
    m = ~np.isnan(x)
    if m.sum() == 0:
        return np.zeros_like(x)
    r = x[m].argsort().argsort().astype(float)        # ranks 0..k-1
    if m.sum() > 1:
        r = (r - r.mean()) / (r.std() if r.std() > 0 else 1.0)
    else:
        r = np.zeros_like(r)
    out[m] = r
    out[~m] = 0.0
    return out


def _mle_rows(j):
    content = _get(j, "MLE", "content", "0", default=None)
    headers = _get(j, "MLE", "headers", default=None)
    if content is None:
        return [], []
    hnames = [h[0] if isinstance(h, (list, tuple)) else str(h) for h in (headers or [])]
    return hnames, content


def parse_busted(j):
    return float(_get(j, "test results", "p-value", default=np.nan))


def parse_meme(j):
    h, rows = _mle_rows(j)
    if not rows:
        return 0
    idx = next((i for i, n in enumerate(h) if "p-value" in n.lower()), None)
    if idx is None:
        return 0
    return int(sum(1 for r in rows if r[idx] is not None and r[idx] <= 0.05))


def parse_fel(j):
    h, rows = _mle_rows(j)
    if not rows:
        return 0
    a = next((i for i, n in enumerate(h) if n.lower().startswith("alpha")), None)
    b = next((i for i, n in enumerate(h) if n.lower().startswith("beta")), None)
    p = next((i for i, n in enumerate(h) if "p-value" in n.lower()), None)
    if None in (a, b, p):
        return 0
    return int(sum(1 for r in rows if r[p] is not None and r[p] <= 0.05 and r[b] > r[a]))


def parse_fubar(j):
    h, rows = _mle_rows(j)
    if not rows:
        return 0
    # FUBAR positive-selection posterior column is "Prob[alpha<beta]" (beta>alpha).
    # Match that (and synonyms) while EXCLUDING the negative "Prob[alpha>beta]".
    def _lc(n):
        return n.lower().replace(" ", "")
    idx = next((i for i, n in enumerate(h)
                if "prob" in _lc(n) and ("alpha<beta" in _lc(n)
                                         or "beta>alpha" in _lc(n)
                                         or "positive" in _lc(n))), None)
    if idx is None:
        return 0
    return int(sum(1 for r in rows if r[idx] is not None and r[idx] > 0.9))


def parse_absrel(j):
    ba = _get(j, "branch attributes", "0", default={}) or {}
    n_sel, n_tot = 0, 0
    for _, attr in ba.items():
        if not isinstance(attr, dict):
            continue
        pkey = next((k for k in attr if "corrected" in k.lower() and "p" in k.lower()), None)
        if pkey is None:
            pkey = next((k for k in attr if k.lower() in ("p-value", "p_value")), None)
        if pkey is None:
            continue
        n_tot += 1
        if attr[pkey] is not None and attr[pkey] <= 0.05:
            n_sel += 1
    if n_tot == 0:
        n_sel = int(_get(j, "test results", "positive test results", default=0) or 0)
        n_tot = 1
    return n_sel, max(n_tot, 1)


def parse_relax(j):
    return float(_get(j, "test results", "relaxation or intensification parameter", default=np.nan))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--hyphy-dir", required=True)
    ap.add_argument("--out", default="selection.tsv")
    args = ap.parse_args()
    hd = args.hyphy_dir

    fams = sorted({os.path.basename(p).split(".")[0]
                   for p in glob.glob(os.path.join(hd, "*.json"))})
    if not fams:
        sys.exit(f"no HyPhy JSON found in {hd}")

    def load(fam, suffix):
        p = os.path.join(hd, f"{fam}.{suffix}.json")
        if os.path.exists(p):
            try:
                return json.load(open(p))
            except Exception:
                return None
        return None

    recs = []
    for fam in fams:
        busted_p = parse_busted(load(fam, "BUSTED") or {})
        n_meme = parse_meme(load(fam, "MEME") or {})
        n_fel = parse_fel(load(fam, "FEL") or {})
        n_fubar = parse_fubar(load(fam, "FUBAR") or {})
        nb, tb = parse_absrel(load(fam, "ABSREL") or {})
        relax_k = parse_relax(load(fam, "RELAX") or {})
        recs.append([fam, busted_p, n_meme, n_fel, n_fubar, nb, nb / tb, relax_k])

    busted_neglog = np.array([-(np.log10(r[1]) if r[1] and r[1] > 0 else 0) for r in recs])
    branch_frac = np.array([r[6] for r in recs])
    n_meme = np.array([r[2] for r in recs], float)
    n_fubar = np.array([r[4] for r in recs], float)
    sel = np.nanmean(np.vstack([rank_z(busted_neglog), 1.5 * rank_z(branch_frac),
                                rank_z(n_meme), rank_z(n_fubar)]), 0)

    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    with open(args.out, "w") as fh:
        fh.write("family\tbusted_p\tn_meme\tn_fel_pos\tn_fubar_pos\t"
                 "n_branch_sel\tbranch_frac\trelax_k\tsel_score\n")
        for i, r in enumerate(recs):
            fh.write("\t".join(str(x) for x in r) + f"\t{sel[i]:.5f}\n")
    print(f"[parse-hyphy] wrote selection features for {len(recs)} families -> {args.out}")


if __name__ == "__main__":
    main()
