#!/usr/bin/env bash
# add_novelty.sh -----------------------------------------------------------
# ESM-2 protein-language-model novelty view (View 1) for BOTH species.
# Embeds the gene-family representatives and scores novelty.
#
#   conda activate amr-labelfree
#   bash add_novelty.sh
#
# Heavy step: ESM-2 on CPU/Rosetta. Default model esm2_t30_150M_UR50D (smaller,
# CPU-friendly); set ESM_MODEL=esm2_t33_650M_UR50D if you have a GPU. Embeddings
# are cached (out/<sp>/novelty.emb.npy), so re-runs skip the ESM pass.
# Knobs: ESM_MODEL, ESM_DEVICE (cpu/cuda), BATCH_TOKENS.
# Requires: fair-esm, torch, scikit-learn (amr-labelfree env).
# -------------------------------------------------------------------------
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODEL="${ESM_MODEL:-esm2_t30_150M_UR50D}"; DEVICE="${ESM_DEVICE:-cpu}"
BT="${BATCH_TOKENS:-8000}"; ESM_ENV="${ESM_ENV:-esm-env}"
say(){ printf '\033[1;36m[add-novelty]\033[0m %s\n' "$*"; }

# PyTorch in the osx-64 amr-labelfree env runs under Rosetta and segfaults; run
# ESM from a NATIVE arm64 env instead. Prefer that env; warn if falling back.
if command -v conda >/dev/null 2>&1 && conda run -n "$ESM_ENV" python -c "import torch, esm" 2>/dev/null; then
  PY=(conda run --no-capture-output -n "$ESM_ENV" python)
  say "using native ESM env '$ESM_ENV'"
elif python3 -c "import torch, esm" 2>/dev/null; then
  PY=(python3)
  say "WARNING: '$ESM_ENV' not found; using the current env's torch -- if it"
  say "         segfaults (Rosetta), create a native arm64 env (see below)."
else
  say "No usable torch/fair-esm. Create a NATIVE arm64 env (one-time):"
  say "    CONDA_SUBDIR=osx-arm64 conda create -n $ESM_ENV -c conda-forge python=3.10 numpy scikit-learn pip"
  say "    conda run -n $ESM_ENV pip install torch fair-esm"
  exit 1
fi

for sp in ecoli kpneumoniae; do
  reps="$HERE/out/$sp/mmseqs/clust_rep_seq.fasta"
  [[ -s "$reps" ]] || { say "$sp: no representatives ($reps) -- run rerun_mmseqs.sh; skipping"; continue; }
  say "=== $sp ($(grep -c '^>' "$reps") representatives, model=$MODEL, device=$DEVICE) ==="
  "${PY[@]}" "$HERE/esm_novelty.py" --reps "$reps" --out "$HERE/out/$sp/novelty.tsv" \
      --model "$MODEL" --device "$DEVICE" --batch-tokens "$BT"
done
echo
for sp in ecoli kpneumoniae; do
  [[ -s "$HERE/out/$sp/novelty.tsv" ]] && say "$sp: novelty -> out/$sp/novelty.tsv ($(($(wc -l < "$HERE/out/$sp/novelty.tsv")-1)) families)"
done
say "next: re-run 'bash add_fusion.sh' to fold novelty into the conjunction"
