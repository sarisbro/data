#!/usr/bin/env python3
"""make_report_pdf.py -- assemble a single multi-page PDF report for one species'
pangenome: title page, gene frequency spectrum, pan/core accumulation, partition
bar, tree-ordered heatmap, and the core tree + presence/absence matrix (with
genome tip labels).

Usage:
  make_report_pdf.py --rtab gene_presence_absence_mmseqs.Rtab \
                     --tree core/core.treefile --label "Escherichia coli" \
                     --out ecoli_pangenome_report.pdf

Reuses the plotting functions in viz_pangenome.py and plot_tree_matrix.py.
"""
import argparse
import os
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import viz_pangenome as vz
import plot_tree_matrix as tm


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rtab", required=True)
    ap.add_argument("--tree", default=None)
    ap.add_argument("--label", default="pangenome")
    ap.add_argument("--out", required=True)
    ap.add_argument("--perms", type=int, default=50)
    args = ap.parse_args()

    mat = vz.load_matrix(args.rtab)
    n = mat.shape[1]
    parts = (0.99, 0.95, 0.15)
    fracs = mat.sum(axis=1) / n
    parts_series = fracs.apply(lambda f: vz.partition(f, *parts))
    counts = parts_series.value_counts().reindex(vz.PART_ORDER).fillna(0).astype(int)
    genome_order = vz.tree_leaf_order(args.tree, list(mat.columns)) if args.tree else None

    with PdfPages(args.out) as pdf:
        # ---- title page ----
        fig = plt.figure(figsize=(11, 8.5)); fig.clf()
        lines = [
            f"Pangenome report", f"{args.label}", "",
            f"Genomes: {n}",
            f"Gene families: {mat.shape[0]}",
            f"Core (≥ 99%): {int(counts.get('core',0))}",
            f"Soft-core (95–99%): {int(counts.get('soft-core',0))}",
            f"Shell (15–95%): {int(counts.get('shell',0))}",
            f"Cloud (< 15%): {int(counts.get('cloud',0))}",
            "", "Clustering: MMseqs2 (90% id / 80% cov) on Prokka proteomes",
            "Tree: IQ-TREE on the single-copy core alignment",
        ]
        y = 0.86
        for i, t in enumerate(lines):
            size = 22 if i == 0 else (16 if i == 1 else 12)
            wt = "bold" if i <= 1 else "normal"
            fig.text(0.1, y, t, fontsize=size, fontweight=wt)
            y -= 0.055 if t else 0.03
        pdf.savefig(fig); plt.close(fig)

        # ---- standard panels ----
        fig, ax = plt.subplots(figsize=(11, 8.5))
        vz.plot_frequency_spectrum(mat, parts, n, args.label, ax)
        fig.tight_layout(); pdf.savefig(fig); plt.close(fig)

        fig, ax = plt.subplots(figsize=(11, 8.5))
        vz.plot_accumulation(mat, args.label, ax, args.perms)
        fig.tight_layout(); pdf.savefig(fig); plt.close(fig)

        fig, ax = plt.subplots(figsize=(11, 8.5))
        vz.plot_partition_bar(parts_series, args.label, ax)
        fig.tight_layout(); pdf.savefig(fig); plt.close(fig)

        fig, ax = plt.subplots(figsize=(11, 8.5))
        vz.plot_heatmap(mat, genome_order, args.label, ax)
        fig.tight_layout(); pdf.savefig(fig); plt.close(fig)

        # ---- tree + matrix with tip labels ----
        if args.tree:
            height = max(9, n * 0.09)
            fig = plt.figure(figsize=(15, height))
            tm.draw_tree_matrix(fig, mat, args.tree, args.label, tip_labels=True)
            pdf.savefig(fig, bbox_inches="tight"); plt.close(fig)

    print(f"[report] wrote {args.out} for {args.label} ({n} genomes, {mat.shape[0]} families)")


if __name__ == "__main__":
    main()
