#!/usr/bin/env bash
# build_family_trees.sh ----------------------------------------------------
# Per-family codon alignments + ML gene trees for one species, from the MMseqs2
# pangenome. MAFFT (protein) -> PAL2NAL (codon) -> IQ-TREE (gene tree).
# These feed the episodic-selection (HyPhy) and reconciliation/HGT analyses.
#
# Usage:
#   bash build_family_trees.sh <label> <out_base> <prokka_dir>
# Example:
#   bash build_family_trees.sh "Escherichia coli" out/ecoli out/ecoli/prokka
#
# Knobs: THREADS (14), MIN_MEMBERS (4), MAX_FAMILIES (0=all), NO_TREES (0/1),
#        FORCE (0/1). Re-entrant: finished families are skipped.
# Requires: mafft, pal2nal.pl, iqtree2, python3 (amr-labelfree env).
# -------------------------------------------------------------------------
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
THREADS="${THREADS:-14}"; MIN_MEMBERS="${MIN_MEMBERS:-4}"; MAX_FAMILIES="${MAX_FAMILIES:-0}"
LABEL="${1:?need a species label}"
OUTB="${2:?need the species out base}"
PROKKA_DIR="${3:?need the prokka dir (for combined.ffn if missing)}"
OUTB="$(cd "$OUTB" && pwd)"; PROKKA_DIR="$(cd "$PROKKA_DIR" && pwd)"
MM="$OUTB/mmseqs"; FAMS="$OUTB/families"
say(){ printf '\033[1;33m[%s]\033[0m %s\n' "$LABEL" "$*"; }

for t in mafft pal2nal.pl iqtree2; do command -v "$t" >/dev/null || { echo "$t not found -- activate amr-labelfree"; exit 1; }; done
CLUST="$MM/clust_cluster.tsv"; FAA="$MM/combined.faa"; FFN="$MM/combined.ffn"
[[ -s "$CLUST" && -s "$FAA" ]] || { echo "missing MMseqs2 outputs in $MM -- run rerun_mmseqs.sh first"; exit 1; }

# combined.ffn (nucleotide CDS); build from Prokka .ffn if absent
if [[ ! -s "$FFN" ]]; then
  say "building combined.ffn from Prokka CDS..."
  : > "$FFN"
  while IFS= read -r f; do
    acc="$(basename "$f" .ffn)"
    awk -v g="$acc" '/^>/{sub(/^>/,">"g"__"); print $1; next} {print}' "$f" >> "$FFN"
  done < <(find "$PROKKA_DIR" -name '*.ffn' | sort)
fi

notrees=(); [[ "${NO_TREES:-0}" == 1 ]] && notrees=(--no-trees)
force=();   [[ "${FORCE:-0}" == 1 ]]   && force=(--force)
say "building per-family codon alignments$([[ "${NO_TREES:-0}" == 1 ]] || echo ' + gene trees') (min_members=$MIN_MEMBERS, threads=$THREADS)..."
python3 "$HERE/build_family_trees.py" \
    --clusters "$CLUST" --prot "$FAA" --nuc "$FFN" --outdir "$FAMS" \
    --min-members "$MIN_MEMBERS" --threads "$THREADS" --max-families "$MAX_FAMILIES" \
    ${notrees[@]+"${notrees[@]}"} ${force[@]+"${force[@]}"} \
    --mafft mafft --pal2nal pal2nal.pl --iqtree iqtree2

na=$(find "$FAMS/align" -name '*.codon.fasta' 2>/dev/null | wc -l | tr -d ' ')
nt=$(find "$FAMS/genetrees" -name '*.treefile' 2>/dev/null | wc -l | tr -d ' ')
say "DONE -> $na codon alignments, $nt gene trees in $FAMS/"
