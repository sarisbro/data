#!/usr/bin/env bash
# add_amr.sh ---------------------------------------------------------------
# AMR-annotate BOTH species' pangenomes (AMRFinderPlus on the MMseqs2 family
# representatives) and map determinants onto the pangenome. Run after
# rerun_mmseqs.sh.
#
# One-time (downloads the AMRFinderPlus database, ~ once):
#   conda activate amr-labelfree
#   amrfinder -u
#
# Run:
#   bash add_amr.sh
#
# Knobs: THREADS (14).
# -------------------------------------------------------------------------
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export THREADS="${THREADS:-14}"
say(){ printf '\033[1;36m[add-amr]\033[0m %s\n' "$*"; }

command -v amrfinder >/dev/null || { say "amrfinder not found -- run: conda activate amr-labelfree"; exit 1; }

# species -> AMRFinderPlus --organism (enables organism-specific curation)
declare_org() { case "$1" in ecoli) echo "Escherichia";; kpneumoniae) echo "Klebsiella_pneumoniae";; *) echo "";; esac; }

for sp in ecoli kpneumoniae; do
  label=$([ "$sp" = ecoli ] && echo "Escherichia coli" || echo "Klebsiella pneumoniae")
  if [[ ! -s "$HERE/out/$sp/mmseqs/clust_rep_seq.fasta" ]]; then
    say "$sp: no MMseqs2 representatives -- run rerun_mmseqs.sh first; skipping"; continue
  fi
  say "=== $sp ==="
  bash "$HERE/build_amr_annotation.sh" "$label" "$HERE/out/$sp" "$(declare_org "$sp")"
done

echo
for sp in ecoli kpneumoniae; do
  f="$HERE/out/$sp/amr/amr_pangenome_amr_families.tsv"
  if [[ -s "$f" ]]; then
    say "$sp: $(($(wc -l < "$f")-1)) AMR families -> out/$sp/amr/amr_pangenome.{png,pdf}"
  else
    say "$sp: AMR annotation did NOT complete -> see out/$sp/amr/amrfinder.log"
  fi
done
