#!/bin/bash
#SBATCH --nodes=1                           # Number of nodes requested
#SBATCH --ntasks=40                         # Number of tasks requested. Has to be a multiple of 40.
#SBATCH -t 0-24:00:0                         # How long will your job run for?
#SBATCH -J VirSorter2_RNA                		# Name of job

##########################################################
##########################################################
##########################################################

# This script was used in Lemieux et al. (2025) to identify
# viral genomes in RNA contigs with VirSorter2.

##########################################################

# Adapted for Trillium

# Load modules
# module load CCEnv arch/avx512 StdEnv/2020
module load StdEnv/2020
module load python/3.8
module load hmmer/3.3.2
module load prodigal/2.6.3

# To modify
USERNAME=username # To modify
DIRECTORY=/home/$USERNAME/scratch/ete2021_V2
NUCL_ACID=RNA # To modify
CUTOFF_VALUE=300 # To modify

SCRATCH=/home/$USERNAME/scratch

VIRAL_CONTIGS_DIR=/home/$USERNAME/scratch/ete2021_V2/3_viral_contigs
mkdir -p $VIRAL_CONTIGS_DIR

R_SCRIPTS=/home/$USERNAME/R_scripts

##########################################################
############# Install software/databases #################
##########################################################

# VirSorter2
# For more information: https://github.com/jiarong/VirSorter2
# Compute Canada: https://docs.alliancecan.ca/wiki/VirSorter2/en

# Create a virtual environment in SCRATCH
VIRTUAL_ENVS=$SCRATCH/virtuals_envs
# mkdir -p $VIRTUAL_ENVS
# cd $VIRTUAL_ENVS

# virtualenv --no-download $VIRTUAL_ENVS/ENV_virsorter
source $VIRTUAL_ENVS/ENV_virsorter/bin/activate
# pip install --no-index --upgrade pip # Upgrade pip

# # Install VirSorter2
# pip install --no-index virsorter==2.2.4
# pip freeze > ~/virsorter-2.2.4-requirements.txt
#
# # Download the database
# virsorter setup --db-dir $SCRATCH/dbs/VirSorter_db -j 4 --skip-deps-install
#
# # Test
# mkdir -p $SCRATCH/Test_VirSorter2
# cd $SCRATCH/Test_VirSorter2
# wget -O test.fa https://raw.githubusercontent.com/jiarong/VirSorter2/master/test/8seq.fa
#
# virsorter run -w test_output -i test.fa --min-length 1500 --use-conda-off --db-dir $SCRATCH/dbs/VirSorter_db all

##########################################################
#################### Run VirSorter 2 #####################
##########################################################

CONTIGS_DIR=$VIRAL_CONTIGS_DIR/$NUCL_ACID
cd $CONTIGS_DIR

# Combine filtered contigs and unclassified contigs
cat filtered_classified_${NUCL_ACID}_${CUTOFF_VALUE}.fasta unclassified_${NUCL_ACID}_${CUTOFF_VALUE}.fasta > contigs_filt_unc_${NUCL_ACID}_${CUTOFF_VALUE}.fasta

# Run VirSorter2 on those filtered and unclassified contigs
virsorter run -w ${NUCL_ACID}_VirSorter2_output \
	-i contigs_filt_unc_${NUCL_ACID}_${CUTOFF_VALUE}.fasta \
	--use-conda-off \
	--db-dir $SCRATCH/dbs/VirSorter_db all

##########################################################
##########################################################
##########################################################
