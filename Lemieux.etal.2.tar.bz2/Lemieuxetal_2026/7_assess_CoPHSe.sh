#!/bin/bash
#SBATCH --nodes=1                           # Number of nodes requested
#SBATCH --ntasks=40                         # Number of tasks requested. Has to be a multiple of 40.
#SBATCH -t 0-2:00:0                         # How long will your job run for?
#SBATCH -J assess_cophse                		# Name of job

##########################################################
##########################################################
##########################################################

# This script was used in Lemieux et al. (2026) to assess
# the branch lengths of trees.

##########################################################

# Adapted for Trilium

# Load modules
# module load CCEnv arch/avx512 StdEnv/2020
module load StdEnv/2020
module load r/4.1.2

# To modify
USERNAME=username # To modify

SCRATCH=/home/$USERNAME/scratch

COPHSE_DIR=$SCRATCH/ete2021_V2/4_cophse
mkdir -p $COPHSE_DIR

R_SCRIPTS=/home/$USERNAME/R_scripts

##########################################################
############### Assess branch lengths (RNA) ##############
##########################################################

NUCL_ACID=RNA

cd $COPHSE_DIR/${NUCL_ACID}

# 1e-20
EVALUE=1e-20
cp $R_SCRIPTS/tree_assessment_${NUCL_ACID}_$EVALUE.R $COPHSE_DIR
R CMD BATCH $R_SCRIPTS/tree_assessment_${NUCL_ACID}_$EVALUE.R

# 1e-15
EVALUE=1e-15
cp $R_SCRIPTS/tree_assessment_${NUCL_ACID}_$EVALUE.R $COPHSE_DIR
R CMD BATCH $R_SCRIPTS/tree_assessment_${NUCL_ACID}_$EVALUE.R

##########################################################
############### Assess branch lengths (DNA) ##############
##########################################################

NUCL_ACID=DNA

cd $COPHSE_DIR/${NUCL_ACID}

# 1e-20
EVALUE=1e-20
cp $R_SCRIPTS/tree_assessment_${NUCL_ACID}_$EVALUE.R $COPHSE_DIR
R CMD BATCH $R_SCRIPTS/tree_assessment_${NUCL_ACID}_$EVALUE.R

# 1e-15
EVALUE=1e-15
cp $R_SCRIPTS/tree_assessment_${NUCL_ACID}_$EVALUE.R $COPHSE_DIR
R CMD BATCH $R_SCRIPTS/tree_assessment_${NUCL_ACID}_$EVALUE.R

##########################################################
##########################################################
##########################################################

