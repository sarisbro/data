#!/bin/bash
#SBATCH --nodes=1                           # Number of nodes requested
#SBATCH --ntasks=40                         # Number of tasks requested. Has to be a multiple of 40.
#SBATCH -t 0-6:00:0                         # How long will your job run for?
#SBATCH -J assembly                		# Name of job

##########################################################
##########################################################
##########################################################

# This script was used in Lemieux et al. (2026) for the
# quality control with Trimmomatic and the de novo assembly
# with MEGAHIT.

# This script was repeated on each replicate.

##########################################################

# Adapted for Trillium

# Load modules
# module load CCEnv arch/avx512 StdEnv/2020
module load StdEnv/2020
module load megahit
module load trimmomatic
module load perl

# To modify
USERNAME=username # To modify
SAMPLE=BS3 # To modify
REPLICATE=003 # To modify
SAMP_REP=${SAMPLE}_${REPLICATE}
RAW_READS_1=raw_R1.fastq.gz # To modify
RAW_READS_2=raw_R2.fastq.gz # To modify
DIRECTORY=/home/$USERNAME/scratch/ete2021/contigs/$SAMPLE/$SAMP_REP # To modify

mkdir -p $DIRECTORY

##########################################################
########## Quality control and Assembly de novo ##########
##########################################################

cd $DIRECTORY

# Trimmomatic
java -jar $EBROOTTRIMMOMATIC/trimmomatic-0.39.jar PE -threads 24 /home/$USERNAME/scratch/ete2021/1_raw_data/$RAW_READS_1 /home/$USERNAME/scratch/ete2021/1_raw_data/$RAW_READS_2 -baseout $DIRECTORY/trimmed ILLUMINACLIP:$EBROOTTRIMMOMATIC/adapters/TruSeq3-PE-2.fa:2:30:10 LEADING:3 TRAILING:3 SLIDINGWINDOW:4:15 MINLEN:36 &> $DIRECTORY/trimmomatic.log

# MEGAHIT
rm -fR $DIRECTORY/assembler_out assembler.log
megahit -t 24 -1 trimmed_1P -2 trimmed_2P --out-dir assembler_out &> assembler.log
cp assembler_out/final.contigs.fa $DIRECTORY
mv final.contigs.fa ${SAMP_REP}_contigs.fasta

##########################################################
##########################################################
##########################################################
