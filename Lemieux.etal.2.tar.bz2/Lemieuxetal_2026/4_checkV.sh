#!/bin/bash
#SBATCH --nodes=1                           # Number of nodes requested
#SBATCH --ntasks=40                         # Number of tasks requested. Has to be a multiple of 40.
#SBATCH -t 0-2:00:0                         # How long will your job run for?
#SBATCH -J CheckV                		# Name of job

##########################################################
##########################################################
##########################################################

# This script was used in Lemieux et al. (2025) to assess
# VirSorter2's viral predicitons using CheckV.

##########################################################

# Adapted for Trillium

# Load modules
# module load CCEnv arch/avx512 StdEnv/2020
module load StdEnv/2020
module load hmmer/3.3.2
module load prodigal-gv/2.6.3
module load diamond/2.1.7
module load python/3.10.2

# To modify
USERNAME=username # To modify
DIRECTORY=/home/$USERNAME/scratch/ete2021_V2
NUCL_ACID=RNA # To modify
CUTOFF_VALUE=300 # To modify

SCRATCH=/home/$USERNAME/scratch

VIRAL_CONTIGS_DIR=/home/$USERNAME/scratch/ete2021_V2/3_viral_contigs
mkdir -p $VIRAL_CONTIGS_DIR

R_SCRIPTS=/home/$USERNAME/R_scripts

##########################################################
############# Install software/databases #################
##########################################################

# CheckV
# For more information: https://bitbucket.org/berkeleylab/checkv/src/master/
# Compute Canada: https://docs.alliancecan.ca/wiki/CheckV/en

# Create a virtual environment in SCRATCH
VIRTUAL_ENVS=$SCRATCH/virtuals_envs
# mkdir -p $VIRTUAL_ENVS
# cd $VIRTUAL_ENVS

# virtualenv $VIRTUAL_ENVS/CheckV_env
source $VIRTUAL_ENVS/CheckV_env/bin/activate

# # Install CheckV
# pip install --no-index --upgrade pip # Upgrade pip
# pip install --no-index checkv
# python -c 'import checkv' # Test

# Download database
CHECKV_DB=$SCRATCH/dbs/CheckV_db
# mkdir -p $CHECKV_DB
# checkv download_database $CHECKV_DB

# # Test
# mkdir -p $SCRATCH/Test_CheckV
# cd $SCRATCH/Test_CheckV
# wget https://bitbucket.org/berkeleylab/checkv/raw/3f185b5841e8c109848cd0b001df7117fe795c50/test/test_sequences.fna
# checkv end_to_end test_sequences.fna test_output -t 16 -d $CHECKV_DB/checkv-db-v1.5

##########################################################
################### Run CheckV (RNA) #####################
##########################################################

CONTIGS_DIR=$VIRAL_CONTIGS_DIR/$NUCL_ACID
cd $CONTIGS_DIR

checkv end_to_end \
	${NUCL_ACID}_VirSorter2_output/final-viral-combined.fa \
	${NUCL_ACID}_CheckV_output \
	-t 16 -d $CHECKV_DB/checkv-db-v1.5

##########################################################
################### Run CheckV (DNA) #####################
##########################################################

NUCL_ACID=DNA

CONTIGS_DIR=$VIRAL_CONTIGS_DIR/$NUCL_ACID
cd $CONTIGS_DIR

checkv end_to_end \
	${NUCL_ACID}_VirSorter2_output/final-viral-combined.fa \
	${NUCL_ACID}_CheckV_output \
	-t 16 -d $CHECKV_DB/checkv-db-v1.5

##########################################################
##########################################################
##########################################################
