#!/bin/bash
#SBATCH --nodes=1                           # Number of nodes requested
#SBATCH --ntasks=40                         # Number of tasks requested. Has to be a multiple of 40.
#SBATCH -t 0-23:00:0                         # How long will your job run for?
#SBATCH -J extract_seqs_RNA                		# Name of job

##########################################################
##########################################################
##########################################################

# This script was used in Lemieux et al. (2026) to create
# the RNA Clusters of Putatively Homogeneous Sequences
# (CoPHSe).

##########################################################

# Adapted for Trillium

# # Load modules
# module load CCEnv arch/avx512 StdEnv/2020
module load StdEnv/2020
module load r/4.3.1
module load python
module load cd-hit/4.8.1
module load hmmer/3.3.2
module load mafft/7.471
module load trimal/1.4 fasttree/2.1.11

# To modify
USERNAME=username # To modify
DIRECTORY=/home/$USERNAME/scratch/ete2021_V2
NUCL_ACID=RNA # To modify
CUTOFF_VALUE=300 # To modify

SCRATCH=/home/$USERNAME/scratch

VIRAL_CONTIGS_DIR=$SCRATCH/ete2021_V2/3_viral_contigs
mkdir -p $VIRAL_CONTIGS_DIR

COPHSE_DIR=$SCRATCH/ete2021_V2/4_cophse
mkdir -p $COPHSE_DIR

R_SCRIPTS=/home/$USERNAME/R_scripts

##########################################################
################### Install software #####################
##########################################################

# # Install GeneMark
# # More information: http://exon.gatech.edu/index.html
# # Download MetaGeneMark v3.38 v.Linux 64 and its key from http://exon.gatech.edu/GeneMark/license_download.cgi (with wget)
# tar xf MetaGeneMark_linux_64.tar.gz
# gunzip gm_key_64.gz
# cp gm_key_64 ~/.gm_key

MGM_DIR=/home/$USERNAME/MetaGeneMark_linux_64/mgm

# # Install seqmagick (Python package)
ENV=/home/$USERNAME/ENV
# virtualenv --no-download ENV # If not done already
source $ENV/bin/activate
# pip install seqmagick

##########################################################
################# Run MetaGeneMark (RNA) #################
##########################################################

CONTIGS_DIR=$VIRAL_CONTIGS_DIR/$NUCL_ACID
cd $CONTIGS_DIR

# Read CheckV output
cp $R_SCRIPTS/read_checkV_output.R $DIRECTORY
R CMD BATCH read_checkV_output.R

# Run MGM (Predict protein-coding regions in contigs)
$MGM_DIR/gmhmmp \
	-m $MGM_DIR/MetaGeneMark_v1.mod \
	-o sequence.lst \
	-A ${NUCL_ACID}_mgm.faa \
	${NUCL_ACID}_CheckV_filtered_viruses.fasta

##########################################################
##### Perform HMM searches against the viral profiles ####
##########################################################

cd $COPHSE_DIR
mkdir -p $NUCL_ACID
cd $NUCL_ACID

# Run hmmer
hmmsearch -E 1e-2 --cpu=64 $COPHSE_DIR/clusters/vir_models.hmm ${NUCL_ACID}_mgm.faa > ${NUCL_ACID}_mgm.out
cp ${NUCL_ACID}_mgm.out ${NUCL_ACID}_hmm.out

# # Copy entire directory
# cp -r $VIRAL_CL/clusters* $COPHSE_DIR/$NUCL_ACID

# Read hmmer output
cp $R_SCRIPTS/parse_hmmer_out.R $COPHSE_DIR
R CMD BATCH parse_hmmer_out.R

# Rename seqs
cp $R_SCRIPTS/rename_RefSeq.R $COPHSE_DIR
R CMD BATCH rename_RefSeq.R

##########################################################
##########################################################
##########################################################
