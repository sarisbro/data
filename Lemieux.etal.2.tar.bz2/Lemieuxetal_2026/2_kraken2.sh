#!/bin/bash
#SBATCH --nodes=1                           # Number of nodes requested
#SBATCH --ntasks=40                         # Number of tasks requested. Has to be a multiple of 40.
#SBATCH -t 0-1:00:0                         # How long will your job run for?
#SBATCH -J Kraken2                		# Name of job

##########################################################
##########################################################
##########################################################

# This script was used in Lemieux et al. (2026) to filter-
# out contigs identified as "Bacterial," "Archaeal," and
# "Eukaryotic" with Kraken2.

##########################################################

# Adapted for Trillium

# Load modules
# module load CCEnv arch/avx512 StdEnv/2020
module load StdEnv/2020
module load r/4.4.0
# module load blast+/2.14.1
module load python/3.13.2
module load kraken2/2.1.3

# To modify
USERNAME=username # To modify
DIRECTORY=/home/$USERNAME/scratch/ete2021_V2
NUCL_ACID=RNA # To modify
CUTOFF_VALUE=300 # To modify

SCRATCH=/home/$USERNAME/scratch

VIRAL_CONTIGS_DIR=/home/$USERNAME/scratch/ete2021_V2/3_viral_contigs
mkdir -p $VIRAL_CONTIGS_DIR

R_SCRIPTS=/home/$USERNAME/R_scripts

##########################################################
############# Install software/databases #################
##########################################################

STANDARD_DB=$SCRATCH/dbs/standard_kraken_db
KRAKENTOOLS=$SCRATCH/KrakenTools

# # Download the standard kraken2 database
# mkdir -p $STANDARD_DB
# cd $STANDARD_DB
# wget https://genome-idx.s3.amazonaws.com/kraken/k2_standard_20250402.tar.gz
# tar xf k2_standard_20250402.tar.gz
#
# # Download t# he extract_kraken_reads.py script from KrakenTools
# mkdir -p $KRAKENTOOLS
# cd $STANDARD_DB
# wget https://raw.githubusercontent.com/jenniferlu717/KrakenTools/refs/heads/master/extract_kraken_reads.py

##########################################################
################### Run Kraken2 (RNA) ####################
##########################################################

# !!! Only have to do it once for DNA OR for RNA !!!

# Combine soil/lake sediments samples together, but separate between RNA and RNA
cd $DIRECTORY

cp $R_SCRIPTS/combine_samples.R $DIRECTORY
R CMD BATCH combine_samples.R

##########################################################

CONTIGS_DIR=$VIRAL_CONTIGS_DIR/$NUCL_ACID
cd $CONTIGS_DIR

# Run Kraken2
kraken2 classify --db $STANDARD_DB \
	--unclassified unclassified_${NUCL_ACID}_${CUTOFF_VALUE}.fasta \
	--classified classified_${NUCL_ACID}_${CUTOFF_VALUE}.fasta \
	--output output_${NUCL_ACID}_${CUTOFF_VALUE}.txt \
	--report report_${NUCL_ACID}_${CUTOFF_VALUE}.txt \
	${NUCL_ACID}_${CUTOFF_VALUE}_cutoff_contigs.fasta

# Problem with kraken2 report: does not output the rank codes for root and domains
# Have to do it for Root (add R in 4th column) and domains (2 -> D)
cp $R_SCRIPTS/fix_kraken_report $DIRECTORY
R CMD BATCH fix_kraken_report.R

# Remove contigs identified as "Bacterial", "Archaeal", and "Eukaryota"
# taxIDs: 2 (Bacteria), 2157 (Archaea), 2759 (Eukaryota)
python $KRAKENTOOLS/extract_kraken_reads.py \
	-k output_${NUCL_ACID}_${CUTOFF_VALUE}.txt \
	-s classified_${NUCL_ACID}_${CUTOFF_VALUE}.fasta \
	-o filtered_classified_${NUCL_ACID}_${CUTOFF_VALUE}.fasta \
	-r report_fixed_${NUCL_ACID}_${CUTOFF_VALUE}.txt \
	-t 2 2157 2759 --exclude --include-children

# Quality control
python $KRAKENTOOLS/extract_kraken_reads.py \
	-k output_${NUCL_ACID}_${CUTOFF_VALUE}.txt \
	-s classified_${NUCL_ACID}_${CUTOFF_VALUE}.fasta \
	-o bacteria_classified_${NUCL_ACID}_${CUTOFF_VALUE}.fasta \
	-r report_fixed_${NUCL_ACID}_${CUTOFF_VALUE}.txt \
	-t 2 2157 2759 --include-children

##########################################################
################### Run Kraken2 (DNA) ####################
##########################################################

# # !!! Only have to do it once for DNA OR for RNA !!!
#
# # Combine soil/lake sediments samples together, but separate between RNA and RNA
# cd $DIRECTORY
#
# cp $R_SCRIPTS/combine_samples.R $DIRECTORY
# R CMD BATCH combine_samples.R

##########################################################

NUCL_ACID=DNA

CONTIGS_DIR=$VIRAL_CONTIGS_DIR/$NUCL_ACID
cd $CONTIGS_DIR

# Run Kraken2
kraken2 classify --db $STANDARD_DB \
	--unclassified unclassified_${NUCL_ACID}_${CUTOFF_VALUE}.fasta \
	--classified classified_${NUCL_ACID}_${CUTOFF_VALUE}.fasta \
	--output output_${NUCL_ACID}_${CUTOFF_VALUE}.txt \
	--report report_${NUCL_ACID}_${CUTOFF_VALUE}.txt \
	${NUCL_ACID}_${CUTOFF_VALUE}_cutoff_contigs.fasta

# Problem with kraken2 report: does not output the rank codes for root and domains
# Have to do it for Root (add R in 4th column) and domains (2 -> D)
cp $R_SCRIPTS/fix_kraken_report $DIRECTORY
R CMD BATCH fix_kraken_report.R

# Remove contigs identified as "Bacterial", "Archaeal", and "Eukaryota"
# taxIDs: 2 (Bacteria), 2157 (Archaea), 2759 (Eukaryota)
python $KRAKENTOOLS/extract_kraken_reads.py \
	-k output_${NUCL_ACID}_${CUTOFF_VALUE}.txt \
	-s classified_${NUCL_ACID}_${CUTOFF_VALUE}.fasta \
	-o filtered_classified_${NUCL_ACID}_${CUTOFF_VALUE}.fasta \
	-r report_fixed_${NUCL_ACID}_${CUTOFF_VALUE}.txt \
	-t 2 2157 2759 --exclude --include-children

# Quality control
python $KRAKENTOOLS/extract_kraken_reads.py \
	-k output_${NUCL_ACID}_${CUTOFF_VALUE}.txt \
	-s classified_${NUCL_ACID}_${CUTOFF_VALUE}.fasta \
	-o bacteria_classified_${NUCL_ACID}_${CUTOFF_VALUE}.fasta \
	-r report_fixed_${NUCL_ACID}_${CUTOFF_VALUE}.txt \
	-t 2 2157 2759 --include-children

##########################################################
##########################################################
##########################################################
