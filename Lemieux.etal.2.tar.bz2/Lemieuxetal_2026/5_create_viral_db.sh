#!/bin/bash
#SBATCH --nodes=1                           # Number of nodes requested
#SBATCH --ntasks=40                         # Number of tasks requested. Has to be a multiple of 40.
#SBATCH -t 0-23:00:0                         # How long will your job run for?
#SBATCH -J create_db               		# Name of job

##########################################################
##########################################################
##########################################################

# This script was used in Lemieux et al. (2026) to create
# the viral reference database.

##########################################################

# Adapted for Trillium

# # Load modules
# module load CCEnv arch/avx512 StdEnv/2020
module load StdEnv/2020
module load r/4.3.1
module load cd-hit/4.8.1

# To modify
USERNAME=username # To modify
DIRECTORY=/home/$USERNAME/scratch/ete2021_V2
NUCL_ACID=RNA # To modify
CUTOFF_VALUE=300 # To modify

SCRATCH=/home/$USERNAME/scratch

VIRAL_CONTIGS_DIR=$SCRATCH/ete2021_V2/3_viral_contigs
mkdir -p $VIRAL_CONTIGS_DIR

COPHSE_DIR=$SCRATCH/ete2021_V2/4_cophse
mkdir -p $COPHSE_DIR

R_SCRIPTS=/home/$USERNAME/R_scripts

##########################################################
################### Install software #####################
##########################################################

# Create directory for viral protein DB
# Will contain RefSeq's viral DB, GenBank viral DB, and IMG/VR V4
VIRAL_PROT=$SCRATCH/dbs/viral_prot
# mkdir -p $VIRAL_PROT
# cd $VIRAL_PROT

# # Download RefSeq's viral DB
# wget ftp://ftp.ncbi.nlm.nih.gov/refseq/release/viral/viral.*.protein.faa.gz
#
# # Download GenBank viral DB
# wget ftp://ftp.ncbi.nlm.nih.gov/ncbi-asn1/protein_fasta/gbvrl*.fsa_aa.gz
#
# # Download IMG/VR v4.1 DB (High-confidence genomes only)
# # Download IMG/VR v4.1 from https://genome.jgi.doe.gov/portal/IMG_VR/IMG_VR.home.html
# # An account has to be created
# gunzip *.gz
#
# # Remove stop codons (* and -) found in IMG/VR
# tr -d "*" < IMGVR_all_proteins-high_confidence.faa > IMGVR_all_proteins-high_confidence_nostop.faa
# sed '/^>/! s/-//g' IMGVR_all_proteins-high_confidence_nostop.faa > IMGVR_all_proteins-high_confidence_nostop_2.faa
#
# # Concatenate
# cat gbvrl*aa *.protein.faa *_nostop_2.faa > all_viral_tmp.faa
#
# module load StdEnv/2023 seqtk
# seqtk seq -l0 all_viral_tmp.faa > all_viral.faa

##########################################################
########### Create viral clusters/HMM profiles ###########
##########################################################

VIRAL_CL=$COPHSE_DIR/viral_clusters
mkdir -p $VIRAL_CL
cd $VIRAL_CL

cp $VIRAL_PROT/all_viral.faa $VIRAL_CL

# # Cluster viral seqs at 90% similarity
cd-hit -i all_viral.faa -o all_viral_cd_hit -c .90 -T 0 -M 0 -d 0

# Parse CD-HIT results
cp $R_SCRIPTS/parse_cdhit.R $VIRAL_CL
R CMD BATCH parse_cdhit.R

# Copy entire directory
cp -r $VIRAL_CL/* $COPHSE_DIR

##########################################################
##########################################################
##########################################################
