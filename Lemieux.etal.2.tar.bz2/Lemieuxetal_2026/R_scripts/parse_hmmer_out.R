
#################################################################################################
#################################################################################################
#################################################################################################

# Audrée Lemieux
# Updated on October 18, 2025

# Analyzes the HMM searches output file from HMMER to create the CoPHSe

#################################################################################################

# Load libraries
library(stringr)
library(seqinr)

# To modify
today <- "251107"

#################################################################################################
#################################################################################################

# Data
main_dir <- getwd()
nucl <- strsplit(getwd(), "/")[[1]][length(strsplit(getwd(), "/")[[1]])]
output_file <- paste0(nucl, "_hmm.out")
lines <- readLines(output_file)

data_list <- list()
pos <- grep("Query:.*Cluster_", lines)
for (i in 1:length(pos)){
  print(paste0("--- Now doing ", i, " out of ", length(pos), " ---"))
  tmp <- NULL
  id <- strsplit(str_squish(lines[pos[i]]), " ")[[1]][2]
  
  if (!grepl("No hits detected that satisfy reporting thresholds", lines[pos[i] + 6])){
    newline <- list()
    print("Hits found!")
    if (i != length(pos)){
      tmp_pos <- (pos[i] + 5):(pos[i + 1] - 1)
    }else{
      tmp_pos <- (pos[i] + 5):(length(lines) - 1)
    }
    tmp_pos <- tmp_pos[1]:(tmp_pos[which(lines[tmp_pos] == "")[1]] - 1) # Read all positions until the first ""
    
    for (j in 1:length(tmp_pos)){
      tmp2 <- strsplit(str_squish(lines[tmp_pos[j]]), " ")[[1]]
      evalue <- as.numeric(tmp2[1]) # e-value for the full sequence
      hit_name <- strsplit(tmp2[9], "\\|")[[1]][1]
      seq_name <- tmp2[10]
      newline[[j]] <- cbind(cluster = id, evalue = evalue, hit_name = hit_name, seq_name = seq_name)
    }
    data_list[[id]] <- as.data.frame(do.call(rbind, newline))
  }
}
data_df <- do.call(rbind, data_list)
rm(evalue, hit_name, i, id, j, tmp2, tmp, seq_name, tmp_pos) # Clean space
save.image(paste0(today, "_", nucl, "_hmmer_out.RData"))

# Data to KEEP depending on the e-value
evalues <- c(10^-2, 10^-5, 10^-10, 10^-15, 10^-20)
to_keep <- list()
# clusters_to_keep <- list()
for (i in evalues){
  tmp <- tmp2 <- tmp3 <- tmp4 <- NULL
  count <- 1
  
  for (j in 1:length(data_list)){
    pos2 <- which(as.numeric(data_list[[j]]$evalue) < i) # < than the e-value threshold
    if (length(pos2) > 0){
      tmp[[count]] <- data_list[[j]][pos2,]
      count <- count + 1
      tmp2 <- c(tmp2, names(data_list)[j]) # Name of cluster
      tmp3 <- c(tmp3, unique(data_list[[j]][pos2,]$cluster))
      tmp4 <- c(tmp4, data_list[[j]])
    }
  }
  names(tmp) <- tmp3
  to_keep[[as.character(i)]] <- tmp
  # clusters_to_keep[[as.character(i)]] <- tmp2
}
rm(tmp, i, j, pos2, tmp2, count, tmp3) # Clean space
save.image(paste0(today, "_", nucl, "_hmmer_out.RData"))

#################################################################################################

# Extract seqs from Clusters faa file
system("mkdir -p clusters_2")
suppressMessages(sapply(evalues, function(x){system(paste0("mkdir -p clusters_2/", x))})) # Create directories for each evalue

mgm_faa <- read.fasta(paste0(nucl, "_mgm.faa"))
mgm_faa_names <- names(mgm_faa)
mgm_faa_names <- strsplit(mgm_faa_names, "\\|")
mgm_faa_names <- sapply(mgm_faa_names, "[", 1)
min_nb_hits <- 1
min_nb_seqs <- 3
save.image(paste0(today, "_", nucl, "_hmmer_out.RData"))

dir2 <- "/home/username/scratch/ete2021_V2/4_cophse/viral_clusters"
mgm_seq2save <- list()

# Check which clusters to keep for each evalue
for (i in evalues){
  print("--- Now checking which clusters to keep ---")
  print(paste0("--- Now doing evalues < ", i, " ---"))
  
  cluster_names <- names(to_keep[[as.character(i)]])
  print(length(cluster_names))
  
  # Create directories
  system(paste0("mkdir -p clusters_2/", i, "/hits_faa_retree"))
  system(paste0("mkdir -p clusters_2/", i, "/hits_aln_retree"))
  system(paste0("mkdir -p clusters_2/", i, "/hits_trimaln_retree"))
  system(paste0("mkdir -p clusters_2/", i, "/hits_trees_retree"))
  
  for (j in 1:length(cluster_names)){
    print(paste0("--- Now doing cluster ", j, " out of ", length(cluster_names), " ---"))
    tmp <- to_keep[[as.character(i)]][[cluster_names[j]]] # Genes
    tmp_faa <- read.fasta(paste0(dir2, "/clusters/faa/", cluster_names[j], ".faa")) # Refseq sequences
    
    if (nrow(tmp) >= min_nb_seqs & length(tmp_faa) >= min_nb_hits){ # Keep that cluster
      tmp_tosave <- NULL
      for (k in 1:nrow(tmp)){
        tmp_tosave <- c(tmp_tosave, which(mgm_faa_names == tmp$hit_name[k]))
      }
      mgm_seq2save[[as.character(i)]][[cluster_names[j]]] <- tmp_tosave
    }
  }
  print(length(mgm_seq2save[[as.character(i)]]))
  save.image(paste0(today, "_", nucl, "_hmmer_out.RData"))
}

# Create alignments
for (i in evalues){
  print(paste0("--- Now doing evalues < ", i, " ---"))
  
  cluster_names <- names(mgm_seq2save[[as.character(i)]])
  
  for (j in 1:length(cluster_names)){
    print(paste0("--- Now doing cluster ", j, " out of ", length(cluster_names), " ---"))
    tmp <- to_keep[[as.character(i)]][[cluster_names[j]]] # Genes
    tmp_faa <- read.fasta(paste0(dir2, "/clusters/faa/", cluster_names[j], ".faa")) # Refseq sequences
    names(tmp_faa) <- gsub(":", "_", names(tmp_faa))
    pos <- mgm_seq2save[[as.character(i)]][[j]]
    
    # Write RefSeq + MGM sequences
    write.fasta(c(tmp_faa, mgm_faa[pos]), c(names(tmp_faa), tmp$hit_name), paste0("clusters_2/", i, "/hits_faa_retree/", cluster_names[j], ".faa"))
    
    # Align them all
    system(paste0("mafft --retree 1 --localpair clusters_2/", i, "/hits_faa_retree/", cluster_names[j], ".faa > clusters_2/", i, "/hits_aln_retree/", cluster_names[j], ".faa"))
    system(paste0("trimal -in clusters_2/", i, "/hits_aln_retree/", cluster_names[j],".faa -out clusters_2/", i, "/hits_trimaln_retree/", cluster_names[j], ".faa -gappyout"))
    
    # Reconstruct tree
    system(paste0("FastTree -lg clusters_2/", i, "/hits_trimaln_retree/", cluster_names[j],".faa > clusters_2/", i, "/hits_trees_retree/", cluster_names[j], ".trees"))
  }
}
save.image(paste0(today, "_", nucl, "_hmmer_out.RData"))

# Check if some trees failed
for (i in evalues){
  dir <- paste0(getwd(), "/clusters_2/", i, "/hits_trees_retree")
  hits_trees_files <- list.files(dir)
  to_redo <- NULL
  
  for (j in 1:length(hits_trees_files)){
    if (j%%1000 == 0){
      print(paste0("--- Now doing ", j, " out of ", length(hits_trees_files), " ---"))
    }
    tmp <- paste0(dir, "/", hits_trees_files[j])
    size <- file.info(tmp)$size
    
    if (size <= 0){
      to_redo <- c(to_redo, hits_trees_files[j])
      print(paste0("*** To redo: ", hits_trees_files[j], " (size ", size, ") ***"))
    }
  }
  
  if (length(to_redo) > 0){
    cluster_names <- gsub(".trees", "", to_redo)
    
    # Create alignments
    for (k in 1:length(cluster_names)){
      print(paste0("--- Now doing cluster ", k, " out of ", length(cluster_names), " ---"))
      tmp <- to_keep[[as.character(i)]][[cluster_names[k]]] # Genes
      tmp_faa <- read.fasta(paste0(dir2, "/clusters/faa/", cluster_names[k], ".faa")) # Refseq sequences
      names(tmp_faa) <- gsub(":", "_", names(tmp_faa))
      pos <- mgm_seq2save[[as.character(i)]][[cluster_names[k]]]
      
      # Write RefSeq + MGM sequences
      write.fasta(c(tmp_faa, mgm_faa[pos]), c(names(tmp_faa), tmp$hit_name), paste0("clusters_2/", i, "/hits_faa_retree/", cluster_names[k], ".faa"))
      
      # Align them all
      system(paste0("mafft --retree 1 --localpair clusters_2/", i, "/hits_faa_retree/", cluster_names[k], ".faa > clusters_2/", i, "/hits_aln_retree/", cluster_names[k], ".faa"))
      system(paste0("trimal -in clusters_2/", i, "/hits_aln_retree/", cluster_names[k],".faa -out clusters_2/", i, "/hits_trimaln_retree/", cluster_names[k], ".faa -gappyout"))
      
      # Reconstruct tree
      system(paste0("FastTree -lg -gamma clusters_2/", i, "/hits_trimaln_retree/", cluster_names[k],".faa > clusters_2/", i, "/hits_trees_retree/", cluster_names[k], ".trees"))
    }
    
    save.image(paste0(today, "_", nucl, "_hmmer_out.RData"))
  }
}

#################################################################################################
#################################################################################################

q(save = "no")

#################################################################################################
#################################################################################################
#################################################################################################
