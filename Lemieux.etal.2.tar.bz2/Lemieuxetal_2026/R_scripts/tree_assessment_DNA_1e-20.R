
#################################################################################################
#################################################################################################
#################################################################################################

# Audrée Lemieux
# Updated on January 19, 2026

# Assesses the CoPHSe's genes and reference sequences mean branch lengths of RNA trees (1e-20).

#################################################################################################

# Load libraries
library(ape)
library(dplyr)
library(reshape2)
library(ggplot2)
library(ggpubr)
library(dunn.test)
library(gridExtra)

# To modify
evalue <- "1e-20"
today <- "260218"
nucl_acid <- "DNA"
directory <- paste0("clusters_2/", evalue, "/hits_trees_fullNames")
min_nb_seqs <- 3
min_nb_refseqs <- 1

#################################################################################################
#################################################################################################

types <- list.files(directory)
raw_data <- list() # Raw data
data <- list() # Summary values (means of branch lengths)
summary_lst <- list()
summary_df <- NULL

for (i in 1:length(types)){
  print(paste0("--- Now doing type ", types[i], " ---"))
  tmp_dir <- paste0(directory, "/", types[i])
  tree_lst <- list.files(tmp_dir)
  names <- gsub(".trees", "", tree_lst)
  names <- gsub(paste0(types[i], "_"), "", names)
  raw <- list() # Store raw data
  summary_values <- list() # Store summary values (mean branch lenghts)
  
  for (j in 1:length(tree_lst)){
    print(paste0("--- Now doing tree ", j, " out of ", length(tree_lst), " ---"))
    tree <- read.tree(paste0(tmp_dir, "/", tree_lst[j]))
    tip_labels <- tree$tip.label
    ngene_labels <- length(grep("gene_", tip_labels))
    nrefseqs_labels <- length(tip_labels) - ngene_labels
    
    # Check if ngenes >= 3 and nrefseqs >= 1
    if (ngene_labels >= min_nb_seqs & nrefseqs_labels >= min_nb_refseqs){
      # Initialize tree2 variable
      tree2 <- NULL
      
      # Reroot the tree
      MRCA <- getMRCA(tree, tree$tip.label[grepl("gene_", tree$tip.label)]) # Find common ancestor
      refseq <- tree$tip.label[!grepl("gene_", tree$tip.label)]
      tryCatch(
        {tree2 <- root(tree, refseq)}, error = function(e){print(paste0(tree_lst[j], ": The specified group is not monophyletic (can't put all sequences in a clade)"))}
      )
      
      # Calculate the mean seqs lengths for our seqs/refseqs
      if (length(tree2) != 0){
        # Get the length of the branch leading to the clade of our sequences
        MRCA_2 <- getMRCA(tree2, tree2$tip.label[grepl("gene_", tree2$tip.label)])
        length_br_clade <- tree2$edge.length[which(tree2$edge[,2] == MRCA_2)]  # Get the length of the branch leading to the clade
        
        # Get the length of all the branches inside the clade
        seqs_lengths <- tree2$edge.length[which.edge(tree2, tree2$tip.label[grepl("gene_", tree2$tip.label)])] # gene seqs
        refseqs_lengths <- tree2$edge.length[which.edge(tree2, tree2$tip.label[!grepl("gene_", tree2$tip.label)])] # reference seqs
        
      }else{ # If the clade is non-monophyletic
        length_br_clade <- ""
        # Get the lengths of our sequences
        tree_seqs <- drop.tip(tree, setdiff(1:length(tree$tip.label), grep("^gene_", tree$tip.label)))
        seqs_lengths <- tree_seqs$edge.length[which.edge(tree_seqs, tree_seqs$tip.label[grepl("gene_", tree_seqs$tip.label)])]
        
        # Get the lengths of the reference sequences
        tree_refseqs <- drop.tip(tree, grep("^gene_", tree$tip.label))
        refseqs_lengths <- tree_refseqs$edge.length[which.edge(tree_refseqs, tree_refseqs$tip.label[!grepl("gene_", tree_refseqs$tip.label)])]
      }
      
      # Save "raw data" in a list
      raw[[1]] <- length_br_clade
      raw[[2]] <- seqs_lengths
      raw[[3]] <- refseqs_lengths
      names(raw) <- c("length_br_clade", "seqs_lengths", "refseqs_lengths")
      raw_data[[types[i]]][[names[j]]] <- raw
      
      # Then, save the summary values (mean branch lengths) in another list
      summary_values[[1]] <- length_br_clade
      summary_values[[2]] <- mean(seqs_lengths)
      summary_values[[3]] <- mean(refseqs_lengths)
      names(summary_values) <- c("length_br_clade", "mean_seqs_lengths", "mean_refseqs_lengths")
      data[[types[i]]][[names[j]]] <- summary_values
    }
  }
  
  summary_lst[[types[i]]] <- as.data.frame(do.call(rbind, data[[types[i]]]))
  summary_lst[[types[i]]] <- as.data.frame(cbind(
    type = types[i], cluster_name = names(data[[types[i]]]), summary_lst[[types[i]]]
  ))
  row.names(summary_lst[[types[i]]]) <- NULL
}
summary_df <- as.data.frame(do.call(rbind, summary_lst))
row.names(summary_df) <- NULL

# Clean space
rm(i, j, length_br_clade, MRCA, MRCA_2, names, raw, refseq, refseqs_lengths, seqs_lengths,
   tmp_dir, tree, tree_lst, tree_refseqs, tree_seqs, tree2, tip_labels,
   ngene_labels, nrefseqs_labels)

# Save image
save.image(paste0(today, "_", nucl_acid, "_", evalue, "_tree_assessment.RData"))

#################################################################################################
#################################################################################################

q(save = "no")

#################################################################################################
#################################################################################################
#################################################################################################
