
#################################################################################################
#################################################################################################
#################################################################################################

# Audrée Lemieux
# Updated on July 29, 2025

# Analyzes the clustering file from CD-HIT of the viral reference sequences 

#################################################################################################

# Load libraries
library(seqinr)
library(doParallel)
library(dplyr)
library(ggplot2)
library(data.table)

# To modify
min_nb_seq <- 10 # Minimum number of refseqs (to keep the cluster)
max_nb_seq <- 100 # Maximum number of refseqs (to keep the cluster)
nseqs_file <- 100000 # Number of clusters per smaller file

#################################################################################################
#################################################################################################

                                    ######################
                                    # Read CD-HIT output #
                                    ######################

# registerDoParallel(cores=80)

# Import CD-HIT output
infile <- readLines("all_viral_cd_hit.clstr")
nLines <- length(infile)

# Find positions of clusters in the file
pos_cluster <- grep("^>Cluster", infile)
cluster_names <- gsub(">", "", infile[pos_cluster])

# More than 31.7M+ clusters
# Split in small files of 100,000 seqs each
remainder <- length(cluster_names)%%nseqs_file
int_division <- length(cluster_names)%/%nseqs_file

for (i in 1:(int_division + 1)){
  print(paste0("-- Now doing file ", i, " out of ", length(cluster_files), " --- "))
  pos1 <- (nseqs_file * (i - 1)) + 1
  pos1 <- pos_cluster[pos1]
  if (i != (int_division + 1)){
    pos2 <- i*nseqs_file
    pos2 <- pos_cluster[pos2 + 1] - 1
  }else{
    pos2 <- nLines
  }
  writeLines(infile[pos1:pos2], paste0("cd_hit_", i, ".clstr"))
}
rm(infile, i, pos1, pos2, pos_cluster, cluster_names, nLines) # Clean space and remove "infile"

# Get the information for each cluster
cluster_info <- NULL
cluster_files <- list.files(path = getwd(), pattern = "^cd_hit_")

for (i in 1:length(cluster_files)){
  newline <- NULL
  print(paste0("-- Now doing file cd_hit_", i, ".clstr --- "))
  tmp <- readLines(paste0("cd_hit_", i, ".clstr"))

  pos_cluster <- grep("^>Cluster", tmp) # pos of clusters
  cluster_names <- gsub(">", "", tmp[pos_cluster]) # names of clusters

  for (j in 1:length(cluster_names)){
    pos1 <- pos_cluster[j] + 1
    if (j != length(cluster_names)){
      pos2 <- pos_cluster[j + 1] - 1
    }else{
      pos2 <- length(tmp)
    }
    nb_hits <- length(pos1:pos2)
    newline[[j]] <- cbind(
        filename = paste0("cd_hit_", i, ".clstr"),
        cluster_name = cluster_names[j],
        pos1 = pos1,
        pos2 = pos2,
        nb_hits = nb_hits
      )
    # cluster_info <- rbind(cluster_info, cbind(
    #   filename = cluster_files[i],
    #   cluster_name = cluster_names[j],
    #   pos1 = pos1,
    #   pos2 = pos2,
    #   nb_hits = nb_hits
    # ))
  }
  tmp2 <- do.call(rbind, newline)
  tmp2 <- as.data.frame(tmp2)
  cluster_info <- rbind(cluster_info, tmp2)
  tmp <- pos_cluster <- cluster_names <- tmp2 <- NULL
  save.image("viral_cluster.RData") # Save image
}
rm(tmp, pos1, pos2, i, j, nb_hits, pos_cluster, cluster_names, tmp2, newline)
cluster_info <- as.data.frame(cluster_info)
save.image("viral_cluster.RData") # Save image

# Quality control
cluster_info <- distinct(cluster_info)
nclusters <- as.numeric(system("grep \">Cluster \" all_viral_cd_hit.clstr | wc -l", intern = TRUE))
nrow_cluster_info <- nrow(cluster_info)
if (nclusters != nrow_cluster_info){
  # Identify which files are missing
  tmp <- unique(cluster_info$filename)
  all_files <- list.files(path = getwd(), pattern = "^cd_hit_")
  cluster_files <- setdiff(all_files, tmp)

  for (i in 1:length(cluster_files)){
    newline <- NULL
    print(paste0("-- Now doing file ", cluster_files[i], " --- "))
    tmp <- readLines(cluster_files[i])

    pos_cluster <- grep("^>Cluster", tmp) # pos of clusters
    cluster_names <- gsub(">", "", tmp[pos_cluster]) # names of clusters

    for (j in 1:length(cluster_names)){
      pos1 <- pos_cluster[j] + 1
      if (j != length(cluster_names)){
        pos2 <- pos_cluster[j + 1] - 1
      }else{
        pos2 <- length(tmp)
      }
      nb_hits <- length(pos1:pos2)
      newline[[j]] <- cbind(
        filename = cluster_files[i],
        cluster_name = cluster_names[j],
        pos1 = pos1,
        pos2 = pos2,
        nb_hits = nb_hits
      )
      # cluster_info <- rbind(cluster_info, cbind(
      #   filename = cluster_files[i],
      #   cluster_name = cluster_names[j],
      #   pos1 = pos1,
      #   pos2 = pos2,
      #   nb_hits = nb_hits
      # ))
    }
    tmp2 <- do.call(rbind, newline)
    tmp2 <- as.data.frame(tmp2)
    cluster_info <- rbind(cluster_info, tmp2)
    tmp <- pos_cluster <- cluster_names <- NULL
    save.image("viral_cluster.RData") # Save image
  }
  rm(tmp, pos1, pos2, i, j, nb_hits, pos_cluster, cluster_names, tmp2, newline)
  new_cluster_info <- as.data.frame(new_cluster_info)
  save.image("viral_cluster.RData") # Save image
}
cluster_info$nb_hits <- as.numeric(cluster_info$nb_hits)
save.image("viral_cluster.RData") # Save image

# Only analyze cluster with >= min_nb_seqs < max_nb_seqs
to_keep <- cluster_info[which(cluster_info$nb_hits >= min_nb_seq & cluster_info$nb_hits < max_nb_seq),]
cluster_names <- to_keep$cluster_name
cluster_lst <- list()

for (i in 1:length(cluster_names)){
  print(paste0("-- Now doing Cluster ", i, " out of ", length(cluster_names)))
  if (i%%1000 == 0){
    save.image("viral_cluster.RData") # Save image
  }
  
  filename <- to_keep$filename[i]
  pos1 <- as.numeric(to_keep$pos1[i])
  pos2 <- as.numeric(to_keep$pos2[i])
  
  # Quality control
  qc <- system(paste0("sed -n \'", format((pos1 - 1), scientific = FALSE), ",", format((pos1 - 1), scientific = FALSE), "p\' ", filename), intern = TRUE)
  if (qc == paste0(">", cluster_names[i])){
    # The lines of interest are between ">Cluster" lines
    tmp <- system(paste0("sed -n \'", format(pos1, scientific = FALSE), ",", format(pos2, scientific = FALSE), "p\' ", filename), intern = TRUE)
    
    # Edit the lines
    tmp <- gsub(", ", "\t", tmp) # Change ", " to tab
    tmp <- gsub("\\.\\.\\. ", "\t", tmp) # Change "... " to tab
    tmp <- gsub("at |>|%|aa", "", tmp) # Remove "at ", ">", "%", and "aa"
    
    # Read the table
    tmp2 <- as.data.frame(read.table(text = tmp, header = F, sep = "\t"))
    cluster_lst[[cluster_names[i]]] <- tmp2
  }else{
    stop(paste0("FLAG: ", cluster_names[i], "(", i, ") in file \'", filename, "\'"))
  }
}
rm(tmp, tmp2, pos1, pos2) # Clean space
save.image("viral_cluster.RData") # Save image

#################################################################################################

                                        ###################
                                        # Align sequences #
                                        ###################

# Move .clstr files
system("mkdir -p clstr")
system("mv *.clstr clstr/")

# Create directories
system("mkdir -p clusters")
system("mkdir -p clusters/faa")
system("mkdir -p clusters/aln")

# More than 169M viral sequences
# Split in small files of 500,000 seqs each
system("split -d -l 1000000 all_viral.faa")
viral_files <- list.files(pattern = "^x")

newline <- list()
for (i in 1:length(viral_files)){
  print(paste0("--- Now doing file #", i, ": ", viral_files[i], " ---"))
  # Read each file
  lines <- readLines(viral_files[i])
  pos <- grep("^>", lines)
  newline[[i]] <- data.frame(
    filename = viral_files[i],
    seqname = lines[pos],
    pos_name = pos,
    pos_seq = pos + 1
  )
}
viral_info <- do.call(rbind, newline)
rm(i, newline, lines) # Clean space
save.image("viral_cluster.RData") # Save image

# Instant lookup with the data.table package
viral_info$accession <- viral_info$seqname
viral_info$accession <- sub(" .*", "", viral_info$accession)
viral_info$accession <- sub(">", "", viral_info$accession)
dt <- as.data.table(viral_info)
setkey(dt, accession) # builds index (only once)
save.image("viral_cluster.RData") # Save image

# Extract seqs from the fasta file
for (i in 1:length(cluster_lst)){
  # Identify which accession numbers we need
  accessions <- cluster_lst[[i]][,3]
  
  # Write to fasta
  name <- paste0("clusters/faa/", gsub(" ", "_", names(cluster_lst[i])), ".faa")
  system(paste0("touch ", name))
  
  for (j in 1:length(accessions)){
    filename <- as.character(dt[accessions[j], 1]) # 1: file
    pos <- c(as.numeric(dt[accessions[j], 3]), as.numeric(dt[accessions[j], 4])) # 3: pos of name, #4: seq
    system(paste0("sed -n \'", format((pos[1]), scientific = FALSE), ",", format((pos[2]), scientific = FALSE), "p\' ", filename, " >> ", name))
  }
}

# Align & run HMMER
system("mkdir -p clusters/sto")
system("mkdir -p clusters/hmm")

files <- gsub(".faa", "", list.files("clusters/faa")) # Find files
tmp <- strsplit(files, "_")
tmp <- sort(as.numeric(sapply(tmp, "[", 2)))
files <- paste0("Cluster_", tmp)

aln_created <- foreach(i = 1:length(files), .combine = rbind)%dopar%{
  print(paste0("--- Now doing ", i, " out of ", length(files), " (", files[i], ") ---"))
  
  # Just to make sure: check if there are duplicated sequences in the FASTA file (error when extracting the FASTA files)
  tmp <- read.fasta(paste0("clusters/faa/", files[i], ".faa"))
  if (any(duplicated(tmp))){
    tmp <- tmp[-which(duplicated(tmp))]
    write.fasta(tmp, names(tmp),file.out = paste0("clusters/faa/", files[i], ".faa"))
  }
  
  # system(paste0("mafft --maxiterate 1000 --genafpair clusters/faa/", cluster_names2aln[i],".faa > clusters/aln/", cluster_names2aln[i], ".fasta"))
  system(paste0("mafft --retree 1 clusters/faa/", files[i],".faa > clusters/aln/", files[i], ".fasta"))
  system(paste0("seqmagick convert clusters/aln/", files[i], ".fasta clusters/sto/", files[i], ".sto"))
  system(paste0("hmmbuild --amino --cpu 4 clusters/hmm/", files[i], ".hmm clusters/sto/", files[i], ".sto"))
  # return(cluster_names2aln[i])
}
save.image("viral_cluster.RData") # Save image

# Concatenate hmm files
# system("cat clusters/hmm/*.hmm > clusters/vir_models.hmm") # Not working - too many files
directory <- "clusters/hmm"
hmm_files <- list.files(directory, pattern = ".hmm")

for (i in 1:length(hmm_files)){
  print(paste0("--- Now doing ", i, " out of ", length(hmm_files), " (", hmm_files[i], ") ---"))
  # See if the file is empty
  file_size <- file.info(paste0(directory, "/", hmm_files[i]))$size
  if (file_size > 0){
    system(paste0("cat ", directory, "/", hmm_files[i], " >> clusters/vir_models.hmm"))
  }else{
    print(paste0(length(hmm_files), " is empty!"))
  }
}

#################################################################################################
#################################################################################################

q(save = "no")

#################################################################################################
#################################################################################################
#################################################################################################
