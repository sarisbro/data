
#################################################################################################
#################################################################################################
#################################################################################################

# Audrée Lemieux
# Updated on April 3, 2026

# Script for Fig. S3 - boxplots for the branch lengths of the CoPHSe's phylogenetic trees
# Mean seqs lengths vs Mean refseqs lengths (10^-15)

#################################################################################################

# Load libraries
library(dplyr)
library(reshape2)
library(ggplot2)
library(ggpubr)
library(dunn.test)
library(gridExtra)
library(ggpattern)

# To modify
today <- "260403"
evalue <- "1e-15"
directory <- paste0("/Users/Data/ete2021_V2/4_cophse/")
output_dir <- "~/Documents/Figures and tables 2/Figure S3 - mean seqs vs mean refseqs (supp)"

colour_RNA <- "#00B050"
colour_DNA <- "#0070C0"

#################################################################################################
#################################################################################################

# Initialize all variables
all_branch_lengths_df <- NULL
seqs_refseqs_df <- NULL
br_clade_refseqs_df <- NULL
all_branch_lengths_df_supp <- NULL
seqs_refseqs_df_supp <- NULL
br_clade_refseqs_df_supp <- NULL

# Get data for RNA
setwd(paste0(directory, "/RNA"))
file <- list.files(getwd())[grep(paste0("RNA_", evalue, "_data.RData"), list.files(getwd()))]
load(file)

all_branch_lengths_df <- rbind(all_branch_lengths_df, df1)
seqs_refseqs_df <- rbind(seqs_refseqs_df, df2a)
br_clade_refseqs_df <- rbind(br_clade_refseqs_df, df2b)
all_branch_lengths_df_supp <- rbind(all_branch_lengths_df_supp, df3)
seqs_refseqs_df_supp <- rbind(seqs_refseqs_df_supp, df4a)
br_clade_refseqs_df_supp <- rbind(br_clade_refseqs_df_supp, df4b)

# Get data for DNA
setwd(paste0(directory, "/DNA"))
file <- list.files(getwd())[grep(paste0("DNA_", evalue, "_data.RData"), list.files(getwd()))]
load(file)

all_branch_lengths_df <- rbind(all_branch_lengths_df, df1)
seqs_refseqs_df <- rbind(seqs_refseqs_df, df2a)
br_clade_refseqs_df <- rbind(br_clade_refseqs_df, df2b)
all_branch_lengths_df_supp <- rbind(all_branch_lengths_df_supp, df3)
seqs_refseqs_df_supp <- rbind(seqs_refseqs_df_supp, df4a)
br_clade_refseqs_df_supp <- rbind(br_clade_refseqs_df_supp, df4b)

# Add levels
all_branch_lengths_df$nucl_acid <- factor(all_branch_lengths_df$nucl_acid, levels = c("RNA", "DNA"))
seqs_refseqs_df$nucl_acid <- factor(seqs_refseqs_df$nucl_acid, levels = c("RNA", "DNA"))
br_clade_refseqs_df$nucl_acid <- factor(br_clade_refseqs_df$nucl_acid, levels = c("RNA", "DNA"))
all_branch_lengths_df_supp$nucl_acid <- factor(all_branch_lengths_df_supp$nucl_acid, levels = c("RNA", "DNA"))
seqs_refseqs_df_supp$nucl_acid <- factor(seqs_refseqs_df_supp$nucl_acid, levels = c("RNA", "DNA"))
br_clade_refseqs_df_supp$nucl_acid <- factor(br_clade_refseqs_df_supp$nucl_acid, levels = c("RNA", "DNA"))

# Go back to output directory
setwd(output_dir)
rm(df1, df2a, df2b, df3, df4a, df4b, melted_summary_df, file, nucl_acid) # Clean space
save.image(paste0(today, "_CombinedData.RData"))

#################################################################################################

# Remove the outlier value everywhere
pos <- which(all_branch_lengths_df$cluster_name == "Cluster_16296205" & all_branch_lengths_df$nucl_acid == "DNA")
if (length(pos) > 0){
  all_branch_lengths_df <- all_branch_lengths_df[-pos,]
}

pos <- which(br_clade_refseqs_df$cluster_name == "Cluster_16296205" & br_clade_refseqs_df$nucl_acid == "DNA")
if (length(pos) > 0){
  br_clade_refseqs_df <- br_clade_refseqs_df[-pos,]
}

pos <- which(seqs_refseqs_df$cluster_name == "Cluster_16296205" & seqs_refseqs_df$nucl_acid == "DNA")
if (length(pos) > 0){
  seqs_refseqs_df <- seqs_refseqs_df[-pos,]
}

#################################################################################################

# Figure S3a - mean refseqs vs mean seqs: non-phage, phage, unknown (non-phage)
ps3a <- ggplot(seqs_refseqs_df[seqs_refseqs_df$type == "non-phage",], aes(x = branch_length_type, y = value)) +
  geom_boxplot(aes(fill = nucl_acid)) + # Fill by branch length type
  scale_fill_manual(values = c(colour_RNA, colour_DNA)) +
  facet_grid(. ~ nucl_acid) +
  # stat_boxplot(geom = "errorbar") +
  # labs(title = paste0("All measures (", evalue, ")"), x = "", y = "sub/site") +
  labs(title = bquote("Non-phage"~(10^-15)), x = "", y = "sub/site", tag = "A") +
  ylim(c(0,3.5)) +
  theme_bw() +
  theme(axis.ticks.x = element_blank(),
        plot.title = element_text(hjust = 0.5, size = 13),
        text = element_text(size = 10.5),
        plot.tag = element_text(size = 15, face = "bold"))
ps3a
# ggsave(paste0("figures/", evalue, "/", nucl_acid, "_seqs_refseqs_", evalue, "_trees.pdf"), plot = ps3, width = 13)

# Get stats
stats_df_2 <- seqs_refseqs_df[seqs_refseqs_df$type == "non-phage",]
stats_df_2$variable <- paste0(stats_df_2$branch_length_type, "_", stats_df_2$nucl_acid)
sink(paste0("non-phage_", evalue, "seqs_refseqs_dunntest.txt"))
dunn.test(stats_df_2$value, stats_df_2$variable, method = "bh", altp = TRUE, list = TRUE)
sink()
rm(stats_df_2) # Clean space

#################################################

# Figure S3b - mean refseqs vs mean seqs: phage, phage, unknown (phage)
ps3b <- ggplot(seqs_refseqs_df[seqs_refseqs_df$type == "phage",], aes(x = branch_length_type, y = value)) +
  geom_boxplot(aes(fill = nucl_acid)) + # Fill by branch length type
  scale_fill_manual(values = c(colour_RNA, colour_DNA)) +
  facet_grid(. ~ nucl_acid) +
  # stat_boxplot(geom = "errorbar") +
  # labs(title = paste0("All measures (", evalue, ")"), x = "", y = "sub/site") +
  labs(title = bquote("Phage"~(10^-15)), x = "", y = "sub/site", tag = "B") +
  ylim(c(0,3.5)) +
  theme_bw() +
  theme(axis.ticks.x = element_blank(),
        plot.title = element_text(hjust = 0.5, size = 13),
        text = element_text(size = 10.5),
        plot.tag = element_text(size = 15, face = "bold"))
ps3b
# ggsave(paste0("figures/", evalue, "/", nucl_acid, "_seqs_refseqs_", evalue, "_trees.pdf"), plot = ps3, width = 13)

# Get stats
stats_df_2 <- seqs_refseqs_df[seqs_refseqs_df$type == "phage",]
stats_df_2$variable <- paste0(stats_df_2$branch_length_type, "_", stats_df_2$nucl_acid)
sink(paste0("phage_", evalue, "seqs_refseqs_dunntest.txt"))
dunn.test(stats_df_2$value, stats_df_2$variable, method = "bh", altp = TRUE, list = TRUE)
sink()
rm(stats_df_2) # Clean space

#################################################

# Figure S3c - mean refseqs vs mean seqs: unknown, unknown, unknown (unknown)
ps3c <- ggplot(seqs_refseqs_df[seqs_refseqs_df$type == "unknown",], aes(x = branch_length_type, y = value)) +
  geom_boxplot(aes(fill = nucl_acid)) + # Fill by branch length type
  scale_fill_manual(values = c(colour_RNA, colour_DNA)) +
  facet_grid(. ~ nucl_acid) +
  # stat_boxplot(geom = "errorbar") +
  # labs(title = paste0("All measures (", evalue, ")"), x = "", y = "sub/site") +
  labs(title = bquote("Unknown"~(10^-15)), x = "", y = "sub/site", tag = "C") +
  ylim(c(0,3.5)) +
  theme_bw() +
  theme(axis.ticks.x = element_blank(),
        plot.title = element_text(hjust = 0.5, size = 13),
        text = element_text(size = 10.5),
        plot.tag = element_text(size = 15, face = "bold"))
ps3c
# ggsave(paste0("figures/", evalue, "/", nucl_acid, "_seqs_refseqs_", evalue, "_trees.pdf"), plot = ps3, width = 13)

# Get stats
stats_df_2 <- seqs_refseqs_df[seqs_refseqs_df$type == "unknown",]
stats_df_2$variable <- paste0(stats_df_2$branch_length_type, "_", stats_df_2$nucl_acid)
sink(paste0("unknown_", evalue, "seqs_refseqs_dunntest.txt"))
dunn.test(stats_df_2$value, stats_df_2$variable, method = "bh", altp = TRUE, list = TRUE)
sink()
rm(stats_df_2) # Clean space

#################################################

# Combine panels
grid.arrange(ps3a, ps3b, ps3c, nrow = 3, ncol = 1)
ggsave(paste0(today, "_seqs_refseqs_", evalue, ".pdf"),
       plot = grid.arrange(ps3a, ps3b, ps3c, nrow = 3, ncol = 1),
       width = 7, height = 11)

#################################################################################################
#################################################################################################

# # Report values
# # First, refseqs vs seqs mean branch lengths
# # non-phage
# tmp1 <- seqs_refseqs_df[seqs_refseqs_df$type == "non-phage",]
# for (i in levels(tmp1$nucl_acid)){
#   for (j in levels(tmp1$branch_length_type)){
#     tmp <- tmp1[tmp1$nucl_acid == i & tmp1$branch_length_type == j,]
#     print(paste0(i, " - ", j, ": ", median(na.omit(tmp$value))))
#   }
# }
# 
# # phage
# tmps3 <- seqs_refseqs_df[seqs_refseqs_df$type == "phage",]
# for (i in levels(tmps3$nucl_acid)){
#   for (j in levels(tmps3$branch_length_type)){
#     tmp <- tmps3[tmps3$nucl_acid == i & tmps3$branch_length_type == j,]
#     print(paste0(i, " - ", j, ": ", median(na.omit(tmp$value))))
#   }
# }
# 
# # unknown
# tmp3 <- seqs_refseqs_df[seqs_refseqs_df$type == "unknown",]
# for (i in levels(tmp3$nucl_acid)){
#   for (j in levels(tmp3$branch_length_type)){
#     tmp <- tmp3[tmp3$nucl_acid == i & tmp3$branch_length_type == j,]
#     print(paste0(i, " - ", j, ": ", median(na.omit(tmp$value))))
#   }
# }

#################################################################################################
#################################################################################################

q(save = "no")

#################################################################################################
#################################################################################################
#################################################################################################
