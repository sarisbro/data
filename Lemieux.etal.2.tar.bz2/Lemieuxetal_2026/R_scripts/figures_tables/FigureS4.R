
#################################################################################################
#################################################################################################
#################################################################################################

# Audrée Lemieux
# Updated on April 3, 2026

# Script for Fig. S4 - boxplots for the branch lengths of the CoPHSe's phylogenetic trees
# Mean seqs lengths vs Mean refseqs lengths (10^20 and 10^-15)
# Non-phage + Unknown, Phage + Unknown

#################################################################################################

# Load libraries
library(dplyr)
library(reshape2)
library(ggplot2)
library(ggpubr)
library(dunn.test)
library(gridExtra)
library(ggpattern)

# To modify
today <- "260403"
# evalue <- "1e-15"
directory <- paste0("/Users/Data/ete2021_V2/4_cophse/")
output_dir <- "~/Documents/Figures and tables 2/Figure S4 - mean seqs vs mean refseqs (supp)"
filename_1e20 <- "260218_CombinedData_1e-20.RData" # Done in previous figures
filename_1e15 <- "260304_CombinedData_1e-15.RData" # Done in previous figures

colour_RNA <- "#00B050"
colour_DNA <- "#0070C0"

#################################################################################################
#################################################################################################

# # Initialize all variables
# all_branch_lengths_df <- NULL
# seqs_refseqs_df <- NULL
# br_clade_refseqs_df <- NULL
# all_branch_lengths_df_supp <- NULL
# seqs_refseqs_df_supp <- NULL
# br_clade_refseqs_df_supp <- NULL
# 
# # Get data for RNA
# setwd(paste0(directory, "/RNA"))
# file <- list.files(getwd())[grep(paste0("RNA_", evalue, "_data.RData"), list.files(getwd()))]
# load(file)
# 
# all_branch_lengths_df <- rbind(all_branch_lengths_df, df1)
# seqs_refseqs_df <- rbind(seqs_refseqs_df, df2a)
# br_clade_refseqs_df <- rbind(br_clade_refseqs_df, df2b)
# all_branch_lengths_df_supp <- rbind(all_branch_lengths_df_supp, df3)
# seqs_refseqs_df_supp <- rbind(seqs_refseqs_df_supp, df4a)
# br_clade_refseqs_df_supp <- rbind(br_clade_refseqs_df_supp, df4b)
# 
# # Get data for DNA
# setwd(paste0(directory, "/DNA"))
# file <- list.files(getwd())[grep(paste0("DNA_", evalue, "_data.RData"), list.files(getwd()))]
# load(file)
# 
# all_branch_lengths_df <- rbind(all_branch_lengths_df, df1)
# seqs_refseqs_df <- rbind(seqs_refseqs_df, df2a)
# br_clade_refseqs_df <- rbind(br_clade_refseqs_df, df2b)
# all_branch_lengths_df_supp <- rbind(all_branch_lengths_df_supp, df3)
# seqs_refseqs_df_supp <- rbind(seqs_refseqs_df_supp, df4a)
# br_clade_refseqs_df_supp <- rbind(br_clade_refseqs_df_supp, df4b)
# 
# # Add levels
# all_branch_lengths_df$nucl_acid <- factor(all_branch_lengths_df$nucl_acid, levels = c("RNA", "DNA"))
# seqs_refseqs_df$nucl_acid <- factor(seqs_refseqs_df$nucl_acid, levels = c("RNA", "DNA"))
# br_clade_refseqs_df$nucl_acid <- factor(br_clade_refseqs_df$nucl_acid, levels = c("RNA", "DNA"))
# all_branch_lengths_df_supp$nucl_acid <- factor(all_branch_lengths_df_supp$nucl_acid, levels = c("RNA", "DNA"))
# seqs_refseqs_df_supp$nucl_acid <- factor(seqs_refseqs_df_supp$nucl_acid, levels = c("RNA", "DNA"))
# br_clade_refseqs_df_supp$nucl_acid <- factor(br_clade_refseqs_df_supp$nucl_acid, levels = c("RNA", "DNA"))
# 
# # Go back to output directory
# setwd(output_dir)
# rm(df1, df2a, df2b, df3, df4a, df4b, melted_summary_df, file, nucl_acid) # Clean space
# save.image(paste0(today, "_CombinedData.RData"))

#################################################################################################

# Load data
load(paste0(directory, "/", filename_1e20)) # 1e-20 first
seqs_refseqs_df_supp_10e20 <- seqs_refseqs_df_supp
br_clade_refseqs_df_supp_10e20 <- br_clade_refseqs_df_supp

load(paste0(directory, "/", filename_1e15)) # 1e-15
seqs_refseqs_df_supp_10e15 <- seqs_refseqs_df_supp
br_clade_refseqs_df_supp_10e15 <- br_clade_refseqs_df_supp

#################################################################################################

# # Remove the outlier value everywhere
pos <- which(br_clade_refseqs_df_supp_10e20$cluster_name == "Cluster_16296205" & br_clade_refseqs_df_supp_10e20$nucl_acid == "DNA")
if (length(pos) > 0){
  br_clade_refseqs_df_supp_10e20 <- br_clade_refseqs_df_supp_10e20[-pos,]
}

pos <- which(br_clade_refseqs_df_supp_10e15$cluster_name == "Cluster_16296205" & br_clade_refseqs_df_supp_10e15$nucl_acid == "DNA")
if (length(pos) > 0){
  br_clade_refseqs_df_supp_10e15 <- br_clade_refseqs_df_supp_10e15[-pos,]
}

pos <- which(seqs_refseqs_df_supp_10e20$cluster_name == "Cluster_16296205" & seqs_refseqs_df_supp_10e20$nucl_acid == "DNA")
if (length(pos) > 0){
  seqs_refseqs_df_supp_10e20 <- seqs_refseqs_df_supp_10e20[-pos,]
}

pos <- which(seqs_refseqs_df_supp_10e15$cluster_name == "Cluster_16296205" & seqs_refseqs_df_supp_10e15$nucl_acid == "DNA")
if (length(pos) > 0){
  seqs_refseqs_df_supp_10e15 <- seqs_refseqs_df_supp_10e15[-pos,]
}

#################################################################################################

# Figure S4a - mean refseqs vs mean seqs: non-phage + Unknown
ps4a <- ggplot(seqs_refseqs_df_supp_10e20[seqs_refseqs_df_supp_10e20$type == "non-phage_unknown",], aes(x = branch_length_type, y = value)) +
  geom_boxplot(aes(fill = nucl_acid)) + # Fill by branch length type
  scale_fill_manual(values = c(colour_RNA, colour_DNA)) +
  facet_grid(. ~ nucl_acid) +
  # stat_boxplot(geom = "errorbar") +
  # labs(title = paste0("All measures (", evalue, ")"), x = "", y = "sub/site") +
  labs(title = bquote("Non-phage + Unknown"~(10^-20)), x = "", y = "sub/site", tag = "A") +
  ylim(c(0,2)) +
  theme_bw() +
  theme(axis.ticks.x = element_blank(),
        plot.title = element_text(hjust = 0.5, size = 13),
        text = element_text(size = 10.5),
        plot.tag = element_text(size = 15, face = "bold"))
ps4a
# ggsave(paste0("figures/", evalue, "/", nucl_acid, "_seqs_refseqs_", evalue, "_trees.pdf_supp_10e20"), plot = ps4, width = 13)

# Get stats
stats_df_supp_10e20 <- seqs_refseqs_df_supp_10e20[seqs_refseqs_df_supp_10e20$type == "non-phage_unknown",]
stats_df_supp_10e20$variable <- paste0(stats_df_supp_10e20$branch_length_type, "_", stats_df_supp_10e20$nucl_acid)
sink(paste0("non-phage_unknown_10e-20_seqs_refseqs_dunntest.txt"))
dunn.test(stats_df_supp_10e20$value, stats_df_supp_10e20$variable, method = "bh", altp = TRUE, list = TRUE)
sink()
rm(stats_df_supp_10e20) # Clean space

#################################################

# Figure S4b - mean refseqs vs mean seqs: phage + Unknown
ps4b <- ggplot(seqs_refseqs_df_supp_10e20[seqs_refseqs_df_supp_10e20$type == "phage_unknown",], aes(x = branch_length_type, y = value)) +
  geom_boxplot(aes(fill = nucl_acid)) + # Fill by branch length type
  scale_fill_manual(values = c(colour_RNA, colour_DNA)) +
  facet_grid(. ~ nucl_acid) +
  # stat_boxplot(geom = "errorbar") +
  # labs(title = paste0("All measures (", evalue, ")"), x = "", y = "sub/site") +
  labs(title = bquote("Phage + Unknown"~(10^-20)), x = "", y = "sub/site", tag = "B") +
  ylim(c(0,2)) +
  theme_bw() +
  theme(axis.ticks.x = element_blank(),
        plot.title = element_text(hjust = 0.5, size = 13),
        text = element_text(size = 10.5),
        plot.tag = element_text(size = 15, face = "bold"))
ps4b
# ggsave(paste0("figures/", evalue, "/", nucl_acid, "_seqs_refseqs_", evalue, "_trees.pdf_supp_10e20"), plot = ps4, width = 13)

# Get stats
stats_df_supp_10e20 <- seqs_refseqs_df_supp_10e20[seqs_refseqs_df_supp_10e20$type == "phage_unknown",]
stats_df_supp_10e20$variable <- paste0(stats_df_supp_10e20$branch_length_type, "_", stats_df_supp_10e20$nucl_acid)
sink(paste0("phage_unknown_10e-20_seqs_refseqs_dunntest.txt"))
dunn.test(stats_df_supp_10e20$value, stats_df_supp_10e20$variable, method = "bh", altp = TRUE, list = TRUE)
sink()
rm(stats_df_supp_10e20) # Clean space

#################################################

# Figure S4c - mean refseqs vs mean seqs: non-phage + Unknown
ps4c <- ggplot(seqs_refseqs_df_supp_10e15[seqs_refseqs_df_supp_10e15$type == "non-phage_unknown",], aes(x = branch_length_type, y = value)) +
  geom_boxplot(aes(fill = nucl_acid)) + # Fill by branch length type
  scale_fill_manual(values = c(colour_RNA, colour_DNA)) +
  facet_grid(. ~ nucl_acid) +
  # stat_boxplot(geom = "errorbar") +
  # labs(title = paste0("All measures (", evalue, ")"), x = "", y = "sub/site") +
  labs(title = bquote("Non-phage + Unknown"~(10^-15)), x = "", y = "sub/site", tag = "C") +
  ylim(c(0,2)) +
  theme_bw() +
  theme(axis.ticks.x = element_blank(),
        plot.title = element_text(hjust = 0.5, size = 13),
        text = element_text(size = 10.5),
        plot.tag = element_text(size = 15, face = "bold"))
ps4c
# ggsave(paste0("figures/", evalue, "/", nucl_acid, "_seqs_refseqs_", evalue, "_trees.pdf_supp_10e15"), plot = ps4, width = 13)

# Get stats
stats_df_supp_10e15 <- seqs_refseqs_df_supp_10e15[seqs_refseqs_df_supp_10e15$type == "non-phage_unknown",]
stats_df_supp_10e15$variable <- paste0(stats_df_supp_10e15$branch_length_type, "_", stats_df_supp_10e15$nucl_acid)
sink(paste0("non-phage_unknown_10e-15_seqs_refseqs_dunntest.txt"))
dunn.test(stats_df_supp_10e15$value, stats_df_supp_10e15$variable, method = "bh", altp = TRUE, list = TRUE)
sink()
rm(stats_df_supp_10e15) # Clean space

#################################################

# Figure S4d - mean refseqs vs mean seqs: phage + Unknown
ps4d <- ggplot(seqs_refseqs_df_supp_10e15[seqs_refseqs_df_supp_10e15$type == "phage_unknown",], aes(x = branch_length_type, y = value)) +
  geom_boxplot(aes(fill = nucl_acid)) + # Fill by branch length type
  scale_fill_manual(values = c(colour_RNA, colour_DNA)) +
  facet_grid(. ~ nucl_acid) +
  # stat_boxplot(geom = "errorbar") +
  # labs(title = paste0("All measures (", evalue, ")"), x = "", y = "sub/site") +
  labs(title = bquote("Phage + Unknown"~(10^-15)), x = "", y = "sub/site", tag = "D") +
  ylim(c(0,2)) +
  theme_bw() +
  theme(axis.ticks.x = element_blank(),
        plot.title = element_text(hjust = 0.5, size = 13),
        text = element_text(size = 10.5),
        plot.tag = element_text(size = 15, face = "bold"))
ps4d
# ggsave(paste0("figures/", evalue, "/", nucl_acid, "_seqs_refseqs_", evalue, "_trees.pdf_supp_10e15"), plot = ps4, width = 13)

# Get stats
stats_df_supp_10e15 <- seqs_refseqs_df_supp_10e15[seqs_refseqs_df_supp_10e15$type == "phage_unknown",]
stats_df_supp_10e15$variable <- paste0(stats_df_supp_10e15$branch_length_type, "_", stats_df_supp_10e15$nucl_acid)
sink(paste0("phage_unknown_10e-15_seqs_refseqs_dunntest.txt"))
dunn.test(stats_df_supp_10e15$value, stats_df_supp_10e15$variable, method = "bh", altp = TRUE, list = TRUE)
sink()
rm(stats_df_supp_10e15) # Clean space

#################################################

# Combine panels
grid.arrange(ps4a, ps4b, ps4c, ps4d, nrow = 2, ncol = 2)
ggsave(paste0(today, "_seqs_refseqs_supp.pdf"),
       plot = grid.arrange(ps4a, ps4b, ps4c, ps4d, nrow = 2, ncol = 2),
       width = 13.5, height = 8)

#################################################################################################
#################################################################################################

# # Report values
# # First, refseqs vs seqs mean branch lengths
# # non-phage
# tmp1 <- seqs_refseqs_df_supp_10e20[seqs_refseqs_df_supp_10e20$type == "non-phage",]
# for (i in levels(tmp1$nucl_acid)){
#   for (j in levels(tmp1$branch_length_type)){
#     tmp <- tmp1[tmp1$nucl_acid == i & tmp1$branch_length_type == j,]
#     print(paste0(i, " - ", j, ": ", median(na.omit(tmp$value))))
#   }
# }
# 
# # phage
# tmps4 <- seqs_refseqs_df_supp_10e20[seqs_refseqs_df_supp_10e20$type == "phage",]
# for (i in levels(tmps4$nucl_acid)){
#   for (j in levels(tmps4$branch_length_type)){
#     tmp <- tmps4[tmps4$nucl_acid == i & tmps4$branch_length_type == j,]
#     print(paste0(i, " - ", j, ": ", median(na.omit(tmp$value))))
#   }
# }
# 
# # unknown
# tmp3 <- seqs_refseqs_df_supp_10e20[seqs_refseqs_df_supp_10e20$type == "unknown",]
# for (i in levels(tmp3$nucl_acid)){
#   for (j in levels(tmp3$branch_length_type)){
#     tmp <- tmp3[tmp3$nucl_acid == i & tmp3$branch_length_type == j,]
#     print(paste0(i, " - ", j, ": ", median(na.omit(tmp$value))))
#   }
# }

#################################################################################################
#################################################################################################

q(save = "no")

#################################################################################################
#################################################################################################
#################################################################################################
