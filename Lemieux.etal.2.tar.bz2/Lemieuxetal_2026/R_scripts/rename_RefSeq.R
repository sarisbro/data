
#################################################################################################
#################################################################################################
#################################################################################################

# Audrée Lemieux
# Updated on April 17, 2026

# Renames the reference sequences in the CoPHSe by their full names, including accession
# numbers, and splits CoPHSe by "phage" and "non-phage"

#################################################################################################

                                    #####################
                                    # Declare functions #
                                    #####################

# Function 1
check_ViralZone <- function(var, df, phage_lines, non_phages_lines){
  # (str, df, str, str) -> df
  #
  # Input:
  #   - var: variable of interest (e.g., all families, all orders, etc.)
  #   - df: df to modify
  #   - phage_lines <- ViralZone "phage" lines extracted
  #   - non_phage_lines <- ViralZone "non-phage" lines extracted
  #
  # Checks ViralZone whether the specified variable is classified as a "phage" virus
  # or anything else ("non-phage")

  for (i in 1:length(var)){
    if (length(grep(var[i], phage_lines)) > 0){
      df$type <- gsub(var[i], "phage", df$type)
    }else{
      if (length(grep(var[i], non_phage_lines)) > 0){
        df$type <- gsub(var[i], "non-phage", df$type)
      }else{
        print(paste0("Not found in ViralZone DB: ", var[i], " (i = ", i, ")"))
      }
    }
  }
  return(df)
}

# Function 2
identify_tree_type <- function(database, refseq_names){
  # (str) -> str
  #
  # Input:
  #   - vector_type: str vector containing all "types" of reference sequences in the tree
  #
  # Identify which "type" of tree it is
  
  tmp_type <- NULL
  for (l in refseq_names){
    tmp_type <- c(tmp_type, as.character(database[l, 3]))
  }
  
  tmp_df <- as.data.frame(cbind(
    query_name = c(
      "IMGVR_UViG_3300050490_000012|3300050490|nmdc",
      "IMGVR_UViG_3300050493_000069|3300050493|nmdc",
      "IMGVR_UViG_3300050496_000070|3300050496|nmdc",
      "IMGVR_UViG_3300050496_000023|3300050496|nmdc",
      "IMGVR_UViG_3300050496_000087|3300050496|nmdc",
      "IMGVR_UViG_3300050496_000130|3300050496|nmdc",
      "IMGVR_UViG_3300050496_000001|3300050496|nmdc",
      "IMGVR_UViG_3300050500_000546|3300050500|nmdc",
      "IMGVR_UViG_3300050500_000417|3300050500|nmdc",
      "IMGVR_UViG_3300050501_000471|3300050501|nmdc",
      "IMGVR_UViG_3300050505_000434|3300050505|nmdc",
      "IMGVR_UViG_3300050505_000093|3300050505|nmdc",
      "IMGVR_UViG_3300050506_000004|3300050506|nmdc",
      "IMGVR_UViG_3300050508_000480|3300050508|nmdc",
      "IMGVR_UViG_3300050509_000529|3300050509|nmdc",
      "IMGVR_UViG_3300050509_000516|3300050509|nmdc",
      "IMGVR_UViG_3300050510_000326|3300050510|nmdc",
      "IMGVR_UViG_3300050512_000032|3300050512|nmdc",
      "IMGVR_UViG_3300050513_000020|3300050513|nmdc",
      "IMGVR_UViG_3300050514_000006|3300050514|nmdc"
    ),
    type = c(
      "non-phage",
      rep("phage", 19)
    )
  ))
  
  # Some types are "NA"
  pos <- which(is.na(tmp_type))
  if (length(pos) > 0){
    for (k in pos){
      if (!is.na(refseq_names[k])){
        pos2 <- which(str_escape(tmp_df$query_name) == str_escape(refseq_names[k]))
        if (length(pos2) > 0){
          tmp_type[k] <- tmp_df$type[pos2]
        }else{
          tmp_type[k] <- "Unknown"
        }
      }
      # pos2 <- grep(str_escape(refseq_names[k]), database$query_name)
      # tmp2 <- database$type[pos2]
      # if (length(unique(tmp2)) == 1){ # Same type for everyone, good to go
      #   tmp_type[k] <- unique(tmp2)
      # }
    }
  }
  tmp <- unique(tmp_type)
  
  # If there are still NAs after that
  pos_na <- which(is.na(tmp))
  if (length(pos_na) > 0){
    tmp[pos_na] <- "NA"
  }
  return(tmp)
}

#################################################################################################

# Load libraries
library(seqinr)
library(ape)
library(data.table)
library(RCurl)
library(AMR)
library(stringr)

# To modify
viraldb_file <- "/home/username/scratch/ete2021_V2/4_cophse/viral_clusters/all_viral.faa"
IMGVR_TSVfile <- "/home/username/scratch/dbs/viral_prot/IMGVR_all_Sequence_information-high_confidence.tsv"

#################################################################################################

directory <- getwd()
nucl <- strsplit(directory, "/")[[1]][length(strsplit(directory, "/")[[1]])]

# Get all the "short" (accession) and long (full RefSeq names) names for NCBI seqs
seq_names <- system(paste0("grep \">\" ", viraldb_file), intern = TRUE)
seq_names <- gsub(">", "", seq_names)
refseq_names <- seq_names[setdiff(1:length(seq_names), grep("IMGVR", seq_names))] # NCBI seqs (RefSeq/GenBank)
IMGVR_names <- seq_names[grep("IMGVR", seq_names)] # IMG_VR
IMGVR_names_tmp <- sapply(strsplit(IMGVR_names, "\\|"), "[", 1)
rm(seq_names) # Clean space
save.image("260210_rename_seqs_viraltax.RData")

# Read the IMGVR db and lookup table
IMGVR_db <- read.table(IMGVR_TSVfile, sep = "\t", fill = TRUE)
colnames(IMGVR_db) <- IMGVR_db[1,]
IMGVR_db <- IMGVR_db[-1,]

# Parse taxonomy
coln <- which(colnames(IMGVR_db) == "Taxonomic classification")
tmp <- unique(IMGVR_db[,coln])
# tmp <- tmp[-which(tmp == ";;;;;;;")]
IMGVR_taxonomy <- gsub("r__|k__|p__|c__|o__|f__|g__|s__", "", tmp)
IMGVR_taxonomy <- read.table(textConnection(IMGVR_taxonomy), sep = ";") # Convert to df
colnames(IMGVR_taxonomy) <- c("realm", "kingdom", "phylum", "class", "order", "family", "genus", "species")
IMGVR_taxonomy <- cbind(taxonomy = tmp, IMGVR_taxonomy)

# Further look at the taxonomy of viruses
# Look at ViralZone
non_phage_lines <- NULL
phage_lines <- NULL
non_phage_URLs <- c("https://viralzone.expasy.org/656", # Human viruses
                    "https://viralzone.expasy.org/655", # Vertebrate viruses
                    "https://viralzone.expasy.org/654", # Invertebrate viruses
                    "https://viralzone.expasy.org/231", # Plant viruses
                    "https://viralzone.expasy.org/8337", # Fungi viruses
                    "https://viralzone.expasy.org/658", # Eukaryotic microorganism viruses
                    "https://viralzone.expasy.org/663") # Archaea viruses
phage_URL <- "https://viralzone.expasy.org/256" # Bacteria viruses

for (i in c(non_phage_URLs, phage_URL)){
  tmp <- getURL(i)
  tmp <- strsplit(tmp, "\n")[[1]]
  if (i != phage_URL){
    non_phage_lines <- c(non_phage_lines, tmp)
  }else{
    phage_lines <- tmp
  }
}
rm(non_phage_URLs, phage_URL, i, tmp) # Clean space

# If the family is classified as bacterial viruses by ViralZone = phage
# If not = check that it is in the non-phage websites
# If not, flag
families <- unique(IMGVR_taxonomy$family)
families <- families[-which(families == "")]
IMGVR_taxonomy$type <- IMGVR_taxonomy$family
IMGVR_taxonomy <- check_ViralZone(families, IMGVR_taxonomy, phage_lines, non_phage_lines)

# Manually complete (sometimes due to typos or variations in spelling)
IMGVR_taxonomy$type <- gsub("Totiviridae", "non-phage", IMGVR_taxonomy$type)
IMGVR_taxonomy$type <- gsub("Betaflexiviridae", "non-phage", IMGVR_taxonomy$type)
IMGVR_taxonomy$type <- gsub("Permutotetraviridae", "non-phage", IMGVR_taxonomy$type)
IMGVR_taxonomy$type <- gsub("Rountreeviridae", "phage", IMGVR_taxonomy$type)
IMGVR_taxonomy$type <- gsub("Smacoviridae", "Unknown", IMGVR_taxonomy$type) # Unknown hosts
IMGVR_taxonomy$type <- gsub("Medioniviridae", "non-phage", IMGVR_taxonomy$type)
IMGVR_taxonomy$type <- gsub("Malacoherpesviridae", "non-phage", IMGVR_taxonomy$type)
IMGVR_taxonomy$type <- gsub("Polydnaviriformidae", "non-phage", IMGVR_taxonomy$type)
IMGVR_taxonomy$type <- gsub("Mononiviridae", "non-phage", IMGVR_taxonomy$type)
IMGVR_taxonomy$type <- gsub("Leishbuviridae", "non-phage", IMGVR_taxonomy$type)
IMGVR_taxonomy$type <- gsub("Matshushitaviridae", "phage", IMGVR_taxonomy$type)
rm(families) # Clean space

# What about those who don't have a family? Try with different taxonomic ranks
# Genus
pos <- which(IMGVR_taxonomy$type == "")
genus <- unique(IMGVR_taxonomy$genus[pos])
genus <- genus[-which(genus == "")]
IMGVR_taxonomy$type[pos] <- IMGVR_taxonomy$genus[pos]
IMGVR_taxonomy[pos,] <- check_ViralZone(genus, IMGVR_taxonomy[pos,], phage_lines, non_phage_lines)
IMGVR_taxonomy$type <- gsub("Chimpavirus", "phage", IMGVR_taxonomy$type)
IMGVR_taxonomy$type <- gsub("Winunavirus", "Unknown", IMGVR_taxonomy$type)
IMGVR_taxonomy$type <- gsub("Tetipavirus", "Unknown", IMGVR_taxonomy$type)
IMGVR_taxonomy$type <- gsub("Meihzavirus", "Unknown", IMGVR_taxonomy$type)
IMGVR_taxonomy$type <- gsub("Incheonvrus", "phage", IMGVR_taxonomy$type)
IMGVR_taxonomy$type <- gsub("Samistivirus", "phage", IMGVR_taxonomy$type)
IMGVR_taxonomy$type <- gsub("Karimacvirus", "phage", IMGVR_taxonomy$type)
rm(genus) # Clean space

# Manually do the rest based on ViralZone/literature
# Non-phage
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$phylum == "Artverviricota")] <- "non-phage"
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$phylum == "Cossaviricota")] <- "non-phage"
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$phylum == "Cressdnaviricota")] <- "non-phage"
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$phylum == "Duplornaviricota" & IMGVR_taxonomy$class != "" & IMGVR_taxonomy$class != "Vidaverviricetes")] <- "non-phage"
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$phylum == "Kitrinoviricota")] <- "non-phage"
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$phylum == "Lenarviricota" & IMGVR_taxonomy$class != "" & IMGVR_taxonomy$class != "Leviviricetes")] <- "non-phage"
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$phylum == "Negarnaviricota")] <- "non-phage"
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$phylum == "Nucleocytoviricota")] <- "non-phage"
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$phylum == "Peploviricota")] <- "non-phage"
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$phylum == "Pisuviricota" & IMGVR_taxonomy$class != "" & IMGVR_taxonomy$class != "Duplopiviricetes")] <- "non-phage"
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$phylum == "Preplasmiviricota" & IMGVR_taxonomy$order == "Rowavirales")] <- "non-phage"
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$phylum == "Preplasmiviricota" & IMGVR_taxonomy$order == "Orthopolintovirales")] <- "non-phage"
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$phylum == "Preplasmiviricota" & IMGVR_taxonomy$order == "Priklausovirales")] <- "non-phage"
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$phylum == "Saleviricota")] <- "non-phage"
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$phylum == "Taleaviricota")] <- "non-phage"
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$phylum == "Uroviricota" & IMGVR_taxonomy$order != "" & IMGVR_taxonomy$order != "Crassvirales")] <- "non-phage"
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$order == "Lefavirales")] <- "non-phage"
# Phage
pos <- which(IMGVR_taxonomy$type == "")
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$class == "Leviviricetes")] <- "phage"
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$phylum == "Duplornaviricota" & IMGVR_taxonomy$class == "Vidaverviricetes")] <- "phage"
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$phylum == "Hofneiviricota")] <- "phage"
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$phylum == "Lenarviricota" & IMGVR_taxonomy$class == "Leviviricetes")] <- "phage"
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$phylum == "Phixviricota")] <- "phage"
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$phylum == "Preplasmiviricota" & IMGVR_taxonomy$order == "Kalamavirales")] <- "phage"
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$phylum == "Preplasmiviricota" & IMGVR_taxonomy$order == "Vinavirales")] <- "phage"
IMGVR_taxonomy$type[which(IMGVR_taxonomy$type == "" & IMGVR_taxonomy$phylum == "Uroviricota" & IMGVR_taxonomy$order == "Crassvirales")] <- "phage"
# Rest: Unknown
pos <- which(IMGVR_taxonomy$type == "")
IMGVR_taxonomy$type[pos] <- "Unknown"

# Put back in IMGVR_db
IMGVR_db$taxonomy <- IMGVR_db[,coln]
colnames(IMGVR_taxonomy)[length(colnames(IMGVR_taxonomy))] <- "tax_type"
IMGVR_db <- merge(
  IMGVR_db,
  IMGVR_taxonomy[,c("taxonomy", "tax_type")],
  by = "taxonomy",
  all.x = TRUE,
  sort= FALSE
)

##################################################

# Clean seqs from GenBank and RefSeq
ncbi_accession <- sapply(strsplit(refseq_names, " "), "[", 1) # Only keep the accession
# ncbi_accession <- sapply(strsplit(ncbi_accession, "\\."), "[", 1) # Remove the version (number after the ".")
virus_sp <- sapply(strsplit(refseq_names, "\\["), "[", 2) # Get the viral species names
virus_sp <- gsub("\\]", "", virus_sp)
GBRS_db <- as.data.frame(cbind(ncbi_accession = ncbi_accession, virus_sp = virus_sp))

# Remove most virus sp first
pos <- grep("Phage|phage", GBRS_db$virus_sp)
pos_SARS2 <- grep("Severe acute respiratory syndrome coronavirus 2", virus_sp)
pos_influenza <- grep("Influenza [ABCD].*virus", virus_sp)
pos_human <- grep("[Hh]uman", virus_sp)
pos_norovirus <- grep("[Nn]orovirus", virus_sp)
pos_sapovirus <- grep("[Ss]apovirus", virus_sp)
pos_rotavirus <- grep("[RR]otavirus", virus_sp)
pos_coronavirus <- grep("[Cc]oronavirus", virus_sp)
GBRS_db_toassess <- GBRS_db[-unique(c(pos, pos_SARS2, pos_influenza, pos_human, pos_norovirus, pos_sapovirus, pos_rotavirus, pos_norovirus)),]

phage_sp <- unique(GBRS_db$virus_sp[pos])

# Verify which ones are archaeal viruses and which are bacterial viruses
GBRS_db$type <- GBRS_db$virus_sp
# Non-phage
GBRS_db$type[setdiff(1:length(GBRS_db$type), pos)] <- "non-phage"
GBRS_db$type[pos[grep("[Vv]irophage", GBRS_db$type[pos])]] <- "non-phage"
# Get list of microorganisms from AMR package
data("microorganisms")
bacteria_list <- microorganisms[microorganisms$kingdom == "Bacteria",]
bacteria_genus <- unique(bacteria_list$genus)
bacteria_genus <- bacteria_genus[-which(bacteria_genus == "" | bacteria_genus == "\\(unknown genus\\))")]
GBRS_db$tmp <- GBRS_db$type
GBRS_db$tmp[pos] <- sapply(strsplit(GBRS_db$tmp[pos], " "), "[", 1)
rm(microorganisms, bacteria_list) # Clean space

tmp_unique <- unique(GBRS_db$tmp[pos])
tmp_unique <- tmp_unique[-which(tmp_unique == "non-phage")]
to_flag <- NULL
for (i in 1:length(tmp_unique)){
  # If first word of viral_sp == genus of bacteria, it's a phage
  # Otherwise, flag it
  if (tmp_unique[i] %in% bacteria_genus){
    pos2 <- which(GBRS_db$tmp == tmp_unique[i])
    GBRS_db$type[pos2] <- "phage"
  }else{
    to_flag <- c(to_flag, tmp_unique[i])
  }
}
rm(pos2) # Clean space

# Take a look at those flagged and manually assign based on ViralZone/literature
# Phage
GBRS_db$type[GBRS_db$tmp == "ssRNA"] <- "phage"
GBRS_db$type[GBRS_db$tmp == "Satellite"] <- "phage"
GBRS_db$type[GBRS_db$tmp == "Enterobacteria"] <- "phage"
GBRS_db$type[GBRS_db$tmp == "uncultured"] <- "phage"
GBRS_db$type[GBRS_db$tmp == "Uncultured"] <- "phage"
GBRS_db$type[GBRS_db$tmp == "Phage"] <- "phage"
GBRS_db$type[GBRS_db$tmp == "Bacteriophage"] <- "phage"
GBRS_db$type[GBRS_db$tmp == "Stx2-converting"] <- "phage"
GBRS_db$type[GBRS_db$tmp == "Cyanophage"] <- "phage"
GBRS_db$type[GBRS_db$tmp == "Deep-sea"] <- "phage"
GBRS_db$type[GBRS_db$tmp == "Halocynthia"] <- "phage"
GBRS_db$type[GBRS_db$tmp == "Idiomarinaceae"] <- "phage"
GBRS_db$type[GBRS_db$tmp == "Verrucomicrobia"] <- "phage"
GBRS_db$type[GBRS_db$tmp == "Stx"] <- "phage"
GBRS_db$type[GBRS_db$tmp == "Stx1"] <- "phage"
GBRS_db$type[GBRS_db$tmp == "Alphaproteobacteria"] <- "phage"
GBRS_db$type[GBRS_db$tmp == "Podophage"] <- "phage"
GBRS_db$type[GBRS_db$tmp == "Dompiswa"] <- "phage"
GBRS_db$type[GBRS_db$tmp == "crAssphage"] <- "phage"
# Non-phage
GBRS_db$type[GBRS_db$tmp == "Aureococcus"] <- "non-phage"
GBRS_db$type[GBRS_db$tmp == "Dragonfly-associated"] <- "non-phage"
GBRS_db$type[GBRS_db$tmp == "Chimpanzee"] <- "non-phage"
GBRS_db$type[GBRS_db$tmp == "Halorubrum"] <- "non-phage"
GBRS_db$type[GBRS_db$tmp == "Methanobacterium"] <- "non-phage"
GBRS_db$type[GBRS_db$tmp == "Natrialba"] <- "non-phage"
GBRS_db$type[GBRS_db$tmp == "Halobacterium"] <- "non-phage"
GBRS_db$type[GBRS_db$tmp == "Methanothermobacter"] <- "non-phage"
GBRS_db$type[GBRS_db$tmp == "Sulfolobus"] <- "non-phage"
GBRS_db$type[GBRS_db$tmp == "Halophage"] <- "non-phage"
rm(bacteria_genus, coln, i, phage_sp, pos, tmp_unique, to_flag, virus_sp) # Clean space

##################################################

# Create combined data frame - start with IMG_VR
viral_db <- as.data.frame(cbind(query_name = IMGVR_names))
viral_db$alt_name <- IMGVR_names_tmp
viral_db$type <- viral_db$alt_name

pos_phage <- which(viral_db$alt_name %in% IMGVR_db$UVIG[which(IMGVR_db$tax_type == "phage")])
pos_nonphage <- which(viral_db$alt_name %in% IMGVR_db$UVIG[which(IMGVR_db$tax_type == "non-phage")])
pos_unknown <- which(viral_db$alt_name %in% IMGVR_db$UVIG[which(IMGVR_db$tax_type == "Unknown")])
viral_db$type[pos_phage] <- "phage"
viral_db$type[pos_nonphage] <- "non-phage"
viral_db$type[pos_unknown] <- "Unknown"
rm(pos_phage, pos_nonphage, pos_unknown) # Clean space

# Add RefSeq/NCBI
viral_db <- rbind(viral_db,
                  cbind(query_name = GBRS_db$ncbi_accession, alt_name = refseq_names, type = GBRS_db$type))
save.image("260210_rename_seqs_viraltax.RData")

# Instant lookup with the data.table package
viral_db_dt <- as.data.table(viral_db)
setkey(viral_db_dt, query_name) # builds index (only once)

# Clean space
rm(IMGVR_names, IMGVR_names_tmp, ncbi_accession, phage_lines, non_phage_lines)
save.image("260210_rename_seqs_viraltax.RData")

##################################################

# A bit of admin
evalues <- c(10^-2, 10^-5, 10^-10, 10^-15, 10^-20)
df_list <- list()
for (i in evalues[c(4,5)]){
  tree_df <- NULL
  tmp_lst <- list()

  tree_dir <- paste0("clusters_2/", i, "/hits_trees_retree_gamma")
  tree_lst <- list.files(tree_dir)
  
  # Tidy up names
  for (j in 1:length(tree_lst)){
    print(paste0("--- Now doing ", j, " out of ", length(tree_lst), " ---"))
    tmp_tree <- read.tree(paste0(tree_dir, "/", tree_lst[j]))
    tree_names <- tmp_tree$tip.label
    ref_names <- tree_names[setdiff(1:length(tree_names), grep("gene_", tree_names))]
    
    if (length(ref_names) > 0){ # If tree is NOT empty
      pos_ncbi <- setdiff(1:length(ref_names), grep("IMGVR_", ref_names))
      
      # What type of tree?
      tmp <- identify_tree_type(viral_db_dt, ref_names)
      tmp_lst[[j]] <- cbind(name = gsub(".trees", "", tree_lst[j]),
                       type = paste0(sort(tmp), collapse = ", "),
                       ngenes = length(grep("gene_", tree_names)),
                       nrefseqs = length(ref_names),
                       contains_ncbi = ifelse(length(pos_ncbi) > 0, "Yes", "No"))
      
    }else{
      print(paste0("trimAL returns an empty tree for ", tree_lst[j]))
    }
  }
  tree_df <- as.data.frame(do.call(rbind, tmp_lst))
  
  # Reassess seqs whose type was "NA" - part of the seq name is missing from the tree's tip label
  pos_na <- grep("NA", tree_df$type)
  tree_dir <- paste0("clusters_2/", i, "/hits_faa_retree") # Get the names from the fasta file instead
  tree_lst <- list.files(tree_dir)
  if (length(pos_na) > 0){
    for (j in pos_na){
      pos <- grep(tree_df$name[j], tree_lst)
      tree_names <- system(paste0("grep \'>\' ", tree_dir, "/", tree_lst[pos]), intern = TRUE)
      tree_names <- gsub(">", "", tree_names)
      ref_names <- tree_names[setdiff(1:length(tree_names), grep("gene_", tree_names))]
      
      if (length(ref_names) > 0){ # If tree is NOT empty
        pos_ncbi <- setdiff(1:length(ref_names), grep("IMGVR_", ref_names))
        
        # What type of tree?
        tmp <- identify_tree_type(viral_db_dt, ref_names)
        tmp_lst[[j]][,2] <- paste0(sort(tmp), collapse = ", ")
        
      }else{
        print(paste0("trimAL returns an empty tree for ", tree_lst[pos]))
      }
    }
  }
  tree_df <- NULL # Just to make sure
  tree_df <- as.data.frame(do.call(rbind, tmp_lst))
  df_list[[as.character(i)]] <- tree_df
}

# rm(GBRS_db, i, IMGVR_taxonomy, j, pos, pos_na, pos_ncbi, ref_names, refseq_names, tmp, tmp_lst, tmp_tree, viral_db) # Clean space
save.image("260210_RNA_rename_seqs_viraltax.RData")

##################################################

# Rename tree files
for (i in evalues[c(4,5)]){
  print(paste0("--- Now doing evalue ", i, " ---"))
  tmp <- df_list[[as.character(i)]]
  tree_dir <- paste0("clusters_2/", i, "/hits_trees_retree_gamma")
  renamed_tree_dir <- paste0("clusters_2/", i, "/hits_trees_fullNames")
  system(paste0("mkdir -p ", renamed_tree_dir))
  
  # Add prefix to tree files
  tmp$cat_type <- tmp$type
  tmp$cat_type <- gsub("^Unknown$", "unknown", tmp$cat_type)
  tmp$cat_type <- gsub("^non-phage, phage$", "non-phage_phage", tmp$cat_type)
  tmp$cat_type <- gsub("non-phage, phage, Unknown", "non-phage_phage_unknown", tmp$cat_type)
  tmp$cat_type <- gsub("^non-phage, Unknown$", "non-phage_unknown", tmp$cat_type)
  tmp$cat_type <- gsub("^phage, Unknown$", "phage_unknown", tmp$cat_type)
  
  types <- unique(tmp$cat_type)
  types <- types[-which(types == "non-phage_phage" | types == "non-phage_phage_unknown")] # Remove non-phage + phage (+ unknown)
  
  for (j in types){
    print(paste0("--- Now doing type: ", j, " ---"))
    dir <- paste0(renamed_tree_dir, "/", j)
    system(paste0("mkdir -p ", dir))
    pos <- which(tmp$cat_type == j)
    
    if (length(pos) > 0){
      for (k in 1:length(pos)){
        print(paste0("--- Now doing ", k, " out of ", length(pos), " ---"))
        system(paste0("cp ", tree_dir, "/", tmp$name[pos[k]], ".trees ", dir, "/", j, "_", tmp$name[pos[k]], ".trees"))
      }
    }
  }
}

#################################################################################################
#################################################################################################

q(save = "no")

#################################################################################################
#################################################################################################
#################################################################################################
