
#################################################################################################
#################################################################################################
#################################################################################################

# Audrée Lemieux
# Updated on June 24, 2025

#################################################################################################

                                      #####################
                                      # Declare functions #
                                      #####################

# Function 1
remove_rows <- function(rows, df){
  # (int, df) -> df
  #
  # Input:
  #   - rows: row n to remove
  #   - df: df to remove rows from
  #
  # Function to remove rows
  
  if (length(rows) > 0){
    df <- df[-rows,]
  }
  return(df)
}

#################################################################################################

# To modify
dir <- "/home/username/scratch/ete2021_V2/3_viral_contigs"

#################################################################################################
#################################################################################################

# Read CheckV output
nuc <- strsplit(getwd(), "\\/")[[1]][length(strsplit(getwd(), "\\/")[[1]])]
tmp_dir <- paste0(dir, "/", nuc, "/", nuc, "_CheckV_output")
output <- read.table(paste0(tmp_dir, "/quality_summary.tsv"), sep = "\t", header = T)

# Only keep seqs with:
# >= 1 viral gene
# Not proviral
# High, medium, or low quality
# Unflagged seqs
output <- remove_rows(which(output$viral_genes == 0), output)
output <- remove_rows(which(output$provirus == "Yes"), output)
output <- remove_rows(which(output$checkv_quality == "Not-determined"), output)
output <- remove_rows(which(output$warnings != ""), output)

seqs_to_keep <- output$contig_id

# Remove other seqs
lines <- readLines(paste0(tmp_dir, "/viruses.fna"))
pos <- grep("^>", lines)
pos_to_keep <- NULL
for (i in pos){
  if (gsub(">", "", lines[i]) %in% seqs_to_keep){
    pos_to_keep <- c(pos_to_keep, i)
  }
}
pos2 <- sort(c(pos_to_keep, pos_to_keep + 1))
writeLines(lines[pos2], paste0(dir, "/", nuc, "/", nuc, "_CheckV_filtered_viruses.fasta"))

#################################################################################################
#################################################################################################

q(save = "no")

#################################################################################################
#################################################################################################
#################################################################################################
