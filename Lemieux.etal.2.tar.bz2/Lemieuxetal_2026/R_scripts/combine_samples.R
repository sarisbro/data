
#################################################################################################
#################################################################################################
#################################################################################################

# Audrée Lemieux
# Updated on April 23, 2025

#################################################################################################

                                    #####################
                                    # Declare functions #
                                    #####################

DNA_or_RNA <- function(replicate){
  # (str) -> str
  #
  # Input:
  #   - replicate: name of the replicate
  #
  # Based on the replicate's name, returns the nucleotic acid (DNA or RNA)
  
  tmp <- strsplit(replicate, "_")[[1]]
  
  if (tmp[2] == "001" | tmp[2] == "002" | tmp[2] == "007" | tmp[2] == "008"){
    return("DNA")
  }else if (tmp[2] == "003" | tmp[2] == "004" | tmp[2] == "005"){
    return("RNA")
  }
}

#################################################################################################

# To modify
contigs_dir <- "/home/username/scratch/ete2021/2_assembly/lazypipe"
viral_contigs_dir <- "/home/username/scratch/ete2021/3_viral_contigs"
cutoff_length <- 300

#################################################################################################
#################################################################################################

nuc <- c("DNA", "RNA")
samples <- c("AS3", "BS3", "RS3", "S3", "S4", "S5", "S1", "S2")

for (i in nuc){
  print(paste0("-- Now doing: ", i, " --"))
  system(paste0("mkdir -p ", viral_contigs_dir, "/", i)) # Create directory
  file.create(paste0(i, "_contigs.fasta")) # Create DNA/RNA contigs file
  system(paste0("mv ", i, "_contigs.fasta ", viral_contigs_dir, "/", i)) # Move the file into its directory
  
  for (j in samples){
    # Get all replicates
    replicates <- list.files(paste0(contigs_dir, "/", j), pattern = "^[A-Z]")
    
    # If it's the right nucleotide acid, append it to the "DNA_contigs.fasta" or "RNA_contigs.fasta" file
    for (k in replicates){
      if (DNA_or_RNA(k) == i){
        print(paste0("-- Now doing: ", k, " --"))
        samp_rep_dir <- paste0(contigs_dir, "/", j, "/", k)
        system(paste0("sed 's/>contig=/>", k, "_contig=/g' ", samp_rep_dir, "/", k, "_contigs.fasta >> ", viral_contigs_dir, "/", i, "/", i, "_contigs.fasta"))
      }
    }
  }
  
  # Only keep contigs >= cutoff length
  lines <- readLines(paste0(viral_contigs_dir, "/", i, "/", i, "_contigs.fasta"))
  contig_names <- lines[grep(">", lines)]
  contig_length <- as.numeric(sapply(strsplit(contig_names, "length="), `[`, 2))
  pos <- which(contig_length < cutoff_length)
  pos2 <- (pos * 2) - 1 # Get the line number
  pos2 <- sort(c(pos2, pos2 + 1)) # To get the names and the sequences
  contig_cutoff <- lines[-pos2] # Remove contigs whose length < cutoff
  writeLines(contig_cutoff, paste0(i, "_", cutoff_length, "_cutoff_contigs.fasta"))
}

#################################################################################################
#################################################################################################

q(save = "no")

#################################################################################################
#################################################################################################
#################################################################################################
